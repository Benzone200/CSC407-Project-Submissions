// PureNest - Interactive Multi-Step Booking Wizard Engine

class BookingWizard {
  constructor() {
    this.currentStep = 1;
    this.totalSteps = 4;

    this.state = {
      serviceId: 'standard',
      serviceName: 'Standard Home Clean',
      basePrice: 89,
      baseDuration: 2.5,
      bedrooms: 2,
      bathrooms: 2,
      sqft: '900-1400',
      addons: [],
      date: this.getTomorrowDateString(),
      timeSlot: 'Morning (8:00 AM - 11:00 AM)',
      frequency: 'onetime',
      frequencyDiscountPct: 0,
      ecoFriendly: true,
      hasPets: false,
      cleanerSupplies: true,
      accessOption: 'home',
      customer: {
        fullName: '',
        email: '',
        phone: '',
        address: '',
        apartment: '',
        city: 'Springfield',
        postalCode: '',
        accessNotes: '',
        specialNotes: ''
      },
      promoCode: '',
      promoDiscount: 0,
      paymentMethod: 'card'
    };

    this.promoCodes = {
      'WELCOME25': { discount: 25, label: '$25 Welcome Discount' },
      'CSC407': { discount: 30, label: '30% CSC407 Academic VIP Credit' },
      'SPARKLE20': { discount: 20, label: '$20 First Booking Promo' },
      'PURESPRING': { discount: 35, label: '$35 Spring Cleaning Bonus' }
    };

    this.init();
  }

  getTomorrowDateString() {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  }

  init() {
    this.renderServicesGrid();
    this.renderAddonsGrid();
    this.setupDateConstraints();
    this.bindEvents();
    this.updateCalculations();
    this.updateStepUI();
  }

  renderServicesGrid() {
    const container = document.getElementById('wizard-services-grid');
    if (!container) return;

    container.innerHTML = SERVICES_DATA.map(s => `
      <div class="service-card cursor-pointer border rounded-2xl p-5 transition-all relative ${
        this.state.serviceId === s.id ? 'border-emerald-600 bg-emerald-50/40 ring-2 ring-emerald-500/20 shadow-md' : 'border-slate-200 hover:border-slate-300 hover:shadow-sm bg-white'
      }" data-service-id="${s.id}">
        ${s.popular ? '<span class="absolute -top-3 right-4 bg-emerald-600 text-white text-xs font-semibold px-3 py-0.5 rounded-full shadow-sm">Most Popular</span>' : ''}
        <div class="flex items-start justify-between mb-3">
          <div class="w-12 h-12 rounded-xl flex items-center justify-center ${this.state.serviceId === s.id ? 'bg-emerald-600 text-white' : 'bg-emerald-100 text-emerald-700'}">
            <i data-lucide="${s.icon}" class="w-6 h-6"></i>
          </div>
          <div class="text-right">
            <span class="text-xs text-slate-500 block">From</span>
            <span class="text-2xl font-bold text-slate-900">$${s.basePrice}</span>
          </div>
        </div>
        <h4 class="font-bold text-slate-900 text-lg mb-1">${s.name}</h4>
        <p class="text-xs text-slate-600 mb-3">${s.tagline}</p>
        <ul class="text-xs text-slate-600 space-y-1 border-t border-slate-100 pt-3">
          ${s.included.slice(0, 3).map(i => `<li class="flex items-center gap-1.5"><i data-lucide="check" class="w-3.5 h-3.5 text-emerald-600 shrink-0"></i><span>${i}</span></li>`).join('')}
        </ul>
      </div>
    `).join('');

    if (window.lucide) window.lucide.createIcons();
  }

  renderAddonsGrid() {
    const container = document.getElementById('wizard-addons-grid');
    if (!container) return;

    container.innerHTML = ADDONS_DATA.map(a => {
      const isSelected = this.state.addons.includes(a.id);
      return `
        <div class="addon-card cursor-pointer border rounded-xl p-4 transition-all flex items-start gap-3 relative ${
          isSelected ? 'border-emerald-600 bg-emerald-50/50 ring-2 ring-emerald-500/20 shadow-sm' : 'border-slate-200 hover:border-slate-300 bg-white'
        }" data-addon-id="${a.id}">
          <div class="w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${isSelected ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'}">
            <i data-lucide="${a.icon}" class="w-5 h-5"></i>
          </div>
          <div class="flex-1 min-w-0">
            <div class="flex items-center justify-between mb-0.5">
              <h5 class="font-semibold text-slate-900 text-sm">${a.name}</h5>
              <span class="font-bold text-emerald-700 text-sm">+$${a.price}</span>
            </div>
            <p class="text-xs text-slate-500 mb-2 leading-relaxed">${a.desc}</p>
            <div class="flex items-center justify-between text-xs">
              <span class="text-slate-400 flex items-center gap-1">
                <i data-lucide="clock" class="w-3 h-3"></i> +${a.duration} hr
              </span>
              <span class="text-xs font-medium px-2 py-0.5 rounded-full ${isSelected ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'}">
                ${isSelected ? 'Added ✓' : 'Add +'}
              </span>
            </div>
          </div>
        </div>
      `;
    }).join('');

    if (window.lucide) window.lucide.createIcons();
  }

  setupDateConstraints() {
    const dateInput = document.getElementById('wizard-date');
    if (dateInput) {
      const tomorrow = this.getTomorrowDateString();
      dateInput.min = tomorrow;
      dateInput.value = this.state.date;

      // Max booking up to 90 days in advance
      const maxDate = new Date();
      maxDate.setDate(maxDate.getDate() + 90);
      dateInput.max = maxDate.toISOString().split('T')[0];
    }
  }

  bindEvents() {
    // Service selection
    const servicesGrid = document.getElementById('wizard-services-grid');
    if (servicesGrid) {
      servicesGrid.addEventListener('click', (e) => {
        const card = e.target.closest('[data-service-id]');
        if (card) {
          const serviceId = card.getAttribute('data-service-id');
          this.selectService(serviceId);
        }
      });
    }

    // Bedrooms counter
    document.getElementById('btn-bedroom-minus')?.addEventListener('click', () => this.adjustBedrooms(-1));
    document.getElementById('btn-bedroom-plus')?.addEventListener('click', () => this.adjustBedrooms(1));

    // Bathrooms counter
    document.getElementById('btn-bathroom-minus')?.addEventListener('click', () => this.adjustBathrooms(-1));
    document.getElementById('btn-bathroom-plus')?.addEventListener('click', () => this.adjustBathrooms(1));

    // Sqft Select
    document.getElementById('wizard-sqft')?.addEventListener('change', (e) => {
      this.state.sqft = e.target.value;
      this.updateCalculations();
    });

    // Addons Grid Click
    const addonsGrid = document.getElementById('wizard-addons-grid');
    if (addonsGrid) {
      addonsGrid.addEventListener('click', (e) => {
        const card = e.target.closest('[data-addon-id]');
        if (card) {
          const addonId = card.getAttribute('data-addon-id');
          this.toggleAddon(addonId);
        }
      });
    }

    // Schedule: Date input
    document.getElementById('wizard-date')?.addEventListener('change', (e) => {
      this.state.date = e.target.value;
      this.updateCalculations();
    });

    // Schedule: Time Slots
    document.querySelectorAll('.time-slot-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.time-slot-btn').forEach(b => {
          b.classList.remove('border-emerald-600', 'bg-emerald-50', 'text-emerald-800', 'ring-2', 'ring-emerald-500/20');
          b.classList.add('border-slate-200', 'bg-white', 'text-slate-700');
        });
        const target = e.currentTarget;
        target.classList.remove('border-slate-200', 'bg-white', 'text-slate-700');
        target.classList.add('border-emerald-600', 'bg-emerald-50', 'text-emerald-800', 'ring-2', 'ring-emerald-500/20');
        this.state.timeSlot = target.getAttribute('data-slot');
        this.updateCalculations();
      });
    });

    // Frequency Selector Cards
    document.querySelectorAll('.frequency-card').forEach(card => {
      card.addEventListener('click', (e) => {
        const target = e.currentTarget;
        document.querySelectorAll('.frequency-card').forEach(c => {
          c.classList.remove('border-emerald-600', 'bg-emerald-50/60', 'ring-2', 'ring-emerald-500/20');
          c.classList.add('border-slate-200', 'bg-white');
        });
        target.classList.remove('border-slate-200', 'bg-white');
        target.classList.add('border-emerald-600', 'bg-emerald-50/60', 'ring-2', 'ring-emerald-500/20');

        const freq = target.getAttribute('data-freq');
        const discountPct = parseFloat(target.getAttribute('data-discount') || 0);
        this.state.frequency = freq;
        this.state.frequencyDiscountPct = discountPct;
        this.updateCalculations();
      });
    });

    // Preferences checkboxes
    document.getElementById('pref-eco')?.addEventListener('change', (e) => {
      this.state.ecoFriendly = e.target.checked;
    });
    document.getElementById('pref-pets')?.addEventListener('change', (e) => {
      this.state.hasPets = e.target.checked;
    });
    document.getElementById('pref-supplies')?.addEventListener('change', (e) => {
      this.state.cleanerSupplies = e.target.checked;
    });

    // Promo Code Application
    document.getElementById('btn-apply-promo')?.addEventListener('click', () => {
      this.applyPromoCode();
    });

    // Step navigation buttons
    document.getElementById('wizard-btn-next')?.addEventListener('click', () => {
      this.handleNextStep();
    });

    document.getElementById('wizard-btn-prev')?.addEventListener('click', () => {
      this.handlePrevStep();
    });

    // Direct Step click via Stepper Bar
    document.querySelectorAll('.stepper-indicator').forEach(stepEl => {
      stepEl.addEventListener('click', (e) => {
        const stepNum = parseInt(e.currentTarget.getAttribute('data-step'));
        if (stepNum < this.currentStep) {
          this.goToStep(stepNum);
        }
      });
    });

    // Payment method selector
    document.querySelectorAll('input[name="payment-method"]').forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.state.paymentMethod = e.target.value;
        const cardDetails = document.getElementById('card-input-details');
        if (cardDetails) {
          cardDetails.style.display = e.target.value === 'card' ? 'block' : 'none';
        }
      });
    });

    // Final Submit Form
    document.getElementById('wizard-submit-booking')?.addEventListener('click', (e) => {
      e.preventDefault();
      this.submitBooking();
    });
  }

  selectService(serviceId) {
    const service = SERVICES_DATA.find(s => s.id === serviceId);
    if (!service) return;

    this.state.serviceId = service.id;
    this.state.serviceName = service.name;
    this.state.basePrice = service.basePrice;
    this.state.baseDuration = service.baseDuration;

    this.renderServicesGrid();
    this.updateCalculations();
  }

  adjustBedrooms(delta) {
    let next = this.state.bedrooms + delta;
    if (next < 1) next = 1;
    if (next > 6) next = 6;
    this.state.bedrooms = next;
    const el = document.getElementById('val-bedrooms');
    if (el) el.textContent = next === 6 ? '6+ Beds' : `${next} ${next === 1 ? 'Bed' : 'Beds'}`;
    this.updateCalculations();
  }

  adjustBathrooms(delta) {
    let next = this.state.bathrooms + delta;
    if (next < 1) next = 1;
    if (next > 5) next = 5;
    this.state.bathrooms = next;
    const el = document.getElementById('val-bathrooms');
    if (el) el.textContent = next === 5 ? '5+ Baths' : `${next} ${next === 1 ? 'Bath' : 'Baths'}`;
    this.updateCalculations();
  }

  toggleAddon(addonId) {
    const index = this.state.addons.indexOf(addonId);
    if (index === -1) {
      this.state.addons.push(addonId);
    } else {
      this.state.addons.splice(index, 1);
    }
    this.renderAddonsGrid();
    this.updateCalculations();
  }

  applyPromoCode() {
    const input = document.getElementById('wizard-promo-input');
    const msg = document.getElementById('promo-feedback-msg');
    if (!input || !msg) return;

    const code = input.value.trim().toUpperCase();
    if (!code) {
      msg.textContent = 'Please enter a voucher or promo code.';
      msg.className = 'text-xs text-amber-600 mt-1 block';
      return;
    }

    if (this.promoCodes[code]) {
      const info = this.promoCodes[code];
      this.state.promoCode = code;
      this.state.promoDiscount = info.discount;
      msg.textContent = `Promo applied! ${info.label}`;
      msg.className = 'text-xs text-emerald-600 font-semibold mt-1 block';
      input.disabled = true;
      document.getElementById('btn-apply-promo').textContent = 'Applied ✓';
      document.getElementById('btn-apply-promo').disabled = true;
      this.updateCalculations();
    } else {
      msg.textContent = 'Invalid promo code. Try "WELCOME25" or "CSC407"';
      msg.className = 'text-xs text-red-500 mt-1 block';
    }
  }

  calculateTotals() {
    // Base Service
    const base = this.state.basePrice;

    // Room multipliers
    // First bedroom/bathroom included in base. Additional bedrooms: $20, bathrooms: $25.
    const extraBeds = Math.max(0, this.state.bedrooms - 1) * 20;
    const extraBaths = Math.max(0, this.state.bathrooms - 1) * 25;

    // Addons
    const addonsTotal = this.state.addons.reduce((sum, id) => {
      const a = ADDONS_DATA.find(item => item.id === id);
      return sum + (a ? a.price : 0);
    }, 0);

    const subtotalBeforeDiscounts = base + extraBeds + extraBaths + addonsTotal;

    // Frequency Discount
    const freqDiscountAmount = subtotalBeforeDiscounts * this.state.frequencyDiscountPct;

    // Promo Discount
    const promoDiscountAmount = Math.min(this.state.promoDiscount, subtotalBeforeDiscounts - freqDiscountAmount);

    const subtotalAfterDiscounts = Math.max(0, subtotalBeforeDiscounts - freqDiscountAmount - promoDiscountAmount);

    // 8% State & Local Service Tax
    const tax = subtotalAfterDiscounts * 0.08;
    const total = subtotalAfterDiscounts + tax;

    // Estimated duration
    let estDuration = this.state.baseDuration;
    estDuration += (this.state.bedrooms - 1) * 0.35;
    estDuration += (this.state.bathrooms - 1) * 0.45;
    this.state.addons.forEach(id => {
      const a = ADDONS_DATA.find(item => item.id === id);
      if (a) estDuration += a.duration;
    });

    return {
      base,
      extraBeds,
      extraBaths,
      addonsTotal,
      subtotalBeforeDiscounts,
      freqDiscountAmount,
      promoDiscountAmount,
      tax,
      total,
      durationHours: estDuration.toFixed(1)
    };
  }

  updateCalculations() {
    const totals = this.calculateTotals();

    // Summary Sidebar Elements
    const setText = (id, text) => {
      const el = document.getElementById(id);
      if (el) el.textContent = text;
    };

    setText('sum-service-name', this.state.serviceName);
    setText('sum-rooms-detail', `${this.state.bedrooms} Bed, ${this.state.bathrooms} Bath (${this.state.sqft} sq ft)`);
    setText('sum-base-price', `$${totals.base.toFixed(2)}`);
    setText('sum-rooms-addon', `+$${(totals.extraBeds + totals.extraBaths).toFixed(2)}`);

    // Addons list in summary
    const addonsListEl = document.getElementById('sum-addons-list');
    if (addonsListEl) {
      if (this.state.addons.length === 0) {
        addonsListEl.innerHTML = '<span class="text-slate-400 italic text-xs">No extras selected</span>';
      } else {
        addonsListEl.innerHTML = this.state.addons.map(id => {
          const a = ADDONS_DATA.find(item => item.id === id);
          return `<div class="flex justify-between text-xs text-slate-600"><span>• ${a.name}</span><span class="font-medium">+$${a.price}</span></div>`;
        }).join('');
      }
    }

    setText('sum-addons-total', `+$${totals.addonsTotal.toFixed(2)}`);

    // Discounts
    const freqDiscountRow = document.getElementById('sum-freq-discount-row');
    if (freqDiscountRow) {
      if (totals.freqDiscountAmount > 0) {
        freqDiscountRow.style.display = 'flex';
        setText('sum-freq-discount-val', `-$${totals.freqDiscountAmount.toFixed(2)}`);
        setText('sum-freq-discount-label', `Frequency Discount (${this.state.frequencyDiscountPct * 100}%)`);
      } else {
        freqDiscountRow.style.display = 'none';
      }
    }

    const promoDiscountRow = document.getElementById('sum-promo-discount-row');
    if (promoDiscountRow) {
      if (totals.promoDiscountAmount > 0) {
        promoDiscountRow.style.display = 'flex';
        setText('sum-promo-discount-val', `-$${totals.promoDiscountAmount.toFixed(2)}`);
      } else {
        promoDiscountRow.style.display = 'none';
      }
    }

    setText('sum-tax', `$${totals.tax.toFixed(2)}`);
    setText('sum-total-price', `$${totals.total.toFixed(2)}`);
    setText('sum-est-duration', `~${totals.durationHours} hrs`);

    // Date & Time in summary
    setText('sum-schedule-date', this.formatDisplayDate(this.state.date));
    setText('sum-schedule-slot', this.state.timeSlot);

    // Floating total on mobile if present
    setText('mobile-floating-total', `$${totals.total.toFixed(2)}`);
  }

  formatDisplayDate(isoDate) {
    if (!isoDate) return 'Select Date';
    try {
      const [year, month, day] = isoDate.split('-');
      const d = new Date(year, month - 1, day);
      return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
    } catch {
      return isoDate;
    }
  }

  handleNextStep() {
    if (this.validateCurrentStep()) {
      if (this.currentStep < this.totalSteps) {
        this.currentStep++;
        this.updateStepUI();
        window.scrollTo({ top: document.getElementById('booking-wizard-section').offsetTop - 60, behavior: 'smooth' });
      }
    }
  }

  handlePrevStep() {
    if (this.currentStep > 1) {
      this.currentStep--;
      this.updateStepUI();
      window.scrollTo({ top: document.getElementById('booking-wizard-section').offsetTop - 60, behavior: 'smooth' });
    }
  }

  goToStep(stepNum) {
    if (stepNum >= 1 && stepNum <= this.totalSteps) {
      this.currentStep = stepNum;
      this.updateStepUI();
    }
  }

  validateCurrentStep() {
    if (this.currentStep === 1) {
      if (!this.state.serviceId) {
        alert('Please select a cleaning service to continue.');
        return false;
      }
      return true;
    }

    if (this.currentStep === 2) {
      return true; // Extras are optional
    }

    if (this.currentStep === 3) {
      if (!this.state.date) {
        alert('Please select a preferred cleaning date.');
        return false;
      }
      return true;
    }

    if (this.currentStep === 4) {
      // Validate customer fields
      const name = document.getElementById('cust-name')?.value.trim();
      const email = document.getElementById('cust-email')?.value.trim();
      const phone = document.getElementById('cust-phone')?.value.trim();
      const address = document.getElementById('cust-address')?.value.trim();
      const postalCode = document.getElementById('cust-postal')?.value.trim();

      if (!name || !email || !phone || !address || !postalCode) {
        alert('Please fill out all required contact and location fields.');
        return false;
      }

      // Basic email check
      if (!/^\S+@\S+\.\S+$/.test(email)) {
        alert('Please provide a valid email address.');
        return false;
      }

      this.state.customer.fullName = name;
      this.state.customer.email = email;
      this.state.customer.phone = phone;
      this.state.customer.address = address;
      this.state.customer.apartment = document.getElementById('cust-apt')?.value.trim() || '';
      this.state.customer.city = document.getElementById('cust-city')?.value.trim() || 'Springfield';
      this.state.customer.postalCode = postalCode;
      this.state.customer.accessNotes = document.getElementById('cust-access-notes')?.value.trim() || '';
      this.state.customer.specialNotes = document.getElementById('cust-special-notes')?.value.trim() || '';

      return true;
    }

    return true;
  }

  updateStepUI() {
    // Hide all step panels, show current
    for (let i = 1; i <= this.totalSteps; i++) {
      const panel = document.getElementById(`wizard-step-${i}`);
      if (panel) {
        if (i === this.currentStep) {
          panel.classList.remove('hidden');
          panel.classList.add('block');
        } else {
          panel.classList.add('hidden');
          panel.classList.remove('block');
        }
      }

      // Update stepper indicators
      const indicator = document.querySelector(`.stepper-indicator[data-step="${i}"]`);
      if (indicator) {
        const circle = indicator.querySelector('.step-circle');
        const text = indicator.querySelector('.step-label');

        if (i === this.currentStep) {
          circle.className = 'step-circle w-9 h-9 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center ring-4 ring-emerald-100 shadow-sm transition-all';
          text.className = 'step-label text-xs font-bold text-emerald-800 transition-all';
        } else if (i < this.currentStep) {
          circle.className = 'step-circle w-9 h-9 rounded-full bg-emerald-100 text-emerald-700 font-bold flex items-center justify-center transition-all cursor-pointer';
          circle.innerHTML = '✓';
          text.className = 'step-label text-xs font-semibold text-slate-700 transition-all';
        } else {
          circle.className = 'step-circle w-9 h-9 rounded-full bg-slate-100 text-slate-500 font-medium flex items-center justify-center transition-all';
          circle.textContent = i;
          text.className = 'step-label text-xs font-medium text-slate-400 transition-all';
        }
      }
    }

    // Toggle Back / Next buttons
    const btnPrev = document.getElementById('wizard-btn-prev');
    const btnNext = document.getElementById('wizard-btn-next');
    const btnSubmit = document.getElementById('wizard-submit-booking');

    if (btnPrev) {
      btnPrev.style.display = this.currentStep > 1 ? 'inline-flex' : 'none';
    }

    if (btnNext && btnSubmit) {
      if (this.currentStep === this.totalSteps) {
        btnNext.style.display = 'none';
        btnSubmit.style.display = 'inline-flex';
      } else {
        btnNext.style.display = 'inline-flex';
        btnSubmit.style.display = 'none';
      }
    }

    if (window.lucide) window.lucide.createIcons();
  }

  submitBooking() {
    if (!this.validateCurrentStep()) return;

    const totals = this.calculateTotals();

    // Auto-assign available cleaner
    const availableCleaners = CLEANERS_DATA.filter(c => c.status === 'Available');
    const assignedCleaner = availableCleaners.length 
      ? availableCleaners[Math.floor(Math.random() * availableCleaners.length)]
      : CLEANERS_DATA[0];

    // Generate random booking ID: PNC-XXXXX
    const randomNum = Math.floor(10000 + Math.random() * 90000);
    const bookingId = `PNC-${randomNum}`;

    const newBooking = {
      id: bookingId,
      createdAt: new Date().toISOString(),
      customer: { ...this.state.customer },
      serviceId: this.state.serviceId,
      serviceName: this.state.serviceName,
      bedrooms: this.state.bedrooms,
      bathrooms: this.state.bathrooms,
      sqft: this.state.sqft,
      frequency: this.state.frequency,
      frequencyDiscount: this.state.frequencyDiscountPct,
      addons: [...this.state.addons],
      addonsTotal: totals.addonsTotal,
      date: this.state.date,
      timeSlot: this.state.timeSlot,
      ecoFriendly: this.state.ecoFriendly,
      hasPets: this.state.hasPets,
      cleanerSupplies: this.state.cleanerSupplies,
      specialNotes: this.state.customer.specialNotes,
      promoCode: this.state.promoCode,
      promoDiscount: totals.promoDiscountAmount,
      subtotal: totals.subtotalBeforeDiscounts,
      tax: totals.tax,
      total: totals.total,
      durationHours: totals.durationHours,
      status: 'assigned', // Confirmed & assigned immediately
      cleanerId: assignedCleaner.id,
      cleanerName: assignedCleaner.name,
      paymentMethod: this.state.paymentMethod === 'card' ? 'Credit Card (Simulated)' : 'Cash / On-Site Pay',
      paymentStatus: 'Confirmed',
      rating: null,
      review: null
    };

    // Save to storage
    StorageManager.addBooking(newBooking);

    // Notify window event for admin and tracker
    window.dispatchEvent(new CustomEvent('bookingCreated', { detail: newBooking }));

    // Show Confirmation Dialog
    this.showConfirmationModal(newBooking);
  }

  showConfirmationModal(booking) {
    const modal = document.getElementById('booking-confirmation-modal');
    if (!modal) return;

    document.getElementById('conf-booking-id').textContent = booking.id;
    document.getElementById('conf-customer-name').textContent = booking.customer.fullName;
    document.getElementById('conf-service').textContent = booking.serviceName;
    document.getElementById('conf-datetime').textContent = `${this.formatDisplayDate(booking.date)} at ${booking.timeSlot}`;
    document.getElementById('conf-address').textContent = `${booking.customer.address}, ${booking.customer.city}`;
    document.getElementById('conf-total').textContent = `$${booking.total.toFixed(2)}`;
    document.getElementById('conf-cleaner').textContent = booking.cleanerName;

    modal.showModal();

    // Setup Track button inside confirmation modal
    document.getElementById('btn-conf-track')?.addEventListener('click', () => {
      modal.close();
      if (window.BookingTracker) {
        window.BookingTracker.openTrackerWithId(booking.id);
      }
    }, { once: true });

    // Setup Print invoice
    document.getElementById('btn-conf-print')?.addEventListener('click', () => {
      window.print();
    });
  }

  resetWizard() {
    this.currentStep = 1;
    this.state.addons = [];
    this.state.promoCode = '';
    this.state.promoDiscount = 0;
    this.renderAddonsGrid();
    this.updateCalculations();
    this.updateStepUI();
  }
}

// Export to window
if (typeof window !== 'undefined') {
  window.BookingWizard = BookingWizard;
}
