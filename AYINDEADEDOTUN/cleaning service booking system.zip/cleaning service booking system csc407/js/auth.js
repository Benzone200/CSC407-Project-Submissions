// PureNest - Web Application Authentication, RBAC & Security Engine
// Implements password hashing, user registration, role checks, and session management

const AuthManager = {
  SESSION_KEY: 'purenest_session_v1',
  USERS_KEY: 'purenest_users_v1',
  AUDIT_KEY: 'purenest_audit_logs_v1',

  // Pre-seeded users with salted hashes
  INITIAL_USERS: [
    {
      id: 'usr-admin-1',
      fullName: 'System Administrator',
      email: 'admin@purenest.com',
      role: 'admin', // admin, user, cleaner
      phone: '(555) 019-9000',
      address: '100 Executive Boulevard, HQ Suite 400',
      city: 'Springfield',
      postalCode: '97477',
      // Hash of 'AdminPass123!' with salt 'purenest_salt_99'
      passwordHash: 'c4e709e8db1eeecd6000b58ce8e3547c42d9efd87586116ef3ff2e67bed2678d',
      salt: 'purenest_salt_99',
      createdAt: '2026-10-01T08:00:00.000Z',
      twoFactorEnabled: true,
      lastLogin: new Date().toISOString()
    },
    {
      id: 'usr-customer-1',
      fullName: 'Alex Vance',
      email: 'alex@example.com',
      role: 'user',
      phone: '(555) 987-6543',
      address: '742 Evergreen Terrace, Apt 4B',
      city: 'Springfield',
      postalCode: '97477',
      // Hash of 'UserPass123!' with salt 'purenest_salt_42'
      passwordHash: '015bcb717850996bf6e6ca9fea6aec97d36c4ed85b05e8f2db95ae586b06f833',
      salt: 'purenest_salt_42',
      createdAt: '2026-10-15T10:30:00.000Z',
      twoFactorEnabled: false,
      lastLogin: new Date(Date.now() - 3600000 * 4).toISOString()
    },
    {
      id: 'usr-cleaner-1',
      fullName: 'Sarah Jenkins',
      email: 'cleaner@purenest.com',
      role: 'cleaner',
      phone: '(555) 234-5678',
      address: '88 Meadow Lane',
      city: 'Springfield',
      postalCode: '97477',
      // Hash of 'CleanerPass123!' with salt 'purenest_salt_17'
      passwordHash: '1f585afc2cdd08ffb34c4ec660b496317ca87de6c76f8b38d62ed9f8311615d9',
      salt: 'purenest_salt_17',
      createdAt: '2026-10-10T12:00:00.000Z',
      twoFactorEnabled: true,
      lastLogin: new Date(Date.now() - 3600000 * 12).toISOString()
    }
  ],

  loginAttempts: {},

  init() {
    this.ensureInitialized();
  },

  resetLockout(email) {
    if (email) {
      delete this.loginAttempts[email.trim().toLowerCase()];
    } else {
      this.loginAttempts = {};
    }
  },

  ensureInitialized() {
    try {
      let users = [];
      const existing = localStorage.getItem(this.USERS_KEY);
      if (existing) {
        try {
          users = JSON.parse(existing) || [];
        } catch (e) {
          users = [];
        }
      }

      this.INITIAL_USERS.forEach(seedUser => {
        const idx = users.findIndex(u => u.email.toLowerCase() === seedUser.email.toLowerCase());
        if (idx === -1) {
          users.push(seedUser);
        } else {
          users[idx].passwordHash = seedUser.passwordHash;
          users[idx].salt = seedUser.salt;
          users[idx].role = seedUser.role;
        }
      });

      localStorage.setItem(this.USERS_KEY, JSON.stringify(users));
      this.loginAttempts = {};

      const logs = localStorage.getItem(this.AUDIT_KEY);
      if (!logs) {
        this.addAuditLog('SYSTEM_BOOT', 'Security audit logging service initialized.', 'SUCCESS', '127.0.0.1');
      }
    } catch (e) {
      console.warn('Auth init storage fallback:', e);
    }
  },

  getUsers() {
    try {
      const data = localStorage.getItem(this.USERS_KEY);
      if (data) return JSON.parse(data);
    } catch (e) {}
    return this.INITIAL_USERS;
  },

  saveUsers(users) {
    try {
      localStorage.setItem(this.USERS_KEY, JSON.stringify(users));
    } catch (e) {}
  },

  // Cryptographic hashing using Web Crypto SHA-256 with salt
  async hashPassword(password, salt) {
    const text = password + ':' + salt;
    const encoder = new TextEncoder();
    const data = encoder.encode(text);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  },

  generateSalt(length = 16) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    const array = new Uint8Array(length);
    window.crypto.getRandomValues(array);
    for (let i = 0; i < length; i++) {
      result += chars[array[i] % chars.length];
    }
    return result;
  },

  // Input Sanitizer to neutralize XSS
  sanitizeInput(str) {
    if (typeof str !== 'string') return str;
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/\//g, '&#x2F;');
  },

  // Login Authentication with Brute-Force Rate Limiting
  async login(email, password) {
    email = email.trim().toLowerCase();
    const now = Date.now();

    // Check brute-force lockout
    const attemptInfo = this.loginAttempts[email] || { count: 0, lockUntil: 0 };
    if (attemptInfo.lockUntil > now) {
      const remainingSec = Math.ceil((attemptInfo.lockUntil - now) / 1000);
      this.addAuditLog('LOGIN_RATE_LIMITED', `Brute force lockout active for ${email}.`, 'BLOCKED', '127.0.0.1');
      return {
        success: false,
        error: `Account temporarily locked due to too many failed attempts. Try again in ${remainingSec} seconds.`
      };
    }

    const users = this.getUsers();
    const user = users.find(u => u.email.toLowerCase() === email);

    if (!user) {
      this.recordFailedAttempt(email);
      this.addAuditLog('LOGIN_FAILED', `Unknown account login attempt: ${email}`, 'FAILED', '127.0.0.1');
      return { success: false, error: 'Invalid email address or password.' };
    }

    // Verify hash
    const inputHash = await this.hashPassword(password, user.salt);
    if (inputHash !== user.passwordHash) {
      this.recordFailedAttempt(email);
      this.addAuditLog('LOGIN_FAILED', `Incorrect password attempt for user: ${email}`, 'FAILED', '127.0.0.1');
      return { success: false, error: 'Invalid email address or password.' };
    }

    // Reset attempts on successful login
    delete this.loginAttempts[email];

    // Generate Session Token (Simulated JWT)
    const token = this.generateSessionToken(user);
    const session = {
      token,
      userId: user.id,
      fullName: user.fullName,
      email: user.email,
      role: user.role,
      loginTime: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 8).toISOString() // 8 hours session
    };

    localStorage.setItem(this.SESSION_KEY, JSON.stringify(session));

    // Update user last login
    user.lastLogin = new Date().toISOString();
    this.saveUsers(users);

    this.addAuditLog('LOGIN_SUCCESS', `User authenticated successfully: ${email} [Role: ${user.role}]`, 'SUCCESS', '127.0.0.1');

    window.dispatchEvent(new CustomEvent('authStateChanged', { detail: session }));
    return { success: true, user: session };
  },

  recordFailedAttempt(email) {
    const info = this.loginAttempts[email] || { count: 0, lockUntil: 0 };
    info.count += 1;
    if (info.count >= 5) {
      info.lockUntil = Date.now() + 30000; // 30 seconds lockout
      this.addAuditLog('BRUTE_FORCE_LOCK', `Rate limit triggered for ${email} (5 failed attempts).`, 'ALERT', '127.0.0.1');
    }
    this.loginAttempts[email] = info;
  },

  generateSessionToken(user) {
    const header = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
    const payload = btoa(JSON.stringify({
      sub: user.id,
      email: user.email,
      role: user.role,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 28800
    }));
    const sig = 'sig_' + Math.random().toString(36).substring(2);
    return `${header}.${payload}.${sig}`;
  },

  // Register a new customer
  async register(fullName, email, phone, address, city, postalCode, password) {
    fullName = this.sanitizeInput(fullName.trim());
    email = email.trim().toLowerCase();
    phone = this.sanitizeInput(phone.trim());
    address = this.sanitizeInput(address.trim());
    city = this.sanitizeInput(city.trim());
    postalCode = this.sanitizeInput(postalCode.trim());

    // Validate email
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      return { success: false, error: 'Please enter a valid email address.' };
    }

    // Validate password policy (Min 8 chars, 1 uppercase, 1 lowercase, 1 number)
    if (password.length < 8) {
      return { success: false, error: 'Password must be at least 8 characters long.' };
    }
    if (!/[A-Z]/.test(password)) {
      return { success: false, error: 'Password must contain at least one uppercase letter.' };
    }
    if (!/[0-9]/.test(password)) {
      return { success: false, error: 'Password must contain at least one number.' };
    }

    const users = this.getUsers();
    if (users.some(u => u.email.toLowerCase() === email)) {
      this.addAuditLog('REGISTRATION_FAILED', `Duplicate registration attempt: ${email}`, 'WARNING', '127.0.0.1');
      return { success: false, error: 'An account with this email address already exists.' };
    }

    const salt = this.generateSalt(16);
    const passwordHash = await this.hashPassword(password, salt);

    const newUser = {
      id: `usr-${Date.now()}`,
      fullName,
      email,
      role: 'user', // regular customer
      phone,
      address,
      city,
      postalCode,
      passwordHash,
      salt,
      createdAt: new Date().toISOString(),
      twoFactorEnabled: false,
      lastLogin: new Date().toISOString()
    };

    users.push(newUser);
    this.saveUsers(users);

    this.addAuditLog('REGISTRATION_SUCCESS', `New user registered: ${email} with SHA-256 salted hash`, 'SUCCESS', '127.0.0.1');

    // Automatically log in
    return await this.login(email, password);
  },

  logout() {
    const session = this.getSession();
    if (session) {
      this.addAuditLog('LOGOUT', `User signed out: ${session.email}`, 'SUCCESS', '127.0.0.1');
    }
    localStorage.removeItem(this.SESSION_KEY);
    window.dispatchEvent(new CustomEvent('authStateChanged', { detail: null }));
  },

  getSession() {
    try {
      const data = localStorage.getItem(this.SESSION_KEY);
      if (data) {
        const session = JSON.parse(data);
        // Check expiry
        if (new Date(session.expiresAt) > new Date()) {
          return session;
        } else {
          this.logout();
        }
      }
    } catch (e) {}
    return null;
  },

  isLoggedIn() {
    return !!this.getSession();
  },

  hasRole(requiredRole) {
    const session = this.getSession();
    if (!session) return false;
    if (session.role === 'admin') return true; // Admin has super-privileges
    return session.role === requiredRole;
  },

  // Access Control Guard
  requireRole(requiredRole) {
    const session = this.getSession();
    if (!session) {
      this.addAuditLog('UNAUTHORIZED_ACCESS', `Access denied: Guest attempted to view protected route (${requiredRole})`, 'BLOCKED', '127.0.0.1');
      return { allowed: false, reason: 'unauthenticated' };
    }

    if (session.role !== requiredRole && session.role !== 'admin') {
      this.addAuditLog('PRIVILEGE_VIOLATION', `Forbidden: User ${session.email} [${session.role}] attempted to access ${requiredRole} resource`, 'SECURITY_ALERT', '127.0.0.1');
      return { allowed: false, reason: 'forbidden' };
    }

    return { allowed: true };
  },

  // Update User Profile
  updateProfile(userId, updates) {
    const users = this.getUsers();
    const index = users.findIndex(u => u.id === userId);
    if (index === -1) return { success: false, error: 'User not found' };

    // Prevent changing role directly
    delete updates.role;
    delete updates.passwordHash;
    delete updates.salt;

    users[index] = { ...users[index], ...updates };
    this.saveUsers(users);

    // Update active session name if current user
    const session = this.getSession();
    if (session && session.userId === userId) {
      session.fullName = updates.fullName || session.fullName;
      localStorage.setItem(this.SESSION_KEY, JSON.stringify(session));
      window.dispatchEvent(new CustomEvent('authStateChanged', { detail: session }));
    }

    this.addAuditLog('PROFILE_UPDATE', `User updated profile info: ${users[index].email}`, 'SUCCESS', '127.0.0.1');
    return { success: true, user: users[index] };
  },

  // Change Password
  async changePassword(userId, currentPassword, newPassword) {
    const users = this.getUsers();
    const user = users.find(u => u.id === userId);
    if (!user) return { success: false, error: 'User not found' };

    const currentHash = await this.hashPassword(currentPassword, user.salt);
    if (currentHash !== user.passwordHash) {
      this.addAuditLog('PASSWORD_CHANGE_FAILED', `Current password incorrect for: ${user.email}`, 'WARNING', '127.0.0.1');
      return { success: false, error: 'Current password does not match our records.' };
    }

    if (newPassword.length < 8) {
      return { success: false, error: 'New password must be at least 8 characters long.' };
    }

    user.salt = this.generateSalt(16);
    user.passwordHash = await this.hashPassword(newPassword, user.salt);
    this.saveUsers(users);

    this.addAuditLog('PASSWORD_CHANGE_SUCCESS', `Password successfully updated with new salt for: ${user.email}`, 'SUCCESS', '127.0.0.1');
    return { success: true };
  },

  // Security Audit Logging
  addAuditLog(event, details, status = 'INFO', ip = '127.0.0.1') {
    try {
      const logs = this.getAuditLogs();
      const newEntry = {
        id: 'log-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
        timestamp: new Date().toISOString(),
        event,
        details,
        status,
        ip
      };
      logs.unshift(newEntry);
      if (logs.length > 100) logs.pop(); // Keep last 100 events
      localStorage.setItem(this.AUDIT_KEY, JSON.stringify(logs));
      window.dispatchEvent(new CustomEvent('auditLogAdded', { detail: newEntry }));
    } catch (e) {}
  },

  getAuditLogs() {
    try {
      const data = localStorage.getItem(this.AUDIT_KEY);
      if (data) return JSON.parse(data);
    } catch (e) {}
    return [];
  }
};

// Initialize on script load
if (typeof window !== 'undefined') {
  window.AuthManager = AuthManager;
  AuthManager.init();
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = AuthManager;
}
