// PureNest - Real-Time Booking Tracker & Customer Management

const BookingTracker = {
  currentBooking: null,

  init() {
    this.bindEvents();
  },

  bindEvents() {
    // Search form submission
    document.getElementById('tracker-search-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = document.getElementById('tracker-input-id')?.value.trim();
      this.trackBooking(input);
    });

    // Quick sample booking pills in tracker
    document.querySelectorAll('.sample-track-pill').forEach(pill => {
      pill.addEventListener('click', (e) => {
        const id = e.currentTarget.getAttribute('data-id');
        if (id) {
          const inputEl = document.getElementById('tracker-input-id');
          if (inputEl) inputEl.value = id;
          this.trackBooking(id);
        }
      });
    });

    // Reschedule form submit
    document.getElementById('reschedule-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleReschedule();
    });

    // Cancel booking button
    document.getElementById('btn-cancel-booking-action')?.addEventListener('click', () => {
      this.handleCancellation();
    });

    // Advance status demo button (For demonstration / testing)
    document.getElementById('btn-advance-status-demo')?.addEventListener('click', () => {
      this.advanceStatusDemo();
    });

    // Review submission
    document.getElementById('review-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleReviewSubmit();
    });

    // Star rating hover/click
    document.querySelectorAll('.star-rating-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const rating = parseInt(e.currentTarget.getAttribute('data-rating'));
        document.getElementById('rating-score-input').value = rating;
        this.highlightStars(rating);
      });
    });
  },

  highlightStars(score) {
    document.querySelectorAll('.star-rating-btn').forEach(btn => {
      const r = parseInt(btn.getAttribute('data-rating'));
      if (r <= score) {
        btn.classList.add('text-amber-400');
        btn.classList.remove('text-slate-300');
      } else {
        btn.classList.remove('text-amber-400');
        btn.classList.add('text-slate-300');
      }
    });
  },

  openTrackerWithId(id) {
    const trackerModal = document.getElementById('tracker-modal');
    if (trackerModal) {
      trackerModal.showModal();
    }
    const inputEl = document.getElementById('tracker-input-id');
    if (inputEl) inputEl.value = id;
    this.trackBooking(id);
  },

  trackBooking(query) {
    const errorEl = document.getElementById('tracker-error-msg');
    const resultEl = document.getElementById('tracker-result-card');
    if (!query) {
      if (errorEl) {
        errorEl.textContent = 'Please enter a booking reference code or email address.';
        errorEl.classList.remove('hidden');
      }
      return;
    }

    const bookings = StorageManager.getBookings();
    let booking = null;

    // Check by ID or Email
    booking = bookings.find(b => 
      b.id.toUpperCase() === query.toUpperCase() || 
      b.customer.email.toLowerCase() === query.toLowerCase()
    );

    if (!booking) {
      if (errorEl) {
        errorEl.textContent = `No booking found for "${query}". Please check your reference code (e.g., PNC-78421).`;
        errorEl.classList.remove('hidden');
      }
      if (resultEl) resultEl.classList.add('hidden');
      return;
    }

    if (errorEl) errorEl.classList.add('hidden');
    this.currentBooking = booking;
    this.renderBookingDetails(booking);
  },

  renderBookingDetails(booking) {
    const resultEl = document.getElementById('tracker-result-card');
    if (!resultEl) return;
    resultEl.classList.remove('hidden');

    // Header Details
    document.getElementById('track-val-id').textContent = booking.id;
    document.getElementById('track-val-date-header').textContent = `Booked on ${new Date(booking.createdAt).toLocaleDateString()}`;

    // Timeline steps
    const statusMap = {
      'pending': 1,
      'assigned': 2,
      'dispatched': 3,
      'in_progress': 4,
      'completed': 5,
      'cancelled': -1
    };

    const currentStepIndex = statusMap[booking.status] || 1;

    // Cancelled banner
    const cancelBanner = document.getElementById('tracker-cancelled-banner');
    const timelineContainer = document.getElementById('tracker-timeline-container');
    const actionButtons = document.getElementById('tracker-action-buttons');
    const demoAdvanceBtn = document.getElementById('btn-advance-status-demo');

    if (booking.status === 'cancelled') {
      if (cancelBanner) cancelBanner.classList.remove('hidden');
      if (timelineContainer) timelineContainer.classList.add('opacity-40');
      if (actionButtons) actionButtons.classList.add('hidden');
      if (demoAdvanceBtn) demoAdvanceBtn.classList.add('hidden');
    } else {
      if (cancelBanner) cancelBanner.classList.add('hidden');
      if (timelineContainer) timelineContainer.classList.remove('opacity-40');
      if (actionButtons) actionButtons.classList.remove('hidden');
      if (demoAdvanceBtn) demoAdvanceBtn.classList.remove('hidden');
    }

    // Update timeline step visual
    const stepItems = [
      { id: 'timeline-step-1', name: 'Order Received', desc: 'Booking confirmed in our system' },
      { id: 'timeline-step-2', name: 'Cleaner Assigned', desc: 'Top-rated certified cleaner matched' },
      { id: 'timeline-step-3', name: 'Cleaner En Route', desc: 'Cleaner dispatched with all equipment' },
      { id: 'timeline-step-4', name: 'Cleaning In Progress', desc: 'Underway according to standard checklist' },
      { id: 'timeline-step-5', name: 'Completed & Inspected', desc: 'Quality inspection passed 100%' }
    ];

    stepItems.forEach((step, idx) => {
      const stepNum = idx + 1;
      const el = document.getElementById(step.id);
      if (!el) return;

      const circle = el.querySelector('.status-dot');
      const title = el.querySelector('.status-title');
      const timeEl = el.querySelector('.status-time');

      if (booking.status === 'cancelled') {
        circle.className = 'status-dot w-8 h-8 rounded-full bg-slate-200 text-slate-400 flex items-center justify-center text-xs font-bold';
      } else if (stepNum < currentStepIndex) {
        circle.className = 'status-dot w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold ring-4 ring-emerald-50';
        circle.innerHTML = '✓';
        title.className = 'status-title font-semibold text-slate-900 text-sm';
      } else if (stepNum === currentStepIndex) {
        circle.className = 'status-dot w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-bold ring-4 ring-blue-100 animate-pulse';
        circle.textContent = stepNum;
        title.className = 'status-title font-bold text-blue-700 text-sm';
      } else {
        circle.className = 'status-dot w-8 h-8 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center text-xs font-bold';
        circle.textContent = stepNum;
        title.className = 'status-title font-medium text-slate-500 text-sm';
      }
    });

    // Cleaner Profile Section
    const cleanerCard = document.getElementById('tracker-cleaner-card');
    const cleaner = CLEANERS_DATA.find(c => c.id === booking.cleanerId) || CLEANERS_DATA[0];

    if (booking.cleanerId && booking.status !== 'pending' && booking.status !== 'cancelled') {
      cleanerCard.classList.remove('hidden');
      document.getElementById('cleaner-avatar-img').src = cleaner.avatar;
      document.getElementById('cleaner-name-display').textContent = cleaner.name;
      document.getElementById('cleaner-rating-display').textContent = `★ ${cleaner.rating} (${cleaner.reviewsCount} cleans)`;
      document.getElementById('cleaner-badge-display').textContent = cleaner.badge;
      document.getElementById('cleaner-phone-display').textContent = cleaner.phone;
      document.getElementById('cleaner-phone-link').href = `tel:${cleaner.phone}`;
    } else {
      cleanerCard.classList.add('hidden');
    }

    // Service & Location Details
    document.getElementById('track-service-name').textContent = booking.serviceName;
    document.getElementById('track-rooms-desc').textContent = `${booking.bedrooms} Bedrooms, ${booking.bathrooms} Bathrooms (${booking.sqft} sq ft)`;
    document.getElementById('track-datetime').textContent = `${booking.date} (${booking.timeSlot})`;
    document.getElementById('track-address').textContent = `${booking.customer.address}, ${booking.customer.city} ${booking.customer.postalCode}`;
    document.getElementById('track-total').textContent = `$${Number(booking.total).toFixed(2)}`;

    // Extras
    const extrasContainer = document.getElementById('track-extras-list');
    if (extrasContainer) {
      if (booking.addons && booking.addons.length > 0) {
        extrasContainer.innerHTML = booking.addons.map(id => {
          const a = ADDONS_DATA.find(item => item.id === id);
          return `<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-50 text-emerald-800 border border-emerald-200/60">${a ? a.name : id}</span>`;
        }).join('');
      } else {
        extrasContainer.innerHTML = '<span class="text-xs text-slate-400">None selected</span>';
      }
    }

    // Special Instructions
    document.getElementById('track-notes').textContent = booking.specialNotes || 'None specified.';
    document.getElementById('track-access').textContent = booking.customer.accessNotes || 'Standard key/entry.';

    // Review / Feedback Section for Completed Cleans
    const reviewBox = document.getElementById('tracker-review-box');
    const existingReviewBox = document.getElementById('tracker-existing-review');

    if (booking.status === 'completed') {
      if (booking.rating) {
        reviewBox.classList.add('hidden');
        existingReviewBox.classList.remove('hidden');
        document.getElementById('existing-rating-stars').textContent = '★'.repeat(booking.rating);
        document.getElementById('existing-review-text').textContent = booking.review || 'No written comment left.';
      } else {
        reviewBox.classList.remove('hidden');
        existingReviewBox.classList.add('hidden');
      }
    } else {
      reviewBox.classList.add('hidden');
      existingReviewBox.classList.add('hidden');
    }

    if (window.lucide) window.lucide.createIcons();
  },

  advanceStatusDemo() {
    if (!this.currentBooking) return;
    const stages = ['pending', 'assigned', 'dispatched', 'in_progress', 'completed'];
    let idx = stages.indexOf(this.currentBooking.status);
    if (idx === -1) idx = 0;
    
    // Cycle to next stage
    const nextIdx = (idx + 1) % stages.length;
    const nextStatus = stages[nextIdx];

    const updated = StorageManager.updateBookingStatus(
      this.currentBooking.id, 
      nextStatus, 
      this.currentBooking.cleanerId || 'cleaner-1', 
      this.currentBooking.cleanerName || 'Sarah Jenkins'
    );

    this.currentBooking = updated;
    this.renderBookingDetails(updated);

    // Notify other components (Admin portal)
    window.dispatchEvent(new CustomEvent('bookingUpdated', { detail: updated }));
  },

  handleReschedule() {
    if (!this.currentBooking) return;
    const newDate = document.getElementById('reschedule-date')?.value;
    const newSlot = document.getElementById('reschedule-slot')?.value;

    if (!newDate) {
      alert('Please pick a new cleaning date.');
      return;
    }

    const updated = StorageManager.rescheduleBooking(this.currentBooking.id, newDate, newSlot);
    if (updated) {
      this.currentBooking = updated;
      this.renderBookingDetails(updated);
      document.getElementById('reschedule-modal')?.close();
      alert(`Booking ${updated.id} successfully rescheduled for ${newDate} (${newSlot}).`);
      window.dispatchEvent(new CustomEvent('bookingUpdated', { detail: updated }));
    }
  },

  handleCancellation() {
    if (!this.currentBooking) return;
    if (confirm(`Are you sure you want to cancel booking ${this.currentBooking.id}? There is no fee when cancelled in advance.`)) {
      const updated = StorageManager.cancelBooking(this.currentBooking.id, 'Cancelled by customer via Tracker');
      if (updated) {
        this.currentBooking = updated;
        this.renderBookingDetails(updated);
        window.dispatchEvent(new CustomEvent('bookingUpdated', { detail: updated }));
      }
    }
  },

  handleReviewSubmit() {
    if (!this.currentBooking) return;
    const rating = parseInt(document.getElementById('rating-score-input')?.value || 5);
    const comment = document.getElementById('review-comment-input')?.value.trim();

    const updated = StorageManager.addReview(this.currentBooking.id, rating, comment);
    if (updated) {
      this.currentBooking = updated;
      this.renderBookingDetails(updated);
      alert('Thank you! Your review has been published.');
      window.dispatchEvent(new CustomEvent('bookingUpdated', { detail: updated }));
    }
  }
};

// Export to window
if (typeof window !== 'undefined') {
  window.BookingTracker = BookingTracker;
}
