// PureNest Cleaning Services - Mock Data & Storage Controller

const SERVICES_DATA = [
  {
    id: 'standard',
    name: 'Standard Home Clean',
    tagline: 'Ideal for regular home maintenance and recurring refreshes',
    basePrice: 89,
    baseDuration: 2.5,
    icon: 'sparkles',
    popular: false,
    description: 'A thorough top-to-bottom clean covering all living areas, bedrooms, kitchen surfaces, and bathrooms.',
    included: [
      'Dusting and wiping all reachable surfaces',
      'Vacuuming rugs and mopping hard floors',
      'Scrubbing toilets, sinks, showers & bathtubs',
      'Emptying trash cans and replacing liners',
      'Making beds & straightening pillows',
      'Kitchen countertop, stove top & exterior appliances clean'
    ]
  },
  {
    id: 'deep',
    name: 'Deep Clean Intensive',
    tagline: 'Recommended for first-time cleans or homes not cleaned in 30+ days',
    basePrice: 149,
    baseDuration: 4.0,
    icon: 'shield-check',
    popular: true,
    description: 'Comprehensive deep sanitize targeting neglected spots, grout, baseboards, vents, and accumulated grime.',
    included: [
      'Everything in the Standard Home Clean',
      'Hand-washing baseboards, door frames & trim',
      'Scrubbing tile grout in kitchen & bathrooms',
      'Detailed dusting of ceiling fans, blinds & vents',
      'Deep scale and soap scum removal in bathrooms',
      'Behind and underneath furniture reachable'
    ]
  },
  {
    id: 'moveinout',
    name: 'Move-In / Move-Out Turnover',
    tagline: 'Full property turnover to ensure 100% deposit return or fresh start',
    basePrice: 199,
    baseDuration: 5.5,
    icon: 'truck',
    popular: false,
    description: 'Vacant property deep clean designed for tenants, landlords, and realtors. Leaves every inch showroom ready.',
    included: [
      'Full deep cleaning of all rooms',
      'Inside and outside of all empty cabinets & drawers',
      'Interior oven and refrigerator cleaning included',
      'Baseboards, light switches, and door frames',
      'Closet shelving and wardrobe wiping',
      'Window tracks, sills, and reachable interior glass'
    ]
  },
  {
    id: 'office',
    name: 'Commercial & Office Clean',
    tagline: 'Customized professional sanitization for workplaces & retail',
    basePrice: 179,
    baseDuration: 3.5,
    icon: 'briefcase',
    popular: false,
    description: 'Disinfection and cleanliness for offices, conference rooms, breakrooms, and reception spaces.',
    included: [
      'Desk surfaces & workstation sanitization',
      'Conference room reset and wipe down',
      'Breakroom counters, microwave & sink sanitize',
      'High-traffic floor vacuuming and mopping',
      'Commercial restroom deep sanitize & restock',
      'Recycling and trash disposal'
    ]
  },
  {
    id: 'postcon',
    name: 'Post-Renovation Clean',
    tagline: 'Specialized removal of drywall dust, paint marks, and debris',
    basePrice: 229,
    baseDuration: 5.0,
    icon: 'hammer',
    popular: false,
    description: 'Intensive post-construction dusting and detailed vacuuming with HEPA filtration equipment.',
    included: [
      'HEPA air & surface fine-dust removal',
      'Removal of stickers, tape residue & paint spatters',
      'Wiping light fixtures, vents, and outlets',
      'Floor buffing & deep mopping for construction residue',
      'Interior window cleaning & sill scrub',
      'Final touch-up ready for immediate occupancy'
    ]
  }
];

const ADDONS_DATA = [
  {
    id: 'fridge',
    name: 'Inside Refrigerator',
    price: 35,
    duration: 0.5,
    icon: 'refrigerator',
    desc: 'Shelves removed, washed, sanitized, and deodorized'
  },
  {
    id: 'oven',
    name: 'Inside Oven',
    price: 40,
    duration: 0.75,
    icon: 'flame',
    desc: 'Heavy-duty degreasing of racks, walls, and glass door'
  },
  {
    id: 'cabinets',
    name: 'Inside Kitchen Cabinets',
    price: 35,
    duration: 0.5,
    icon: 'archive',
    desc: 'Interior shelf dusting, wiping, and organization'
  },
  {
    id: 'windows',
    name: 'Interior Windows (Up to 10)',
    price: 45,
    duration: 0.75,
    icon: 'sun',
    desc: 'Streak-free glass cleaning, tracks and sills wiped'
  },
  {
    id: 'carpet',
    name: 'Deep Carpet Shampoo (Per Room)',
    price: 60,
    duration: 1.0,
    icon: 'waves',
    desc: 'Hot-water extraction removing deep stains & allergens'
  },
  {
    id: 'pet',
    name: 'Pet Hair & Odor Neutralizer',
    price: 25,
    duration: 0.5,
    icon: 'paw-print',
    desc: 'Specialized rubber brush treatment and pet-safe enzyme deodorizer'
  },
  {
    id: 'laundry',
    name: 'Wash, Dry & Fold Laundry (1 Load)',
    price: 30,
    duration: 1.0,
    icon: 'shirt',
    desc: 'Washing, machine drying, and neat garment folding'
  },
  {
    id: 'balcony',
    name: 'Balcony / Patio Sweep & Wash',
    price: 20,
    duration: 0.5,
    icon: 'leaf',
    desc: 'Debris removal, furniture wipe, and floor scrub'
  },
  {
    id: 'eco_steam',
    name: 'Eco Green Steam Sterilization',
    price: 25,
    duration: 0.5,
    icon: 'wind',
    desc: 'Chemical-free 220°F steam sanitization of high-touch zones'
  }
];

const CLEANERS_DATA = [
  {
    id: 'cleaner-1',
    name: 'Sarah Jenkins',
    badge: 'Master Cleaner',
    rating: 4.98,
    reviewsCount: 342,
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    experience: '6 Years',
    specialties: ['Deep Clean', 'Eco-friendly', 'Pet Friendly'],
    phone: '(555) 234-5678',
    status: 'Available'
  },
  {
    id: 'cleaner-2',
    name: 'Marcus Ramirez',
    badge: 'Top Rated Pro',
    rating: 4.95,
    reviewsCount: 288,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    experience: '5 Years',
    specialties: ['Move-In/Out', 'Carpet Shampoo', 'Appliance Detailing'],
    phone: '(555) 345-6789',
    status: 'On Job'
  },
  {
    id: 'cleaner-3',
    name: 'Elena Rostova',
    badge: 'Sanitization Expert',
    rating: 4.99,
    reviewsCount: 412,
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    experience: '7 Years',
    specialties: ['Post-Renovation', 'Commercial Office', 'Allergy-free'],
    phone: '(555) 456-7890',
    status: 'Available'
  },
  {
    id: 'cleaner-4',
    name: 'David Chen',
    badge: 'Fast & Thorough',
    rating: 4.92,
    reviewsCount: 195,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    experience: '4 Years',
    specialties: ['Standard Home', 'Windows & Blinds', 'Organization'],
    phone: '(555) 567-8901',
    status: 'Available'
  }
];

const INITIAL_BOOKINGS = [
  {
    id: 'PNC-78421',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 26).toISOString(),
    customer: {
      fullName: 'Alex Vance',
      email: 'alex.vance@example.com',
      phone: '(555) 987-6543',
      address: '742 Evergreen Terrace, Apt 4B',
      city: 'Springfield',
      postalCode: '97477',
      accessNotes: 'Buzzer #402. Gate code: 1984. Leave key with doorman if not home.'
    },
    serviceId: 'deep',
    serviceName: 'Deep Clean Intensive',
    bedrooms: 3,
    bathrooms: 2,
    sqft: '1400-1800',
    frequency: 'biweekly',
    frequencyDiscount: 0.15,
    addons: ['fridge', 'oven', 'windows'],
    addonsTotal: 120,
    date: new Date(Date.now() + 1000 * 60 * 60 * 18).toISOString().split('T')[0],
    timeSlot: 'Morning (8:00 AM - 11:00 AM)',
    ecoFriendly: true,
    hasPets: true,
    cleanerSupplies: true,
    specialNotes: 'Please focus on the kitchen stove backsplash and master shower grout.',
    promoCode: 'WELCOME25',
    promoDiscount: 25,
    subtotal: 319,
    tax: 23.52,
    total: 317.52,
    status: 'assigned', // pending, assigned, in_progress, completed, cancelled
    cleanerId: 'cleaner-1',
    cleanerName: 'Sarah Jenkins',
    paymentMethod: 'Credit Card (**** 4242)',
    paymentStatus: 'Paid',
    rating: null,
    review: null
  },
  {
    id: 'PNC-78422',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 12).toISOString(),
    customer: {
      fullName: 'Dr. Michael Sterling',
      email: 'm.sterling@example.com',
      phone: '(555) 876-5432',
      address: '125 Ocean Breeze Boulevard',
      city: 'Springfield',
      postalCode: '97478',
      accessNotes: 'Front keypad pin: 4321. Lockbox on side gate.'
    },
    serviceId: 'moveinout',
    serviceName: 'Move-In / Move-Out Turnover',
    bedrooms: 4,
    bathrooms: 3,
    sqft: '2200-2800',
    frequency: 'onetime',
    frequencyDiscount: 0,
    addons: ['carpet', 'windows', 'balcony'],
    addonsTotal: 125,
    date: new Date(Date.now() + 1000 * 60 * 60 * 42).toISOString().split('T')[0],
    timeSlot: 'Midday (11:30 AM - 2:30 PM)',
    ecoFriendly: true,
    hasPets: false,
    cleanerSupplies: true,
    specialNotes: 'House will be vacant. Inspection scheduled with realtor at 4 PM.',
    promoCode: '',
    promoDiscount: 0,
    subtotal: 404,
    tax: 32.32,
    total: 436.32,
    status: 'in_progress',
    cleanerId: 'cleaner-2',
    cleanerName: 'Marcus Ramirez',
    paymentMethod: 'Credit Card (**** 8831)',
    paymentStatus: 'Paid',
    rating: null,
    review: null
  },
  {
    id: 'PNC-78419',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 72).toISOString(),
    customer: {
      fullName: 'Sophia Martinez',
      email: 'sophia.m@example.com',
      phone: '(555) 765-4321',
      address: '58 Maple Avenue',
      city: 'Springfield',
      postalCode: '97477',
      accessNotes: 'Ring bell, I work from home in the attic office.'
    },
    serviceId: 'standard',
    serviceName: 'Standard Home Clean',
    bedrooms: 2,
    bathrooms: 1,
    sqft: '900-1200',
    frequency: 'weekly',
    frequencyDiscount: 0.20,
    addons: ['pet'],
    addonsTotal: 25,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString().split('T')[0],
    timeSlot: 'Morning (8:00 AM - 11:00 AM)',
    ecoFriendly: true,
    hasPets: true,
    cleanerSupplies: true,
    specialNotes: 'Golden Retriever in house, super friendly.',
    promoCode: '',
    promoDiscount: 0,
    subtotal: 139,
    tax: 11.12,
    total: 122.32,
    status: 'completed',
    cleanerId: 'cleaner-3',
    cleanerName: 'Elena Rostova',
    paymentMethod: 'Apple Pay',
    paymentStatus: 'Paid',
    rating: 5,
    review: 'Elena did a phenomenal job! My apartment has never smelled or looked so fresh. The pet hair is totally gone.'
  },
  {
    id: 'PNC-78425',
    createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    customer: {
      fullName: 'Jonathan Reed',
      email: 'jreed@synergytech.io',
      phone: '(555) 654-3210',
      address: '300 Innovation Way, Suite 500',
      city: 'Springfield',
      postalCode: '97479',
      accessNotes: 'Check in with security desk at ground floor for elevator badge.'
    },
    serviceId: 'office',
    serviceName: 'Commercial & Office Clean',
    bedrooms: 1, // serves as suites/zones
    bathrooms: 2,
    sqft: '2500+',
    frequency: 'weekly',
    frequencyDiscount: 0.20,
    addons: ['eco_steam'],
    addonsTotal: 25,
    date: new Date(Date.now() + 1000 * 60 * 60 * 64).toISOString().split('T')[0],
    timeSlot: 'Evening (6:00 PM - 8:30 PM)',
    ecoFriendly: true,
    hasPets: false,
    cleanerSupplies: true,
    specialNotes: 'Sanitize conference room table and all 25 keyboard surfaces.',
    promoCode: 'CSC407',
    promoDiscount: 30,
    subtotal: 224,
    tax: 17.92,
    total: 167.12,
    status: 'pending',
    cleanerId: null,
    cleanerName: 'Pending Assignment',
    paymentMethod: 'Invoice / Corporate Billing',
    paymentStatus: 'Pending',
    rating: null,
    review: null
  }
];

// Storage Helper with LocalStorage fallback
const StorageManager = {
  STORAGE_KEY: 'purenest_bookings_v1',
  REVIEWS_KEY: 'purenest_reviews_v1',

  getBookings() {
    try {
      const data = localStorage.getItem(this.STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.warn('LocalStorage read error:', e);
    }
    // Initialize with mock bookings
    this.saveBookings(INITIAL_BOOKINGS);
    return INITIAL_BOOKINGS;
  },

  saveBookings(bookings) {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(bookings));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }
  },

  getBookingById(id) {
    const bookings = this.getBookings();
    return bookings.find(b => b.id.toUpperCase() === id.trim().toUpperCase());
  },

  addBooking(booking) {
    const bookings = this.getBookings();
    bookings.unshift(booking);
    this.saveBookings(bookings);
    return booking;
  },

  updateBookingStatus(id, newStatus, cleanerId = null, cleanerName = null) {
    const bookings = this.getBookings();
    const index = bookings.findIndex(b => b.id.toUpperCase() === id.trim().toUpperCase());
    if (index !== -1) {
      bookings[index].status = newStatus;
      if (cleanerId) bookings[index].cleanerId = cleanerId;
      if (cleanerName) bookings[index].cleanerName = cleanerName;
      this.saveBookings(bookings);
      return bookings[index];
    }
    return null;
  },

  rescheduleBooking(id, newDate, newTimeSlot) {
    const bookings = this.getBookings();
    const index = bookings.findIndex(b => b.id.toUpperCase() === id.trim().toUpperCase());
    if (index !== -1) {
      bookings[index].date = newDate;
      bookings[index].timeSlot = newTimeSlot;
      this.saveBookings(bookings);
      return bookings[index];
    }
    return null;
  },

  cancelBooking(id, reason = 'Cancelled by customer') {
    const bookings = this.getBookings();
    const index = bookings.findIndex(b => b.id.toUpperCase() === id.trim().toUpperCase());
    if (index !== -1) {
      bookings[index].status = 'cancelled';
      bookings[index].cancellationReason = reason;
      this.saveBookings(bookings);
      return bookings[index];
    }
    return null;
  },

  addReview(bookingId, rating, reviewText) {
    const bookings = this.getBookings();
    const index = bookings.findIndex(b => b.id.toUpperCase() === bookingId.trim().toUpperCase());
    if (index !== -1) {
      bookings[index].rating = rating;
      bookings[index].review = reviewText;
      this.saveBookings(bookings);
      return bookings[index];
    }
    return null;
  },

  getStats() {
    const bookings = this.getBookings();
    const totalBookings = bookings.length;
    const completedBookings = bookings.filter(b => b.status === 'completed').length;
    const activeBookings = bookings.filter(b => ['pending', 'assigned', 'in_progress'].includes(b.status)).length;
    const grossRevenue = bookings
      .filter(b => b.status !== 'cancelled')
      .reduce((sum, b) => sum + (Number(b.total) || 0), 0);
    
    const rated = bookings.filter(b => b.rating);
    const avgRating = rated.length 
      ? (rated.reduce((sum, b) => sum + Number(b.rating), 0) / rated.length).toFixed(1)
      : '4.9';

    return {
      totalBookings,
      completedBookings,
      activeBookings,
      grossRevenue: grossRevenue.toFixed(2),
      avgRating
    };
  }
};

// Export to window
if (typeof window !== 'undefined') {
  window.SERVICES_DATA = SERVICES_DATA;
  window.ADDONS_DATA = ADDONS_DATA;
  window.CLEANERS_DATA = CLEANERS_DATA;
  window.StorageManager = StorageManager;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    SERVICES_DATA,
    ADDONS_DATA,
    CLEANERS_DATA,
    INITIAL_BOOKINGS,
    StorageManager
  };
}
