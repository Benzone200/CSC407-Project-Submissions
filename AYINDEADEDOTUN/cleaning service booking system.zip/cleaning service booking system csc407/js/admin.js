// PureNest - Staff & Operations Management Dashboard

const AdminPortal = {
  currentFilter: 'all',
  searchQuery: '',
  activeBookingForModal: null,

  init() {
    this.renderKPIs();
    this.renderBookingsTable();
    this.bindEvents();

    // Listen to updates from booking wizard and tracker
    window.addEventListener('bookingCreated', () => {
      this.refresh();
    });
    window.addEventListener('bookingUpdated', () => {
      this.refresh();
    });
  },

  refresh() {
    this.renderKPIs();
    this.renderBookingsTable();
  },

  bindEvents() {
    // Search input
    document.getElementById('admin-search-input')?.addEventListener('input', (e) => {
      this.searchQuery = e.target.value.toLowerCase().trim();
      this.renderBookingsTable();
    });

    // Status filter buttons
    document.querySelectorAll('.admin-filter-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.admin-filter-btn').forEach(b => {
          b.classList.remove('bg-emerald-600', 'text-white', 'shadow-sm');
          b.classList.add('bg-white', 'text-slate-600', 'hover:bg-slate-50');
        });
        const target = e.currentTarget;
        target.classList.remove('bg-white', 'text-slate-600', 'hover:bg-slate-50');
        target.classList.add('bg-emerald-600', 'text-white', 'shadow-sm');

        this.currentFilter = target.getAttribute('data-status');
        this.renderBookingsTable();
      });
    });

    // Export CSV
    document.getElementById('btn-admin-export-csv')?.addEventListener('click', () => {
      this.exportCSV();
    });

    // Save cleaner assignment
    document.getElementById('form-assign-cleaner')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.saveCleanerAssignment();
    });

    // Save status update
    document.getElementById('form-update-status')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.saveStatusUpdate();
    });
  },

  renderKPIs() {
    const stats = StorageManager.getStats();

    const setText = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    setText('kpi-total-bookings', stats.totalBookings);
    setText('kpi-gross-revenue', `$${Number(stats.grossRevenue).toLocaleString()}`);
    setText('kpi-active-jobs', stats.activeBookings);
    setText('kpi-avg-rating', `★ ${stats.avgRating}`);
  },

  renderBookingsTable() {
    const tbody = document.getElementById('admin-bookings-tbody');
    if (!tbody) return;

    let bookings = StorageManager.getBookings();

    // Filter by status tab
    if (this.currentFilter !== 'all') {
      bookings = bookings.filter(b => b.status === this.currentFilter);
    }

    // Filter by search query
    if (this.searchQuery) {
      bookings = bookings.filter(b => 
        b.id.toLowerCase().includes(this.searchQuery) ||
        b.customer.fullName.toLowerCase().includes(this.searchQuery) ||
        b.customer.email.toLowerCase().includes(this.searchQuery) ||
        b.customer.city.toLowerCase().includes(this.searchQuery) ||
        b.serviceName.toLowerCase().includes(this.searchQuery)
      );
    }

    if (bookings.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7" class="py-12 text-center text-slate-400">
            <i data-lucide="inbox" class="w-10 h-10 mx-auto mb-2 opacity-50"></i>
            <p class="font-medium">No bookings match your current filter</p>
          </td>
        </tr>
      `;
      if (window.lucide) window.lucide.createIcons();
      return;
    }

    tbody.innerHTML = bookings.map(b => {
      const statusBadge = this.getStatusBadge(b.status);
      const isCompleted = b.status === 'completed';
      const isCancelled = b.status === 'cancelled';

      return `
        <tr class="hover:bg-slate-50/70 border-b border-slate-100 transition-colors">
          <td class="py-3 px-4 font-mono font-bold text-xs text-slate-800">
            <button class="text-emerald-700 hover:underline view-booking-link" data-id="${b.id}">${b.id}</button>
          </td>
          <td class="py-3 px-4">
            <div class="font-semibold text-sm text-slate-900">${b.customer.fullName}</div>
            <div class="text-xs text-slate-500">${b.customer.phone} • ${b.customer.city}</div>
          </td>
          <td class="py-3 px-4">
            <div class="text-sm font-medium text-slate-800">${b.serviceName}</div>
            <div class="text-xs text-slate-500">${b.bedrooms} Bed, ${b.bathrooms} Bath • ${b.frequency}</div>
          </td>
          <td class="py-3 px-4">
            <div class="text-sm font-semibold text-slate-800">${b.date}</div>
            <div class="text-xs text-slate-500">${b.timeSlot}</div>
          </td>
          <td class="py-3 px-4">
            <div class="text-xs font-medium text-slate-800 flex items-center gap-1.5">
              <i data-lucide="user-check" class="w-3.5 h-3.5 text-slate-400"></i>
              <span>${b.cleanerName || '<span class="text-amber-600 font-semibold italic">Unassigned</span>'}</span>
            </div>
          </td>
          <td class="py-3 px-4">
            <div class="text-sm font-bold text-slate-900">$${Number(b.total).toFixed(2)}</div>
            <div class="text-xs text-emerald-600">${b.paymentStatus || 'Paid'}</div>
          </td>
          <td class="py-3 px-4">
            ${statusBadge}
          </td>
          <td class="py-3 px-4 text-right">
            <div class="flex items-center justify-end gap-1.5">
              <button class="btn-action-view p-1.5 rounded-lg hover:bg-slate-200 text-slate-600 transition" title="View Full Details" data-id="${b.id}">
                <i data-lucide="eye" class="w-4 h-4"></i>
              </button>
              <button class="btn-action-assign p-1.5 rounded-lg hover:bg-emerald-50 text-emerald-700 transition" title="Assign Cleaner" data-id="${b.id}">
                <i data-lucide="user-plus" class="w-4 h-4"></i>
              </button>
              <button class="btn-action-status p-1.5 rounded-lg hover:bg-blue-50 text-blue-700 transition" title="Update Status" data-id="${b.id}">
                <i data-lucide="refresh-cw" class="w-4 h-4"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

    if (window.lucide) window.lucide.createIcons();

    // Bind action buttons in table
    tbody.querySelectorAll('.btn-action-view, .view-booking-link').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.currentTarget.getAttribute('data-id');
        this.openDetailsModal(id);
      });
    });

    tbody.querySelectorAll('.btn-action-assign').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.currentTarget.getAttribute('data-id');
        this.openAssignModal(id);
      });
    });

    tbody.querySelectorAll('.btn-action-status').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.currentTarget.getAttribute('data-id');
        this.openStatusModal(id);
      });
    });
  },

  getStatusBadge(status) {
    const badges = {
      'pending': '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800">Pending</span>',
      'assigned': '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800">Assigned</span>',
      'dispatched': '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-800">En Route</span>',
      'in_progress': '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-800 animate-pulse">In Progress</span>',
      'completed': '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">Completed</span>',
      'cancelled': '<span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-100 text-rose-800">Cancelled</span>'
    };
    return badges[status] || badges['pending'];
  },

  openDetailsModal(bookingId) {
    const booking = StorageManager.getBookingById(bookingId);
    if (!booking) return;

    this.activeBookingForModal = booking;
    const modal = document.getElementById('admin-details-modal');
    if (!modal) return;

    document.getElementById('modal-det-id').textContent = booking.id;
    document.getElementById('modal-det-status').innerHTML = this.getStatusBadge(booking.status);
    document.getElementById('modal-det-created').textContent = new Date(booking.createdAt).toLocaleString();
    document.getElementById('modal-det-name').textContent = booking.customer.fullName;
    document.getElementById('modal-det-email').textContent = booking.customer.email;
    document.getElementById('modal-det-phone').textContent = booking.customer.phone;
    document.getElementById('modal-det-address').textContent = `${booking.customer.address}, ${booking.customer.apartment ? booking.customer.apartment + ', ' : ''}${booking.customer.city} ${booking.customer.postalCode}`;
    document.getElementById('modal-det-service').textContent = booking.serviceName;
    document.getElementById('modal-det-schedule').textContent = `${booking.date} (${booking.timeSlot})`;
    document.getElementById('modal-det-cleaner').textContent = booking.cleanerName || 'None assigned yet';
    document.getElementById('modal-det-notes').textContent = booking.specialNotes || 'No special instructions.';
    document.getElementById('modal-det-access').textContent = booking.customer.accessNotes || 'No gate/access notes.';
    document.getElementById('modal-det-total').textContent = `$${Number(booking.total).toFixed(2)}`;
    document.getElementById('modal-det-payment').textContent = `${booking.paymentMethod} (${booking.paymentStatus})`;

    // Addons
    const extrasBox = document.getElementById('modal-det-addons');
    if (extrasBox) {
      if (booking.addons && booking.addons.length > 0) {
        extrasBox.innerHTML = booking.addons.map(id => {
          const a = ADDONS_DATA.find(item => item.id === id);
          return `<span class="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-xs">${a ? a.name : id}</span>`;
        }).join(' ');
      } else {
        extrasBox.textContent = 'None';
      }
    }

    modal.showModal();
  },

  openAssignModal(bookingId) {
    const booking = StorageManager.getBookingById(bookingId);
    if (!booking) return;

    this.activeBookingForModal = booking;
    const modal = document.getElementById('admin-assign-cleaner-modal');
    if (!modal) return;

    document.getElementById('assign-modal-booking-id').textContent = booking.id;
    document.getElementById('assign-modal-customer').textContent = `${booking.customer.fullName} • ${booking.serviceName} on ${booking.date}`;

    const select = document.getElementById('assign-cleaner-select');
    if (select) {
      select.innerHTML = CLEANERS_DATA.map(c => `
        <option value="${c.id}" ${booking.cleanerId === c.id ? 'selected' : ''}>
          ${c.name} (${c.badge} - ★ ${c.rating}) - ${c.status}
        </option>
      `).join('');
    }

    modal.showModal();
  },

  saveCleanerAssignment() {
    if (!this.activeBookingForModal) return;
    const cleanerId = document.getElementById('assign-cleaner-select')?.value;
    const cleaner = CLEANERS_DATA.find(c => c.id === cleanerId);

    if (cleaner) {
      const updated = StorageManager.updateBookingStatus(
        this.activeBookingForModal.id, 
        this.activeBookingForModal.status === 'pending' ? 'assigned' : this.activeBookingForModal.status,
        cleaner.id,
        cleaner.name
      );

      document.getElementById('admin-assign-cleaner-modal')?.close();
      this.refresh();
      window.dispatchEvent(new CustomEvent('bookingUpdated', { detail: updated }));
    }
  },

  openStatusModal(bookingId) {
    const booking = StorageManager.getBookingById(bookingId);
    if (!booking) return;

    this.activeBookingForModal = booking;
    const modal = document.getElementById('admin-update-status-modal');
    if (!modal) return;

    document.getElementById('status-modal-booking-id').textContent = booking.id;
    const select = document.getElementById('update-status-select');
    if (select) {
      select.value = booking.status;
    }

    modal.showModal();
  },

  saveStatusUpdate() {
    if (!this.activeBookingForModal) return;
    const newStatus = document.getElementById('update-status-select')?.value;

    const updated = StorageManager.updateBookingStatus(
      this.activeBookingForModal.id,
      newStatus
    );

    document.getElementById('admin-update-status-modal')?.close();
    this.refresh();
    window.dispatchEvent(new CustomEvent('bookingUpdated', { detail: updated }));
  },

  exportCSV() {
    const bookings = StorageManager.getBookings();
    if (!bookings.length) {
      alert('No booking records to export.');
      return;
    }

    const headers = [
      'Booking ID',
      'Created Date',
      'Customer Name',
      'Email',
      'Phone',
      'Address',
      'City',
      'Service',
      'Bedrooms',
      'Bathrooms',
      'Clean Date',
      'Time Slot',
      'Cleaner Assigned',
      'Total Price',
      'Status',
      'Rating'
    ];

    const rows = bookings.map(b => [
      `"${b.id}"`,
      `"${b.createdAt}"`,
      `"${b.customer.fullName.replace(/"/g, '""')}"`,
      `"${b.customer.email}"`,
      `"${b.customer.phone}"`,
      `"${b.customer.address.replace(/"/g, '""')}"`,
      `"${b.customer.city}"`,
      `"${b.serviceName}"`,
      b.bedrooms,
      b.bathrooms,
      `"${b.date}"`,
      `"${b.timeSlot}"`,
      `"${b.cleanerName || 'Unassigned'}"`,
      Number(b.total).toFixed(2),
      `"${b.status}"`,
      b.rating || 'N/A'
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `PureNest_Bookings_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};

// Export to window
if (typeof window !== 'undefined') {
  window.AdminPortal = AdminPortal;
}
