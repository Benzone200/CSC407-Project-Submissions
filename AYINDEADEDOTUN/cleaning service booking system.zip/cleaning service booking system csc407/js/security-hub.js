// PureNest - Web Application Security Hub & Interactive Defense Playground
// Demonstrates OWASP Top 10 defenses, live XSS/SQLi sanitization, and security logs

const SecurityHub = {
  init() {
    this.renderAuditLogs();
    this.bindEvents();

    window.addEventListener('auditLogAdded', () => {
      this.renderAuditLogs();
    });
  },

  bindEvents() {
    // Live XSS Playground
    document.getElementById('btn-test-xss')?.addEventListener('click', () => {
      this.runXssTest();
    });

    // Preset XSS payloads
    document.querySelectorAll('.xss-preset-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const payload = e.currentTarget.getAttribute('data-payload');
        const input = document.getElementById('xss-test-input');
        if (input) {
          input.value = payload;
          this.runXssTest();
        }
      });
    });

    // Live SQLi Playground
    document.getElementById('btn-test-sqli')?.addEventListener('click', () => {
      this.runSqliTest();
    });

    // Preset SQLi payloads
    document.querySelectorAll('.sqli-preset-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const payload = e.currentTarget.getAttribute('data-payload');
        const input = document.getElementById('sqli-test-input');
        if (input) {
          input.value = payload;
          this.runSqliTest();
        }
      });
    });

    // Password Hash Visualizer
    document.getElementById('hash-test-input')?.addEventListener('input', (e) => {
      this.visualizeHash(e.target.value);
    });

    // RBAC Route Privilege Tester
    document.getElementById('btn-test-rbac')?.addEventListener('click', () => {
      this.testRbacRoute();
    });

    // Clear Audit Logs
    document.getElementById('btn-clear-audit-logs')?.addEventListener('click', () => {
      if (confirm('Clear security event audit trail?')) {
        localStorage.removeItem(AuthManager.AUDIT_KEY);
        this.renderAuditLogs();
        if (window.showToast) window.showToast('Audit logs cleared.');
      }
    });
  },

  runXssTest() {
    const input = document.getElementById('xss-test-input')?.value || '<script>alert("XSS Vulnerability")</script>';
    const sanitized = AuthManager.sanitizeInput(input);

    const rawPreview = document.getElementById('xss-raw-output');
    const safePreview = document.getElementById('xss-safe-output');
    const statusNotice = document.getElementById('xss-status-notice');

    if (rawPreview) rawPreview.textContent = input;
    if (safePreview) safePreview.textContent = sanitized;

    if (statusNotice) {
      statusNotice.innerHTML = `
        <div class="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-start gap-2">
          <i data-lucide="shield-check" class="w-4 h-4 text-emerald-600 shrink-0 mt-0.5"></i>
          <div>
            <strong>Attack Neutralized!</strong> Special characters &lt;, &gt;, &quot;, and &#x27; were successfully encoded to safe HTML entities. The browser parser treats this as benign plain text without executing scripts.
          </div>
        </div>
      `;
      if (window.lucide) window.lucide.createIcons();
    }

    AuthManager.addAuditLog('XSS_ATTACK_NEUTRALIZED', `Sanitized malicious input: "${input.substring(0, 30)}..."`, 'BLOCKED', '127.0.0.1');
  },

  runSqliTest() {
    const input = document.getElementById('sqli-test-input')?.value || "' OR '1'='1";
    const statusNotice = document.getElementById('sqli-status-notice');
    const queryDisplay = document.getElementById('sqli-query-display');

    if (queryDisplay) {
      queryDisplay.innerHTML = `
        <span class="text-blue-400">SELECT</span> * <span class="text-blue-400">FROM</span> bookings <br>
        <span class="text-blue-400">WHERE</span> customer_email = <span class="text-emerald-400">?</span> 
        <span class="text-slate-400 text-[10px] block mt-1">Bound Parameter: "${input}" (Strict String Literal)</span>
      `;
    }

    if (statusNotice) {
      statusNotice.innerHTML = `
        <div class="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-start gap-2">
          <i data-lucide="shield-check" class="w-4 h-4 text-emerald-600 shrink-0 mt-0.5"></i>
          <div>
            <strong>SQL Injection Prevented!</strong> Parameterized prepared statements isolate code from user parameters. The input <code>${input}</code> is passed solely as a literal string value, preventing boolean evasion or tautologies.
          </div>
        </div>
      `;
      if (window.lucide) window.lucide.createIcons();
    }

    AuthManager.addAuditLog('SQLI_PROBE_BLOCKED', `Parameterized query prevented SQLi attempt: "${input}"`, 'BLOCKED', '127.0.0.1');
  },

  async visualizeHash(password) {
    if (!password) {
      document.getElementById('hash-val-salt').textContent = '-';
      document.getElementById('hash-val-digest').textContent = '-';
      return;
    }

    const salt = AuthManager.generateSalt(16);
    const digest = await AuthManager.hashPassword(password, salt);

    const saltEl = document.getElementById('hash-val-salt');
    const digestEl = document.getElementById('hash-val-digest');

    if (saltEl) saltEl.textContent = salt;
    if (digestEl) digestEl.textContent = digest;
  },

  testRbacRoute() {
    const simulatedRole = document.getElementById('rbac-sim-role')?.value || 'user';
    const targetRoute = document.getElementById('rbac-sim-route')?.value || '/admin';
    const resultBox = document.getElementById('rbac-test-result');

    if (!resultBox) return;

    let isAllowed = false;
    let reason = '';

    if (targetRoute.startsWith('/admin')) {
      if (simulatedRole === 'admin') {
        isAllowed = true;
      } else {
        isAllowed = false;
        reason = simulatedRole === 'guest' ? '401 Unauthorized (Login required)' : '403 Forbidden (Admin privilege required)';
      }
    } else if (targetRoute.startsWith('/profile')) {
      if (simulatedRole !== 'guest') {
        isAllowed = true;
      } else {
        isAllowed = false;
        reason = '401 Unauthorized (Must sign in to view personal profile)';
      }
    } else {
      isAllowed = true; // public routes
    }

    if (isAllowed) {
      resultBox.innerHTML = `
        <div class="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
          <span><strong>Access Granted (200 OK):</strong> Role <strong>${simulatedRole}</strong> holds sufficient authorization for <code>${targetRoute}</code>.</span>
        </div>
      `;
    } else {
      resultBox.innerHTML = `
        <div class="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
          <span><strong>Access Denied (${reason}):</strong> Role <strong>${simulatedRole}</strong> attempted privilege escalation to <code>${targetRoute}</code>. Security exception logged.</span>
        </div>
      `;
      AuthManager.addAuditLog('RBAC_VIOLATION_BLOCKED', `Simulated privilege escalation blocked: [${simulatedRole}] -> ${targetRoute}`, 'SECURITY_ALERT', '127.0.0.1');
    }
  },

  renderAuditLogs() {
    const container = document.getElementById('security-audit-tbody');
    if (!container) return;

    const logs = AuthManager.getAuditLogs();
    if (!logs.length) {
      container.innerHTML = `<tr><td colspan="5" class="py-8 text-center text-slate-400">No security audit events recorded yet.</td></tr>`;
      return;
    }

    container.innerHTML = logs.slice(0, 15).map(log => {
      let badgeClass = 'bg-slate-100 text-slate-800';
      if (log.status === 'SUCCESS') badgeClass = 'bg-emerald-100 text-emerald-800';
      else if (log.status === 'BLOCKED') badgeClass = 'bg-amber-100 text-amber-800';
      else if (log.status === 'SECURITY_ALERT' || log.status === 'FAILED') badgeClass = 'bg-rose-100 text-rose-800 font-bold';

      const time = new Date(log.timestamp).toLocaleTimeString();

      return `
        <tr class="hover:bg-slate-50 border-b border-slate-100 text-xs font-mono">
          <td class="py-2.5 px-3 text-slate-500 whitespace-nowrap">${time}</td>
          <td class="py-2.5 px-3 font-bold text-slate-900">${log.event}</td>
          <td class="py-2.5 px-3 text-slate-700 font-sans max-w-sm truncate" title="${log.details}">${log.details}</td>
          <td class="py-2.5 px-3 text-slate-500">${log.ip}</td>
          <td class="py-2.5 px-3 text-right">
            <span class="px-2 py-0.5 rounded-full text-[10px] ${badgeClass}">${log.status}</span>
          </td>
        </tr>
      `;
    }).join('');
  }
};

if (typeof window !== 'undefined') {
  window.SecurityHub = SecurityHub;
}
