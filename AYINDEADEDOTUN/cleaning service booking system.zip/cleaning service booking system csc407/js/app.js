// PureNest Cleaning Services - Master Application Controller

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Lucide icons
  if (window.lucide) {
    window.lucide.createIcons();
  }

  // Initialize Modules
  const wizard = new BookingWizard();
  window.BookingWizardInstance = wizard;

  BookingTracker.init();
  AdminPortal.init();
  AuthManager.init();
  TestingSuite.init();
  SecurityHub.init();

  if (window.VirtualConcierge) {
    window.VirtualConcierge.init();
  }

  // Navigation, Multi-View Switcher & Auth
  setupMultiViewNavigation();
  setupAuthUI();
  setupQuickCalculator(wizard);
  setupServiceCards(wizard);
  setupFaqAccordion();
  setupModals();
  setupToastSystem();
  setupBeforeAfterSlider();
  setupChecklistTabs();
  setupSavingsCalculator();
  setupCleanerTeamActions(wizard);
  setupAdminManualBooking();
});

// Multi-View Page Switcher (Home, Security Hub, Testing, Deployment, Review, Admin)
function setupMultiViewNavigation() {
  const views = [
    'view-customer',
    'view-security',
    'view-testing',
    'view-deployment',
    'view-review',
    'view-admin'
  ];

  window.switchView = function(viewId) {
    // RBAC Route Guard for Admin Portal
    if (viewId === 'view-admin') {
      const check = AuthManager.requireRole('admin');
      if (!check.allowed) {
        const deniedModal = document.getElementById('access-denied-modal');
        if (deniedModal) {
          const reasonText = document.getElementById('denied-reason-text');
          if (reasonText) {
            reasonText.textContent = check.reason === 'unauthenticated'
              ? '401 Unauthorized: You must be logged in as an Administrator to view the Operations Dashboard.'
              : '403 Forbidden: Your current account role does not have Administrator privileges.';
          }
          deniedModal.showModal();
        }
        return;
      }
    }

    views.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        if (id === viewId) {
          el.classList.remove('hidden');
        } else {
          el.classList.add('hidden');
        }
      }
    });

    // Update active state on nav links
    document.querySelectorAll('.view-nav-link').forEach(link => {
      if (link.getAttribute('data-view') === viewId) {
        link.classList.add('text-emerald-600', 'font-extrabold', 'border-b-2', 'border-emerald-600');
        link.classList.remove('text-slate-600');
      } else {
        link.classList.remove('text-emerald-600', 'font-extrabold', 'border-b-2', 'border-emerald-600');
        link.classList.add('text-slate-600');
      }
    });

    // Trigger refreshes for specific views
    if (viewId === 'view-admin') AdminPortal.refresh();
    if (viewId === 'view-testing') TestingSuite.renderTestTable();
    if (viewId === 'view-security') SecurityHub.renderAuditLogs();

    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (window.lucide) window.lucide.createIcons();
  };

  // Nav Links click
  document.querySelectorAll('.view-nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetView = link.getAttribute('data-view');
      window.switchView(targetView);
    });
  });

  // Track Booking Modal trigger
  document.getElementById('nav-btn-track')?.addEventListener('click', () => {
    document.getElementById('tracker-modal')?.showModal();
  });

  // Return to customer view from other views
  document.querySelectorAll('.btn-return-home').forEach(btn => {
    btn.addEventListener('click', () => window.switchView('view-customer'));
  });

  // Mobile drawer controls
  const mobileDrawer = document.getElementById('mobile-drawer');
  document.getElementById('btn-mobile-menu')?.addEventListener('click', () => {
    mobileDrawer?.classList.remove('translate-x-full');
  });
  document.getElementById('btn-close-mobile-drawer')?.addEventListener('click', () => {
    mobileDrawer?.classList.add('translate-x-full');
  });

  // Mobile drawer view links
  document.querySelectorAll('.mobile-view-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetView = link.getAttribute('data-view');
      mobileDrawer?.classList.add('translate-x-full');
      window.switchView(targetView);
    });
  });

  // Smooth scroll to booking
  document.querySelectorAll('.btn-scroll-book').forEach(btn => {
    btn.addEventListener('click', () => {
      window.switchView('view-customer');
      const target = document.getElementById('booking-wizard-section');
      if (target) target.scrollIntoView({ behavior: 'smooth' });
    });
  });
}

// Authentication UI & Session State
function setupAuthUI() {
  const updateAuthDisplay = () => {
    const session = AuthManager.getSession();
    const guestNav = document.getElementById('nav-auth-guest');
    const userNav = document.getElementById('nav-auth-user');
    const userBadge = document.getElementById('nav-user-badge');
    const userName = document.getElementById('nav-user-name');
    const userRole = document.getElementById('nav-user-role');
    const userInitials = document.getElementById('nav-user-initials');

    if (session) {
      if (guestNav) guestNav.classList.add('hidden');
      if (userNav) userNav.classList.remove('hidden');
      if (userName) userName.textContent = session.fullName;
      if (userRole) userRole.textContent = session.role.toUpperCase();
      if (userInitials) {
        const parts = session.fullName.split(' ');
        userInitials.textContent = parts.map(p => p[0]).join('').substring(0, 2).toUpperCase();
      }
      if (userBadge) {
        if (session.role === 'admin') userBadge.className = 'w-7 h-7 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-xs';
        else if (session.role === 'cleaner') userBadge.className = 'w-7 h-7 rounded-full bg-teal-600 text-white font-bold flex items-center justify-center text-xs';
        else userBadge.className = 'w-7 h-7 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-xs';
      }
    } else {
      if (guestNav) guestNav.classList.remove('hidden');
      if (userNav) userNav.classList.add('hidden');
    }
  };

  updateAuthDisplay();
  window.addEventListener('authStateChanged', updateAuthDisplay);

  // Open Login Modal
  document.querySelectorAll('.btn-open-login').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById('auth-register-modal')?.close();
      document.getElementById('auth-login-modal')?.showModal();
    });
  });

  // Open Register Modal
  document.querySelectorAll('.btn-open-register').forEach(btn => {
    btn.addEventListener('click', () => {
      document.getElementById('auth-login-modal')?.close();
      document.getElementById('auth-register-modal')?.showModal();
    });
  });

  // Quick-fill Demo Credentials
  document.querySelectorAll('.demo-creds-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const email = e.currentTarget.getAttribute('data-email');
      const pass = e.currentTarget.getAttribute('data-pass');
      const emailInput = document.getElementById('login-email');
      const passInput = document.getElementById('login-password');
      if (emailInput && passInput) {
        emailInput.value = email;
        passInput.value = pass;
      }
      AuthManager.resetLockout(email);
      const errorEl = document.getElementById('login-error-msg');
      if (errorEl) errorEl.classList.add('hidden');
    });
  });

  // Login Form Submit
  document.getElementById('form-login')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email')?.value.trim();
    const pass = document.getElementById('login-password')?.value;
    const errorEl = document.getElementById('login-error-msg');

    const result = await AuthManager.login(email, pass);
    if (result.success) {
      document.getElementById('auth-login-modal')?.close();
      if (window.showToast) window.showToast(`Welcome back, ${result.user.fullName}!`);
      if (errorEl) errorEl.classList.add('hidden');
    } else {
      if (errorEl) {
        errorEl.textContent = result.error;
        errorEl.classList.remove('hidden');
      }
    }
  });

  // Password Strength Meter in Registration Form
  document.getElementById('reg-password')?.addEventListener('input', (e) => {
    const val = e.target.value;
    const meter = document.getElementById('reg-password-meter');
    const label = document.getElementById('reg-password-label');
    if (!meter || !label) return;

    let score = 0;
    if (val.length >= 8) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;

    const colors = ['w-1/4 bg-rose-500', 'w-2/4 bg-amber-500', 'w-3/4 bg-teal-500', 'w-full bg-emerald-500'];
    const texts = ['Weak (Needs 8+ chars & variety)', 'Fair', 'Good', 'Strong & Secure'];

    meter.className = `h-1.5 rounded-full transition-all duration-300 ${colors[Math.max(0, score - 1)] || 'w-0'}`;
    label.textContent = val ? texts[Math.max(0, score - 1)] : '';
  });

  // Register Form Submit
  document.getElementById('form-register')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('reg-fullname')?.value;
    const email = document.getElementById('reg-email')?.value;
    const phone = document.getElementById('reg-phone')?.value;
    const address = document.getElementById('reg-address')?.value;
    const city = document.getElementById('reg-city')?.value || 'Springfield';
    const postal = document.getElementById('reg-postal')?.value || '97477';
    const pass = document.getElementById('reg-password')?.value;
    const confirmPass = document.getElementById('reg-confirm-password')?.value;
    const errorEl = document.getElementById('reg-error-msg');

    if (pass !== confirmPass) {
      if (errorEl) {
        errorEl.textContent = 'Passwords do not match.';
        errorEl.classList.remove('hidden');
      }
      return;
    }

    const result = await AuthManager.register(name, email, phone, address, city, postal, pass);
    if (result.success) {
      document.getElementById('auth-register-modal')?.close();
      if (window.showToast) window.showToast(`Account registered successfully! Logged in as ${result.user.fullName}.`);
      if (errorEl) errorEl.classList.add('hidden');
    } else {
      if (errorEl) {
        errorEl.textContent = result.error;
        errorEl.classList.remove('hidden');
      }
    }
  });

  // Profile Modal & Edit Form
  document.getElementById('btn-open-profile')?.addEventListener('click', () => {
    openProfileModal();
  });

  // Change Password Form in Profile
  document.getElementById('form-change-password')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const session = AuthManager.getSession();
    if (!session) return;

    const curr = document.getElementById('profile-curr-pass')?.value;
    const next = document.getElementById('profile-new-pass')?.value;
    const errorEl = document.getElementById('change-pass-msg');

    const res = await AuthManager.changePassword(session.userId, curr, next);
    if (res.success) {
      if (errorEl) {
        errorEl.textContent = 'Password successfully updated!';
        errorEl.className = 'text-xs text-emerald-600 font-semibold block mt-1';
      }
      document.getElementById('form-change-password').reset();
    } else {
      if (errorEl) {
        errorEl.textContent = res.error;
        errorEl.className = 'text-xs text-rose-600 font-semibold block mt-1';
      }
    }
  });

  // Logout button
  document.querySelectorAll('.btn-logout-action').forEach(btn => {
    btn.addEventListener('click', () => {
      AuthManager.logout();
      window.switchView('view-customer');
      if (window.showToast) window.showToast('You have been signed out successfully.');
    });
  });
}

function openProfileModal() {
  const session = AuthManager.getSession();
  if (!session) return;

  const users = AuthManager.getUsers();
  const user = users.find(u => u.id === session.userId) || session;

  const modal = document.getElementById('user-profile-modal');
  if (!modal) return;

  document.getElementById('prof-name-display').textContent = user.fullName;
  document.getElementById('prof-email-display').textContent = user.email;
  document.getElementById('prof-role-badge').textContent = user.role.toUpperCase();

  const nameInput = document.getElementById('prof-edit-name');
  const phoneInput = document.getElementById('prof-edit-phone');
  const addressInput = document.getElementById('prof-edit-address');

  if (nameInput) nameInput.value = user.fullName || '';
  if (phoneInput) phoneInput.value = user.phone || '';
  if (addressInput) addressInput.value = user.address || '';

  // Render user's bookings history
  const historyContainer = document.getElementById('prof-bookings-history');
  if (historyContainer) {
    const allBookings = StorageManager.getBookings();
    const userBookings = allBookings.filter(b => b.customer.email.toLowerCase() === user.email.toLowerCase());

    if (!userBookings.length) {
      historyContainer.innerHTML = '<p class="text-xs text-slate-400 italic">No bookings on record under this email address.</p>';
    } else {
      historyContainer.innerHTML = userBookings.map(b => `
        <div class="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
          <div>
            <span class="font-mono font-bold text-slate-800">${b.id}</span>
            <span class="text-slate-500 block">${b.serviceName} • ${b.date}</span>
          </div>
          <div class="text-right">
            <span class="font-bold text-slate-900">$${Number(b.total).toFixed(2)}</span>
            <span class="block text-[11px] font-semibold text-emerald-700">${b.status}</span>
          </div>
        </div>
      `).join('');
    }
  }

  modal.showModal();
}


// Homepage Quick Cost Estimator
function setupQuickCalculator(wizard) {
  const serviceSelect = document.getElementById('calc-service');
  const bedsSelect = document.getElementById('calc-beds');
  const bathsSelect = document.getElementById('calc-baths');
  const freqSelect = document.getElementById('calc-freq');
  const priceDisplay = document.getElementById('calc-price-display');
  const btnApplyCalc = document.getElementById('btn-calc-continue');

  if (!serviceSelect || !priceDisplay) return;

  const calculateQuickEstimate = () => {
    const serviceId = serviceSelect.value;
    const service = SERVICES_DATA.find(s => s.id === serviceId) || SERVICES_DATA[0];
    const beds = parseInt(bedsSelect.value) || 2;
    const baths = parseInt(bathsSelect.value) || 2;
    const freq = freqSelect.value;

    let base = service.basePrice;
    let extraBeds = Math.max(0, beds - 1) * 20;
    let extraBaths = Math.max(0, baths - 1) * 25;
    let subtotal = base + extraBeds + extraBaths;

    let discount = 0;
    if (freq === 'weekly') discount = 0.20;
    else if (freq === 'biweekly') discount = 0.15;
    else if (freq === 'monthly') discount = 0.10;

    let discounted = subtotal * (1 - discount);
    let totalWithTax = discounted * 1.08;

    priceDisplay.textContent = `$${Math.round(totalWithTax)}`;
  };

  serviceSelect.addEventListener('change', calculateQuickEstimate);
  bedsSelect.addEventListener('change', calculateQuickEstimate);
  bathsSelect.addEventListener('change', calculateQuickEstimate);
  freqSelect.addEventListener('change', calculateQuickEstimate);

  // Initial calculation
  calculateQuickEstimate();

  // Apply to Booking Wizard
  btnApplyCalc?.addEventListener('click', () => {
    wizard.selectService(serviceSelect.value);
    wizard.state.bedrooms = parseInt(bedsSelect.value);
    wizard.state.bathrooms = parseInt(bathsSelect.value);
    
    const freq = freqSelect.value;
    wizard.state.frequency = freq;
    wizard.state.frequencyDiscountPct = freq === 'weekly' ? 0.20 : freq === 'biweekly' ? 0.15 : freq === 'monthly' ? 0.10 : 0;

    // Update wizard frequency card visual
    document.querySelectorAll('.frequency-card').forEach(c => {
      if (c.getAttribute('data-freq') === freq) {
        c.classList.add('border-emerald-600', 'bg-emerald-50/60', 'ring-2', 'ring-emerald-500/20');
        c.classList.remove('border-slate-200', 'bg-white');
      } else {
        c.classList.remove('border-emerald-600', 'bg-emerald-50/60', 'ring-2', 'ring-emerald-500/20');
        c.classList.add('border-slate-200', 'bg-white');
      }
    });

    // Update beds/baths UI in wizard
    const bedEl = document.getElementById('val-bedrooms');
    if (bedEl) bedEl.textContent = `${wizard.state.bedrooms} ${wizard.state.bedrooms === 1 ? 'Bed' : 'Beds'}`;
    const bathEl = document.getElementById('val-bathrooms');
    if (bathEl) bathEl.textContent = `${wizard.state.bathrooms} ${wizard.state.bathrooms === 1 ? 'Bath' : 'Baths'}`;

    wizard.updateCalculations();

    // Scroll down to booking wizard
    const section = document.getElementById('booking-wizard-section');
    section?.scrollIntoView({ behavior: 'smooth' });
  });
}

// Service Cards click-to-book and details modal
function setupServiceCards(wizard) {
  const serviceDetailModal = document.getElementById('service-detail-modal');

  document.querySelectorAll('.btn-service-details').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const serviceId = e.currentTarget.getAttribute('data-service-id');
      const service = SERVICES_DATA.find(s => s.id === serviceId);
      if (!service || !serviceDetailModal) return;

      document.getElementById('modal-service-title').textContent = service.name;
      document.getElementById('modal-service-tagline').textContent = service.tagline;
      document.getElementById('modal-service-desc').textContent = service.description;
      document.getElementById('modal-service-price').textContent = `$${service.basePrice}`;

      const checklistEl = document.getElementById('modal-service-checklist');
      if (checklistEl) {
        checklistEl.innerHTML = service.included.map(item => `
          <li class="flex items-start gap-2.5 text-sm text-slate-700">
            <span class="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold">✓</span>
            <span>${item}</span>
          </li>
        `).join('');
      }

      const bookBtn = document.getElementById('modal-service-book-btn');
      if (bookBtn) {
        bookBtn.onclick = () => {
          serviceDetailModal.close();
          wizard.selectService(service.id);
          document.getElementById('booking-wizard-section')?.scrollIntoView({ behavior: 'smooth' });
        };
      }

      serviceDetailModal.showModal();
    });
  });

  document.querySelectorAll('.btn-service-quick-select').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const serviceId = e.currentTarget.getAttribute('data-service-id');
      wizard.selectService(serviceId);
      document.getElementById('booking-wizard-section')?.scrollIntoView({ behavior: 'smooth' });
    });
  });
}

// FAQ Accordion
function setupFaqAccordion() {
  document.querySelectorAll('.faq-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const parent = btn.closest('.faq-item');
      const answer = parent.querySelector('.faq-content');
      const icon = btn.querySelector('.faq-chevron');

      const isOpen = !answer.classList.contains('hidden');

      // Close all others
      document.querySelectorAll('.faq-content').forEach(a => a.classList.add('hidden'));
      document.querySelectorAll('.faq-chevron').forEach(i => i.classList.remove('rotate-180'));

      if (!isOpen) {
        answer.classList.remove('hidden');
        icon.classList.add('rotate-180');
      }
    });
  });
}

// Modern Dialog Light-Dismiss & Fallback
function setupModals() {
  // Setup close buttons on all dialogs with [data-close-dialog]
  document.querySelectorAll('[data-close-dialog]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const dialog = e.currentTarget.closest('dialog');
      if (dialog) dialog.close();
    });
  });

  // Light dismiss fallback for dialogs: click outside modal box closes it
  document.querySelectorAll('dialog').forEach(dialog => {
    dialog.addEventListener('click', (e) => {
      const rect = dialog.getBoundingClientRect();
      const isInDialog = (
        rect.top <= e.clientY &&
        e.clientY <= rect.top + rect.height &&
        rect.left <= e.clientX &&
        e.clientX <= rect.left + rect.width
      );
      if (!isInDialog) {
        dialog.close();
      }
    });
  });
}

// Lightweight Toast notification helper
function setupToastSystem() {
  window.showToast = (message, type = 'success') => {
    const toast = document.createElement('div');
    const bgClass = type === 'success' ? 'bg-emerald-700 text-white' : 'bg-slate-900 text-white';
    
    toast.className = `fixed bottom-6 right-6 z-50 px-5 py-3.5 rounded-xl shadow-2xl flex items-center gap-3 text-sm font-medium transition-all duration-300 transform translate-y-10 opacity-0 ${bgClass}`;
    toast.innerHTML = `
      <span class="w-2 h-2 rounded-full bg-emerald-300"></span>
      <span>${message}</span>
    `;

    document.body.appendChild(toast);

    requestAnimationFrame(() => {
      toast.classList.remove('translate-y-10', 'opacity-0');
    });

    setTimeout(() => {
      toast.classList.add('opacity-0', 'translate-y-4');
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  };
}

// Interactive Before & After Transformation Slider
function setupBeforeAfterSlider() {
  const container = document.getElementById('ba-slider');
  const beforeWrapper = document.getElementById('ba-before-wrapper');
  const handle = document.getElementById('ba-handle');

  if (!container || !beforeWrapper || !handle) return;

  let isDragging = false;

  const setSliderPosition = (clientX) => {
    const rect = container.getBoundingClientRect();
    let x = clientX - rect.left;
    if (x < 0) x = 0;
    if (x > rect.width) x = rect.width;

    const percentage = (x / rect.width) * 100;
    beforeWrapper.style.clipPath = `polygon(0 0, ${percentage}% 0, ${percentage}% 100%, 0 100%)`;
    handle.style.left = `${percentage}%`;
  };

  const startDrag = (e) => {
    isDragging = true;
    setSliderPosition(e.clientX || (e.touches && e.touches[0].clientX));
  };

  const stopDrag = () => {
    isDragging = false;
  };

  const onDrag = (e) => {
    if (!isDragging) return;
    setSliderPosition(e.clientX || (e.touches && e.touches[0].clientX));
  };

  // Mouse & Touch events
  container.addEventListener('mousedown', startDrag);
  window.addEventListener('mouseup', stopDrag);
  window.addEventListener('mousemove', onDrag);

  container.addEventListener('touchstart', startDrag, { passive: true });
  window.addEventListener('touchend', stopDrag);
  window.addEventListener('touchmove', onDrag, { passive: true });
}

// Room-by-room Checklist Tab Switcher
function setupChecklistTabs() {
  const tabs = document.querySelectorAll('.checklist-tab-btn');
  const contents = document.querySelectorAll('.checklist-tab-content');

  tabs.forEach(tab => {
    tab.addEventListener('click', (e) => {
      const targetRoom = e.currentTarget.getAttribute('data-room');

      tabs.forEach(t => t.classList.remove('active'));
      e.currentTarget.classList.add('active');

      contents.forEach(content => {
        if (content.getAttribute('data-room') === targetRoom) {
          content.classList.remove('hidden');
        } else {
          content.classList.add('hidden');
        }
      });
    });
  });
}

// Interactive Free Time & Savings Calculator
function setupSavingsCalculator() {
  const slider = document.getElementById('savings-hours-slider');
  const hoursDisplay = document.getElementById('savings-hours-display');
  const yearlyHoursDisplay = document.getElementById('savings-yearly-hours');
  const valueRecoveredDisplay = document.getElementById('savings-value-recovered');

  if (!slider || !hoursDisplay) return;

  const updateSavings = () => {
    const weeklyHours = parseInt(slider.value) || 4;
    hoursDisplay.textContent = `${weeklyHours} ${weeklyHours === 1 ? 'hour' : 'hours'}/wk`;
    
    // 52 weeks in a year
    const yearlyHours = weeklyHours * 52;
    yearlyHoursDisplay.textContent = `${yearlyHours} hrs`;

    // Average value of personal free time ($35/hr)
    const dollarsSaved = yearlyHours * 35;
    valueRecoveredDisplay.textContent = `$${dollarsSaved.toLocaleString()}`;
  };

  slider.addEventListener('input', updateSavings);
  updateSavings();
}

// Vetted Cleaners Team Action Buttons
function setupCleanerTeamActions(wizard) {
  document.querySelectorAll('.btn-book-with-cleaner').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const cleanerId = e.currentTarget.getAttribute('data-cleaner-id');
      const cleaner = CLEANERS_DATA.find(c => c.id === cleanerId);

      if (cleaner) {
        wizard.state.preferredCleanerId = cleaner.id;
        wizard.state.preferredCleanerName = cleaner.name;
        
        window.showToast(`Selected preferred cleaner: ${cleaner.name} (★ ${cleaner.rating})`);
        
        document.getElementById('booking-wizard-section')?.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}

// Staff Admin: Manual Booking Modal
function setupAdminManualBooking() {
  const form = document.getElementById('form-admin-manual-booking');
  const modal = document.getElementById('admin-manual-booking-modal');
  const btnOpen = document.getElementById('btn-admin-add-booking');

  btnOpen?.addEventListener('click', () => {
    modal?.showModal();
  });

  form?.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('manual-cust-name').value.trim();
    const email = document.getElementById('manual-cust-email').value.trim();
    const phone = document.getElementById('manual-cust-phone').value.trim();
    const address = document.getElementById('manual-cust-address').value.trim();
    const serviceId = document.getElementById('manual-service-select').value;
    const date = document.getElementById('manual-clean-date').value;
    const timeSlot = document.getElementById('manual-time-slot').value;
    const cleanerId = document.getElementById('manual-cleaner-select').value;
    const total = parseFloat(document.getElementById('manual-total-amount').value) || 120;

    const service = SERVICES_DATA.find(s => s.id === serviceId) || SERVICES_DATA[0];
    const cleaner = CLEANERS_DATA.find(c => c.id === cleanerId) || CLEANERS_DATA[0];

    const randomNum = Math.floor(10000 + Math.random() * 90000);
    const bookingId = `PNC-${randomNum}`;

    const newBooking = {
      id: bookingId,
      createdAt: new Date().toISOString(),
      customer: {
        fullName: name,
        email: email,
        phone: phone,
        address: address,
        city: 'Springfield',
        postalCode: '97477',
        accessNotes: 'Entered via Admin Portal',
        specialNotes: 'Direct phone booking'
      },
      serviceId: service.id,
      serviceName: service.name,
      bedrooms: 2,
      bathrooms: 2,
      sqft: '900-1400',
      frequency: 'onetime',
      frequencyDiscount: 0,
      addons: [],
      addonsTotal: 0,
      date: date,
      timeSlot: timeSlot,
      ecoFriendly: true,
      hasPets: false,
      cleanerSupplies: true,
      specialNotes: 'Staff manual booking',
      promoCode: '',
      promoDiscount: 0,
      subtotal: total * 0.92,
      tax: total * 0.08,
      total: total,
      durationHours: '3.0',
      status: 'assigned',
      cleanerId: cleaner.id,
      cleanerName: cleaner.name,
      paymentMethod: 'Phone / Office Pay',
      paymentStatus: 'Confirmed',
      rating: null,
      review: null
    };

    StorageManager.addBooking(newBooking);
    modal?.close();
    form.reset();
    AdminPortal.refresh();

    window.showToast(`Manual booking created: ${bookingId}`);
    window.dispatchEvent(new CustomEvent('bookingCreated', { detail: newBooking }));
  });
}

