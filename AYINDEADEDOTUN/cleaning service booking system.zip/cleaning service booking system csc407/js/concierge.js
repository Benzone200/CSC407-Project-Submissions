// PureNest - Virtual Concierge AI Assistant
// Provides instant intelligent guidance and interactive shortcuts

const VirtualConcierge = {
  isOpen: false,
  messages: [
    {
      sender: 'bot',
      time: 'Just now',
      text: 'Hello! 👋 Welcome to PureNest. I am your 24/7 Virtual Cleaning Concierge. How can I assist you with your home or office cleaning today?',
      actions: ['Estimate Cost', 'Track a Booking', 'Promo Codes', 'What is Included?']
    }
  ],

  knowledgeBase: [
    {
      keywords: ['price', 'cost', 'quote', 'estimate', 'rate', 'how much'],
      reply: 'Our flat rates start at $89 for a Standard Home Clean, $149 for Deep Cleaning, and $199 for Move-In/Out turnovers. You can also save up to 20% by booking weekly!',
      actions: ['Open Cost Calculator', 'Book a Clean']
    },
    {
      keywords: ['promo', 'discount', 'voucher', 'coupon', 'code'],
      reply: 'You can use code **WELCOME25** for $25 off your first booking, or **CSC407** for an exclusive $30 academic discount! Enter either code at Step 4 of the checkout.',
      actions: ['Book with WELCOME25']
    },
    {
      keywords: ['supplies', 'equipment', 'chemical', 'vacuum', 'mop', 'bring'],
      reply: 'All PureNest certified cleaners bring 100% of the required equipment — including HEPA vacuums, microfiber mops, and plant-based, eco-friendly sanitizing products. You don\'t need to provide anything.',
      actions: ['View Checklist', 'Book a Clean']
    },
    {
      keywords: ['insured', 'bonded', 'safe', 'vet', 'background', 'trust'],
      reply: 'Every cleaner on PureNest is thoroughly background-checked, insured with a $2,000,000 general liability policy, and backed by our 100% Happiness Guarantee.',
      actions: ['Meet Cleaners', 'Book a Clean']
    },
    {
      keywords: ['cancel', 'reschedule', 'change', 'policy', 'refund'],
      reply: 'You can reschedule or cancel anytime with zero penalty up to 24 hours before your scheduled appointment directly through our Live Booking Tracker portal.',
      actions: ['Track Booking']
    },
    {
      keywords: ['pet', 'dog', 'cat', 'animal', 'hair'],
      reply: 'We love pets! In Step 3 of the booking wizard, you can select "Pets in the Home" and add our specialized Pet Hair & Odor Neutralizer extra. We match you with a pet-friendly cleaner.',
      actions: ['Book a Clean']
    },
    {
      keywords: ['track', 'status', 'where', 'cleaner', 'arrive'],
      reply: 'You can track any booking in real-time by clicking "Track Booking" in the top menu and entering your Booking Reference ID (e.g. PNC-78421) or your email.',
      actions: ['Track Booking']
    },
    {
      keywords: ['deep', 'difference', 'standard', 'included'],
      reply: 'Deep Cleaning includes everything in Standard, plus intensive hand-washing of baseboards, scrubbing tile grout, sanitizing doorframes, and removing scale buildup. Perfect if your home hasn\'t been cleaned in 30+ days!',
      actions: ['View Checklist', 'Book Deep Clean']
    }
  ],

  init() {
    this.renderChatWindow();
    this.bindEvents();
  },

  renderChatWindow() {
    // Check if elements exist
    let container = document.getElementById('concierge-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'concierge-container';
      container.innerHTML = `
        <!-- Floating Trigger Button -->
        <button id="btn-concierge-toggle" class="concierge-bubble w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-xl shadow-emerald-600/40 flex items-center justify-center focus:outline-none cursor-pointer" aria-label="Open Virtual Concierge Assistant">
          <div class="relative">
            <i data-lucide="message-square" class="w-6 h-6"></i>
            <span class="absolute -top-1 -right-1 w-3 h-3 bg-teal-300 rounded-full border-2 border-emerald-600 animate-pulse"></span>
          </div>
        </button>

        <!-- Chat Window -->
        <div id="concierge-window" class="concierge-window hidden">
          <!-- Chat Header -->
          <div class="bg-gradient-to-r from-emerald-700 to-teal-700 text-white p-4 flex items-center justify-between shadow-sm">
            <div class="flex items-center gap-3">
              <div class="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
                <i data-lucide="sparkles" class="w-5 h-5 text-teal-200"></i>
              </div>
              <div>
                <h4 class="font-bold text-sm leading-tight">PureNest Concierge</h4>
                <div class="flex items-center gap-1.5 text-[11px] text-teal-100">
                  <span class="w-2 h-2 rounded-full bg-teal-300"></span>
                  <span>Instant 24/7 Assistance</span>
                </div>
              </div>
            </div>
            <button id="btn-concierge-close" class="p-1.5 rounded-lg hover:bg-white/10 text-white/80 hover:text-white transition">
              <i data-lucide="x" class="w-5 h-5"></i>
            </button>
          </div>

          <!-- Messages Body -->
          <div id="concierge-messages" class="flex-1 p-4 overflow-y-auto space-y-3 text-xs bg-slate-50">
            <!-- Messages rendered dynamically -->
          </div>

          <!-- Input Footer -->
          <form id="concierge-input-form" class="p-3 bg-white border-t border-slate-200/80 flex items-center gap-2">
            <input type="text" id="concierge-text-input" placeholder="Ask a question or type a request..." class="flex-1 px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500">
            <button type="submit" class="w-8 h-8 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center shrink-0 transition">
              <i data-lucide="send" class="w-4 h-4"></i>
            </button>
          </form>
        </div>
      `;
      document.body.appendChild(container);
    }

    this.renderMessages();
    if (window.lucide) window.lucide.createIcons();
  },

  bindEvents() {
    document.getElementById('btn-concierge-toggle')?.addEventListener('click', () => {
      this.toggle();
    });

    document.getElementById('btn-concierge-close')?.addEventListener('click', () => {
      this.toggle(false);
    });

    document.getElementById('concierge-input-form')?.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = document.getElementById('concierge-text-input');
      const val = input.value.trim();
      if (val) {
        this.handleUserMessage(val);
        input.value = '';
      }
    });

    // Delegate action chips
    document.getElementById('concierge-messages')?.addEventListener('click', (e) => {
      const chip = e.target.closest('.chat-action-chip');
      if (chip) {
        const actionText = chip.getAttribute('data-action');
        this.executeAction(actionText);
      }
    });
  },

  toggle(forceState) {
    this.isOpen = forceState !== undefined ? forceState : !this.isOpen;
    const win = document.getElementById('concierge-window');
    if (win) {
      if (this.isOpen) {
        win.classList.remove('hidden');
        this.scrollToBottom();
        document.getElementById('concierge-text-input')?.focus();
      } else {
        win.classList.add('hidden');
      }
    }
  },

  renderMessages() {
    const container = document.getElementById('concierge-messages');
    if (!container) return;

    container.innerHTML = this.messages.map(m => {
      if (m.sender === 'user') {
        return `
          <div class="flex justify-end">
            <div class="chat-bubble-user max-w-[80%] px-3.5 py-2.5 rounded-2xl text-xs shadow-sm">
              ${m.text}
            </div>
          </div>
        `;
      } else {
        return `
          <div class="flex flex-col items-start gap-1.5 max-w-[88%]">
            <div class="chat-bubble-bot px-3.5 py-2.5 rounded-2xl text-xs text-slate-800 shadow-sm border border-slate-200/60 leading-relaxed">
              ${this.formatBotText(m.text)}
            </div>
            ${m.actions && m.actions.length ? `
              <div class="flex flex-wrap gap-1.5 pt-1">
                ${m.actions.map(act => `
                  <button type="button" class="chat-action-chip px-2.5 py-1 rounded-full bg-white hover:bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-semibold transition shadow-xs" data-action="${act}">
                    ${act}
                  </button>
                `).join('')}
              </div>
            ` : ''}
          </div>
        `;
      }
    }).join('');

    this.scrollToBottom();
    if (window.lucide) window.lucide.createIcons();
  },

  formatBotText(text) {
    return text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  },

  scrollToBottom() {
    const el = document.getElementById('concierge-messages');
    if (el) {
      setTimeout(() => el.scrollTop = el.scrollHeight, 50);
    }
  },

  handleUserMessage(userText) {
    // Push user message
    this.messages.push({
      sender: 'user',
      text: userText,
      time: 'Just now'
    });
    this.renderMessages();

    // Generate response
    const query = userText.toLowerCase();
    let matched = this.knowledgeBase.find(kb => kb.keywords.some(kw => query.includes(kw)));

    let botReply = "I can definitely help with that! You can explore our services, use our real-time price estimator, or speak directly with our team at (555) 789-0123.";
    let actions = ['Book a Clean', 'Track Booking', 'Estimate Cost'];

    if (matched) {
      botReply = matched.reply;
      actions = matched.actions;
    } else if (query.includes('hello') || query.includes('hi') || query.includes('hey')) {
      botReply = "Hello there! How can I help make your home sparkle today? Are you looking for a quote, wanting to book, or checking an existing reservation?";
      actions = ['Estimate Cost', 'Book a Clean', 'Track Booking'];
    }

    setTimeout(() => {
      this.messages.push({
        sender: 'bot',
        text: botReply,
        actions: actions,
        time: 'Just now'
      });
      this.renderMessages();
    }, 450);
  },

  executeAction(action) {
    switch (action) {
      case 'Estimate Cost':
      case 'Open Cost Calculator':
        this.toggle(false);
        document.getElementById('calculator-section')?.scrollIntoView({ behavior: 'smooth' });
        break;
      
      case 'Book a Clean':
        this.toggle(false);
        document.getElementById('booking-wizard-section')?.scrollIntoView({ behavior: 'smooth' });
        break;

      case 'Book Deep Clean':
        this.toggle(false);
        if (window.BookingWizardInstance) {
          window.BookingWizardInstance.selectService('deep');
        }
        document.getElementById('booking-wizard-section')?.scrollIntoView({ behavior: 'smooth' });
        break;

      case 'Book with WELCOME25':
        this.toggle(false);
        const promoInput = document.getElementById('wizard-promo-input');
        if (promoInput) {
          promoInput.value = 'WELCOME25';
          document.getElementById('btn-apply-promo')?.click();
        }
        document.getElementById('booking-wizard-section')?.scrollIntoView({ behavior: 'smooth' });
        break;

      case 'Track a Booking':
      case 'Track Booking':
        this.toggle(false);
        document.getElementById('tracker-modal')?.showModal();
        break;

      case 'Promo Codes':
        this.handleUserMessage('What promo codes are available?');
        break;

      case 'What is Included?':
      case 'View Checklist':
        this.toggle(false);
        document.getElementById('checklist-section')?.scrollIntoView({ behavior: 'smooth' });
        break;

      case 'Meet Cleaners':
        this.toggle(false);
        document.getElementById('cleaners-team-section')?.scrollIntoView({ behavior: 'smooth' });
        break;

      default:
        this.handleUserMessage(action);
        break;
    }
  }
};

if (typeof window !== 'undefined') {
  window.VirtualConcierge = VirtualConcierge;
}
