const HOD = { user: "admin", pass: "notice123" };
const CATS = ["General", "Events", "Timetable", "Exams"];

const load = (key, fallback) => {
  try {
    return JSON.parse(localStorage.getItem(key)) || fallback;
  } catch (e) {
    return fallback;
  }
};
const save = (key, value) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {}
};

function seed() {
  return [
    {
      id: 1,
      title: "Second Semester Examination Timetable released",
      cat: "Exams",
      msg: "The full timetable is now available. Report clashes to the exam officer before the deadline.",
      by: "Exam Officer",
      at: "2026-10-12T09:00",
      pin: true,
      img: "",
    },
    {
      id: 2,
      title: "Final-year project presentations",
      cat: "Events",
      msg: "Friday at 10:00 in the main lecture hall. All final-year students must attend.",
      by: "Project Coordinator",
      at: "2026-10-12T08:00",
      pin: false,
      img: "",
    },
    {
      id: 3,
      title: "Course registration deadline extended",
      cat: "General",
      msg: "Registration stays open for one more week.",
      by: "Head of Department",
      at: "2026-10-10T08:30",
      pin: false,
      img: "",
    },
    {
      id: 4,
      title: "Lab sessions move to Block B",
      cat: "Timetable",
      msg: "Practical sessions will hold in the Block B laboratory at the usual times.",
      by: "Level Adviser",
      at: "2026-10-08T14:00",
      pin: false,
      img: "",
    },
    {
      id: 5,
      title: "Departmental scholarship applications open",
      cat: "General",
      msg: "Collect the application form from the department office.",
      by: "Head of Department",
      at: "2026-10-02T09:00",
      pin: false,
      img: "",
    },
  ];
}

let notices = load("tack-notices", seed());
let staff = load("tack-staff", []);
let session = null;
let filter = "";
let query = "";
let editId = null;
let confirmId = null;
let next = "";

const $ = (selector) => document.querySelector(selector);
const esc = (s) =>
  String(s).replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[
        c
      ])
  );
const fmtDate = (at) =>
  new Date(at).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
const fmtTime = (at) =>
  new Date(at).toLocaleTimeString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
  });
const sorted = (list) =>
  [...list].sort((a, b) => b.pin - a.pin || b.at.localeCompare(a.at)); // pinned first, then newest
const toast = (text) => {
  const el = $("#toast");
  el.textContent = text;
  el.classList.add("on");
  setTimeout(() => el.classList.remove("on"), 2500);
};

async function hash(text) {
  try {
    const buf = await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(text)
    );
    return [...new Uint8Array(buf)]
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  } catch (e) {
    return "plain:" + text;
  }
}

const shrink = (file) =>
  new Promise((done) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const k = Math.min(1, 800 / img.width),
          canvas = document.createElement("canvas");
        canvas.width = img.width * k;
        canvas.height = img.height * k;
        canvas
          .getContext("2d")
          .drawImage(img, 0, 0, canvas.width, canvas.height);
        done(canvas.toDataURL("image/jpeg", 0.7));
      };
      img.onerror = () => done("");
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });

const svg = (paths, size = 24) =>
  `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;
const ICON = {
  cal: svg(
    '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    18
  ),
  clock: svg('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', 18),
  funnel: svg('<path d="M3 4h18l-7 8.5V20l-4-2v-5.5z"/>', 18),
  plus: svg('<path d="M12 5v14M5 12h14"/>', 18),
  check: svg('<path d="M5 12l5 5 9-10"/>', 36),
  board: svg(
    '<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>'
  ),
  search: svg('<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>'),
  staff: svg(
    '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>'
  ),
  post: svg('<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>'),
  manage: svg('<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>'),
};

function card(n, manage) {
  const img = n.img ? `<div class="im"><img src="${n.img}" alt=""></div>` : "";
  const buttons = manage
    ? `<div class="acts"><button class="sm" data-act="edit" data-id="${
        n.id
      }">Edit</button><button class="sm dg" data-act="del" data-id="${n.id}">${
        confirmId === n.id ? "Tap again to delete" : "Delete"
      }</button></div>`
    : "";
  return `<article class="card${n.pin && !n.img ? " noimg" : ""}">
    ${n.pin ? '<span class="pb">Pinned</span>' : ""}${img}
    <div class="cb"><h3>${esc(n.title)}</h3><p>${esc(n.msg)}</p>
      <div class="mr"><span>${ICON.cal}${fmtDate(n.at)}</span><span>${
    ICON.clock
  }${fmtTime(n.at)}</span></div>${buttons}</div>
  </article>`;
}

function results() {
  const q = query.trim().toLowerCase();
  if (!q) return '<p class="empty">Type a word to search the notices.</p>';
  const list = sorted(
    notices.filter((n) =>
      (n.title + " " + n.msg + " " + n.cat).toLowerCase().includes(q)
    )
  );
  return (
    `<p class="count">${list.length} ${
      list.length === 1 ? "notice" : "notices"
    } found</p>` + list.map((n) => card(n)).join("")
  );
}

const views = {
  board() {
    const list = sorted(notices.filter((n) => !filter || n.cat === filter));
    return `<h1>Notice board</h1><p class="sub">Your electronic easy to use notice board</p>
      <div class="chips">${CATS.map(
        (c) =>
          `<button class="chip${
            filter === c ? " on" : ""
          }" data-act="filter" data-cat="${c}">${ICON.funnel}${c}</button>`
      ).join("")}</div>
      ${
        list.map((n) => card(n)).join("") ||
        '<p class="empty">No notices here yet.</p>'
      }`;
  },

  search() {
    return `<h1>Search</h1><div class="pad"><label for="q">Search notices</label>
      <div class="sbox">${ICON.search}<input id="q" type="search" value="${esc(
      query
    )}" placeholder="Try &quot;exam&quot;"></div></div>
      <div id="results">${results()}</div>`;
  },

  login() {
    return `<h1>Staff log in</h1>
      <form id="loginForm" class="pad">
        <label for="u">Staff email or staff ID</label><input id="u" autocomplete="username">
        <label for="p">Password</label><input id="p" type="password" autocomplete="current-password">
        <p class="err" id="err" role="alert"></p>
        <button class="btn">Log in</button>
        <a class="btn ghost" href="#signup">Create staff account</a>
      </form>`;
  },

  signup() {
    return `<h1>Staff sign up</h1>
      <form id="signupForm" class="pad">
        <label for="n">Full name</label><input id="n" autocomplete="name">
        <label for="s">Staff ID</label><input id="s">
        <label for="e">Staff email</label><input id="e" type="email" autocomplete="email">
        <label for="w">Password (at least 8 characters)</label><input id="w" type="password" autocomplete="new-password">
        <p class="err" id="err" role="alert"></p>
        <button class="btn">Request account</button>
        <a class="btn ghost" href="#login">Back to log in</a>
      </form>`;
  },

  post() {
    const n = notices.find((x) => x.id === editId) || {
      title: "",
      cat: "General",
      msg: "",
      pin: false,
    };
    return `<h1>${editId ? "Edit notice" : "Post a notice"}</h1>
      <form id="postForm" class="pad">
        <label for="t">Title</label><input id="t" value="${esc(n.title)}">
        <label for="c">Category</label><select id="c">${CATS.map(
          (c) => `<option${c === n.cat ? " selected" : ""}>${c}</option>`
        ).join("")}</select>
        <label for="m">Message</label><textarea id="m" rows="5">${esc(
          n.msg
        )}</textarea>
        <label for="i">Image (optional)</label><input id="i" type="file" accept="image/*">
        <div class="check"><input id="pin" type="checkbox"${
          n.pin ? " checked" : ""
        }><label for="pin">Pin to the top of the board</label></div>
        <p class="err" id="err" role="alert"></p>
        <button class="btn">${ICON.plus}${
      editId ? "Save changes" : "Publish notice"
    }</button>
        <a class="btn ghost" href="#manage" data-act="cancel">Cancel</a>
      </form>`;
  },

  published() {
    return `<div class="ok">${ICON.check}</div><h1>Notice published</h1>
      <div class="pad">
        <a class="btn" href="#board">View the board</a>
        <a class="btn ghost" href="#post" data-act="new">Post another notice</a>
        <a class="btn ghost" href="#manage">Manage notices</a>
      </div>`;
  },

  manage() {
    const mine = notices.filter(
      (n) => session.role === "hod" || n.by === session.name
    );
    const pending =
      session.role === "hod" ? staff.filter((s) => s.status === "pending") : [];
    const approvals =
      session.role === "hod"
        ? `<section class="card"><div class="cb"><h3>Staff waiting for approval</h3>
          ${
            pending
              .map(
                (s) => `<div class="req"><b>${esc(s.name)}</b><span>${esc(
                  s.staffId
                )}, ${esc(s.email)}</span>
            <div class="acts"><button class="sm" data-act="approve" data-id="${
              s.id
            }">Approve</button><button class="sm dg" data-act="reject" data-id="${
                  s.id
                }">Reject</button></div></div>`
              )
              .join("") || '<p class="mr">No requests right now.</p>'
          }
        </div></section>`
        : "";
    return `<h1>Manage notices</h1>
      <div class="pad"><a class="btn out" href="#post" data-act="new">${
        ICON.plus
      }Post a notice</a></div>
      <div style="height:20px"></div>${approvals}
      ${
        sorted(mine)
          .map((n) => card(n, true))
          .join("") ||
        '<p class="empty">You have not posted any notices yet.</p>'
      }`;
  },
};

function topRight(route) {
  if (session)
    return '<a class="link" href="#board" data-act="logout">Log out</a>';
  if (route === "login" || route === "signup")
    return '<a class="link" href="#board">Notices</a>';
  return `<a class="btn out pbtn" href="#post" data-act="new">${ICON.plus}Post a notice</a>`;
}

function navBar(route) {
  const items = session
    ? [
        ["board", "Board", "#board"],
        ["post", "Post", "#post"],
        ["manage", "Manage", "#manage"],
      ]
    : [
        ["board", "Board", "#board"],
        ["search", "Search", "#search"],
        ["staff", "Staff", "#login"],
      ];
  const active = {
    board: "board",
    search: "search",
    login: "staff",
    signup: "staff",
    post: "post",
    published: "post",
    manage: "manage",
  }[route];
  return items
    .map(
      ([key, label, href]) =>
        `<a href="${href}"${
          key === active ? ' class="on" aria-current="page"' : ""
        }${key === "post" ? ' data-act="new"' : ""}>${ICON[key]}${label}</a>`
    )
    .join("");
}

const PRIVATE = ["post", "published", "manage"];

function render(keepScroll) {
  let route = location.hash.slice(1) || "board";
  if (!views[route]) route = "board";
  if (PRIVATE.includes(route) && !session) {
    next = route;
    location.hash = "#login";
    return;
  }
  $("#view").innerHTML = views[route]();
  $("#nav").innerHTML = navBar(route);
  $("#topRight").innerHTML = topRight(route);
  if (!keepScroll) window.scrollTo(0, 0);
}
window.addEventListener("hashchange", () => render());

document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-act]");
  if (!el) return;
  const act = el.dataset.act,
    id = Number(el.dataset.id);

  if (act === "filter") {
    filter = filter === el.dataset.cat ? "" : el.dataset.cat;
    render(true);
  } else if (act === "new") {
    editId = null;
    render(true);
  } else if (act === "cancel") {
    editId = null;
  } else if (act === "logout") {
    e.preventDefault();
    session = null;
    next = "";
    editId = null;
    location.hash = "#board";
    render();
  } else if (act === "edit") {
    editId = id;
    location.hash = "#post";
  } else if (act === "del") {
    if (confirmId === id) {
      notices = notices.filter((n) => n.id !== id);
      save("tack-notices", notices);
      confirmId = null;
      toast("Notice deleted");
    } else confirmId = id;
    render(true);
  } else if (act === "approve") {
    staff.find((s) => s.id === id).status = "approved";
    save("tack-staff", staff);
    toast("Staff approved");
    render(true);
  } else if (act === "reject") {
    staff = staff.filter((s) => s.id !== id);
    save("tack-staff", staff);
    toast("Request rejected");
    render(true);
  }
});

document.addEventListener("input", (e) => {
  if (e.target.id === "q") {
    query = e.target.value;
    $("#results").innerHTML = results();
  }
});

document.addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const val = (id) => form.querySelector("#" + id).value.trim();
  const fail = (text) => {
    $("#err").textContent = text;
  };

  if (form.id === "loginForm") {
    const who = val("u").toLowerCase(),
      password = form.querySelector("#p").value;
    if (who === HOD.user && password === HOD.pass) {
      session = { role: "hod", name: "Head of Department" };
    } else {
      const code = await hash(password);
      const account = staff.find(
        (s) =>
          (s.email === who || s.staffId.toLowerCase() === who) &&
          s.hash === code
      );
      if (!account) return fail("Wrong details. Try again.");
      if (account.status !== "approved")
        return fail(
          "Your account is waiting for approval by the Head of Department."
        );
      session = { role: "staff", name: account.name };
    }
    toast("Logged in");
    const to = next || "post";
    next = "";
    location.hash = "#" + to;
  } else if (form.id === "signupForm") {
    const password = form.querySelector("#w").value,
      email = val("e").toLowerCase();
    if (!val("n") || !val("s") || !email || !password)
      return fail("Please fill in every field.");
    if (password.length < 8)
      return fail("Use a password of at least 8 characters.");
    if (
      staff.some(
        (s) =>
          s.email === email ||
          s.staffId.toLowerCase() === val("s").toLowerCase()
      )
    )
      return fail("An account with that email or staff ID already exists.");
    staff.push({
      id: Date.now(),
      name: val("n"),
      staffId: val("s"),
      email,
      hash: await hash(password),
      status: "pending",
    });
    save("tack-staff", staff);
    toast("Request sent. You can log in once it is approved.");
    location.hash = "#login";
  } else if (form.id === "postForm") {
    if (!val("t") || !val("m"))
      return fail("Please add a title and a message.");
    const file = form.querySelector("#i").files[0];
    const image = file ? await shrink(file) : "";
    const data = {
      title: val("t"),
      cat: val("c"),
      msg: val("m"),
      pin: form.querySelector("#pin").checked,
    };
    if (editId) {
      const n = notices.find((x) => x.id === editId);
      Object.assign(n, data);
      if (image) n.img = image;
      editId = null;
      save("tack-notices", notices);
      toast("Notice updated");
      location.hash = "#manage";
    } else {
      notices.push({
        id: Date.now(),
        ...data,
        img: image,
        by: session.name,
        at: new Date().toISOString(),
      });
      save("tack-notices", notices);
      location.hash = "#published";
    }
  }
});

render();
