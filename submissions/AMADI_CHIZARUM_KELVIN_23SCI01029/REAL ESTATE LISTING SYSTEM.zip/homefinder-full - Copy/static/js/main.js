"use strict";
const $ = (sel, root = document) => root.querySelector(sel);
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const naira = n => "\u20a6" + Number(n).toLocaleString("en-NG");


function el(tag, attrs = {}, ...kids) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
  node.append(...kids);
  return node;
}

let session = { user: null, csrf: "" };
const currentUser = () => session.user;

async function api(path, { method = "GET", body } = {}) {
  const opts = { method, headers: {}, credentials: "same-origin" };
  if (method !== "GET") {
    opts.headers["Content-Type"] = "application/json";
    opts.headers["X-CSRFToken"] = session.csrf;       
    opts.body = JSON.stringify(body ?? {});
  }
  try {
    const res = await fetch(path, opts);
    let data = {};
    try { data = await res.json(); } catch { /* empty body */ }
    return { ok: res.ok, status: res.status, data };
  } catch {
    return { ok: false, status: 0, data: { errors: ["Could not reach the server. Is it running?"] } };
  }
}
async function loadSession() {
  const r = await api("/api/me");
  if (r.ok) session = r.data;
}
const errorsOf = r => r.data.errors || ["Something went wrong. Please try again."];


const ICONS = {
  pin: '<path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
  bed: '<path d="M3 19V6M3 15h18v4M21 15v-3a3 3 0 0 0-3-3h-7v6"/><circle cx="7" cy="11" r="1.5"/>',
  bath: '<path d="M4 12h16v3a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4v-3zM6 12V6a2 2 0 0 1 4 0M7 19l-1 2M17 19l1 2"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  phone: '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
};
function icon(name, cls = "ico") {
  const s = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  s.setAttribute("viewBox", "0 0 24 24"); s.setAttribute("class", cls); s.setAttribute("aria-hidden", "true");
  s.innerHTML = ICONS[name];
  return s;
}


const FALLBACK = { house: "images/house-a.jpg", apartment: "images/apartment-a.jpg", land: "images/land-a.jpg", commercial: "images/commercial-a.jpg" };
const safeSrc = s => typeof s === "string" && (/^images\/[a-z0-9-]+\.(svg|jpg)$/.test(s) || s.startsWith("data:image/jpeg;base64,")) ? s : null;
function pic(path, alt, loading = "lazy") {
  const isLocal = path.startsWith("images/");
  const img = el("img", { src: isLocal ? path.replace(/\.svg$/, ".jpg") : path, alt, loading });
  img.addEventListener("error", () => {
    const fb = isLocal ? path.replace(/\.jpg$/, ".svg") : FALLBACK.house;
    if (!img.src.endsWith(fb)) img.src = fb;
  });
  return img;
}
function photo(l) {
  const src = safeSrc(l.image) || FALLBACK[l.type];
  const img = pic(src, `${cap(l.type)} in ${l.city}`);
  img.addEventListener("error", () => { if (!src.startsWith("images/")) img.src = FALLBACK[l.type]; });
  return img;
}


function renderHeader() {
  const user = currentUser();
  const here = location.pathname.split("/").pop() || "index.html";
  const header = $("#site-header");
  header.className = "site-header";

  const burger = el("button", { class: "burger", type: "button", "aria-expanded": "false", "aria-controls": "nav", "aria-label": "Toggle menu" }, icon("menu", ""));
  const nav = el("nav", { class: "nav", id: "nav", "aria-label": "Main" });
  const links = [["index.html", "Dashboard"], ["listings.html", "Browse"]];
  if (user) links.push(["post.html", "Post listing"], ["profile.html", "Profile"]);
  if (user && user.role === "admin") links.push(["admin.html", "Admin"]);
  links.push(["security.html", "Security"]);
  for (const [href, label] of links) {
    const a = el("a", { href }, label);
    if (href === here) a.setAttribute("aria-current", "page");
    nav.append(a);
  }
  if (user) {
    const out = el("button", { class: "linkbtn", type: "button" }, `Log out (${user.username})`);
    out.addEventListener("click", async () => { await api("/api/logout", { method: "POST" }); location.href = "index.html"; });
    nav.append(out);
  } else {
    nav.append(el("a", { href: "login.html" }, "Log in"), el("a", { class: "btn small", href: "register.html" }, "Register"));
  }

  const setOpen = open => {
    nav.classList.toggle("open", open);
    burger.setAttribute("aria-expanded", String(open));
    burger.replaceChildren(icon(open ? "close" : "menu", ""));
  };
  burger.addEventListener("click", () => setOpen(!nav.classList.contains("open")));
  document.addEventListener("keydown", e => { if (e.key === "Escape") setOpen(false); });
  document.addEventListener("click", e => { if (!header.contains(e.target)) setOpen(false); });
  window.matchMedia("(min-width: 800px)").addEventListener("change", e => { if (e.matches) setOpen(false); });

  const brand = el("a", { class: "brand", href: "index.html" }, el("img", { src: "images/logo.svg", alt: "" }), "HomeFinder");
  header.append(el("div", { class: "bar" }, brand, burger, nav));
}

function renderFooter() {
  const f = $("#site-footer");
  f.className = "site-footer";
  f.append(el("div", { class: "wrap" },
    el("div", { class: "foot-grid" },
      el("div", {}, el("h3", {}, "HomeFinder"), el("p", {}, "Find houses, apartments, land and commercial space across Nigeria.")),
      el("div", {}, el("h3", {}, "Explore"), el("a", { href: "index.html" }, "Dashboard"), el("a", { href: "listings.html" }, "Browse listings"), el("a", { href: "security.html" }, "Security")),
      el("div", {}, el("h3", {}, "Account"), el("a", { href: "login.html" }, "Log in"), el("a", { href: "register.html" }, "Register"), el("a", { href: "profile.html" }, "Profile"))),
    el("p", { class: "copy" }, `\u00a9 ${new Date().getFullYear()} HomeFinder.`)));
}

function card(l) {
  const showRooms = l.type === "house" || l.type === "apartment";
  const facts = el("p", { class: "facts" });
  if (showRooms) facts.append(el("span", {}, icon("bed"), `${l.beds} bed`), el("span", {}, icon("bath"), `${l.baths} bath`));
  else facts.append(el("span", {}, cap(l.type)));
  const b = el("button", { class: "card", type: "button" },
    el("div", { class: "card-img" }, photo(l), el("span", { class: "badge" }, cap(l.type)),
      ...(l.status !== "available" ? [el("span", { class: "badge alt" }, cap(l.status))] : [])),
    el("div", { class: "card-body" },
      el("p", { class: "price" }, naira(l.price)),
      el("h3", {}, l.title),
      el("p", { class: "loc" }, icon("pin"), l.city),
      facts));
  b.addEventListener("click", () => openDetail(l));
  return b;
}

function openDetail(l) {
  let dlg = $("#detail");
  if (!dlg) { dlg = el("dialog", { id: "detail", "aria-labelledby": "detail-title" }); document.body.append(dlg); }
  const x = el("button", { class: "dlg-close", type: "button", "aria-label": "Close" }, "\u00d7");
  x.addEventListener("click", () => dlg.close());
  dlg.replaceChildren(
    x,
    el("div", { class: "dlg-img" }, photo(l)),
    el("div", { class: "dlg-body" },
      el("p", { class: "loc" }, `${cap(l.type)} \u00b7 ${cap(l.status)}`),
      el("h2", { id: "detail-title" }, l.title),
      el("p", { class: "price big" }, naira(l.price)),
      el("p", { class: "loc" }, icon("pin"), `${l.city} \u00b7 ${l.beds} bed \u00b7 ${l.baths} bath \u00b7 Listed by ${l.owner} on ${l.date}`),
      el("p", { class: "desc" }, l.description)));
  dlg.onclick = e => { if (e.target === dlg) dlg.close(); };
  dlg.showModal();
}

function showErrors(form, errors) {
  const box = $(".errors", form);
  if (!errors.length) { box.hidden = true; box.replaceChildren(); return; }
  const ul = el("ul");
  errors.forEach(m => ul.append(el("li", {}, m)));
  box.replaceChildren(ul);
  box.hidden = false;
  box.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function wirePasswordToggle() {
  document.querySelectorAll("[data-toggle-password]").forEach(cb =>
    cb.addEventListener("change", () =>
      cb.form.querySelectorAll("input[name=password], input[name=confirm]").forEach(i => { i.type = cb.checked ? "text" : "password"; })));
}


function shrink(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const s = Math.min(1, 900 / img.width), c = document.createElement("canvas");
      c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/jpeg", 0.8));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("bad image")); };
    img.src = url;
  });
}

const requireLogin = () => { if (!currentUser()) { location.href = "login.html"; return false; } return true; };


const pages = {
  async home() {
    const [st, ls] = await Promise.all([api("/api/stats"), api("/api/listings?limit=6")]);
    const s = st.data;
    const chips = $("#hero-stats");
    chips.append(el("li", {}, `${s.available ?? 0} properties available`), el("li", {}, `${s.cities ?? 0} cities`));
    if (currentUser()) chips.append(el("li", {}, `${s.mine} of your own listings`));

    const tiles = [["house", "Houses"], ["apartment", "Apartments"], ["land", "Land"], ["commercial", "Commercial"]];
    $("#tiles").append(...tiles.map(([t, label]) => {
      const n = (s.by_type || {})[t] || 0;
      return el("a", { class: "tile", href: `listings.html?type=${t}` },
        pic(FALLBACK[t], ""),
        el("span", {}, el("b", {}, label), el("small", {}, `${n} listing${n === 1 ? "" : "s"}`)));
    }));
    const items = ls.data.items || [];
    $("#latest").append(...(items.length ? items.map(card) : [el("p", { class: "empty" }, "No listings yet.")]));
    document.querySelectorAll("[data-icon]").forEach(n => n.append(icon(n.dataset.icon)));
    if (currentUser()) $("#cta-wrap").hidden = true;
  },

  listings() {
    const PAGE = 6;
    const form = $("#filters"), results = $("#results"), more = $("#more"), count = $("#count");
    let shown = PAGE, seq = 0;
    for (const [k, v] of new URLSearchParams(location.search)) if (form.elements[k]) form.elements[k].value = v;

    async function render() {
      const mine = ++seq, p = new URLSearchParams();
      for (const [k, v] of new FormData(form)) if (v !== "") p.set(k, v);
      p.set("limit", shown);
      const r = await api("/api/listings?" + p);
      if (mine !== seq) return;                                  // ignore out-of-date responses
      const items = r.data.items || [], total = r.data.total || 0;
      count.textContent = `${total} propert${total === 1 ? "y" : "ies"} found`;
      results.replaceChildren(...(items.length ? items.map(card)
        : [el("p", { class: "empty" }, r.ok ? "No listings match those filters. Try clearing some of them." : errorsOf(r)[0])]));
      more.hidden = total <= items.length;
    }
    let timer;
    form.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => { shown = PAGE; render(); }, 250); });
    form.addEventListener("submit", e => e.preventDefault());
    form.addEventListener("reset", () => setTimeout(() => { shown = PAGE; render(); }));
    more.addEventListener("click", () => { shown += PAGE; render(); });
    render();
  },

  async login() {
    const form = $("#login-form");
    wirePasswordToggle();
    const st = await api("/api/setup-status");
    if (st.ok && st.data.needed) $("#setup-note").hidden = false;
    form.addEventListener("submit", async e => {
      e.preventDefault();
      const d = Object.fromEntries(new FormData(form));
      if (!d.username.trim() || !d.password) { showErrors(form, ["Enter your username and password."]); return; }
      const r = await api("/api/login", { method: "POST", body: d });
      if (r.ok) location.href = r.data.user.role === "admin" ? "admin.html" : "index.html";
      else showErrors(form, errorsOf(r));
    });
  },

  register() {
    const form = $("#register-form"), pw = $("#pw"), bar = $("#meter-bar"), text = $("#meter-text");
    wirePasswordToggle();
    pw.addEventListener("input", () => {
      const v = pw.value;
      const score = [v.length >= 8, /[a-z]/.test(v), /[A-Z]/.test(v), /\d/.test(v), v.length >= 12].filter(Boolean).length;
      bar.style.width = `${score * 20}%`;
      bar.style.background = score < 3 ? "#a3392b" : score < 5 ? "#c48a2c" : "#14624f";
      text.textContent = ["Very weak", "Weak", "Weak", "Okay", "Good", "Strong"][score];
    });
    form.addEventListener("submit", async e => {
      e.preventDefault();
      const d = Object.fromEntries(new FormData(form));
      const r = await api("/api/register", { method: "POST", body: d });
      if (!r.ok) { showErrors(form, errorsOf(r)); return; }
      const l = await api("/api/login", { method: "POST", body: { username: d.username, password: d.password } });
      location.href = l.ok ? "index.html" : "login.html";
    });
  },

  async setup() {
    const st = await api("/api/setup-status");
    if (!st.ok || !st.data.needed) { location.href = "login.html"; return; }
    const form = $("#setup-form");
    wirePasswordToggle();
    form.addEventListener("submit", async e => {
      e.preventDefault();
      const d = Object.fromEntries(new FormData(form));
      const r = await api("/api/setup", { method: "POST", body: d });
      if (!r.ok) { showErrors(form, errorsOf(r)); return; }
      const l = await api("/api/login", { method: "POST", body: { username: d.username, password: d.password } });
      location.href = l.ok ? "admin.html" : "login.html";
    });
  },

  post() {
    if (!requireLogin()) return;
    const form = $("#post-form"), file = form.elements.photo, preview = $("#preview");
    let photoData = null;
    file.addEventListener("change", async () => {
      photoData = null; preview.hidden = true;
      const f = file.files[0];
      if (!f) return;
      if (!["image/jpeg", "image/png", "image/webp"].includes(f.type)) { showErrors(form, ["Photo must be a JPG, PNG or WebP image."]); file.value = ""; return; }
      if (f.size > 5 * 1024 * 1024) { showErrors(form, ["Photo must be smaller than 5 MB."]); file.value = ""; return; }
      try { photoData = await shrink(f); preview.src = photoData; preview.hidden = false; showErrors(form, []); }
      catch { showErrors(form, ["That file could not be read as an image."]); file.value = ""; }
    });
    form.addEventListener("submit", async e => {
      e.preventDefault();
      const d = Object.fromEntries(new FormData(form));
      delete d.photo;
      if (photoData) d.image = photoData;
      const r = await api("/api/listings", { method: "POST", body: d });
      if (r.ok) location.href = "profile.html";
      else showErrors(form, errorsOf(r));
    });
  },

  async profile() {
    if (!requireLogin()) return;
    const user = currentUser();
    $("#avatar").textContent = user.username.charAt(0).toUpperCase();
    $("#profile-info").append(
      el("dt", {}, "Username"), el("dd", {}, user.username),
      el("dt", {}, "Email"), el("dd", {}, user.email),
      el("dt", {}, "Role"), el("dd", {}, user.role),
      el("dt", {}, "Member since"), el("dd", {}, user.created));
    const box = $("#my-listings");
    async function render() {
      const r = await api("/api/my/listings"), mine = r.data.items || [];
      if (!mine.length) {
        box.replaceChildren(el("p", { class: "empty" }, "You haven't posted anything yet. ", el("a", { href: "post.html" }, "Post your first listing.")));
        return;
      }
      box.replaceChildren(...mine.map(l => {
        const view = el("button", { class: "btn ghost small", type: "button" }, "View");
        const del = el("button", { class: "btn danger small", type: "button" }, "Delete");
        view.addEventListener("click", () => openDetail(l));
        del.addEventListener("click", async () => {
          if (!confirm("Delete this listing?")) return;
          await api(`/api/listings/${l.id}`, { method: "DELETE" });
          render();
        });
        return el("div", { class: "item" }, photo(l),
          el("div", { class: "info" }, el("strong", {}, l.title), el("span", { class: "loc" }, `${naira(l.price)} \u00b7 ${l.city}`)),
          el("div", { class: "actions" }, view, del));
      }));
    }
    render();
  },

  async admin() {
    const user = currentUser();
    if (!user) { location.href = "login.html"; return; }
    if (user.role !== "admin") { location.href = "index.html"; return; }
    const note = $("#admin-note");
    const say = (msg, bad) => { note.textContent = msg; note.className = bad ? "errors" : "notice"; note.hidden = !msg; };

    async function renderUsers() {
      const r = await api("/api/admin/users");
      const rows = (r.data.items || []).map(u => {
        let roleCell;
        if (u.id === user.id) roleCell = el("span", {}, `${u.role} (you)`);
        else {
          const sel = el("select", { "aria-label": `Role for ${u.username}` });
          for (const role of ["user", "admin"]) { const o = el("option", { value: role }, role); if (u.role === role) o.selected = true; sel.append(o); }
          const save = el("button", { class: "btn small", type: "button" }, "Save");
          save.addEventListener("click", async () => {
            const res = await api(`/api/admin/users/${u.id}/role`, { method: "POST", body: { role: sel.value } });
            if (res.ok) { say(`Role for ${u.username} updated.`, false); renderUsers(); } else say(errorsOf(res)[0], true);
          });
          roleCell = el("span", { class: "role-form" }, sel, save);
        }
        return el("tr", {}, el("td", {}, u.username), el("td", {}, u.email), el("td", {}, String(u.listings)), el("td", {}, u.created), el("td", {}, roleCell));
      });
      $("#admin-users").replaceChildren(el("table", { class: "table" },
        el("thead", {}, el("tr", {}, ...["User", "Email", "Listings", "Joined", "Role"].map(h => el("th", {}, h)))),
        el("tbody", {}, ...rows)));
    }
    async function renderListings() {
      const r = await api("/api/admin/listings");
      const rows = (r.data.items || []).map(l => {
        const del = el("button", { class: "btn danger small", type: "button" }, "Delete");
        del.addEventListener("click", async () => {
          if (!confirm(`Delete "${l.title}"?`)) return;
          const res = await api(`/api/listings/${l.id}`, { method: "DELETE" });
          if (res.ok) { say("Listing deleted.", false); renderListings(); renderUsers(); } else say(errorsOf(res)[0], true);
        });
        return el("tr", {}, el("td", {}, l.title), el("td", {}, l.owner), el("td", {}, naira(l.price)), el("td", {}, l.status), el("td", {}, del));
      });
      $("#admin-listings").replaceChildren(el("table", { class: "table" },
        el("thead", {}, el("tr", {}, ...["Title", "Owner", "Price", "Status", ""].map(h => el("th", {}, h)))),
        el("tbody", {}, ...rows)));
    }
    renderUsers(); renderListings();
  },
};

document.addEventListener("DOMContentLoaded", async () => {
  await loadSession();
  renderHeader();
  renderFooter();
  await pages[document.body.dataset.page]?.();
});
