@echo off
cd /d "%~dp0"
set PY=
where py >nul 2>nul && set PY=py
if "%PY%"=="" where python >nul 2>nul && set PY=python
if "%PY%"=="" goto nopython

if not exist ".venv\Scripts\activate.bat" (
  echo First-time setup, please wait a minute or two...
  %PY% -m venv .venv
)
call ".venv\Scripts\activate.bat"
python -m pip install -q -r requirements.txt
python -m flask --app app seed

echo.
echo ===============================================================
echo  HomeFinder is starting. Your browser will open in a moment.
echo  First time? Click "Create the admin account" on the login page.
echo  Keep this window open. Close it to stop the website.
echo ===============================================================
start "" /b cmd /c "timeout /t 4 /nobreak >nul && start http://127.0.0.1:5000/login.html"
python -m flask --app app run
pause
goto :eof

:nopython
echo Python was not found. Install it from python.org and tick "Add python.exe to PATH".
pause
