"""Automated tests: functional, validation, security, error handling, database."""
import base64
import sqlite3
import pytest
from app import create_app

PW = "Passw0rdOK"
TINY_JPEG = "data:image/jpeg;base64," + base64.b64encode(b"\xff\xd8\xff\xe0" + b"0" * 64).decode()


@pytest.fixture
def app(tmp_path):
    return create_app({"TESTING": True, "SECRET_KEY": "test", "WTF_CSRF_ENABLED": False,
                       "DATABASE": str(tmp_path / "t.db")})


@pytest.fixture
def client(app):
    return app.test_client()


def register(c, u="alice", e=None, pw=PW):
    return c.post("/api/register", json={"username": u, "email": e or f"{u}@x.com", "password": pw, "confirm": pw})


def login(c, u="alice", pw=PW):
    return c.post("/api/login", json={"username": u, "password": pw})


def listing(**o):
    d = {"title": "Nice bungalow", "description": "A lovely quiet bungalow.", "price": 5000000,
         "city": "Port Harcourt", "type": "house", "beds": 3, "baths": 2, "status": "available"}
    d.update(o)
    return d


def make_admin(app, c, name="boss"):
    runner = app.test_cli_runner()
    res = runner.invoke(args=["create-admin", "--username", name, "--email", f"{name}@x.com", "--password", PW])
    assert res.exit_code == 0, res.output
    return login(c, name)


def user_session(app, name):
    c = app.test_client(); register(c, name); login(c, name); return c


# ---- registration / login -------------------------------------------------
def test_register_ok(client):
    assert register(client).status_code == 201

def test_register_duplicate(client):
    register(client)
    assert register(client).status_code == 400
    assert register(client, u="ALICE", e="other@x.com").status_code == 400   # case-insensitive

@pytest.mark.parametrize("pw", ["short1A", "alllowercase1", "NoDigitsHere"])
def test_register_weak_password(client, pw):
    assert register(client, pw=pw).status_code == 400

def test_register_empty_bad_email_mismatch(client):
    assert client.post("/api/register", json={}).status_code == 400
    assert register(client, u="bob", e="not-an-email").status_code == 400
    r = client.post("/api/register", json={"username": "bob", "email": "b@x.com", "password": PW, "confirm": "Different1A"})
    assert r.status_code == 400

def test_login_me_logout(client):
    register(client)
    assert login(client).status_code == 200
    assert client.get("/api/me").get_json()["user"]["username"] == "alice"
    client.post("/api/logout")
    assert client.get("/api/me").get_json()["user"] is None

def test_login_wrong_password(client):
    register(client)
    r = login(client, pw="WrongPass1")
    assert r.status_code == 401 and "Invalid credentials" in r.get_json()["errors"][0]

def test_unknown_user_same_message(client):
    assert login(client, "ghost").get_json() == login(client, "alice", "WrongPass1").get_json()

def test_account_lockout(client):
    register(client)
    for _ in range(5):
        login(client, pw="WrongPass1")
    assert login(client).status_code == 401           # correct password, still locked


# ---- admin --------------------------------------------------------------
def test_create_admin_and_login(app, client):
    r = make_admin(app, client)
    assert r.status_code == 200 and r.get_json()["user"]["role"] == "admin"

def test_create_admin_rejects_weak_password(app):
    res = app.test_cli_runner().invoke(args=["create-admin", "--username", "boss", "--email", "b@x.com", "--password", "weak"])
    assert res.exit_code != 0

def test_admin_endpoints_blocked_for_anonymous_and_users(app, client):
    for path in ["/api/admin/users", "/api/admin/listings"]:
        assert client.get(path).status_code == 401
    uc = user_session(app, "alice")
    for path in ["/api/admin/users", "/api/admin/listings"]:
        assert uc.get(path).status_code == 403
    assert uc.post("/api/admin/users/1/role", json={"role": "admin"}).status_code == 403

def test_admin_lists_users_and_changes_role(app, client):
    make_admin(app, client)
    user_session(app, "alice")
    users = client.get("/api/admin/users").get_json()["items"]
    alice = next(u for u in users if u["username"] == "alice")
    assert client.post(f"/api/admin/users/{alice['id']}/role", json={"role": "admin"}).status_code == 200
    assert client.post(f"/api/admin/users/{alice['id']}/role", json={"role": "superuser"}).status_code == 400

def test_admin_cannot_change_own_role(app, client):
    make_admin(app, client)
    me = client.get("/api/me").get_json()["user"]
    assert client.post(f"/api/admin/users/{me['id']}/role", json={"role": "user"}).status_code == 400

def test_demoted_admin_loses_access_immediately(app, client):
    make_admin(app, client)
    b = user_session(app, "alice")
    alice = next(u for u in client.get("/api/admin/users").get_json()["items"] if u["username"] == "alice")
    client.post(f"/api/admin/users/{alice['id']}/role", json={"role": "admin"})
    assert b.get("/api/admin/users").status_code == 200
    client.post(f"/api/admin/users/{alice['id']}/role", json={"role": "user"})
    assert b.get("/api/admin/users").status_code == 403

def test_admin_can_delete_any_listing(app, client):
    a = user_session(app, "alice")
    lid = a.post("/api/listings", json=listing()).get_json()["listing"]["id"]
    make_admin(app, client)
    assert client.delete(f"/api/listings/{lid}").status_code == 200

def test_reset_password_command(app, client):
    register(client)
    res = app.test_cli_runner().invoke(args=["reset-password", "--username", "alice", "--password", "NewPassw0rd"])
    assert res.exit_code == 0 and login(client, pw="NewPassw0rd").status_code == 200

def test_seed_command(app, client):
    assert app.test_cli_runner().invoke(args=["seed"]).exit_code == 0
    assert client.get("/api/listings?limit=60").get_json()["total"] == 9


# ---- security -----------------------------------------------------------
def test_password_is_hashed(app, client):
    register(client)
    h = sqlite3.connect(app.config["DATABASE"]).execute("SELECT password_hash FROM users").fetchone()[0]
    assert PW not in h and h.startswith(("scrypt", "pbkdf2"))

def test_sql_injection_login(client):
    register(client)
    assert client.post("/api/login", json={"username": "alice' OR '1'='1' --", "password": "x"}).status_code == 401

def test_sql_injection_search(client):
    for p in ["' OR 1=1 --", "'; DROP TABLE listings; --", "%", "_"]:
        assert client.get("/api/listings", query_string={"q": p, "city": p}).status_code == 200
    assert client.get("/api/listings", query_string={"sort": "price; DROP TABLE users"}).status_code == 200
    assert client.get("/api/listings").status_code == 200

def test_script_text_is_stored_as_plain_data(app):
    c = user_session(app, "alice")
    payload = "<script>alert(1)</script>"
    r = c.post("/api/listings", json=listing(title=payload))
    assert r.status_code == 201
    got = c.get("/api/listings")
    assert got.mimetype == "application/json" and got.headers["X-Content-Type-Options"] == "nosniff"

def test_csrf_enforced(tmp_path):
    app = create_app({"TESTING": True, "SECRET_KEY": "t", "DATABASE": str(tmp_path / "c.db")})
    c = app.test_client()
    assert c.post("/api/login", json={"username": "a", "password": "b"}).status_code == 400
    token = c.get("/api/me").get_json()["csrf"]
    assert c.post("/api/login", json={"username": "a", "password": "b"}, headers={"X-CSRFToken": token}).status_code == 401

def test_security_headers(client):
    r = client.get("/api/me")
    assert "Content-Security-Policy" in r.headers and r.headers["X-Frame-Options"] == "DENY"
    assert r.headers["Cache-Control"] == "no-store"

def test_session_cookie_flags(client):
    register(client)
    cookie = login(client).headers.get("Set-Cookie", "")
    assert "HttpOnly" in cookie and "SameSite=Lax" in cookie

def test_anonymous_cannot_write(client):
    assert client.post("/api/listings", json=listing()).status_code == 401
    assert client.delete("/api/listings/1").status_code == 401
    assert client.get("/api/my/listings").status_code == 401

def test_user_cannot_delete_others_listing(app):
    a, b = user_session(app, "alice"), user_session(app, "bobby")
    lid = a.post("/api/listings", json=listing()).get_json()["listing"]["id"]
    assert b.delete(f"/api/listings/{lid}").status_code == 403
    assert a.get(f"/api/listings/{lid}").status_code == 200


# ---- validation / functional -------------------------------------------
@pytest.mark.parametrize("bad", [{"title": ""}, {"price": -5}, {"price": "abc"}, {"price": True}, {"type": "castle"},
                                 {"beds": 999}, {"city": ""}, {"status": "hacked"}, {"image": "javascript:alert(1)"},
                                 {"image": "data:image/jpeg;base64,!!!notbase64"},
                                 {"image": "data:image/jpeg;base64," + base64.b64encode(b"not a jpeg").decode()}])
def test_listing_validation(app, bad):
    c = user_session(app, "alice")
    assert c.post("/api/listings", json=listing(**bad)).status_code == 400

def test_listing_with_valid_photo(app):
    c = user_session(app, "alice")
    r = c.post("/api/listings", json=listing(image=TINY_JPEG))
    assert r.status_code == 201 and r.get_json()["listing"]["image"] == TINY_JPEG

def test_oversized_request_rejected(app):
    c = user_session(app, "alice")
    assert c.post("/api/listings", json=listing(description="x" * 700_000)).status_code == 413

def test_search_filter_limit_and_stats(app):
    c = user_session(app, "alice")
    c.post("/api/listings", json=listing(title="Cheap flat", price=1000000, type="apartment", city="Lagos"))
    c.post("/api/listings", json=listing(title="Big house", price=90000000))
    titles = lambda **q: [i["title"] for i in c.get("/api/listings", query_string=q).get_json()["items"]]
    assert titles(city="Lagos") == ["Cheap flat"]
    assert titles(min=50000000) == ["Big house"]
    assert titles(type="apartment") == ["Cheap flat"]
    assert titles(sort="asc")[0] == "Cheap flat"
    assert len(titles(limit=1)) == 1
    s = c.get("/api/stats").get_json()
    assert s["available"] == 2 and s["mine"] == 2 and s["by_type"]["house"] == 1

def test_sold_listings_hidden_from_browse(app):
    c = user_session(app, "alice")
    c.post("/api/listings", json=listing(status="sold"))
    assert c.get("/api/listings").get_json()["total"] == 0
    assert len(c.get("/api/my/listings").get_json()["items"]) == 1


# ---- error handling + static front end ------------------------------------
def test_404_json_for_api(client):
    r = client.get("/api/listings/9999")
    assert r.status_code == 404 and "errors" in r.get_json()

def test_405_json_for_api(client):
    assert client.put("/api/listings").status_code == 405

def test_no_traceback_leak(app, client):
    @app.route("/api/boom")
    def boom(): raise ValueError("secret detail")
    app.config["PROPAGATE_EXCEPTIONS"] = False
    r = client.get("/api/boom")
    assert r.status_code == 500 and b"secret detail" not in r.data

def test_front_end_is_served(client):
    for path in ["/", "/index.html", "/login.html", "/admin.html", "/security.html", "/js/main.js", "/css/style.css", "/images/hero.svg"]:
        assert client.get(path).status_code == 200, path

def test_source_files_not_exposed(client):
    for path in ["/app.py", "/.env", "/homefinder.db", "/requirements.txt"]:
        assert client.get(path).status_code == 404, path


# ---- first-run admin setup (browser) ------------------------------------
SETUP = {"username": "owner", "email": "owner@x.com", "password": PW, "confirm": PW}

def test_setup_needed_then_creates_admin_then_locks(client):
    assert client.get("/api/setup-status").get_json()["needed"] is True
    assert client.post("/api/setup", json=SETUP).status_code == 201
    assert client.get("/api/setup-status").get_json()["needed"] is False
    assert login(client, "owner").get_json()["user"]["role"] == "admin"
    again = client.post("/api/setup", json={**SETUP, "username": "intruder", "email": "i@x.com"})
    assert again.status_code == 403

def test_setup_validates_input(client):
    assert client.post("/api/setup", json={}).status_code == 400
    assert client.post("/api/setup", json={**SETUP, "password": "weak", "confirm": "weak"}).status_code == 400
    assert client.post("/api/setup", json={**SETUP, "confirm": "Different1A"}).status_code == 400
    assert client.get("/api/setup-status").get_json()["needed"] is True

def test_setup_locked_when_admin_made_by_cli(app, client):
    make_admin(app, client)
    assert client.get("/api/setup-status").get_json()["needed"] is False
    assert client.post("/api/setup", json={**SETUP, "username": "late", "email": "l@x.com"}).status_code == 403

def test_normal_user_registration_does_not_close_setup(client):
    register(client)
    assert client.get("/api/setup-status").get_json()["needed"] is True

def test_setup_page_served(client):
    assert client.get("/setup.html").status_code == 200
