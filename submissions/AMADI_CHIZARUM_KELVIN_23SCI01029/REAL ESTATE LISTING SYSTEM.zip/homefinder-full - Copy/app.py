"""HomeFinder backend: Flask + SQLite JSON API that also serves the front end in /static."""
import base64
import binascii
import logging
import os
import re
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone
from functools import wraps
from logging.handlers import RotatingFileHandler

import click
from dotenv import load_dotenv
from flask import Flask, current_app, g, jsonify, request, send_from_directory, session
from flask_wtf.csrf import CSRFError, CSRFProtect, generate_csrf
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))
csrf = CSRFProtect()

PROPERTY_TYPES = ("house", "apartment", "land", "commercial")
STATUSES = ("available", "sold", "rented")
ROLES = ("user", "admin")
SORTS = {"newest": "l.created_at DESC, l.id DESC", "asc": "l.price ASC", "desc": "l.price DESC"}
USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,30}$")
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]+\.[^@\s]+$")
MAX_FAILED, LOCK_MINUTES = 5, 15
JPEG_PREFIX = "data:image/jpeg;base64,"
MAX_IMAGE_CHARS = 450_000
DUMMY_HASH = generate_password_hash("dummy-password-for-timing")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS listings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  price INTEGER NOT NULL CHECK (price > 0),
  city TEXT NOT NULL,
  property_type TEXT NOT NULL,
  bedrooms INTEGER NOT NULL DEFAULT 0,
  bathrooms INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'available',
  image TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_listings_city ON listings(city);
"""

SAMPLE = [
    ("3-bedroom bungalow, GRA Phase 2", "Spacious bungalow with boys' quarters, tiled floors and steady water supply.", 85000000, "Port Harcourt", "house", 3, 3, "images/house-a.svg", "2026-09-20"),
    ("Serviced 2-bed apartment, Trans-Amadi", "Modern apartment with prepaid meter, generator backup and parking.", 3500000, "Port Harcourt", "apartment", 2, 2, "images/apartment-a.svg", "2026-09-18"),
    ("600 sqm land, Lekki", "Dry land with survey and C of O, close to the expressway.", 45000000, "Lagos", "land", 0, 0, "images/land-a.svg", "2026-09-15"),
    ("Office space, Wuse II", "Open-plan floor of 250 sqm with lift and ample parking.", 12000000, "Abuja", "commercial", 0, 2, "images/commercial-a.svg", "2026-09-12"),
    ("4-bedroom duplex, Rumuigbo", "Newly built duplex with BQ, fenced compound and gate house.", 120000000, "Port Harcourt", "house", 4, 5, "images/house-b.svg", "2026-09-10"),
    ("Mini flat, Yaba", "Clean self-contained flat near the tech hub, good road access.", 1800000, "Lagos", "apartment", 1, 1, "images/apartment-b.svg", "2026-09-08"),
    ("3-bed terrace, Ikeja GRA", "Terrace house in a quiet gated estate with 24-hour security.", 68000000, "Lagos", "house", 3, 3, "images/house-b.svg", "2026-09-05"),
    ("Plot of land, Enugu", "Half plot in a developed layout, all documents available.", 6500000, "Enugu", "land", 0, 0, "images/land-b.svg", "2026-09-01"),
    ("Commercial block, Aba Road", "Ground-floor shop units on a busy road with constant foot traffic.", 55000000, "Port Harcourt", "commercial", 0, 4, "images/commercial-b.svg", "2026-08-28"),
]


def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def q_all(sql, params=()):          # ALWAYS parameterised -> no SQL injection
    return get_db().execute(sql, params).fetchall()


def q_one(sql, params=()):
    return get_db().execute(sql, params).fetchone()


def q_exec(sql, params=()):
    db = get_db()
    cur = db.execute(sql, params)
    db.commit()
    return cur


# -------------------------------------------------------------- validation
def parse_int(value, lo, hi):
    if isinstance(value, bool):
        return None
    try:
        n = int(str(value).strip())
    except (TypeError, ValueError):
        return None
    return n if lo <= n <= hi else None


def text(d, key):
    v = d.get(key, "")
    return v.strip() if isinstance(v, str) else ""


def validate_password(pw):
    errs = []
    if not isinstance(pw, str) or len(pw) < 8:
        errs.append("Password must be at least 8 characters.")
        return errs
    if len(pw) > 128:
        errs.append("Password is too long.")
    if not re.search(r"[a-z]", pw) or not re.search(r"[A-Z]", pw):
        errs.append("Password needs upper and lower case letters.")
    if not re.search(r"\d", pw):
        errs.append("Password needs at least one digit.")
    return errs


def validate_image(value):
    """Accept None, a bundled image path, or a small real JPEG sent as a data URL."""
    if not value:
        return None, None
    if not isinstance(value, str):
        return None, "Invalid photo."
    if value.startswith("images/") and re.fullmatch(r"images/[a-z0-9-]+\.(svg|jpg)", value):
        return value, None
    if not value.startswith(JPEG_PREFIX) or len(value) > MAX_IMAGE_CHARS:
        return None, "Photo must be a JPEG under about 300 KB."
    try:
        raw = base64.b64decode(value[len(JPEG_PREFIX):], validate=True)
    except (binascii.Error, ValueError):
        return None, "Photo data is corrupt."
    if not raw.startswith(b"\xff\xd8\xff"):          # check the real file signature
        return None, "Photo is not a valid JPEG."
    return value, None


def validate_listing(d):
    c = {"title": text(d, "title"), "description": text(d, "description"), "city": text(d, "city"),
         "type": d.get("type"), "status": d.get("status", "available")}
    errors = []
    if not 5 <= len(c["title"]) <= 120:
        errors.append("Title must be 5-120 characters.")
    if not 10 <= len(c["description"]) <= 2000:
        errors.append("Description must be 10-2000 characters.")
    if not 2 <= len(c["city"]) <= 60:
        errors.append("City must be 2-60 characters.")
    if c["type"] not in PROPERTY_TYPES:
        errors.append("Choose a valid property type.")
    if c["status"] not in STATUSES:
        errors.append("Choose a valid status.")
    c["price"] = parse_int(d.get("price"), 1, 10_000_000_000)
    c["beds"] = parse_int(d.get("beds", 0), 0, 50)
    c["baths"] = parse_int(d.get("baths", 0), 0, 50)
    if c["price"] is None:
        errors.append("Price must be a whole number greater than 0.")
    if c["beds"] is None or c["baths"] is None:
        errors.append("Bedrooms and bathrooms must be 0-50.")
    c["image"], img_err = validate_image(d.get("image"))
    if img_err:
        errors.append(img_err)
    return c, errors


# -------------------------------------------------------------- serialisers
def user_json(u):
    return {"id": u["id"], "username": u["username"], "email": u["email"],
            "role": u["role"], "created": u["created_at"][:10]}


def listing_json(r):
    return {"id": r["id"], "title": r["title"], "description": r["description"], "price": r["price"],
            "city": r["city"], "type": r["property_type"], "beds": r["bedrooms"], "baths": r["bathrooms"],
            "status": r["status"], "owner": r["owner"], "owner_id": r["owner_id"],
            "date": r["created_at"][:10], "image": r["image"]}


LISTING_SELECT = "SELECT l.*, u.username AS owner FROM listings l JOIN users u ON u.id = l.owner_id"


def sec_log(msg):
    current_app.logger.warning("SECURITY %s ip=%s", msg, request.remote_addr)


# ---------------------------------------------------------- access control
def login_required(f):
    @wraps(f)
    def wrapper(*a, **k):
        if g.user is None:
            return jsonify(errors=["Please log in."]), 401
        return f(*a, **k)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*a, **k):
        if g.user is None:
            return jsonify(errors=["Please log in."]), 401
        if g.user["role"] != "admin":
            sec_log(f"ACCESS_DENIED user={g.user['username']} path={request.path}")
            return jsonify(errors=["Admin access required."]), 403
        return f(*a, **k)
    return wrapper


def ensure_secret_key():
    """First-run convenience: create a random SECRET_KEY in .env if none exists."""
    key = os.environ.get("SECRET_KEY")
    if key:
        return key
    key = secrets.token_hex(32)
    with open(os.path.join(BASE_DIR, ".env"), "a", encoding="utf-8") as f:
        f.write(f"\nSECRET_KEY={key}\n")
    os.environ["SECRET_KEY"] = key
    return key


# --------------------------------------------------------------- app factory
def create_app(config=None):
    app = Flask(__name__, static_folder="static", static_url_path="")
    app.config.update(
        DATABASE=os.path.join(BASE_DIR, "homefinder.db"),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
        PERMANENT_SESSION_LIFETIME=timedelta(minutes=30),
        MAX_CONTENT_LENGTH=600 * 1024,
    )
    if config:
        app.config.update(config)
    if not app.config.get("SECRET_KEY"):
        app.config["SECRET_KEY"] = ensure_secret_key()
    csrf.init_app(app)

    if not app.config.get("TESTING"):
        os.makedirs(os.path.join(BASE_DIR, "logs"), exist_ok=True)
        h = RotatingFileHandler(os.path.join(BASE_DIR, "logs", "app.log"), maxBytes=1_000_000, backupCount=5)
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        app.logger.addHandler(h)
        app.logger.setLevel(logging.INFO)

    with app.app_context():
        get_db().executescript(SCHEMA)

    @app.teardown_appcontext
    def close_db(_):
        db = g.pop("db", None)
        if db is not None:
            db.close()

    @app.before_request
    def load_user():
        g.user = None
        if request.endpoint == "static":
            return
        uid = session.get("user_id")
        if uid:
            g.user = q_one("SELECT * FROM users WHERE id = ?", (uid,))   # role is re-read every request
            if g.user is None:
                session.clear()

    @app.after_request
    def security_headers(resp):
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; "
            "font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; "
            "frame-ancestors 'none'; form-action 'self'; base-uri 'self'")
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        resp.headers["Permissions-Policy"] = "geolocation=(), camera=(), microphone=()"
        if app.config["SESSION_COOKIE_SECURE"]:
            resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    # ------------------------------------------------------------- errors
    def err(code, msg):
        if request.path.startswith("/api/"):
            return jsonify(errors=[msg]), code
        return msg, code

    @app.errorhandler(400)
    def e400(_): return err(400, "Bad request.")

    @app.errorhandler(403)
    def e403(_): return err(403, "Access denied.")

    @app.errorhandler(404)
    def e404(_): return err(404, "Not found.")

    @app.errorhandler(405)
    def e405(_): return err(405, "Method not allowed.")

    @app.errorhandler(413)
    def e413(_): return err(413, "That request was too large.")

    @app.errorhandler(CSRFError)
    def ecsrf(_): return err(400, "Your session expired. Refresh the page and try again.")

    @app.errorhandler(500)
    def e500(e):
        app.logger.exception("Unhandled error: %s", e)
        return err(500, "Something went wrong. It has been logged.")

    # -------------------------------------------------------------- pages
    @app.get("/")
    def home():
        return send_from_directory(app.static_folder, "index.html")

    # ------------------------------------------------------------ session
    @app.get("/api/me")
    def me():
        return jsonify(user=user_json(g.user) if g.user else None, csrf=generate_csrf())

    @app.post("/api/register")
    def register():
        d = request.get_json(silent=True) or {}
        username, email = text(d, "username"), text(d, "email")
        pw, pw2 = d.get("password", ""), d.get("confirm", "")
        errors = []
        if not USERNAME_RE.match(username):
            errors.append("Username: 3-30 letters, numbers or underscores.")
        if not EMAIL_RE.match(email) or len(email) > 120:
            errors.append("Enter a valid email address.")
        errors += validate_password(pw)
        if pw != pw2:
            errors.append("Passwords do not match.")
        if errors:
            return jsonify(errors=errors), 400
        try:
            q_exec("INSERT INTO users (username,email,password_hash,role,created_at) VALUES (?,?,?,'user',?)",
                   (username, email, generate_password_hash(pw), now()))
        except sqlite3.IntegrityError:
            return jsonify(errors=["That username or email is already registered."]), 400
        return jsonify(ok=True), 201

    @app.post("/api/login")
    def login():
        d = request.get_json(silent=True) or {}
        username, pw = text(d, "username"), d.get("password", "")
        if not isinstance(pw, str):
            pw = ""
        user = q_one("SELECT * FROM users WHERE username = ?", (username,))
        locked = bool(user and user["locked_until"] and user["locked_until"] > now())
        ok = check_password_hash(user["password_hash"] if user else DUMMY_HASH, pw)
        if user and ok and not locked:
            q_exec("UPDATE users SET failed_attempts=0, locked_until=NULL WHERE id=?", (user["id"],))
            session.clear()                       # prevents session fixation
            session["user_id"] = user["id"]
            session.permanent = True
            current_app.logger.info("LOGIN_OK user=%s", user["username"])
            return jsonify(user=user_json(user))
        if user and not locked:
            fails, until = user["failed_attempts"] + 1, None
            if fails >= MAX_FAILED:
                until = (datetime.now(timezone.utc) + timedelta(minutes=LOCK_MINUTES)).isoformat(timespec="seconds")
                fails = 0
                sec_log(f"ACCOUNT_LOCKED user={user['username']}")
            q_exec("UPDATE users SET failed_attempts=?, locked_until=? WHERE id=?", (fails, until, user["id"]))
        sec_log(f"LOGIN_FAILED username={username[:30]!r}")
        return jsonify(errors=["Invalid credentials, or the account is temporarily locked."]), 401

    # ---------------------------------------------- first-run admin setup
    def admin_exists():
        return q_one("SELECT 1 FROM users WHERE role = 'admin' LIMIT 1") is not None

    @app.get("/api/setup-status")
    def setup_status():
        return jsonify(needed=not admin_exists())

    @app.post("/api/setup")
    def setup():
        """Create the very first admin from the browser. Locked forever once an admin exists."""
        if admin_exists():
            sec_log("SETUP_BLOCKED admin already exists")
            return jsonify(errors=["Setup is already complete."]), 403
        d = request.get_json(silent=True) or {}
        username, email = text(d, "username"), text(d, "email")
        pw, pw2 = d.get("password", ""), d.get("confirm", "")
        errors = []
        if not USERNAME_RE.match(username):
            errors.append("Username: 3-30 letters, numbers or underscores.")
        if not EMAIL_RE.match(email) or len(email) > 120:
            errors.append("Enter a valid email address.")
        errors += validate_password(pw)
        if pw != pw2:
            errors.append("Passwords do not match.")
        if errors:
            return jsonify(errors=errors), 400
        try:
            q_exec("INSERT INTO users (username,email,password_hash,role,created_at) VALUES (?,?,?,'admin',?)",
                   (username, email, generate_password_hash(pw), now()))
        except sqlite3.IntegrityError:
            return jsonify(errors=["That username or email is already registered."]), 400
        current_app.logger.warning("SECURITY ADMIN_CREATED via setup user=%s ip=%s", username, request.remote_addr)
        return jsonify(ok=True), 201

    @app.post("/api/logout")
    def logout():
        session.clear()
        return jsonify(ok=True)

    # ----------------------------------------------------------- listings
    @app.get("/api/stats")
    def stats():
        by_type = {r["property_type"]: r["n"] for r in q_all(
            "SELECT property_type, COUNT(*) n FROM listings WHERE status='available' GROUP BY property_type")}
        total = q_one("SELECT COUNT(*) c FROM listings WHERE status='available'")["c"]
        cities = q_one("SELECT COUNT(DISTINCT city) c FROM listings WHERE status='available'")["c"]
        mine = q_one("SELECT COUNT(*) c FROM listings WHERE owner_id=?", (g.user["id"],))["c"] if g.user else 0
        return jsonify(available=total, cities=cities, by_type=by_type, mine=mine)

    @app.get("/api/listings")
    def listings():
        a = request.args
        where, params = ["l.status = 'available'"], []
        q = a.get("q", "").strip()[:100]
        city = a.get("city", "").strip()[:60]
        esc = lambda s: s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        if q:
            where.append("(l.title LIKE ? ESCAPE '\\' OR l.description LIKE ? ESCAPE '\\')")
            params += [f"%{esc(q)}%"] * 2
        if city:
            where.append("l.city LIKE ? ESCAPE '\\'")
            params.append(f"%{esc(city)}%")
        if a.get("type") in PROPERTY_TYPES:
            where.append("l.property_type = ?"); params.append(a["type"])
        beds, lo, hi = parse_int(a.get("beds"), 0, 50), parse_int(a.get("min"), 0, 10**10), parse_int(a.get("max"), 0, 10**10)
        if beds is not None:
            where.append("l.bedrooms >= ?"); params.append(beds)
        if lo is not None:
            where.append("l.price >= ?"); params.append(lo)
        if hi is not None:
            where.append("l.price <= ?"); params.append(hi)
        order = SORTS.get(a.get("sort"), SORTS["newest"])            # whitelist, never raw input
        limit = parse_int(a.get("limit"), 1, 60) or 9
        clause = " AND ".join(where)
        total = q_one(f"SELECT COUNT(*) c FROM listings l WHERE {clause}", params)["c"]
        rows = q_all(f"{LISTING_SELECT} WHERE {clause} ORDER BY {order} LIMIT ?", params + [limit])
        return jsonify(items=[listing_json(r) for r in rows], total=total)

    @app.get("/api/my/listings")
    @login_required
    def my_listings():
        rows = q_all(f"{LISTING_SELECT} WHERE l.owner_id = ? ORDER BY l.created_at DESC, l.id DESC", (g.user["id"],))
        return jsonify(items=[listing_json(r) for r in rows])

    @app.get("/api/listings/<int:listing_id>")
    def listing_get(listing_id):
        r = q_one(f"{LISTING_SELECT} WHERE l.id = ?", (listing_id,))
        if r is None:
            return jsonify(errors=["Listing not found."]), 404
        return jsonify(listing=listing_json(r))

    @app.post("/api/listings")
    @login_required
    def listing_create():
        c, errors = validate_listing(request.get_json(silent=True) or {})
        if errors:
            return jsonify(errors=errors), 400
        cur = q_exec("""INSERT INTO listings (owner_id,title,description,price,city,property_type,
                        bedrooms,bathrooms,status,image,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                     (g.user["id"], c["title"], c["description"], c["price"], c["city"], c["type"],
                      c["beds"], c["baths"], c["status"], c["image"], now()))
        r = q_one(f"{LISTING_SELECT} WHERE l.id = ?", (cur.lastrowid,))
        return jsonify(listing=listing_json(r)), 201

    @app.delete("/api/listings/<int:listing_id>")
    @login_required
    def listing_delete(listing_id):
        r = q_one("SELECT owner_id FROM listings WHERE id = ?", (listing_id,))
        if r is None:
            return jsonify(errors=["Listing not found."]), 404
        if g.user["role"] != "admin" and r["owner_id"] != g.user["id"]:   # object-level access check
            sec_log(f"IDOR_BLOCKED user={g.user['username']} listing={listing_id}")
            return jsonify(errors=["You can only delete your own listings."]), 403
        q_exec("DELETE FROM listings WHERE id = ?", (listing_id,))
        return jsonify(ok=True)

    # -------------------------------------------------------------- admin
    @app.get("/api/admin/users")
    @admin_required
    def admin_users():
        rows = q_all("""SELECT u.*, (SELECT COUNT(*) FROM listings WHERE owner_id=u.id) AS n
                        FROM users u ORDER BY u.created_at, u.id""")
        return jsonify(items=[{**user_json(u), "listings": u["n"]} for u in rows])

    @app.get("/api/admin/listings")
    @admin_required
    def admin_listings():
        rows = q_all(f"{LISTING_SELECT} ORDER BY l.created_at DESC, l.id DESC")
        return jsonify(items=[listing_json(r) for r in rows])

    @app.post("/api/admin/users/<int:user_id>/role")
    @admin_required
    def admin_role(user_id):
        role = (request.get_json(silent=True) or {}).get("role")
        if role not in ROLES:
            return jsonify(errors=["Invalid role."]), 400
        if user_id == g.user["id"]:
            return jsonify(errors=["You can't change your own role."]), 400
        if q_one("SELECT id FROM users WHERE id=?", (user_id,)) is None:
            return jsonify(errors=["User not found."]), 404
        q_exec("UPDATE users SET role=? WHERE id=?", (role, user_id))
        sec_log(f"ROLE_CHANGED by={g.user['username']} target={user_id} role={role}")
        return jsonify(ok=True)

    # ---------------------------------------------------------------- CLI
    @app.cli.command("create-admin")
    @click.option("--username", prompt=True)
    @click.option("--email", prompt=True)
    @click.password_option()
    def create_admin(username, email, password):
        """Create an admin account (admins cannot self-register)."""
        errs = validate_password(password)
        if not USERNAME_RE.match(username) or not EMAIL_RE.match(email) or errs:
            raise click.ClickException("Invalid input. " + " ".join(errs or ["Check the username and email."]))
        try:
            q_exec("INSERT INTO users (username,email,password_hash,role,created_at) VALUES (?,?,?,'admin',?)",
                   (username, email, generate_password_hash(password), now()))
        except sqlite3.IntegrityError:
            raise click.ClickException("That username or email already exists.")
        click.echo(f"Admin '{username}' created. Log in at /login.html")

    @app.cli.command("reset-password")
    @click.option("--username", prompt=True)
    @click.password_option()
    def reset_password(username, password):
        """Set a new password for any account (use if you forget the admin password)."""
        errs = validate_password(password)
        if errs:
            raise click.ClickException(" ".join(errs))
        cur = q_exec("UPDATE users SET password_hash=?, failed_attempts=0, locked_until=NULL WHERE username=?",
                     (generate_password_hash(password), username))
        if cur.rowcount == 0:
            raise click.ClickException("No such user.")
        click.echo("Password updated.")

    @app.cli.command("seed")
    def seed():
        """Add demo listings (owned by a locked 'demo' account)."""
        if q_one("SELECT COUNT(*) c FROM listings")["c"]:
            click.echo("Listings already exist; nothing to do.")
            return
        demo = q_one("SELECT id FROM users WHERE username='demo'")
        if demo is None:
            demo = q_exec("INSERT INTO users (username,email,password_hash,role,created_at) VALUES ('demo','demo@example.com',?,'user',?)",
                          (generate_password_hash(secrets.token_urlsafe(32)), now())).lastrowid
        else:
            demo = demo["id"]
        for t, d, p, c, ty, b, ba, img, date in SAMPLE:
            q_exec("""INSERT INTO listings (owner_id,title,description,price,city,property_type,bedrooms,
                      bathrooms,status,image,created_at) VALUES (?,?,?,?,?,?,?,?,'available',?,?)""",
                   (demo, t, d, p, c, ty, b, ba, img, date + "T09:00:00+00:00"))
        click.echo(f"Added {len(SAMPLE)} demo listings.")

    return app
