# HomeFinder: Real Estate Listing System (full stack)
Front end (HTML/CSS/JS in `static/`) + Flask/SQLite backend (`app.py`) with user and **admin login**.

## Quick start (Windows): double-click `start.bat`
1. Install Python 3.10+ from python.org (tick "Add python.exe to PATH") if you do not have it.
2. Double-click **start.bat**. The first run sets everything up (a minute or two), then opens the site.
3. **First time only:** on the login page click **Create the admin account**, choose a username, email and
   password (8+ characters with upper case, lower case and a digit). You are logged in as admin straight away.
4. Keep the black window open while you use the site. Close it to stop the website.
Next time just double-click `start.bat` again and log in at `/login.html`.

The "Create the admin account" page (`/setup.html`) only works while no admin exists; after that it is locked (403).

### Manual way (terminal)
```powershell
python -m venv .venv
.venv\Scripts\activate.bat
pip install -r requirements.txt
flask --app app seed
flask --app app run --debug
```
Optional: create the admin from the terminal instead of the browser:
`flask --app app create-admin`. Forgot the password? `flask --app app reset-password --username YOURNAME`

## Admin
- Log in at `/login.html`. Admins go straight to `/admin.html`, and an **Admin** link appears in the menu.
- The admin can change any user's role (user or admin) and delete any listing.
- On a public server, create the admin right after deploying (before anyone else visits `/setup.html`).

## API summary
| Method | Route | Who |
|---|---|---|
| GET | `/api/me`, `/api/stats`, `/api/listings`, `/api/listings/<id>` | anyone |
| POST | `/api/register`, `/api/login`, `/api/logout` | anyone |
| POST / DELETE | `/api/listings`, `/api/listings/<id>` | logged in (delete: owner or admin) |
| GET | `/api/my/listings` | logged in |
| GET | `/api/admin/users`, `/api/admin/listings` | admin |
| POST | `/api/admin/users/<id>/role` | admin |

## Security
Scrypt password hashing, 5-strike lockout, roles checked on every request, owner/admin checks (IDOR),
server-side validation (incl. real JPEG check), parameterised SQL, CSP + escaped DOM output (XSS),
CSRF header token on every write, HttpOnly/SameSite cookies, `.env` secrets, security headers,
rotating log `logs/app.log`. See `/security.html`.

## Testing
`python -m pytest -v` runs 53 tests: registration, login, lockout, admin access, role changes, hashing,
SQL injection, CSRF, headers, access control, validation, filters, error handling, static files.

| Manual test | Expected | Status |
|---|---|---|
| Register then log in | Home page, menu shows your name | |
| Wrong password | Generic error | |
| Normal user opens `/admin.html` | Redirected to home | |
| Admin changes a user's role | Role saved | |
| Admin deletes any listing | Listing gone | |
| Post listing with photo | Appears on Browse | |
| Phone width 360px (DevTools) | Menu collapses, cards stack | |

## Deployment (summary)
1. Server: Ubuntu + Python, `git clone`, `python3 -m venv venv && venv/bin/pip install -r requirements.txt`.
2. `.env`: set `COOKIE_SECURE=1`; create admin with `create-admin`.
3. Run with Gunicorn: `venv/bin/gunicorn -w 3 -b 127.0.0.1:8000 wsgi:app` (systemd service, `Restart=always`).
4. Nginx reverse proxy to port 8000, then `sudo certbot --nginx -d yourdomain.com` for HTTPS.
5. Backups: nightly `sqlite3 homefinder.db ".backup /var/backups/hf-$(date +%F).db"`.
6. Monitor: `tail -f logs/app.log`, `grep SECURITY logs/app.log`.
Free option: PythonAnywhere or Render (HTTPS included).



