import io
import os
import shutil
import sqlite3
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

# Import the app with isolated paths so the bundled data stays untouched.
with tempfile.TemporaryDirectory() as startup:
    with patch.dict(os.environ, {
        "SAFEREPORT_DATABASE": str(Path(startup) / "startup.db"),
        "SAFEREPORT_UPLOADS": str(Path(startup) / "uploads"),
    }):
        from app import app, get_db, init_db

from werkzeug.security import check_password_hash, generate_password_hash


class SafeReportTests(unittest.TestCase):
    def setUp(self):
        # Prepare a temporary database, upload folder, test administrator, and separate clients.
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.db_path = Path(self.folder.name) / "test.db"
        self.uploads = Path(self.folder.name) / "uploads"
        self.uploads.mkdir()
        config = patch.dict(app.config, DATABASE=self.db_path, UPLOAD_FOLDER=self.uploads, TESTING=True)
        config.start()
        self.addCleanup(config.stop)
        with app.app_context():
            init_db()
            db = get_db()
            with db:
                db.execute(
                    "INSERT INTO admins (username, password_hash) VALUES (?, ?)",
                    ("TestAdmin", generate_password_hash("TestPassword20")),
                )
        self.user = app.test_client()
        self.admin = app.test_client()

    def register(self, client, username="Reporter", **overrides):
        # Submit the sample registration form with any fields overridden by the test.
        data = {
            "username": username,
            "full_name": "Test Reporter",
            "phone": "08012345678",
            "password": "TestPassword20",
            "confirm_password": "TestPassword20",
        }
        return client.post("/register", data={**data, **overrides}, follow_redirects=True)

    def login(self, client, username="Reporter", admin=False, password="TestPassword20"):
        # Sign a test client in through the chosen account role's login page.
        return client.post(
            "/admin/login" if admin else "/login",
            data={"username": username, "password": password},
            follow_redirects=True,
        )

    def submit(self, **overrides):
        # Send a sample report with any fields or attachment supplied by the test.
        data = {
            "full_name": "Test Reporter",
            "phone": "08012345678",
            "disaster_type": "Flood",
            "location": "Ado-Ekiti",
            "description": "Flooding near the main road.",
        }
        return self.user.post("/report", data={**data, **overrides}, follow_redirects=True)

    def test_registration_validation_password_storage_and_role(self):
        # Check registration validation, duplicate usernames, password hashing, and account roles.
        invalid = self.register(self.user, full_name="")
        self.assertIn(b"valid phone number", invalid.data)
        created = self.register(self.user, role="admin")
        self.assertIn(b"Account created", created.data)
        duplicate = self.register(self.user, username="reporter")
        self.assertIn(b"already taken", duplicate.data)
        with app.app_context():
            db = get_db()
            stored_hash = db.execute("SELECT password_hash FROM users").fetchone()[0]
            self.assertNotEqual(stored_hash, "TestPassword20")
            self.assertTrue(check_password_hash(stored_hash, "TestPassword20"))
            self.assertEqual(db.execute("SELECT COUNT(*) FROM admins").fetchone()[0], 1)

    def test_login_cookie_access_control_and_logout(self):
        # Check sign-in, session cookie settings, route permissions, and sign-out.
        self.assertEqual(self.user.get("/admin/dashboard").status_code, 302)
        self.assertEqual(self.user.get("/report").status_code, 302)
        self.register(self.user)
        self.assertIn(b"Invalid username or password", self.login(self.user, password="wrong").data)
        response = self.user.post("/login", data={"username": "Reporter", "password": "TestPassword20"})
        self.assertTrue(response.location.endswith("/dashboard"))
        cookie = response.headers["Set-Cookie"]
        self.assertIn("HttpOnly", cookie)
        self.assertIn("SameSite=Lax", cookie)
        self.assertEqual(self.user.get("/admin/dashboard").status_code, 403)
        self.assertEqual(self.user.post("/admin/reports/1", data={"status": "Resolved"}).status_code, 403)
        self.assertEqual(self.user.get("/logout").status_code, 405)
        self.user.post("/logout")
        self.assertEqual(self.user.get("/profile").status_code, 302)

    def test_profile_and_report_form_validation(self):
        # Check profile updates and rejection of invalid reports and uploads.
        self.register(self.user)
        self.login(self.user)
        self.assertIn(b"valid phone number", self.user.post("/profile", data={"phone": "bad"}).data)
        updated = self.user.post(
            "/profile", data={"full_name": "Updated Reporter", "phone": "+234 8012345678"},
            follow_redirects=True,
        )
        self.assertIn(b"Profile updated", updated.data)
        self.assertIn(b"Updated Reporter", self.user.get("/report").data)
        self.assertIn(b"valid disaster type", self.submit(disaster_type="Invalid").data)
        self.assertIn(b"within the field limits", self.submit(location="").data)
        self.assertIn(b"Use a JPG", self.submit(image=(io.BytesIO(b"test"), "notes.txt")).data)
        oversized = self.submit(image=(io.BytesIO(b"0" * (5 * 1024 * 1024)), "evidence.png"))
        self.assertEqual(oversized.status_code, 413)
        oversized.close()

    def test_report_search_status_ownership_and_attachment(self):
        # Check search, access to reports and images, and administrator status updates.
        self.register(self.user)
        self.login(self.user)
        attachment = next((Path(__file__).parent / "uploads").glob("*.png"))
        submitted = self.submit(image=(io.BytesIO(attachment.read_bytes()), "evidence.png"))
        self.assertIn(b"Your disaster report was submitted", submitted.data)
        with app.app_context():
            row = get_db().execute("SELECT image, user_id, status FROM reports").fetchone()
            self.assertEqual(row["user_id"], 1)
            self.assertEqual(row["status"], "Pending")
            filename = row["image"]

        detail = self.user.get("/reports/1")
        self.assertEqual(detail.status_code, 200)
        self.assertNotIn(b"Update Report Status", detail.data)
        with self.user.get("/reports/1/image") as image_response:
            self.assertEqual(image_response.mimetype, "image/png")
            self.assertEqual(image_response.data, attachment.read_bytes())
        self.assertEqual(self.user.get(f"/static/uploads/{filename}").status_code, 404)

        other = app.test_client()
        self.register(other, username="OtherUser")
        self.login(other, username="OtherUser")
        self.assertIn(b"No reports have been submitted", other.get("/dashboard").data)
        self.assertEqual(other.get("/reports/1").status_code, 404)
        self.assertEqual(other.get("/reports/1/image").status_code, 404)
        self.assertEqual(app.test_client().get("/reports/1/image").status_code, 404)

        self.assertIn(b"Admin Dashboard", self.login(self.admin, "TestAdmin", admin=True).data)
        self.assertIn(b"Ado-Ekiti", self.admin.get("/admin/dashboard?q=ado&status=Pending&type=Flood").data)
        self.assertIn(b"No reports match", self.admin.get("/admin/dashboard?status=Rejected").data)
        invalid = self.admin.post("/admin/reports/1", data={"status": "Invalid"}, follow_redirects=True)
        self.assertIn(b"Select a valid report status", invalid.data)
        updated = self.admin.post("/admin/reports/1", data={"status": "Resolved"}, follow_redirects=True)
        self.assertIn(b"Report status updated", updated.data)
        self.assertIn(b"Resolved", self.user.get("/reports/1").data)
        self.assertEqual(self.admin.get("/admin/reports/99999").status_code, 404)

    def test_report_text_is_escaped_and_search_input_is_literal(self):
        # Check HTML escaping in report text and literal handling of search terms.
        self.register(self.user)
        self.login(self.user)
        self.submit(description="Use <b>bold</b> for this note.")
        detail = self.user.get("/reports/1")
        self.assertIn(b"&lt;b&gt;bold&lt;/b&gt;", detail.data)
        self.assertNotIn(b"<b>bold</b>", detail.data)
        response = self.user.get("/dashboard", query_string={"q": "O'Brien %_"})
        self.assertIn(b"No reports match", response.data)
        self.assertEqual(response.status_code, 200)

    def test_bundled_database_is_compatible(self):
        # Check that repeated database initialization preserves existing records.
        source = Path(__file__).with_name("database.db")
        copy = self.db_path.with_name("legacy.db")
        shutil.copyfile(source, copy)
        with closing(sqlite3.connect(copy)) as db:
            expected = db.execute("SELECT id, username, password_hash FROM admins").fetchall()
            original_reports = db.execute("SELECT id, image, status FROM reports").fetchall()
        with patch.dict(app.config, DATABASE=copy), app.app_context():
            init_db()
            init_db()
            db = get_db()
            self.assertEqual([tuple(row) for row in db.execute("SELECT id, username, password_hash FROM admins")], expected)
            self.assertEqual([tuple(row) for row in db.execute("SELECT id, image, status FROM reports")], original_reports)
            self.assertEqual(db.execute("PRAGMA integrity_check").fetchone()[0], "ok")


if __name__ == "__main__":
    unittest.main()
