import os
import re
import secrets
import sqlite3
import uuid
from datetime import timedelta
from functools import wraps
from pathlib import Path

from flask import (
    Flask, abort, flash, g, redirect, render_template, request,
    send_from_directory, session, url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash


BASE_DIR = Path(__file__).resolve().parent
DISASTER_TYPES = ("Fire Outbreak", "Flood", "Building Collapse", "Road Accident", "Storm", "Other")
STATUSES = ("Pending", "Under Review", "Resolved", "Rejected")
IMAGE_TYPES = {"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "webp": "image/webp"}
USERNAME_PATTERN = r"[A-Za-z0-9_]{3,30}"
PHONE_PATTERN = r"\+?[0-9][0-9 ().-]{5,19}"


def get_db():
    # Open SQLite on the first use in this Flask context, then reuse the connection.
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def init_db():
    # Create missing tables and add report ownership to older databases.
    db = get_db()
    with db:
        # Lock before inspecting the schema so simultaneous startups cannot migrate twice.
        db.execute("BEGIN IMMEDIATE")
        db.execute("""
            CREATE TABLE IF NOT EXISTS admins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT COLLATE NOCASE UNIQUE NOT NULL,
                full_name TEXT NOT NULL,
                phone TEXT NOT NULL,
                password_hash TEXT NOT NULL
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                phone TEXT NOT NULL,
                disaster_type TEXT NOT NULL,
                location TEXT NOT NULL,
                description TEXT NOT NULL,
                image TEXT,
                date_reported DATETIME DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'Pending',
                user_id INTEGER REFERENCES users(id)
            )
        """)
        columns = db.execute("PRAGMA table_info(reports)").fetchall()
        if all(column["name"] != "user_id" for column in columns):
            db.execute("ALTER TABLE reports ADD COLUMN user_id INTEGER REFERENCES users(id)")
        db.execute("CREATE INDEX IF NOT EXISTS reports_by_user ON reports(user_id)")


app = Flask(__name__)

app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_hex(32),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=2),
    DATABASE=Path(os.environ.get("SAFEREPORT_DATABASE", BASE_DIR / "database.db")).resolve(),
    UPLOAD_FOLDER=Path(os.environ.get("SAFEREPORT_UPLOADS", BASE_DIR / "uploads")).resolve(),
    MAX_CONTENT_LENGTH=5 * 1024 * 1024,
)
app.config["DATABASE"].parent.mkdir(parents=True, exist_ok=True)
app.config["UPLOAD_FOLDER"].mkdir(parents=True, exist_ok=True)


@app.teardown_appcontext
def close_db(error):
    # Close the SQLite connection when Flask finishes using the application context.
    db = g.pop("db", None)
    if db is not None:
        db.close()


@app.before_request
def load_account():
    # Load the signed-in account for this request and block direct access to legacy uploads.
    g.account = None
    g.role = None
    if request.endpoint == "static":
        # Legacy evidence may still exist here when installing over an older copy.
        filename = request.view_args["filename"].replace("\\", "/").lstrip("/")
        if any(part.casefold() == "uploads" for part in Path(filename).parts):
            abort(404)
        return

    role = session.get("role")
    account_id = session.get("account_id")
    if role == "user" and account_id is not None:
        g.account = get_db().execute(
            "SELECT id, username, full_name, phone FROM users WHERE id = ?", (account_id,)
        ).fetchone()
    elif role == "admin" and account_id is not None:
        g.account = get_db().execute(
            "SELECT id, username FROM admins WHERE id = ?", (account_id,)
        ).fetchone()
    if g.account:
        g.role = role
    elif role:
        session.clear()


@app.after_request
def set_response_headers(response):
    # Prevent MIME type guessing and tell browsers to avoid caching protected responses.
    response.headers["X-Content-Type-Options"] = "nosniff"
    if request.endpoint != "static" or response.status_code >= 400:
        response.headers["Cache-Control"] = "no-store"
    return response


def role_required(role):
    # Build a decorator for routes that require the given account role.
    def decorator(view):
        # Wrap the route handler while preserving its name for Flask.
        @wraps(view)
        def protected_view(*args, **kwargs):
            # Redirect guests to sign-in, reject other roles, and run the permitted handler.
            if g.role is None:
                flash("Sign in to continue.", "error")
                return redirect(url_for("admin_login" if role == "admin" else "login"))
            if g.role != role:
                abort(403)
            return view(*args, **kwargs)
        return protected_view
    return decorator


def start_session(role, account_id):
    # Clear the old session and store the signed-in account ID and role.
    session.clear()
    session.update(role=role, account_id=account_id)
    session.permanent = True


def valid_contact(full_name, phone):
    # Check the name length, phone format, and number of digits.
    return (
        1 <= len(full_name) <= 100
        and re.fullmatch(PHONE_PATTERN, phone) is not None
        and 7 <= sum(char.isdigit() for char in phone) <= 15
    )


@app.get("/")
def home():
    # Render the public SafeReport homepage.
    return render_template("index.html")


@app.get("/security")
def security():
    # Render the page describing SafeReport's security measures.
    return render_template("security.html")


@app.get("/review")
def review():
    # Render the project review and local demonstration instructions.
    return render_template("review.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    # Show the sign-up form or validate and save a new reporter with a hashed password.
    if g.role:
        return redirect(url_for("admin_dashboard" if g.role == "admin" else "user_dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        full_name = request.form.get("full_name", "").strip()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        if not re.fullmatch(USERNAME_PATTERN, username):
            flash("Use 3–30 letters, numbers or underscores for your username.", "error")
        elif not valid_contact(full_name, phone):
            flash("Enter a name and a valid phone number with 7–15 digits.", "error")
        elif not 8 <= len(password) <= 128:
            flash("Use a password between 8 and 128 characters.", "error")
        elif password != request.form.get("confirm_password"):
            flash("The passwords must match.", "error")
        else:
            db = get_db()
            try:
                with db:
                    db.execute(
                        "INSERT INTO users (username, full_name, phone, password_hash) VALUES (?, ?, ?, ?)",
                        (username, full_name, phone, generate_password_hash(password)),
                    )
            except sqlite3.IntegrityError:
                flash("That username is already taken.", "error")
            else:
                flash("Account created. Sign in to get started.", "success")
                return redirect(url_for("login"))
    return render_template("register.html")


def sign_in(role):
    # Check the password against the stored hash and open the dashboard for the given role.
    dashboard = "admin_dashboard" if role == "admin" else "user_dashboard"
    if g.role == role:
        return redirect(url_for(dashboard))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if 1 <= len(username) <= 100 and 1 <= len(password) <= 128:
            query = (
                "SELECT id, password_hash FROM admins WHERE username = ?"
                if role == "admin"
                else "SELECT id, password_hash FROM users WHERE username = ?"
            )
            account = get_db().execute(query, (username,)).fetchone()
            if account and check_password_hash(account["password_hash"], password):
                start_session(role, account["id"])
                flash("You are signed in.", "success")
                return redirect(url_for(dashboard))
        flash("Invalid username or password.", "error")
    return render_template("login.html", admin_login_page=role == "admin")


@app.route("/login", methods=["GET", "POST"])
def login():
    # Handle the reporter sign-in page using the shared sign-in logic.
    return sign_in("user")


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    # Handle the administrator sign-in page using the shared sign-in logic.
    return sign_in("admin")


@app.post("/admin/logout")
@app.post("/logout")
def logout():
    # Clear the current session and return to the homepage.
    session.clear()
    flash("You have been signed out.", "success")
    return redirect(url_for("home"))


@app.route("/profile", methods=["GET", "POST"])
@role_required("user")
def profile():
    # Show the reporter's profile and save validated contact changes.
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        phone = request.form.get("phone", "").strip()
        if valid_contact(full_name, phone):
            db = get_db()
            with db:
                db.execute(
                    "UPDATE users SET full_name = ?, phone = ? WHERE id = ?",
                    (full_name, phone, g.account["id"]),
                )
            flash("Profile updated.", "success")
            return redirect(url_for("profile"))
        flash("Enter a name and a valid phone number with 7–15 digits.", "error")
    return render_template("profile.html")


@app.route("/report", methods=["GET", "POST"])
@role_required("user")
def report():
    # Show the report form or save a valid submission and its optional image.
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        phone = request.form.get("phone", "").strip()
        disaster_type = request.form.get("disaster_type", "")
        location = request.form.get("location", "").strip()
        description = request.form.get("description", "").strip()
        image = request.files.get("image")
        extension = Path(image.filename).suffix.lower().lstrip(".") if image and image.filename else ""

        if not valid_contact(full_name, phone):
            flash("Enter a name and a valid phone number with 7–15 digits.", "error")
        elif disaster_type not in DISASTER_TYPES:
            flash("Please select a valid disaster type.", "error")
        elif not 1 <= len(location) <= 200 or not 1 <= len(description) <= 3000:
            flash("Enter a location and description within the field limits.", "error")
        elif image and image.filename and extension not in IMAGE_TYPES:
            flash("Use a JPG, PNG or WebP image.", "error")
        else:
            filename = f"{uuid.uuid4().hex}.{extension}" if extension else None
            saved_path = app.config["UPLOAD_FOLDER"] / filename if filename else None
            db = get_db()
            try:
                if saved_path:
                    image.save(saved_path)
                with db:
                    db.execute("""
                        INSERT INTO reports
                        (full_name, phone, disaster_type, location, description, image, user_id)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (full_name, phone, disaster_type, location, description, filename, g.account["id"]))
            except (OSError, sqlite3.Error):
                if saved_path:
                    try:
                        saved_path.unlink(missing_ok=True)
                    except OSError:
                        app.logger.exception("Could not remove an incomplete attachment.")
                raise
            flash("Your disaster report was submitted.", "success")
            return redirect(url_for("user_dashboard"))
    return render_template("report.html", disaster_types=DISASTER_TYPES)


def list_reports(user_id=None):
    # Return matching reports and active filters, scoped to one reporter when supplied.
    q = request.args.get("q", "").strip()[:100]
    status = request.args.get("status", "")
    disaster_type = request.args.get("type", "")
    filters = {
        "q": q,
        "status": status if status in STATUSES else "",
        "type": disaster_type if disaster_type in DISASTER_TYPES else "",
    }
    conditions = []
    values = []
    if user_id is not None:
        conditions.append("user_id = ?")
        values.append(user_id)
    if q:
        conditions.append("(instr(lower(location), lower(?)) > 0 OR instr(lower(full_name), lower(?)) > 0)")
        values.extend((q, q))
    if filters["status"]:
        conditions.append("status = ?")
        values.append(filters["status"])
    if filters["type"]:
        conditions.append("disaster_type = ?")
        values.append(filters["type"])
    # Only fixed SQL clauses enter the query. Every form value is bound separately.
    where = " WHERE " + " AND ".join(conditions) if conditions else ""
    rows = get_db().execute(
        "SELECT * FROM reports" + where + " ORDER BY date_reported DESC, id DESC", values
    ).fetchall()
    return rows, filters


@app.get("/dashboard")
@role_required("user")
def user_dashboard():
    # Show the signed-in reporter's own submissions and search filters.
    reports, filters = list_reports(g.account["id"])
    return render_template("dashboard.html", reports=reports, filters=filters,
                           statuses=STATUSES, disaster_types=DISASTER_TYPES)


@app.get("/admin/dashboard")
@role_required("admin")
def admin_dashboard():
    # Show reports matching the filters and totals for each status across all reports.
    reports, filters = list_reports()
    counts = dict(get_db().execute("SELECT status, COUNT(*) FROM reports GROUP BY status").fetchall())
    return render_template("dashboard.html", reports=reports, filters=filters,
                           statuses=STATUSES, disaster_types=DISASTER_TYPES, counts=counts)


def find_report(report_id):
    # Find a report the current account can view, or return a 404.
    # Avoid binding an integer outside SQLite's signed 64-bit range.
    if report_id > 2**63 - 1:
        abort(404)
    db = get_db()
    if g.role == "admin":
        row = db.execute("SELECT * FROM reports WHERE id = ?", (report_id,)).fetchone()
    elif g.role == "user":
        row = db.execute(
            "SELECT * FROM reports WHERE id = ? AND user_id = ?", (report_id, g.account["id"])
        ).fetchone()
    else:
        abort(404)
    if row is None:
        abort(404)
    return row


@app.get("/reports/<int:report_id>")
@role_required("user")
def user_report_details(report_id):
    # Show a reporter the details of one of their own submissions.
    return render_template("report_details.html", report=find_report(report_id))


@app.route("/admin/reports/<int:report_id>", methods=["GET", "POST"])
@role_required("admin")
def report_details(report_id):
    # Show an administrator the report and save a valid status change.
    row = find_report(report_id)
    if request.method == "POST":
        new_status = request.form.get("status")
        if new_status in STATUSES:
            db = get_db()
            with db:
                db.execute("UPDATE reports SET status = ? WHERE id = ?", (new_status, report_id))
            flash("Report status updated.", "success")
        else:
            flash("Select a valid report status.", "error")
        return redirect(url_for("report_details", report_id=report_id))
    return render_template("report_details.html", report=row, statuses=STATUSES)


@app.get("/reports/<int:report_id>/image")
def report_image(report_id):
    # Serve the attached image after checking access to its report.
    filename = find_report(report_id)["image"]
    if not filename or not re.fullmatch(r"[a-f0-9]{32}\.(?:jpe?g|png|webp)", filename):
        abort(404)
    directory = app.config["UPLOAD_FOLDER"]
    if not (directory / filename).is_file():
        directory = BASE_DIR / "static" / "uploads"
    extension = filename.rsplit(".", 1)[1]
    return send_from_directory(directory, filename, mimetype=IMAGE_TYPES[extension])


@app.errorhandler(403)
@app.errorhandler(404)
@app.errorhandler(413)
@app.errorhandler(500)
def error_page(error):
    # Render a readable error page while preserving the HTTP status code.
    messages = {
        403: ("Access denied", "Your account does not have access to this page."),
        404: ("Page or report not found", "Check the address or return to the homepage."),
        413: ("Upload too large", "Keep the entire report submission under 5 MB."),
        500: ("Something went wrong", "Please try again later."),
    }
    title, message = messages[error.code]
    return render_template("error.html", title=title, message=message), error.code


with app.app_context():
    init_db()


if __name__ == "__main__":
    app.run(host="127.0.0.1")
