# SafeReport — refreshed edition

A refreshed interface for the existing CSC 407 Disaster Reporting System.

## Run the website

1. Extract this ZIP into a new folder. Keep the project files together.
2. Open a terminal in `CSC_407_Project`.
3. Install Python 3.10 or newer if needed.
4. Run `python -m pip install -r requirements.txt`.
5. Run `python -m waitress --listen=127.0.0.1:8080 app:app`.
6. Open http://127.0.0.1:8080 in your browser.

On Windows, `py` can be used instead of `python` if that is how Python is installed.

## Existing administrator account

Use the **same administrator username and password as before** at `/admin/login`.
The bundled database, administrator records, password hashes, account-creation
script, uploaded evidence, and application backend have been preserved. Do not
run `create_admin.py` to access your existing administrator account.

If replacing a copy that has received newer reports since the supplied ZIP was
created, stop the server and retain that copy's `database.db` and `uploads/`
folder together. Back them up before installing the refreshed templates and assets.

## What changed

- New teal, cream, and lime visual design across the website.
- Rebuilt homepage with clearer reporting guidance and navigation.
- Responsive navigation with an accessible mobile menu.
- New layouts for sign-in, registration, profile, and report submission.
- Password show/hide controls and clearer field styling.
- Refreshed dashboards, filters, report details, and empty states.
- Distinct visual styles for each report status.
- Updated security-page wording for everyday readers.
- Keyboard focus styles, a skip link, and reduced-motion support.

The original reporting, attachment, account, and administrator workflows remain
in place. No cloud hosting or public deployment is required. Google Fonts improves
typography when internet access is available; local fallback fonts work offline.

## Check the application

Run `python -m unittest -v test_app` from the project folder.
The existing tests use temporary databases, leaving your bundled data untouched.
