from getpass import getpass
import sqlite3

from werkzeug.security import generate_password_hash

from app import app, get_db


def main():
    # Read administrator credentials from the terminal and save the hashed password in SQLite.
    username = input("Enter admin username: ").strip()
    password = getpass("Enter admin password: ")

    if not 1 <= len(username) <= 100 or not 8 <= len(password) <= 128:
        print("Enter a username of up to 100 characters and a password of 8–128 characters.")
        return

    try:
        with app.app_context():
            db = get_db()
            with db:
                db.execute(
                    "INSERT INTO admins (username, password_hash) VALUES (?, ?)",
                    (username, generate_password_hash(password)),
                )
    except sqlite3.IntegrityError:
        print("That administrator username already exists.")
    else:
        print("Administrator account created.")


if __name__ == "__main__":
    main()
