const menu = document.querySelector('.menu-toggle');
const nav = document.querySelector('#main-nav');
function closeMenu() { menu?.setAttribute('aria-expanded', 'false'); nav?.classList.remove('is-open'); }
menu?.addEventListener('click', () => {
  const open = menu.getAttribute('aria-expanded') !== 'true';
  menu.setAttribute('aria-expanded', String(open)); nav.classList.toggle('is-open', open);
});
nav?.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape' && menu?.getAttribute('aria-expanded') === 'true') { closeMenu(); menu.focus(); } });
document.querySelectorAll('input[type="password"]').forEach(input => {
  const wrapper = document.createElement('div'); wrapper.className = 'password-field';
  input.before(wrapper); wrapper.append(input);
  const button = document.createElement('button'); button.type = 'button'; button.className = 'password-toggle';
  button.textContent = 'Show'; button.setAttribute('aria-label', 'Show ' + input.labels[0].textContent.toLowerCase());
  button.setAttribute('aria-controls', input.id); button.setAttribute('aria-pressed', 'false');
  button.addEventListener('click', () => { const show = input.type === 'password'; input.type = show ? 'text' : 'password'; button.textContent = show ? 'Hide' : 'Show'; button.setAttribute('aria-pressed', String(show)); button.setAttribute('aria-label', (show ? 'Hide ' : 'Show ') + input.labels[0].textContent.toLowerCase()); });
  wrapper.append(button);
});
