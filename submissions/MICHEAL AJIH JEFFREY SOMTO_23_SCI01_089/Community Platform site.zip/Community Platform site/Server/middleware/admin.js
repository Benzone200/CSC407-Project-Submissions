const crypto = require('crypto');

// Protects committee-only routes. Send the token in the x-admin-token header.
module.exports = (req, res, next) => {
  const expected = Buffer.from(process.env.ADMIN_TOKEN || '');
  const given = Buffer.from(req.get('x-admin-token') || '');
  const ok = expected.length > 0 &&
    given.length === expected.length &&
    crypto.timingSafeEqual(given, expected);
  if (!ok) return res.status(401).json({ error: 'Admin token required' });
  next();
};