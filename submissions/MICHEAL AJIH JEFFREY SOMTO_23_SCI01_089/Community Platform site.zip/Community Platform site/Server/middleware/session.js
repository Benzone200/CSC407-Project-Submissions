const accounts = require('../lib/accounts');

const decode = (value) => {
  try { return decodeURIComponent(value); } catch { return value; }
};

const parseCookies = (header = '') =>
  Object.fromEntries(
    header.split(';')
      .map((part) => part.trim().split('='))
      .filter(([key]) => key)
      .map(([key, ...rest]) => [key, decode(rest.join('='))])
  );

// Runs on every request: sets req.user to the signed-in resident, or null.
exports.loadUser = (req, res, next) => {
  const token = parseCookies(req.headers.cookie).sid || null;
  req.sessionToken = token;
  req.user = token ? accounts.findUserBySession(token) || null : null;
  next();
};

// Use on routes that need a signed-in resident.
exports.requireUser = (req, res, next) => {
  if (!req.user) return res.status(401).json({ error: 'Please sign in first' });
  next();
};