const router = require('express').Router();
const db = require('../Db');
const admin = require('../middleware/admin');
const { requireUser } = require('../middleware/session');
const { postLimiter } = require('../lib/limits');
const { text } = require('../lib/validate');
const { httpError } = require('../lib/httpError');

const CATEGORIES = ['Urgent', 'Maintenance', 'Events', 'Community'];

router.get('/', (req, res) => {
  res.json(db.prepare('SELECT * FROM notices ORDER BY created_at DESC, id DESC').all());
});

router.post('/', requireUser, postLimiter, (req, res) => {
  const b = req.body || {};
  const category = text(b.category, { max: 20, label: 'Category' });
  if (!CATEGORIES.includes(category)) throw httpError(400, 'Unknown category');
  const row = {
    title: text(b.title, { max: 80, label: 'Title' }),
    category,
    body: text(b.body, { max: 400, label: 'Details' }),
    details: text(b.details, { max: 1000, label: 'More details', required: false }),
    author: `${req.user.name}, Flat ${req.user.flat}`,
  };
  const { lastInsertRowid } = db.prepare(
    `INSERT INTO notices (title, category, body, details, author)
     VALUES (@title, @category, @body, @details, @author)`).run(row);
  res.status(201).json(db.prepare('SELECT * FROM notices WHERE id = ?').get(lastInsertRowid));
});

router.delete('/:id', admin, (req, res) => {
  const { changes } = db.prepare('DELETE FROM notices WHERE id = ?').run(req.params.id);
  if (!changes) throw httpError(404, 'Notice not found');
  res.status(204).end();
});

module.exports = router;