const router = require('express').Router();
const db = require('../db');
const admin = require('../middleware/admin');
const { text } = require('../lib/validate');
const { httpError } = require('../lib/httpError');

router.get('/', (req, res) => {
  res.json(db.prepare(
    "SELECT * FROM events WHERE starts_on >= date('now') ORDER BY starts_on").all());
});

router.post('/', admin, (req, res) => {
  const b = req.body || {};
  const startsOn = text(b.starts_on, { max: 10, label: 'Date' });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startsOn)) throw httpError(400, 'Date must look like 2026-12-12');
  const row = {
    title: text(b.title, { max: 80, label: 'Title' }),
    starts_on: startsOn,
    place: text(b.place, { max: 80, label: 'Time and place' }),
    body: text(b.body, { max: 400, label: 'Details', required: false }),
  };
  const { lastInsertRowid } = db.prepare(
    'INSERT INTO events (title, starts_on, place, body) VALUES (@title, @starts_on, @place, @body)').run(row);
  res.status(201).json(db.prepare('SELECT * FROM events WHERE id = ?').get(lastInsertRowid));
});

router.delete('/:id', admin, (req, res) => {
  const { changes } = db.prepare('DELETE FROM events WHERE id = ?').run(req.params.id);
  if (!changes) throw httpError(404, 'Event not found');
  res.status(204).end();
});

module.exports = router;