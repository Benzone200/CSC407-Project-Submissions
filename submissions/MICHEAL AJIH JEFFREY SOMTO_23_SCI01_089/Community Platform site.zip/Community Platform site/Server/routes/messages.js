const router = require('express').Router();
const db = require('../db');
const admin = require('../middleware/admin');
const { postLimiter } = require('../lib/limits');
const { text } = require('../lib/validate');

// Committee only: read messages sent through the About page.
router.get('/', admin, (req, res) => {
  res.json(db.prepare('SELECT * FROM messages ORDER BY created_at DESC, id DESC').all());
});

router.post('/', postLimiter, (req, res) => {
  const b = req.body || {};
  const row = {
    name: text(b.name, { max: 60, label: 'Name' }),
    body: text(b.body, { max: 1000, label: 'Message' }),
  };
  db.prepare('INSERT INTO messages (name, body) VALUES (@name, @body)').run(row);
  res.status(201).json({ ok: true });
});

module.exports = router;