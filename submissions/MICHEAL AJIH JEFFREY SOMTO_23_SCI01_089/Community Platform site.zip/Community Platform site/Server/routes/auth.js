const router = require('express').Router();
const accounts = require('../lib/accounts');
const { hashPassword, verifyPassword } = require('../lib/password');
const { authLimiter } = require('../lib/limits');
const { text } = require('../lib/validate');
const { httpError } = require('../lib/httpError');

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function setSessionCookie(res, token) {
  const flags = ['HttpOnly', 'SameSite=Lax', 'Path=/', `Max-Age=${accounts.SESSION_MAX_AGE}`];
  if (process.env.NODE_ENV === 'production') flags.push('Secure'); // HTTPS only when deployed
  res.setHeader('Set-Cookie', `sid=${token}; ${flags.join('; ')}`);
}

const readEmail = (value) => {
  const email = text(value, { max: 120, label: 'Email' }).toLowerCase();
  if (!EMAIL.test(email)) throw httpError(400, 'Enter a valid email address');
  return email;
};

const readPassword = (value) => (typeof value === 'string' ? value : '');

router.get('/me', (req, res) => res.json({ user: req.user }));

router.post('/signup', authLimiter, (req, res) => {
  const b = req.body || {};
  const email = readEmail(b.email);
  const password = readPassword(b.password);
  if (password.length < 8) throw httpError(400, 'Password must be at least 8 characters');
  if (password.length > 200) throw httpError(400, 'Password is too long');
  const name = text(b.name, { max: 60, label: 'Name' });
  const flat = text(b.flat, { max: 20, label: 'Flat' });
  if (accounts.findUserByEmail(email)) throw httpError(409, 'An account with this email already exists');

  const id = accounts.createUser({ name, flat, email, passwordHash: hashPassword(password) });
  setSessionCookie(res, accounts.createSession(id));
  res.status(201).json({ user: { id, name, flat, email } });
});

router.post('/login', authLimiter, (req, res) => {
  const b = req.body || {};
  const email = readEmail(b.email);
  const user = accounts.findUserByEmail(email);
  // One message for both cases, so the form never reveals which emails have accounts.
  if (!user || !verifyPassword(readPassword(b.password), user.password_hash)) {
    throw httpError(401, 'Email or password is incorrect');
  }
  setSessionCookie(res, accounts.createSession(user.id));
  res.json({ user: { id: user.id, name: user.name, flat: user.flat, email: user.email } });
});

router.post('/logout', (req, res) => {
  if (req.sessionToken) accounts.deleteSession(req.sessionToken);
  res.setHeader('Set-Cookie', 'sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
  res.status(204).end();
});

module.exports = router;