const path = require('path');
const { DatabaseSync } = require('node:sqlite'); // built into Node, nothing to compile

const db = new DatabaseSync(process.env.DB_PATH || path.join(__dirname, '..', 'data.db'));
db.exec('PRAGMA journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS notices (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    body TEXT NOT NULL,
    details TEXT NOT NULL DEFAULT '',
    author TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    starts_on TEXT NOT NULL,
    place TEXT NOT NULL,
    body TEXT NOT NULL DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    body TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

// Sample content so a fresh install is not empty. Delete it through the admin API.
if (db.prepare('SELECT COUNT(*) AS n FROM notices').get().n === 0) {
  const addNotice = db.prepare(
    'INSERT INTO notices (title, category, body, details, author) VALUES (?, ?, ?, ?, ?)');
  addNotice.run('Water shut-off on Thursday', 'Urgent',
    'Water to Buildings A and B will be off from 9 am to 1 pm.',
    'Taps may run brown for a few minutes afterwards.', 'Estate office');
  addNotice.run('Courtyard clean-up this Saturday', 'Events',
    'Gloves, bags and tea are provided.', 'Meet by the main gate at 10 am.', 'Committee');
  addNotice.run('Bin collection moves to Monday', 'Community',
    'Because of the public holiday, bins go out on Sunday night.', '', 'Committee');

  const addEvent = db.prepare("INSERT INTO events (title, starts_on, place, body) VALUES (?, date('now', ?), ?, ?)");
  addEvent.run('Courtyard clean-up', '+5 days', '10 am, main gate', 'Tea and snacks afterwards.');
  addEvent.run('Residents’ meeting', '+12 days', '6 pm, community room', 'Budget and the new gate lock.');
}

module.exports = db;