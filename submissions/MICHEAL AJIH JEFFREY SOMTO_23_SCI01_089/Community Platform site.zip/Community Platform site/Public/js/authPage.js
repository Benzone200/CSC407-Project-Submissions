import { api } from './api.js';

const form = document.getElementById('authForm');
const msg = document.getElementById('msg');
const mode = form.dataset.mode; // "login" or "signup"
const value = (id) => document.getElementById(id)?.value ?? '';

function show(text, isError) {
  msg.textContent = text;
  msg.classList.toggle('error', isError);
}

// Already signed in? Go straight back to the news page.
api.getMe().then(({ user }) => { if (user) location.href = 'index.html#news'; }).catch(() => {});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const button = form.querySelector('button');
  try {
    if (mode === 'signup' && value('password') !== value('confirm')) {
      throw new Error('The two passwords do not match');
    }
    button.disabled = true;
    show('Please wait…', false);
    if (mode === 'signup') {
      await api.signup({ name: value('name'), flat: value('flat'), email: value('email'), password: value('password') });
    } else {
      await api.login({ email: value('email'), password: value('password') });
    }
    location.href = 'index.html#news';
  } catch (err) {
    show(err.message, true);
    button.disabled = false;
  }
});