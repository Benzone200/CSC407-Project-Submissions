import { api } from './api.js';

const $ = (id) => document.getElementById(id);
const esc = (s) => {
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
};
const CATEGORIES = ['All', 'Urgent', 'Maintenance', 'Events', 'Community'];
const PAGES = ['home', 'news', 'events', 'about'];
const state = { notices: [], filter: 'All', user: null };

// ---------- Formatting ----------
const noticeDate = (iso) =>
  new Date(iso.replace(' ', 'T') + 'Z').toLocaleDateString('en-GB', {
    weekday: 'short', day: 'numeric', month: 'short',
  });

// ---------- Templates ----------
function noticeHTML(n, withDetails) {
  const more = withDetails && n.details
    ? `<details><summary>More details</summary><p>${esc(n.details)}</p></details>` : '';
  return `<article class="notice" data-cat="${esc(n.category)}">
    <div class="meta">${esc(n.category)} · ${noticeDate(n.created_at)} · ${esc(n.author)}</div>
    <h3>${esc(n.title)}</h3><p>${esc(n.body)}</p>${more}</article>`;
}

function eventHTML(e) {
  const d = new Date(e.starts_on + 'T00:00:00');
  const month = d.toLocaleDateString('en-GB', { month: 'short' });
  return `<div class="ev"><div class="date">${d.getDate()}<small>${month}</small></div>
    <div><h3>${esc(e.title)}</h3><div class="meta">${esc(e.place)}</div>
    <p>${esc(e.body)}</p></div></div>`;
}

// ---------- Rendering ----------
function renderNews() {
  $('filters').innerHTML = CATEGORIES.map(
    (c) => `<button class="chip" aria-pressed="${c === state.filter}" data-c="${c}">${c}</button>`
  ).join('');
  const rows = state.notices.filter((n) => state.filter === 'All' || n.category === state.filter);
  $('list').innerHTML = rows.length
    ? rows.map((n) => noticeHTML(n, true)).join('')
    : '<div class="empty">No notices in this category yet. Post one using the form.</div>';
  $('homeNews').innerHTML = state.notices.slice(0, 3).map((n) => noticeHTML(n, false)).join('');

  const urgent = state.notices.find((n) => n.category === 'Urgent');
  $('alert').hidden = !urgent;
  if (urgent) $('alert').innerHTML = `<strong>${esc(urgent.title)}.</strong> ${esc(urgent.body)}`;
}

function renderEvents(events) {
  $('evList').innerHTML = events.length
    ? events.map(eventHTML).join('')
    : '<div class="empty">No upcoming events yet.</div>';
  $('homeEvents').innerHTML = events.slice(0, 2).map(eventHTML).join('');
}

// ---------- Account state ----------
function renderAuth() {
  const signedIn = Boolean(state.user);
  const link = $('authLink');
  link.textContent = signedIn ? 'Sign out' : 'Sign in';
  link.setAttribute('href', signedIn ? '#' : 'login.html');
  $('form').hidden = !signedIn;
  $('postGate').hidden = signedIn;
}

async function loadUser() {
  try { state.user = (await api.getMe()).user; } catch { state.user = null; }
  renderAuth();
}

$('authLink').addEventListener('click', async (e) => {
  if (!state.user) return; // signed out: follow the link to the login page
  e.preventDefault();
  await api.logout();
  state.user = null;
  renderAuth();
});

// ---------- Data loading ----------
async function load() {
  try {
    const [notices, events] = await Promise.all([api.getNotices(), api.getEvents()]);
    state.notices = notices;
    renderNews();
    renderEvents(events);
  } catch {
    $('list').innerHTML = '<div class="empty">We couldn’t load the news. Please refresh the page.</div>';
  }
}

// ---------- Forms ----------
function wireForm(formId, toastId, submit, success) {
  $(formId).addEventListener('submit', async (e) => {
    e.preventDefault();
    const toast = $(toastId);
    toast.textContent = '';
    try {
      await submit();
      e.target.reset();
      toast.textContent = success;
    } catch (err) {
      toast.textContent = err.message;
    }
  });
}

wireForm('form', 'toast',
  async () => {
    const notice = await api.addNotice({
      title: $('t').value, category: $('c').value, body: $('b').value,
    });
    state.notices.unshift(notice);
    state.filter = 'All';
    renderNews();
  },
  'Notice posted.');

wireForm('cform', 'ctoast',
  () => api.sendMessage({ name: $('cn').value, body: $('cm').value }),
  'Message sent. The committee will reply within two days.');

$('filters').addEventListener('click', (e) => {
  const c = e.target.getAttribute('data-c');
  if (c) { state.filter = c; renderNews(); }
});

// ---------- Routing (#home, #news, #events, #about) ----------
function route() {
  let page = location.hash.slice(1);
  if (!PAGES.includes(page)) page = 'home';
  PAGES.forEach((p) => $(p).classList.toggle('on', p === page));
  document.querySelectorAll('nav a').forEach((a) => {
    if (a.getAttribute('href') === '#' + page) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
  window.scrollTo(0, 0);
}

window.addEventListener('hashchange', route);
route();
load();
loadUser();