// Thin wrapper around fetch for the Maple Court API.
async function request(url, options) {
  const res = await fetch(url, options);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || 'Request failed');
  }
  return res.status === 204 ? null : res.json();
}

const post = (url, data) =>
  request(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

export const api = {
  getNotices: () => request('/api/notices'),
  addNotice: (data) => post('/api/notices', data),
  getEvents: () => request('/api/events'),
  sendMessage: (data) => post('/api/messages', data),
  getMe: () => request('/api/auth/me'),
  signup: (data) => post('/api/auth/signup', data),
  login: (data) => post('/api/auth/login', data),
  logout: () => post('/api/auth/logout', {}),
};