// ---------- Config & data ----------
const DEFAULTS = {
    services: [
      { id: 'cut',    name: 'Haircut',    icon: '✂️', mins: 45,  price: 5000 },
      { id: 'braids', name: 'Braids',     icon: '💇', mins: 180, price: 15000 },
      { id: 'mani',   name: 'Manicure',   icon: '💅', mins: 40,  price: 6000 },
      { id: 'facial', name: 'Facial',     icon: '✨', mins: 60,  price: 10000 },
      { id: 'beard',  name: 'Beard trim', icon: '🧔', mins: 20,  price: 3000 }
    ],
    stylists: [
      { id: 'amara', name: 'Amara', role: 'Senior stylist' },
      { id: 'tolu',  name: 'Tolu',  role: 'Nails and skin' },
      { id: 'kemi',  name: 'Kemi',  role: 'Braid specialist' }
    ]
  };
  const SLOTS = ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00'];
  const ADMIN = { email: 'admin@sheen.com', password: 'admin123' };
  const KEY = 'sheen_appointments', CKEY = 'sheen_config';
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  
  const $ = id => document.getElementById(id);
  const naira = n => '₦' + Number(n).toLocaleString('en-NG');
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const pretty = s => new Date(s + 'T00:00').toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });
  const digits = s => String(s).replace(/\D/g, '');
  
  let CFG = (() => {
    try { const c = JSON.parse(localStorage.getItem(CKEY)); if (c && c.services && c.stylists) return c; } catch (e) {}
    return JSON.parse(JSON.stringify(DEFAULTS));
  })();
  const saveCfg = () => localStorage.setItem(CKEY, JSON.stringify(CFG));
  // Safe lookups: old bookings or removed items never crash the app
  const svc = id => CFG.services.find(s => s.id === id) || { id, name: 'Removed service', icon: '💈', mins: 0, price: 0 };
  const stylist = id => CFG.stylists.find(s => s.id === id) || { id, name: 'Any stylist', role: '' };
  
  function getAppts() {
    let l = [];
    try { l = JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) {}
    return l.map(a => ({ ...a, status: a.status || 'pending', code: a.code || 'SH-' + String(a.id).slice(-4), name: a.name || 'Guest', phone: a.phone || '' }));
  }
  const saveAppts = l => localStorage.setItem(KEY, JSON.stringify(l));
  
  // ---------- Motion helpers ----------
  function toast(msg) {
    const t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2400);
  }
  function fx(el, anim) { // staggered entrance for a list's children
    el.classList.toggle('st', !!anim);
    if (anim) [...el.children].forEach((c, i) => c.style.setProperty('--i', i));
  }
  function restart(el, cls) { el.className = ''; void el.offsetWidth; el.className = cls; }
  function animateOut(el, fn) { if (reduce) return fn(); el.classList.add('out'); setTimeout(fn, 260); }
  function countUp(el, to, money, anim) {
    const fmt = v => money ? naira(Math.round(v)) : Math.round(v);
    if (!anim || reduce || !to) { el.textContent = fmt(to); return; }
    const t0 = performance.now();
    (function f(t) {
      const p = Math.min((t - t0) / 700, 1);
      el.textContent = fmt(to * (1 - Math.pow(1 - p, 3)));
      if (p < 1) requestAnimationFrame(f);
    })(t0);
  }
  
  // ---------- Navigation ----------
  function show(id) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    $(id).classList.add('active');
    document.body.classList.toggle('wizard', id === 'book');
    const tab = id === 'login' || id === 'admin' ? 'staff' : id === 'done' ? 'book' : id;
    document.querySelectorAll('.nav button').forEach(b => b.classList.toggle('on', b.dataset.go === tab));
    window.scrollTo(0, 0);
  }
  function go(name) {
    if (name === 'book') startBooking();
    else if (name === 'staff') {
      if (sessionStorage.getItem('sheen_admin')) { renderAdmin(true); show('admin'); }
      else { $('loginError').textContent = ''; show('login'); }
    } else show(name);
  }
  document.querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => go(b.dataset.go)));
  
  // ---------- Home ----------
  function renderHome() {
    $('serviceList').innerHTML = CFG.services.map(s =>
      `<button class="svc" data-s="${s.id}"><span class="ic">${esc(s.icon)}</span><strong>${esc(s.name)}</strong><small>${s.mins} min</small><span class="p">${naira(s.price)}</span></button>`).join('');
    $('serviceList').querySelectorAll('.svc').forEach(b => b.addEventListener('click', () => startBooking(b.dataset.s)));
    $('teamList').innerHTML = CFG.stylists.map(s =>
      `<div class="person"><div class="avatar">${esc(s.name[0] || '?')}</div><strong>${esc(s.name)}</strong><small>${esc(s.role)}</small></div>`).join('');
  }
  renderHome();
  
  // ---------- Booking wizard ----------
  let w = {};
  const TITLES = ['', 'Choose a service', 'Choose a stylist', 'Pick a day and time', 'Your details'];
  
  function startBooking(serviceId) {
    w = { step: serviceId ? 2 : 1, service: serviceId || null, stylist: null, date: null, time: null, name: '', phone: '' };
    renderWizard('fwd'); show('book');
  }
  function isFree(date, time, who) {
    const busy = getAppts().filter(a => a.date === date && a.time === time && a.status !== 'cancelled').map(a => a.stylist);
    return who === 'any' ? CFG.stylists.some(s => !busy.includes(s.id)) : !busy.includes(who);
  }
  function pick(b) { b.parentElement.querySelectorAll('.sel').forEach(x => x.classList.remove('sel')); b.classList.add('sel'); }
  function updateSum() {
    const s = CFG.services.find(x => x.id === w.service);
    $('wizSum').innerHTML = s ? `<strong>${naira(s.price)}</strong>${esc(s.name)}, ${s.mins} min` : 'Nothing selected yet';
  }
  
  function renderTimes() {
    const box = $('times'), now = new Date();
    if (!w.date) { box.innerHTML = '<p class="hint">Choose a day to see open times.</p>'; return; }
    box.innerHTML = '<p class="sec">Available times</p><div class="chips">' + SLOTS.map(t => {
      const past = w.date === iso(now) && new Date(w.date + 'T' + t) <= now;
      const off = past || !isFree(w.date, t, w.stylist);
      return `<button class="chip ${w.time === t ? 'sel' : ''}" data-t="${t}" ${off ? 'disabled' : ''}>${t}</button>`;
    }).join('') + '</div>';
    restart(box, 'rise');
    box.querySelectorAll('[data-t]').forEach(b => b.addEventListener('click', () => { w.time = b.dataset.t; pick(b); }));
  }
  
  function renderWizard(dir) {
    $('wizStep').textContent = 'Step ' + w.step + ' of 4';
    $('wizTitle').textContent = TITLES[w.step];
    $('prog').style.width = (w.step * 25) + '%';
    $('wizNext').textContent = w.step === 4 ? 'Confirm booking' : 'Continue';
    updateSum();
    const body = $('wizBody'); restart(body, dir);
  
    if (w.step === 1) {
      body.innerHTML = '<div class="options">' + CFG.services.map(x =>
        `<button class="opt ${w.service === x.id ? 'sel' : ''}" data-v="${x.id}"><span class="ic">${esc(x.icon)}</span><span class="grow">${esc(x.name)}<small>${x.mins} min</small></span><strong>${naira(x.price)}</strong></button>`).join('') + '</div>';
      body.querySelectorAll('.opt').forEach(b => b.addEventListener('click', () => { w.service = b.dataset.v; pick(b); updateSum(); }));
    }
    if (w.step === 2) {
      const list = [{ id: 'any', name: 'Any stylist', role: 'First one available' }, ...CFG.stylists];
      body.innerHTML = '<div class="options">' + list.map(x =>
        `<button class="opt ${w.stylist === x.id ? 'sel' : ''}" data-v="${x.id}"><span class="avatar">${x.id === 'any' ? '★' : esc(x.name[0] || '?')}</span><span class="grow">${esc(x.name)}<small>${esc(x.role)}</small></span></button>`).join('') + '</div>';
      body.querySelectorAll('.opt').forEach(b => b.addEventListener('click', () => { w.stylist = b.dataset.v; w.time = null; pick(b); }));
    }
    if (w.step === 3) {
      const days = [];
      for (let i = 0; i < 14; i++) { const d = new Date(); d.setDate(d.getDate() + i); days.push(d); }
      body.innerHTML = '<div class="chips dates">' + days.map((d, i) => {
        const day = i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : d.toLocaleDateString('en-GB', { weekday: 'short' });
        return `<button class="chip ${w.date === iso(d) ? 'sel' : ''}" data-d="${iso(d)}">${day}<small>${d.getDate()} ${d.toLocaleDateString('en-GB', { month: 'short' })}</small></button>`;
      }).join('') + '</div><div id="times"></div>';
      body.querySelectorAll('[data-d]').forEach(b => b.addEventListener('click', () => { w.date = b.dataset.d; w.time = null; pick(b); renderTimes(); }));
      renderTimes();
    }
    if (w.step === 4) {
      const s = svc(w.service);
      body.innerHTML = `<div class="receipt">
          <div><span>Service</span><strong>${esc(s.name)}</strong></div>
          <div><span>Stylist</span><strong>${w.stylist === 'any' ? 'Any stylist' : esc(stylist(w.stylist).name)}</strong></div>
          <div><span>When</span><strong>${pretty(w.date)}, ${w.time}</strong></div>
          <div><span>Total</span><strong>${naira(s.price)}</strong></div></div>
        <label for="name">Full name</label><input id="name" type="text" autocomplete="name" value="${esc(w.name)}">
        <label for="phone">Phone number</label><input id="phone" type="tel" autocomplete="tel" value="${esc(w.phone)}">
        <p class="error" id="bookError" role="alert"></p>`;
      $('name').addEventListener('input', e => w.name = e.target.value);
      $('phone').addEventListener('input', e => w.phone = e.target.value);
    }
  }
  
  $('wizBack').addEventListener('click', () => {
    if (w.step > 1) { w.step--; renderWizard('back'); } else show('home');
  });
  
  $('wizNext').addEventListener('click', () => {
    if (w.step === 1 && !w.service) return toast('Choose a service');
    if (w.step === 2 && !w.stylist) return toast('Choose a stylist');
    if (w.step === 3 && (!w.date || !w.time)) return toast('Choose a day and a time');
    if (w.step < 4) { w.step++; return renderWizard('fwd'); }
  
    const err = $('bookError');
    if (w.name.trim().length < 2) return err.textContent = 'Enter your full name.';
    if (digits(w.phone).length < 7) return err.textContent = 'Enter a valid phone number.';
    const list = getAppts();
    const busy = list.filter(a => a.date === w.date && a.time === w.time && a.status !== 'cancelled').map(a => a.stylist);
    const who = w.stylist === 'any' ? (CFG.stylists.find(s => !busy.includes(s.id)) || {}).id : (busy.includes(w.stylist) ? null : w.stylist);
    if (!who) { toast('That time was just taken. Pick another.'); w.step = 3; w.time = null; return renderWizard('back'); }
  
    const appt = { id: Date.now(), code: 'SH-' + Math.floor(1000 + Math.random() * 9000), service: w.service, stylist: who, date: w.date, time: w.time, name: w.name.trim(), phone: w.phone.trim(), status: 'pending' };
    list.push(appt); saveAppts(list);
    $('code').textContent = appt.code;
    $('receipt').innerHTML = `
      <div><span>Service</span><strong>${esc(svc(appt.service).name)}</strong></div>
      <div><span>Stylist</span><strong>${esc(stylist(who).name)}</strong></div>
      <div><span>When</span><strong>${pretty(appt.date)}, ${appt.time}</strong></div>
      <div><span>Total</span><strong>${naira(svc(appt.service).price)}</strong></div>
      <div><span>Name</span><strong>${esc(appt.name)}</strong></div>`;
    show('done');
  });
  
  // ---------- My bookings ----------
  function renderTrack() {
    const q = $('trackPhone').value.trim(), out = $('trackList');
    if (!q) { out.innerHTML = '<p class="empty">Enter your phone number or booking code.</p>'; return; }
    let mine = [];
    if (/^sh-?\d{3,}$/i.test(q)) {
      const c = q.toUpperCase().replace(/^SH-?/, 'SH-');
      mine = getAppts().filter(a => a.code === c);
    } else {
      const p = digits(q).slice(-9); // ignores +234 or a leading 0
      if (p.length >= 7) mine = getAppts().filter(a => digits(a.phone).slice(-9) === p);
    }
    mine.sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
    out.innerHTML = mine.length ? mine.map(a => `<div class="card">
        <span class="status ${a.status}">${a.status}</span><strong>${esc(svc(a.service).name)}</strong>
        <p>${a.date ? pretty(a.date) : ''}, ${a.time}<br>with ${esc(stylist(a.stylist).name)} · ${a.code}</p>
        ${a.status === 'pending' || a.status === 'confirmed' ? `<div class="actions"><button data-cancel="${a.id}">Cancel booking</button></div>` : ''}</div>`).join('')
      : '<p class="empty">No bookings found. Check the number or try your booking code.</p>';
    fx(out, true);
    out.querySelectorAll('[data-cancel]').forEach(b => b.addEventListener('click', () => {
      if (!confirm('Cancel this booking?')) return;
      const all = getAppts(); all.find(x => x.id === Number(b.dataset.cancel)).status = 'cancelled';
      saveAppts(all); toast('Booking cancelled'); renderTrack();
    }));
  }
  $('trackBtn').addEventListener('click', renderTrack);
  $('trackPhone').addEventListener('keydown', e => { if (e.key === 'Enter') renderTrack(); });
  
  // ---------- Admin login ----------
  $('loginBtn').addEventListener('click', () => {
    if ($('email').value.trim() === ADMIN.email && $('password').value === ADMIN.password) {
      sessionStorage.setItem('sheen_admin', '1'); $('password').value = ''; renderAdmin(true); show('admin');
    } else $('loginError').textContent = 'Wrong email or password. Check the demo account below.';
  });
  $('logoutBtn').addEventListener('click', () => { sessionStorage.removeItem('sheen_admin'); toast('Logged out'); show('home'); });
  
  // ---------- Admin dashboard ----------
  let tab = 'bookings', filter = 'all', query = '';
  const MSG = { confirmed: 'Booking confirmed', done: 'Marked as done', cancelled: 'Booking cancelled', delete: 'Booking deleted' };
  
  function renderAdmin(anim) {
    renderStats(anim);
    $('tabs').innerHTML = [['bookings', 'Bookings'], ['services', 'Services'], ['team', 'Team']].map(([k, l]) =>
      `<button class="chip ${tab === k ? 'sel' : ''}" data-tab="${k}">${l}</button>`).join('');
    renderPanel(anim);
  }
  $('tabs').addEventListener('click', e => {
    const b = e.target.closest('[data-tab]'); if (!b) return;
    tab = b.dataset.tab; pick(b); renderPanel(true);
  });
  
  function renderStats(anim) {
    const all = getAppts(), today = iso(new Date());
    const rev = all.filter(a => a.status === 'confirmed' || a.status === 'done').reduce((t, a) => t + svc(a.service).price, 0);
    const items = [
      [all.filter(a => a.date === today && a.status !== 'cancelled').length, 'Today'],
      [all.filter(a => a.status === 'pending').length, 'Waiting for you'],
      [all.filter(a => a.status === 'confirmed').length, 'Confirmed'],
      [rev, 'Revenue', true]
    ];
    $('stats').innerHTML = items.map(([n, l, m]) => `<div class="stat"><strong data-n="${n}" ${m ? 'data-m="1"' : ''}>0</strong><span>${l}</span></div>`).join('');
    $('stats').querySelectorAll('strong').forEach(s => countUp(s, Number(s.dataset.n), !!s.dataset.m, anim));
    fx($('stats'), anim);
  }
  
  function renderPanel(anim) {
    const p = $('panel');
    if (tab === 'bookings') {
      p.innerHTML = `<input id="q" type="search" placeholder="Search name, phone or code" aria-label="Search bookings" value="${esc(query)}">
        <div class="chips" id="filters">${['all', 'pending', 'confirmed', 'done', 'cancelled'].map(f =>
          `<button class="chip ${filter === f ? 'sel' : ''}" data-f="${f}">${f[0].toUpperCase() + f.slice(1)}</button>`).join('')}</div>
        <div id="adminList"></div>`;
      renderBookList(anim);
    } else {
      const isS = tab === 'services', list = isS ? CFG.services : CFG.stylists;
      const fields = it => isS
        ? `<label class="f">Icon<input data-k="icon" maxlength="4" value="${esc(it.icon || '')}"></label>
           <label class="f">Name<input data-k="name" value="${esc(it.name || '')}"></label>
           <label class="f">Minutes<input data-k="mins" type="number" min="5" value="${it.mins ?? ''}"></label>
           <label class="f">Price (₦)<input data-k="price" type="number" min="0" value="${it.price ?? ''}"></label>`
        : `<label class="f">Name<input data-k="name" value="${esc(it.name || '')}"></label>
           <label class="f">Role<input data-k="role" value="${esc(it.role || '')}"></label>`;
      p.innerHTML = '<div id="editList">' + list.map(it => `<div class="card edit" data-id="${it.id}"><div class="fields">${fields(it)}</div>
          <div class="actions"><button class="yes" data-save>Save changes</button><button data-del>Remove</button></div></div>`).join('') + '</div>' +
        `<h2>Add ${isS ? 'a service' : 'a stylist'}</h2><div class="card edit"><div class="fields">${fields({})}</div>
          <div class="actions"><button class="yes" data-add>${isS ? 'Add service' : 'Add stylist'}</button></div></div>`;
      fx($('editList'), anim);
    }
    if (anim) restart(p, 'rise');
  }
  
  function renderBookList(anim) {
    const q = query.trim().toLowerCase(), qd = digits(q);
    const list = getAppts().filter(a => (filter === 'all' || a.status === filter) &&
      (!q || a.name.toLowerCase().includes(q) || a.code.toLowerCase().includes(q) || svc(a.service).name.toLowerCase().includes(q) || (qd && digits(a.phone).includes(qd))))
      .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
    const el = $('adminList');
    el.innerHTML = list.length ? list.map(a => {
      const b = (act, label, cls = '') => `<button class="${cls}" data-act="${act}" data-id="${a.id}">${label}</button>`;
      const acts = (a.status === 'pending' ? b('confirmed', 'Confirm', 'yes') + b('cancelled', 'Cancel') : '') +
                   (a.status === 'confirmed' ? b('done', 'Mark done', 'yes') + b('cancelled', 'Cancel') : '') + b('delete', 'Delete');
      return `<div class="card"><span class="status ${a.status}">${a.status}</span><strong>${esc(svc(a.service).name)}</strong>
        <p>${a.date ? pretty(a.date) : ''}, ${a.time} · ${esc(stylist(a.stylist).name)}</p>
        <p>${esc(a.name)}, ${esc(a.phone)} · ${a.code}</p><div class="actions">${acts}</div></div>`;
    }).join('') : '<p class="empty">Nothing here yet. Matching bookings appear in this list.</p>';
    fx(el, anim);
  }
  
  function bookingAction(b) {
    const id = Number(b.dataset.id), act = b.dataset.act;
    const apply = () => {
      let l = getAppts();
      if (act === 'delete') l = l.filter(x => x.id !== id); else l.find(x => x.id === id).status = act;
      saveAppts(l); toast(MSG[act]); renderStats(false); renderBookList(false);
    };
    if (act === 'delete') { if (!confirm('Delete this booking for good?')) return; animateOut(b.closest('.card'), apply); }
    else apply();
  }
  
  function editConfig(b, card) {
    const isS = tab === 'services', list = isS ? CFG.services : CFG.stylists, id = card.dataset.id;
    const done = msg => { saveCfg(); renderHome(); renderPanel(false); toast(msg); };
    if (b.hasAttribute('data-del')) {
      if (list.length <= 1) return toast('Keep at least one ' + (isS ? 'service' : 'stylist'));
      if (!confirm('Remove this ' + (isS ? 'service' : 'stylist') + '? Existing bookings are kept.')) return;
      return animateOut(card, () => { list.splice(list.findIndex(x => x.id === id), 1); done('Removed'); });
    }
    const v = {}; card.querySelectorAll('[data-k]').forEach(i => v[i.dataset.k] = i.value.trim());
    if (!v.name) return toast('Enter a name');
    let item;
    if (isS) {
      const mins = Number(v.mins), price = Number(v.price);
      if (!(mins > 0) || v.price === '' || !(price >= 0)) return toast('Enter valid minutes and price');
      item = { name: v.name, icon: v.icon || '💈', mins, price };
    } else item = { name: v.name, role: v.role || 'Stylist' };
    if (b.hasAttribute('data-add')) { list.push({ id: (isS ? 's' : 'st') + Date.now(), ...item }); done('Added'); }
    else { Object.assign(list.find(x => x.id === id), item); done('Saved'); }
  }
  
  $('panel').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.f) { filter = b.dataset.f; return renderPanel(true); }
    if (b.dataset.act) return bookingAction(b);
    if (b.hasAttribute('data-save') || b.hasAttribute('data-add') || b.hasAttribute('data-del')) editConfig(b, b.closest('.edit'));
  });
  $('panel').addEventListener('input', e => { if (e.target.id === 'q') { query = e.target.value; renderBookList(false); } });