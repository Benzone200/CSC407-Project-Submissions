/* Course-Desk admin: login page + dashboard (registrations, courses, settings). */
const KEY = 'cd_admin_token';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtDate = (d) => new Date(d.replace(' ', 'T') + 'Z').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
const label = (s) => ({ pending: 'Pending', approved: 'Approved', rejected: 'Rejected' }[s] || s);

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + (localStorage.getItem(KEY) || '') },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && !path.endsWith('/login')) { localStorage.removeItem(KEY); location.href = 'admin-login.html'; }
  if (!res.ok) throw new Error(data.error || 'Something went wrong. Try again.');
  return data;
}
function toast(msg, bad) {
  const t = Object.assign(document.createElement('div'), { className: 'toast' + (bad ? ' bad' : ''), textContent: msg });
  document.body.append(t); setTimeout(() => t.remove(), 3000);
}
const empty = (cols, text) => `<tr><td colspan="${cols}" class="empty">${text}</td></tr>`;

/* ---------- Login page ---------- */
if (document.body.dataset.page === 'admin-login') {
  $('#admin-login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const err = $('#form-error'); err.textContent = '';
    const f = new FormData(e.target);
    try {
      const d = await api('/admin/login', { method: 'POST', body: { username: f.get('username'), password: f.get('password') } });
      localStorage.setItem(KEY, d.token); location.href = 'admin.html';
    } catch (x) { err.textContent = x.message; }
  });
} else {
  if (!localStorage.getItem(KEY)) location.href = 'admin-login.html';
  else boot();
}

function boot() {
  $('#logout').addEventListener('click', () => { localStorage.removeItem(KEY); location.href = 'admin-login.html'; });
  const loaders = { registrations: loadRegs, courses: loadCourses, settings: loadSettings };
  const show = (tab) => {
    $$('[data-tab]').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
    ['registrations', 'courses', 'settings'].forEach((t) => ($('#tab-' + t).hidden = t !== tab));
    loaders[tab]().catch((e) => toast(e.message, true));
  };
  $$('[data-tab]').forEach((b) => b.addEventListener('click', () => show(b.dataset.tab)));
  show('registrations');

  /* ----- Registrations ----- */
  let regs = [];
  async function loadRegs() {
    const [d, s] = await Promise.all([api('/admin/registrations?status=' + $('#f-status').value), api('/admin/summary')]);
    regs = d.registrations;
    for (const k of ['pending', 'approved', 'rejected', 'students']) $('#n-' + k).textContent = s[k];
    drawRegs();
  }
  function drawRegs() {
    const q = $('#f-search').value.trim().toLowerCase();
    const list = regs.filter((r) => !q || [r.full_name, r.student_id, r.code, r.title, r.department].join(' ').toLowerCase().includes(q));
    $('#check-all').checked = false;
    $('#reg-rows').innerHTML = list.length ? list.map((r) => `<tr>
      <td><input type="checkbox" data-id="${r.id}" aria-label="Select"></td>
      <td>${esc(r.full_name)}<br><small>${esc(r.student_id)} · ${esc(r.department)} · ${r.level}L</small></td>
      <td>${esc(r.code)} — ${esc(r.title)}</td><td>${r.unit}</td>
      <td><span class="pill ${r.status}">${label(r.status)}</span>${r.reason ? `<br><small>${esc(r.reason)}</small>` : ''}</td>
      <td>${fmtDate(r.created_at)}</td></tr>`).join('') : empty(6, 'No registrations here.');
  }
  $('#f-status').addEventListener('change', () => loadRegs().catch((e) => toast(e.message, true)));
  $('#f-search').addEventListener('input', drawRegs);
  $('#check-all').addEventListener('change', (e) => $$('#reg-rows input[type=checkbox]').forEach((c) => (c.checked = e.target.checked)));
  async function review(status) {
    const ids = $$('#reg-rows input:checked').map((c) => +c.dataset.id);
    if (!ids.length) return toast('Select at least one registration.', true);
    let reason = '';
    if (status === 'rejected') { reason = prompt('Reason for rejecting (the student will see this). You can leave it empty.'); if (reason === null) return; }
    try { const d = await api('/admin/registrations/review', { method: 'POST', body: { ids, status, reason } }); toast(`${d.updated} registration(s) ${status}`); await loadRegs(); }
    catch (e) { toast(e.message, true); }
  }
  $('#approve').addEventListener('click', () => review('approved'));
  $('#reject').addEventListener('click', () => review('rejected'));

  /* ----- Courses ----- */
  let courses = [];
  async function loadCourses() { courses = (await api('/admin/courses')).courses; drawCourses(); }
  function drawCourses() {
    const q = $('#c-search').value.trim().toLowerCase();
    const list = courses.filter((c) => !q || (c.code + c.title + c.department).toLowerCase().includes(q));
    $('#course-rows').innerHTML = list.length ? list.map((c) => `<tr><td>${esc(c.code)}</td><td>${esc(c.title)}</td><td>${c.unit}</td><td>${c.status}</td>
      <td>${c.level}</td><td>${c.semester}</td><td>${esc(c.department) || '<small>All</small>'}</td>
      <td class="act"><button class="btn sm danger" data-del="${c.id}">Delete</button></td></tr>`).join('') : empty(8, 'No courses yet.');
  }
  $('#c-search').addEventListener('input', drawCourses);
  $('#course-rows').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-del]'); if (!b || !confirm('Delete this course?')) return;
    try { await api('/admin/courses/' + b.dataset.del, { method: 'DELETE' }); await loadCourses(); toast('Course deleted'); } catch (x) { toast(x.message, true); }
  });
  $('#course-form').addEventListener('submit', async (e) => {
    e.preventDefault(); $('#course-msg').textContent = '';
    const body = { code: $('#c-code').value, title: $('#c-title').value, unit: $('#c-unit').value, status: $('#c-status').value, level: $('#c-level').value, semester: $('#c-sem').value, department: $('#c-dept').value };
    try { await api('/admin/courses', { method: 'POST', body }); toast('Course saved'); $('#c-code').value = $('#c-title').value = ''; await loadCourses(); }
    catch (x) { $('#course-msg').textContent = x.message; }
  });
  $('#csv').addEventListener('change', async (e) => {
    const file = e.target.files[0]; if (!file) return;
    const msg = $('#csv-msg'); msg.textContent = '';
    const lines = (await file.text()).split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    if (lines[0] && /^code\b/i.test(lines[0])) lines.shift();
    const rows = lines.map((l) => { const [code, title, unit, status, level, semester, department = ''] = l.split(',').map((x) => x.trim().replace(/^"|"$/g, '')); return { code, title, unit, status, level, semester, department }; });
    try { const d = await api('/admin/courses/bulk', { method: 'POST', body: { rows } }); toast(`${d.saved} courses saved`); await loadCourses(); }
    catch (x) { msg.textContent = x.message; }
    e.target.value = '';
  });

  /* ----- Settings ----- */
  async function loadSettings() {
    const c = await api('/admin/settings');
    $('#s-session').value = c.session; $('#s-sem').value = c.semester; $('#s-units').value = c.maxUnits;
    $('#s-deadline').value = String(c.deadline).slice(0, 16); $('#s-open').checked = c.open;
  }
  $('#settings-form').addEventListener('submit', async (e) => {
    e.preventDefault(); $('#settings-msg').textContent = '';
    const body = { session: $('#s-session').value.trim(), semester: $('#s-sem').value, maxUnits: $('#s-units').value, deadline: $('#s-deadline').value, open: $('#s-open').checked };
    try { await api('/admin/settings', { method: 'PUT', body }); toast('Settings saved'); } catch (x) { $('#settings-msg').textContent = x.message; }
  });
}
