/* Course-Desk front-end logic: auth pages + the four app pages. */
const TOKEN = 'cd_token';
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtDate = (d) => new Date(d.replace(' ', 'T') + 'Z').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
const semName = (n) => (n === 1 ? 'First' : 'Second') + ' Semester';
const statusLabel = (s) => ({ pending: 'Pending', approved: 'Approved', rejected: 'Rejected' }[s] || s);
const initials = (name) => (name || '?').split(/\s+/).slice(0, 2).map((w) => w[0]).join('').toUpperCase();

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + (localStorage.getItem(TOKEN) || '') },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && !path.startsWith('/auth')) { localStorage.removeItem(TOKEN); location.href = 'login.html'; }
  if (!res.ok) throw new Error(data.error || 'Something went wrong. Try again.');
  return data;
}

function toast(msg, bad) {
  const t = Object.assign(document.createElement('div'), { className: 'toast' + (bad ? ' bad' : ''), textContent: msg });
  document.body.append(t);
  setTimeout(() => t.remove(), 2800);
}

const tableMsg = (cols, text) => `<tr><td colspan="${cols}" class="empty">${text}</td></tr>`;

/* ---------------- Auth pages ---------------- */
const formError = (m = '') => { const e = $('#form-error'); if (e) e.textContent = m; };
const lockBtn = (form, on) => { const b = $('button[type=submit]', form); b.disabled = on; };

const AUTH = {
  login() {
    $('#login-form').addEventListener('submit', async (e) => {
      e.preventDefault(); formError(); lockBtn(e.target, true);
      const f = new FormData(e.target);
      try {
        const d = await api('/auth/login', { method: 'POST', body: { studentId: f.get('student_id'), password: f.get('password') } });
        localStorage.setItem(TOKEN, d.token);
        location.href = 'dashboard.html';
      } catch (err) { formError(err.message); lockBtn(e.target, false); }
    });
  },
  signup() {
    $('#signup-form').addEventListener('submit', (e) => {
      e.preventDefault(); formError();
      const f = new FormData(e.target);
      if (f.get('password').length < 8) return formError('Password must be at least 8 characters.');
      if (f.get('password') !== f.get('confirm_password')) return formError('Passwords do not match.');
      sessionStorage.setItem('cd_signup', JSON.stringify({ email: f.get('email'), password: f.get('password') }));
      location.href = 'signup-details.html';
    });
  },
  details() {
    const step1 = JSON.parse(sessionStorage.getItem('cd_signup') || 'null');
    if (!step1) return (location.href = 'signup.html');
    $('#details-form').addEventListener('submit', async (e) => {
      e.preventDefault(); formError(); lockBtn(e.target, true);
      const f = new FormData(e.target);
      try {
        const d = await api('/auth/register', { method: 'POST', body: {
          ...step1, fullName: f.get('full_name'), studentId: f.get('student_id'), department: f.get('department'), level: f.get('level'),
        } });
        sessionStorage.removeItem('cd_signup');
        localStorage.setItem(TOKEN, d.token);
        location.href = 'dashboard.html';
      } catch (err) { formError(err.message); lockBtn(e.target, false); }
    });
  },
};

/* ---------------- App shell ---------------- */
const ICONS = {
  dashboard: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  register: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4h6M12 10v6M9 13h6"/>',
  history: '<path d="M6 3h8l4 4v4M6 3v18h5"/><circle cx="17" cy="17" r="4"/><path d="M17 15v2l1 1"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
  logout: '<path d="M9 4H5v16h4M16 8l4 4-4 4M20 12H9"/>',
};
const icon = (k) => `<svg viewBox="0 0 24 24" aria-hidden="true">${ICONS[k]}</svg>`;
const NAV = [['dashboard', 'Dashboard', 'dashboard.html'], ['register', 'Register Courses', 'register-courses.html'], ['history', 'Course History', 'course-history.html'], ['settings', 'Settings', 'settings.html']];

function renderShell(me, page) {
  $('#sidebar').innerHTML = `<div class="logo">Course-Desk</div><nav>${NAV.map(([k, label, href]) =>
    `<a class="nav-link${k === page ? ' active' : ''}" href="${href}">${icon(k)}${label}</a>`).join('')}</nav>
    <div class="spacer"></div><button class="nav-link logout" id="logout">${icon('logout')}Log out</button>`;
  $('#topbar').innerHTML = `<div class="avatar" title="${esc(me.fullName)}">${esc(initials(me.fullName))}</div>`;
  $('#logout').addEventListener('click', () => { localStorage.removeItem(TOKEN); location.href = 'login.html'; });
}

/* ---------------- Pages ---------------- */
const PAGES = {
  async dashboard(me) {
    const d = await api('/dashboard');
    $('#greeting').textContent = `Welcome back, ${me.fullName.split(' ')[0]}`;
    $('#term').textContent = `Semester ${d.semester} · ${d.session} · ${d.open ? 'Registration closes ' + new Date(d.deadline).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : 'Registration is closed'}`;
    $('#s-reg').textContent = d.registered;
    $('#s-avail').textContent = d.available;
    $('#s-units').textContent = `${d.units}/${d.maxUnits}`;
    $('#recent').innerHTML = d.recent.length
      ? d.recent.map((r) => `<tr><td>${esc(r.code)}</td><td>${esc(r.title)}</td><td>${fmtDate(r.created_at)}</td><td><span class="pill ${esc(r.status)}">${statusLabel(r.status)}</span></td></tr>`).join('')
      : tableMsg(4, 'You have not registered any course yet. Use “Register Courses” to start.');
  },

  async register() {
    let courses = [];
    const draw = () => {
      const q = $('#search').value.trim().toLowerCase();
      const list = courses.filter((c) => !q || (c.code + ' ' + c.title).toLowerCase().includes(q));
      $('#rows').innerHTML = list.length
        ? list.map((c) => {
            const a = c.approval;
            const btn = a === 'approved' ? '<button class="btn" disabled>Approved</button>'
              : `<button class="btn ${a ? 'remove' : 'add'}" data-id="${c.id}">${a ? 'Remove Course' : 'Add Course'}</button>`;
            const pill = a ? `<span class="pill ${a}">${statusLabel(a)}</span>${a === 'rejected' && c.reason ? `<br><small class="why">${esc(c.reason)}</small>` : ''}` : '—';
            return `<tr><td>${esc(c.code)}</td><td>${esc(c.title)}</td><td>${c.unit}</td><td>${esc(c.status)}</td><td>${pill}</td><td class="act">${btn}</td></tr>`;
          }).join('')
        : tableMsg(6, courses.length ? 'No course matches your search.' : 'No courses have been uploaded for your level and department yet.');
      const mine = courses.filter((c) => c.approval && c.approval !== 'rejected');
      $('#t-count').textContent = `Total Course Registered - ${mine.length}`;
      $('#t-units').textContent = `Total Unit - ${mine.reduce((s, c) => s + c.unit, 0)}`;
    };
    const load = async () => { courses = (await api('/courses')).courses; draw(); };
    await load();
    $('#search').addEventListener('input', draw);
    $('#rows').addEventListener('click', async (e) => {
      const b = e.target.closest('button[data-id]'); if (!b) return;
      const c = courses.find((x) => x.id === +b.dataset.id);
      b.disabled = true;
      try {
        await api(c.approval ? `/registrations/${c.id}` : '/registrations', c.approval ? { method: 'DELETE' } : { method: 'POST', body: { courseId: c.id } });
        await load();
      } catch (err) { toast(err.message, true); b.disabled = false; }
    });
    $('#clear').addEventListener('click', async () => {
      if (!courses.some((c) => c.approval && c.approval !== 'approved') || !confirm('Remove all courses that are not yet approved?')) return;
      try { await api('/registrations', { method: 'DELETE' }); await load(); } catch (err) { toast(err.message, true); }
    });
  },

  async history() {
    let terms = (await api('/history')).terms, detail = null, courses = [];
    const draw = () => {
      const q = $('#search').value.trim().toLowerCase();
      $('#back').hidden = !detail;
      if (!detail) {
        $('#head').innerHTML = '<tr><th>Semester</th><th>Level</th><th>Total Unit</th><th class="act">Action</th></tr>';
        const list = terms.filter((t) => !q || semName(t.semester).toLowerCase().includes(q) || t.session.includes(q));
        $('#rows').innerHTML = list.length
          ? list.map((t, i) => `<tr><td>${semName(t.semester)} (${esc(t.session)})</td><td>${t.level}</td><td>${t.total_unit}</td>
              <td class="act"><button class="btn" data-i="${terms.indexOf(t)}">View</button></td></tr>`).join('')
          : tableMsg(4, terms.length ? 'No result found.' : 'No history yet. Courses you register will show up here.');
      } else {
        $('#head').innerHTML = '<tr><th>Course Code</th><th>Course Title</th><th>Unit</th><th>Status</th></tr>';
        const list = courses.filter((c) => !q || (c.code + ' ' + c.title).toLowerCase().includes(q));
        $('#rows').innerHTML = list.length ? list.map((c) => `<tr><td>${esc(c.code)}</td><td>${esc(c.title)}</td><td>${c.unit}</td><td>${esc(c.status)}</td></tr>`).join('') : tableMsg(4, 'No result found.');
      }
    };
    draw();
    $('#search').addEventListener('input', draw);
    $('#back').addEventListener('click', () => { detail = null; $('#search').value = ''; draw(); });
    $('#rows').addEventListener('click', async (e) => {
      const b = e.target.closest('button[data-i]'); if (!b) return;
      detail = terms[+b.dataset.i];
      try { courses = (await api(`/history/detail?session=${encodeURIComponent(detail.session)}&semester=${detail.semester}`)).courses; $('#search').value = ''; draw(); }
      catch (err) { detail = null; toast(err.message, true); }
    });
  },

  async settings(me) {
    const pf = $('#profile-form'), pw = $('#password-form');
    const fill = (m) => { for (const k of ['fullName', 'studentId', 'email', 'faculty', 'department', 'level']) pf.elements[k].value = m[k] ?? ''; $('#big-avatar').textContent = initials(m.fullName); };
    fill(me);
    document.querySelectorAll('.tab').forEach((t) => t.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('active', x === t));
      pf.hidden = t.dataset.tab !== 'profile'; pw.hidden = t.dataset.tab !== 'password';
    }));
    document.querySelectorAll('[data-clear]').forEach((b) => b.addEventListener('click', () => {
      b.closest('form').querySelectorAll('input:not([readonly])').forEach((i) => (i.value = ''));
    }));
    // Photo: preview only. Saving photos needs file storage on the server (see README).
    $('#photo-btn').addEventListener('click', () => $('#photo').click());
    $('#photo').addEventListener('change', (e) => {
      const f = e.target.files[0]; if (!f) return;
      if (f.size > 2 * 1024 * 1024) return toast('Photo must be 2 MB or less.', true);
      $('#big-avatar').style.cssText = `background:url(${URL.createObjectURL(f)}) center/cover`; $('#big-avatar').textContent = '';
    });
    pf.addEventListener('submit', async (e) => {
      e.preventDefault(); $('#profile-msg').textContent = '';
      const body = Object.fromEntries(['fullName', 'email', 'faculty', 'department', 'level'].map((k) => [k, pf.elements[k].value]));
      try { const m = await api('/me', { method: 'PUT', body }); fill(m); $('#topbar .avatar').textContent = initials(m.fullName); toast('Profile saved'); }
      catch (err) { $('#profile-msg').textContent = err.message; }
    });
    pw.addEventListener('submit', async (e) => {
      e.preventDefault(); const msg = $('#password-msg'); msg.textContent = '';
      if ($('#pw1').value !== $('#pw2').value) return (msg.textContent = 'Passwords do not match.');
      try { await api('/me/password', { method: 'PUT', body: { password: $('#pw1').value } }); pw.reset(); toast('Password updated'); }
      catch (err) { msg.textContent = err.message; }
    });
  },
};

/* ---------------- Boot ---------------- */
const pageKey = document.body.dataset.page;
if (AUTH[pageKey]) {
  if (localStorage.getItem(TOKEN) && pageKey === 'login') location.href = 'dashboard.html';
  else AUTH[pageKey]();
} else if (!localStorage.getItem(TOKEN)) {
  location.href = 'login.html';
} else {
  api('/me').then((me) => {
    renderShell(me, { dashboard: 'dashboard', register: 'register', history: 'history', settings: 'settings' }[pageKey]);
    return PAGES[pageKey](me);
  }).catch((err) => toast(err.message, true));
}
