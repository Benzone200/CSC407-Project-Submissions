const path = require('path');
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { DatabaseSync } = require('node:sqlite');

const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || 'change-this-secret-before-deploying';
// First admin account, created only when no admin exists yet. Change the password after first login in production.
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin12345';
const LEVELS = [100, 200, 300, 400, 500, 600];

/* ---------- Database ---------- */
const db = new DatabaseSync(path.join(__dirname, 'coursedesk.db'));
db.exec('PRAGMA foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT NOT NULL UNIQUE, email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL, full_name TEXT NOT NULL, faculty TEXT DEFAULT '', department TEXT NOT NULL,
  level INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS courses (
  id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE, title TEXT NOT NULL, unit INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('C','E')), level INTEGER NOT NULL, semester INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS registrations (
  id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  course_id INTEGER NOT NULL REFERENCES courses(id), session TEXT NOT NULL, level INTEGER NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE (student_id, course_id, session)
);
CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`);

// Upgrade older databases without losing data.
const addColumn = (table, col, def) => {
  if (!db.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${def}`);
};
addColumn('courses', 'department', "TEXT NOT NULL DEFAULT ''");          // blank = every department
addColumn('registrations', 'status', "TEXT NOT NULL DEFAULT 'pending'"); // pending | approved | rejected
addColumn('registrations', 'reason', "TEXT NOT NULL DEFAULT ''");
addColumn('registrations', 'reviewed_at', 'TEXT');

// Settings the admin can change from the dashboard.
const DEFAULTS = { session: '2026/27', semester: '1', maxUnits: '30', deadline: '2026-12-31T23:59', open: '1' };
for (const [k, v] of Object.entries(DEFAULTS)) db.prepare('INSERT OR IGNORE INTO settings (key,value) VALUES (?,?)').run(k, v);
const getCfg = () => {
  const r = Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map((x) => [x.key, x.value]));
  return { session: r.session, semester: +r.semester, maxUnits: +r.maxUnits, deadline: r.deadline, open: r.open === '1' };
};
const isOpen = (cfg) => cfg.open && new Date() <= new Date(cfg.deadline);

if (!db.prepare('SELECT 1 FROM admins LIMIT 1').get()) {
  db.prepare('INSERT INTO admins (username,password_hash) VALUES (?,?)').run(ADMIN_USER, bcrypt.hashSync(ADMIN_PASSWORD, 10));
  console.log(`First admin created -> username: ${ADMIN_USER}  password: ${ADMIN_PASSWORD}`);
}
if (!db.prepare('SELECT 1 FROM courses LIMIT 1').get()) {
  const add = db.prepare('INSERT INTO courses (code,title,unit,status,level,semester,department) VALUES (?,?,?,?,?,?,?)');
  [['CSC301', 'Matrix 1', 3, 'E'], ['CSC302', 'Algorithm 1', 3, 'E'], ['CSC303', 'Programming Algorithm', 3, 'C'],
   ['CSC305', 'Operating Systems', 3, 'C'], ['CSC308', 'Matrix 2', 3, 'C'], ['CSC309', 'Algorithm 2', 3, 'C'],
   ['CSC310', 'Algorithm 3', 3, 'E'], ['CSC312', 'Matrix 3', 3, 'C']].forEach(([c, t, u, s]) => add.run(c, t, u, s, 300, 1, ''));
}

/* ---------- Helpers ---------- */
const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

const fail = (res, code, error) => res.status(code).json({ error });
const tokenFor = (id, role) => jwt.sign({ id, role }, SECRET, { expiresIn: role === 'admin' ? '12h' : '7d' });
const publicStudent = (s) => ({ id: s.id, studentId: s.student_id, email: s.email, fullName: s.full_name, faculty: s.faculty, department: s.department, level: s.level });
const getStudent = (id) => db.prepare('SELECT * FROM students WHERE id = ?').get(id);
const normId = (s) => String(s || '').trim().toUpperCase();
const validEmail = (s) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);

const guard = (role) => (req, res, next) => {
  try {
    const p = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET);
    if ((p.role || 'student') !== role) throw new Error();
    const ok = role === 'admin' ? db.prepare('SELECT 1 FROM admins WHERE id=?').get(p.id) : getStudent(p.id);
    if (!ok) throw new Error();
    req.uid = p.id; next();
  } catch { fail(res, 401, 'Please log in again.'); }
};
const auth = guard('student'), adminOnly = guard('admin');

// Courses a student can see: their level + current semester + their department (blank or "All" = every department).
const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
const forDept = (c, dept) => {
  const list = String(c.department || '').split(/[,;]/).map(norm).filter(Boolean);
  return !list.length || list.includes('all') || list.includes(norm(dept));
};
const availableFor = (me, cfg) => db.prepare('SELECT * FROM courses WHERE level=? AND semester=? ORDER BY code').all(me.level, cfg.semester).filter((c) => forDept(c, me.department));
const unitsFor = (id, cfg) => db.prepare(`SELECT COALESCE(SUM(c.unit),0) AS u FROM registrations r JOIN courses c ON c.id=r.course_id
  WHERE r.student_id=? AND r.session=? AND c.semester=? AND r.status != 'rejected'`).get(id, cfg.session, cfg.semester).u;

/* ---------- Student auth + profile ---------- */
app.post('/api/auth/register', (req, res) => {
  const { email, password, fullName, studentId, department, level } = req.body;
  const lvl = parseInt(level, 10);
  if (!validEmail(email || '')) return fail(res, 400, 'Enter a valid email address.');
  if (!password || password.length < 8) return fail(res, 400, 'Password must be at least 8 characters.');
  if (!String(fullName || '').trim() || !normId(studentId) || !String(department || '').trim()) return fail(res, 400, 'Fill in all the fields.');
  if (!LEVELS.includes(lvl)) return fail(res, 400, 'Level must be 100, 200, 300, 400, 500 or 600.');
  try {
    const info = db.prepare('INSERT INTO students (student_id,email,password_hash,full_name,department,level) VALUES (?,?,?,?,?,?)')
      .run(normId(studentId), email.trim().toLowerCase(), bcrypt.hashSync(password, 10), fullName.trim(), department.trim(), lvl);
    res.status(201).json({ token: tokenFor(Number(info.lastInsertRowid), 'student') });
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return fail(res, 409, 'That student ID or email is already registered.');
    throw e;
  }
});

app.post('/api/auth/login', (req, res) => {
  const s = db.prepare('SELECT * FROM students WHERE student_id = ?').get(normId(req.body.studentId));
  if (!s || !bcrypt.compareSync(String(req.body.password || ''), s.password_hash)) return fail(res, 401, 'Wrong student ID or password.');
  res.json({ token: tokenFor(s.id, 'student') });
});

app.get('/api/me', auth, (req, res) => res.json(publicStudent(getStudent(req.uid))));

app.put('/api/me', auth, (req, res) => {
  const { fullName, email, faculty = '', department } = req.body;
  const lvl = parseInt(req.body.level, 10);
  if (!String(fullName || '').trim() || !String(department || '').trim()) return fail(res, 400, 'Full name and department are required.');
  if (!validEmail(email || '')) return fail(res, 400, 'Enter a valid email address.');
  if (!LEVELS.includes(lvl)) return fail(res, 400, 'Level must be 100, 200, 300, 400, 500 or 600.');
  try {
    db.prepare('UPDATE students SET full_name=?, email=?, faculty=?, department=?, level=? WHERE id=?')
      .run(fullName.trim(), email.trim().toLowerCase(), String(faculty).trim(), department.trim(), lvl, req.uid);
    res.json(publicStudent(getStudent(req.uid)));
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) return fail(res, 409, 'That email is already in use.');
    throw e;
  }
});

app.put('/api/me/password', auth, (req, res) => {
  if (!req.body.password || req.body.password.length < 8) return fail(res, 400, 'Password must be at least 8 characters.');
  db.prepare('UPDATE students SET password_hash=? WHERE id=?').run(bcrypt.hashSync(req.body.password, 10), req.uid);
  res.json({ ok: true });
});

/* ---------- Student: dashboard, courses, registration ---------- */
app.get('/api/dashboard', auth, (req, res) => {
  const me = getStudent(req.uid), cfg = getCfg();
  const registered = db.prepare(`SELECT COUNT(*) n FROM registrations r JOIN courses c ON c.id=r.course_id
    WHERE r.student_id=? AND r.session=? AND c.semester=? AND r.status != 'rejected'`).get(me.id, cfg.session, cfg.semester).n;
  const recent = db.prepare(`SELECT c.code, c.title, r.created_at, r.status FROM registrations r JOIN courses c ON c.id=r.course_id
    WHERE r.student_id=? AND r.session=? AND c.semester=? ORDER BY r.created_at DESC, r.id DESC LIMIT 5`).all(me.id, cfg.session, cfg.semester);
  res.json({ ...cfg, open: isOpen(cfg), registered, available: availableFor(me, cfg).length, units: unitsFor(me.id, cfg), recent });
});

app.get('/api/courses', auth, (req, res) => {
  const me = getStudent(req.uid), cfg = getCfg();
  const regs = new Map(db.prepare('SELECT course_id, status, reason FROM registrations WHERE student_id=? AND session=?').all(me.id, cfg.session).map((r) => [r.course_id, r]));
  const courses = availableFor(me, cfg).map((c) => ({
    id: c.id, code: c.code, title: c.title, unit: c.unit, status: c.status,
    approval: regs.get(c.id)?.status || null, reason: regs.get(c.id)?.reason || '',
  }));
  res.json({ courses });
});

app.post('/api/registrations', auth, (req, res) => {
  const cfg = getCfg();
  if (!isOpen(cfg)) return fail(res, 403, 'Course registration is closed.');
  const me = getStudent(req.uid);
  const course = availableFor(me, cfg).find((c) => c.id === Number(req.body.courseId));
  if (!course) return fail(res, 404, 'That course is not available for your level and department.');
  if (unitsFor(me.id, cfg) + course.unit > cfg.maxUnits) return fail(res, 400, `You cannot register more than ${cfg.maxUnits} units.`);
  try {
    db.prepare('INSERT INTO registrations (student_id,course_id,session,level) VALUES (?,?,?,?)').run(me.id, course.id, cfg.session, me.level);
    res.status(201).json({ ok: true });
  } catch { fail(res, 409, 'This course is already in your list. Remove it first to add it again.'); }
});

app.delete('/api/registrations/:courseId', auth, (req, res) => {
  const cfg = getCfg();
  if (!isOpen(cfg)) return fail(res, 403, 'Course registration is closed.');
  const r = db.prepare('SELECT status FROM registrations WHERE student_id=? AND course_id=? AND session=?').get(req.uid, req.params.courseId, cfg.session);
  if (r?.status === 'approved') return fail(res, 409, 'This course was approved. Contact the admin to change it.');
  db.prepare('DELETE FROM registrations WHERE student_id=? AND course_id=? AND session=?').run(req.uid, req.params.courseId, cfg.session);
  res.json({ ok: true });
});

app.delete('/api/registrations', auth, (req, res) => {
  const cfg = getCfg();
  if (!isOpen(cfg)) return fail(res, 403, 'Course registration is closed.');
  db.prepare(`DELETE FROM registrations WHERE student_id=? AND session=? AND status != 'approved'
    AND course_id IN (SELECT id FROM courses WHERE semester=?)`).run(req.uid, cfg.session, cfg.semester);
  res.json({ ok: true });
});

// History only lists courses the admin approved.
app.get('/api/history', auth, (req, res) => {
  const terms = db.prepare(`SELECT r.session, c.semester, r.level, SUM(c.unit) AS total_unit FROM registrations r JOIN courses c ON c.id=r.course_id
    WHERE r.student_id=? AND r.status='approved' GROUP BY r.session, c.semester, r.level ORDER BY r.session DESC, c.semester ASC`).all(req.uid);
  res.json({ terms });
});

app.get('/api/history/detail', auth, (req, res) => {
  const courses = db.prepare(`SELECT c.code, c.title, c.unit, c.status FROM registrations r JOIN courses c ON c.id=r.course_id
    WHERE r.student_id=? AND r.session=? AND c.semester=? AND r.status='approved' ORDER BY c.code`).all(req.uid, String(req.query.session), parseInt(req.query.semester, 10));
  res.json({ courses });
});

/* ---------- Admin ---------- */
app.post('/api/admin/login', (req, res) => {
  const a = db.prepare('SELECT * FROM admins WHERE username = ?').get(String(req.body.username || '').trim());
  if (!a || !bcrypt.compareSync(String(req.body.password || ''), a.password_hash)) return fail(res, 401, 'Wrong username or password.');
  res.json({ token: tokenFor(a.id, 'admin') });
});

app.get('/api/admin/summary', adminOnly, (req, res) => {
  const by = Object.fromEntries(db.prepare('SELECT status, COUNT(*) n FROM registrations GROUP BY status').all().map((r) => [r.status, r.n]));
  const n = (t) => db.prepare(`SELECT COUNT(*) n FROM ${t}`).get().n;
  res.json({ pending: by.pending || 0, approved: by.approved || 0, rejected: by.rejected || 0, students: n('students'), courses: n('courses') });
});

// 1) Registration settings (deadline, open/closed, session, semester, unit cap)
app.get('/api/admin/settings', adminOnly, (req, res) => res.json(getCfg()));
app.put('/api/admin/settings', adminOnly, (req, res) => {
  const { session, semester, maxUnits, deadline, open } = req.body;
  if (!/^\d{4}\/\d{2}$/.test(session || '')) return fail(res, 400, 'Session must look like 2026/27.');
  if (![1, 2].includes(+semester)) return fail(res, 400, 'Semester must be 1 or 2.');
  if (!(+maxUnits > 0 && +maxUnits <= 60)) return fail(res, 400, 'Maximum units must be between 1 and 60.');
  if (!deadline || isNaN(new Date(deadline))) return fail(res, 400, 'Enter a valid deadline.');
  const set = db.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  [['session', session], ['semester', +semester], ['maxUnits', +maxUnits], ['deadline', deadline], ['open', open ? 1 : 0]].forEach(([k, v]) => set.run(k, String(v)));
  res.json(getCfg());
});

// 2) Approve / reject registrations
app.get('/api/admin/registrations', adminOnly, (req, res) => {
  const st = ['pending', 'approved', 'rejected'].includes(req.query.status) ? req.query.status : null;
  const rows = db.prepare(`SELECT r.id, r.status, r.reason, r.created_at, r.session, r.level, s.full_name, s.student_id, s.department, c.code, c.title, c.unit
    FROM registrations r JOIN students s ON s.id=r.student_id JOIN courses c ON c.id=r.course_id
    ${st ? 'WHERE r.status=?' : ''} ORDER BY s.student_id, c.code`).all(...(st ? [st] : []));
  res.json({ registrations: rows });
});

app.post('/api/admin/registrations/review', adminOnly, (req, res) => {
  const { ids, status, reason = '' } = req.body;
  if (!Array.isArray(ids) || !ids.length || !['approved', 'rejected', 'pending'].includes(status)) return fail(res, 400, 'Select at least one registration.');
  const up = db.prepare('UPDATE registrations SET status=?, reason=?, reviewed_at=CURRENT_TIMESTAMP WHERE id=?');
  let updated = 0;
  for (const id of ids) updated += Number(up.run(status, status === 'rejected' ? String(reason).slice(0, 200) : '', Number(id)).changes);
  res.json({ updated });
});

// 3) Upload courses (one at a time or in bulk). Saving an existing code updates that course.
const parseCourse = (b) => {
  const course = {
    code: String(b.code || '').trim().toUpperCase().replace(/\s+/g, ''), title: String(b.title || '').trim(),
    unit: parseInt(b.unit, 10), status: String(b.status || 'C').trim().toUpperCase().charAt(0),
    level: parseInt(b.level, 10), semester: parseInt(b.semester, 10), department: String(b.department || '').trim(),
  };
  let error = null;
  if (!course.code || !course.title) error = 'code and title are required';
  else if (!(course.unit >= 1 && course.unit <= 10)) error = 'unit must be 1 to 10';
  else if (!['C', 'E'].includes(course.status)) error = 'status must be C or E';
  else if (!LEVELS.includes(course.level)) error = 'level must be 100 to 600';
  else if (![1, 2].includes(course.semester)) error = 'semester must be 1 or 2';
  return { course, error };
};
const upsert = db.prepare(`INSERT INTO courses (code,title,unit,status,level,semester,department) VALUES (?,?,?,?,?,?,?)
  ON CONFLICT(code) DO UPDATE SET title=excluded.title, unit=excluded.unit, status=excluded.status, level=excluded.level, semester=excluded.semester, department=excluded.department`);
const saveCourse = (c) => upsert.run(c.code, c.title, c.unit, c.status, c.level, c.semester, c.department);

app.get('/api/admin/courses', adminOnly, (req, res) => res.json({ courses: db.prepare('SELECT * FROM courses ORDER BY level, semester, code').all() }));

app.post('/api/admin/courses', adminOnly, (req, res) => {
  const { course, error } = parseCourse(req.body);
  if (error) return fail(res, 400, `Course: ${error}.`);
  saveCourse(course); res.status(201).json({ ok: true });
});

app.post('/api/admin/courses/bulk', adminOnly, (req, res) => {
  if (!Array.isArray(req.body.rows) || !req.body.rows.length) return fail(res, 400, 'No courses found in the file.');
  const parsed = req.body.rows.map(parseCourse);
  const bad = parsed.map((p, i) => (p.error ? `Row ${i + 1}: ${p.error}` : null)).filter(Boolean);
  if (bad.length) return fail(res, 400, `Nothing was saved. ${bad.slice(0, 5).join('; ')}${bad.length > 5 ? ` (+${bad.length - 5} more)` : ''}`);
  db.exec('BEGIN');
  try { parsed.forEach((p) => saveCourse(p.course)); db.exec('COMMIT'); } catch (e) { db.exec('ROLLBACK'); throw e; }
  res.status(201).json({ saved: parsed.length });
});

app.delete('/api/admin/courses/:id', adminOnly, (req, res) => {
  if (db.prepare('SELECT 1 FROM registrations WHERE course_id=?').get(req.params.id)) return fail(res, 409, 'Students have registered this course, so it cannot be deleted.');
  db.prepare('DELETE FROM courses WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

/* ---------- Errors ---------- */
app.use('/api', (req, res) => fail(res, 404, 'Not found.'));
app.use((err, req, res, next) => { console.error(err); fail(res, 500, 'Server error. Try again.'); });

app.listen(PORT, () => console.log(`Course-Desk running at http://localhost:${PORT}/login.html  (admin: /admin-login.html)`));
