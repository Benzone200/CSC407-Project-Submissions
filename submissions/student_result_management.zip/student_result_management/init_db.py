"""Initialise the database and the default administrator.

Usage:
    python init_db.py
    python init_db.py --set-admin-password "NewStrongPassword"
"""
import argparse
import sqlite3
import sys

from werkzeug.security import generate_password_hash

import config
from app import DB_PATH, DEFAULT_ADMIN_CREATED, setup_database


def main():
    parser = argparse.ArgumentParser(description="Initialise the result management database.")
    parser.add_argument("--set-admin-password", metavar="NEW_PASSWORD",
                        help="Change the administrator password.")
    args = parser.parse_args()

    setup_database()  # safe to repeat
    print(f"Database ready: {DB_PATH}")
    if DEFAULT_ADMIN_CREATED:
        print(f"Default administrator created: username '{config.DEFAULT_ADMIN_USERNAME}'. "
              "See README.md for the password and change it before deployment.")

    if args.set_admin_password:
        if len(args.set_admin_password) < 8:
            sys.exit("The administrator password must be at least 8 characters.")
        conn = sqlite3.connect(DB_PATH)
        conn.execute("UPDATE users SET password_hash = ? WHERE role = 'admin'",
                     (generate_password_hash(args.set_admin_password),))
        conn.commit()
        conn.close()
        print("Administrator password updated.")


if __name__ == "__main__":
    main()