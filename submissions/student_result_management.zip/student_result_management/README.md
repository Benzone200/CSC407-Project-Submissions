# Student Result Management System

A small, lightweight result management system built with Flask, SQLite, Jinja2 templates and vanilla JavaScript. It has two roles: **Administrator** and **Student**.

## Main features

- Public pages: home page, login, student registration, and a security page explaining the protections in place.
- Student registration (accounts wait for administrator approval before they can sign in).
- Administrator: dashboard overview, student management (register, approve, search, edit, delete, profile), course management, score entry with automatic grading, edit saved results, publish or unpublish results.
- Student: dashboard, personal information, published results by session and semester, semester GPA, CGPA, printable result sheet.
- Profile page for both roles: change password (students can also update their email).
- Responsive layout for phones and computers.

## Security summary

Password hashing (Werkzeug), role-based access control, server-side input validation, parameterised SQL (SQL injection protection), Jinja2 autoescaping plus a Content Security Policy (XSS protection), CSRF tokens on every form, login lockout after repeated failures, secure session cookies, security headers. Details are on the in-app **Security** page (`/security`).

## Technology stack

Python, Flask, SQLite (standard library `sqlite3`), HTML5, CSS3, Vanilla JavaScript, Jinja2.

## Project structure

```
student_result_management/
├── app.py            # routes, authentication, database, grading logic
├── config.py         # settings
├── init_db.py        # database initialisation, admin password change
├── requirements.txt
├── README.md
├── instance/         # results.db is created here automatically
├── templates/
│   ├── base.html            # layouts: public, admin, student
│   ├── home.html, login.html, register.html, security.html, error.html
│   ├── profile.html
│   ├── admin_dashboard.html, student_dashboard.html
│   ├── students.html, student_form.html, student_profile.html
│   ├── courses.html, course_form.html
│   └── results.html, view_result.html
└── static/
    ├── css/style.css # design system, responsive and print styles
    └── js/
        ├── main.js     # confirmations, printing, auto-submit
        └── results.js  # live score preview and validation
```

## Installation

```bash
python -m venv venv
```

Activate the environment:

- macOS / Linux: `source venv/bin/activate`
- Windows (PowerShell): `venv\Scripts\Activate.ps1`

```bash
pip install -r requirements.txt
python init_db.py
python app.py
```

Open http://127.0.0.1:5000

The database is also created automatically on first launch, so `python init_db.py` is optional. An existing database from the earlier version is upgraded automatically (all existing students stay approved).

## Default administrator login

| Username | Password |
|---|---|
| `admin` | `Admin@12345` |

**Change this password before deployment.**

## Changing the administrator password

Either sign in and use **Profile > Change password**, or run:

```bash
python init_db.py --set-admin-password "YourNewStrongPassword"
```

(minimum 8 characters). Alternatively, set `ADMIN_USERNAME` and `ADMIN_PASSWORD` environment variables before the very first run to create the account with different credentials.

## Other settings

Environment variables: `SECRET_KEY`, `INSTITUTION_NAME`, `FLASK_DEBUG=1`, `SECURE_COOKIES=1` (set when serving over HTTPS). If `SECRET_KEY` is not set, a random key is generated and stored in `instance/secret.key`. Session length and login lockout limits are in `config.py`.

## Typical workflow

1. Sign in as administrator.
2. Add courses (Courses > Add course).
3. Register students (Students > Register student), or let students register themselves at `/register` and approve them on the Students page.
4. Results: select a student, session and semester, enter CA and exam scores, then save.
5. Review with "View semester result", then click **Publish results**.
6. The student signs in and sees only published results.

## Before deploying

- Change the default administrator password.
- Run behind HTTPS and set `SECURE_COOKIES=1`.
- Set a fixed `SECRET_KEY`, leave `FLASK_DEBUG` unset, and use a production server (for example gunicorn or waitress) instead of `python app.py`.
- Back up `instance/results.db` regularly.