"""Application settings. Environment variables override the defaults."""
import os

INSTITUTION_NAME = os.environ.get("INSTITUTION_NAME", "Heritage University")
DATABASE_NAME = "results.db"  # stored in the instance/ folder
SECRET_KEY = os.environ.get("SECRET_KEY")  # if unset, a random key is stored in instance/secret.key
DEBUG = os.environ.get("FLASK_DEBUG") == "1"

# Set SECURE_COOKIES=1 when the site is served over HTTPS.
SECURE_COOKIES = os.environ.get("SECURE_COOKIES") == "1"
SESSION_MINUTES = 120          # sign-in lasts this long
MAX_LOGIN_ATTEMPTS = 5         # failed attempts before a temporary lockout
LOCKOUT_SECONDS = 300

# Default administrator (created only if no administrator exists). Change before deployment.
DEFAULT_ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
DEFAULT_ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "Admin@12345")

LEVELS = ["100", "200", "300", "400", "500"]
SEMESTERS = ["First", "Second"]
MAX_CA = 30
MAX_EXAM = 70
MAX_CREDIT_UNIT = 10
MIN_PASSWORD_LENGTH = 8

# (minimum total score, grade, grade point, remark), highest first
GRADE_SCALE = [
    (70, "A", 5.0, "Excellent"),
    (60, "B", 4.0, "Very Good"),
    (50, "C", 3.0, "Good"),
    (45, "D", 2.0, "Fair"),
    (40, "E", 1.0, "Pass"),
    (0, "F", 0.0, "Fail"),
]