"""Student Result Management System: Flask application, routes and logic."""
import os
import re
import secrets
import sqlite3
import time
from datetime import datetime, timedelta
from functools import wraps

from flask import (Flask, abort, flash, g, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

import config

app = Flask(__name__, instance_relative_config=True)
os.makedirs(app.instance_path, exist_ok=True)
DB_PATH = os.path.join(app.instance_path, config.DATABASE_NAME)


def load_secret_key():
    """Use SECRET_KEY from the environment, else a random key kept in instance/."""
    if config.SECRET_KEY:
        return config.SECRET_KEY
    path = os.path.join(app.instance_path, "secret.key")
    if not os.path.exists(path):
        with open(path, "w") as handle:
            handle.write(secrets.token_hex(32))
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    with open(path) as handle:
        return handle.read().strip()


app.config["SECRET_KEY"] = load_secret_key()
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = config.SECURE_COOKIES
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(minutes=config.SESSION_MINUTES)
app.config["MAX_CONTENT_LENGTH"] = 256 * 1024  # reject oversized request bodies

EMAIL_RE = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")
SESSION_RE = re.compile(r"(\d{4})/(\d{4})")

# Browsers may only load scripts and styles from this site (plus Google Fonts).
CONTENT_SECURITY_POLICY = (
    "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; "
    "font-src https://fonts.gstatic.com; img-src 'self' data:; object-src 'none'; "
    "base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
)

# --------------------------------------------------------------------------
# Database
# --------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'student'))
);
CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    matric_no TEXT NOT NULL UNIQUE COLLATE NOCASE,
    email TEXT NOT NULL,
    department TEXT NOT NULL,
    level TEXT NOT NULL,
    approved INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE COLLATE NOCASE,
    title TEXT NOT NULL,
    credit_unit INTEGER NOT NULL CHECK (credit_unit BETWEEN 1 AND 10),
    department TEXT NOT NULL,
    level TEXT NOT NULL,
    semester TEXT NOT NULL CHECK (semester IN ('First', 'Second'))
);
CREATE TABLE IF NOT EXISTS results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE RESTRICT,
    academic_session TEXT NOT NULL,
    semester TEXT NOT NULL CHECK (semester IN ('First', 'Second')),
    ca_score REAL NOT NULL CHECK (ca_score BETWEEN 0 AND 30),
    exam_score REAL NOT NULL CHECK (exam_score BETWEEN 0 AND 70),
    total_score REAL NOT NULL,
    grade TEXT NOT NULL,
    grade_point REAL NOT NULL,
    remark TEXT NOT NULL,
    published INTEGER NOT NULL DEFAULT 0 CHECK (published IN (0, 1)),
    updated_at TEXT NOT NULL,
    UNIQUE (student_id, course_id, academic_session, semester)
);
CREATE INDEX IF NOT EXISTS idx_results_lookup
    ON results (student_id, academic_session, semester);
"""


def setup_database():
    """Create tables and the default administrator. Returns True if admin was created."""
    conn = sqlite3.connect(DB_PATH)
    created = False
    try:
        conn.executescript(SCHEMA)
        # Upgrade databases created before self-registration existed.
        columns = [row[1] for row in conn.execute("PRAGMA table_info(students)")]
        if "approved" not in columns:
            conn.execute("ALTER TABLE students ADD COLUMN approved INTEGER NOT NULL DEFAULT 1")
        has_admin = conn.execute("SELECT 1 FROM users WHERE role = 'admin'").fetchone()
        if not has_admin:
            conn.execute(
                "INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'admin')",
                (config.DEFAULT_ADMIN_USERNAME,
                 generate_password_hash(config.DEFAULT_ADMIN_PASSWORD)),
            )
            created = True
        conn.commit()
    finally:
        conn.close()
    return created


DEFAULT_ADMIN_CREATED = setup_database()


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def query(sql, args=(), one=False):
    rows = get_db().execute(sql, args).fetchall()
    if one:
        return rows[0] if rows else None
    return rows


def scalar(sql, args=()):
    return query(sql, args, one=True)[0]


# --------------------------------------------------------------------------
# Grading logic (backend is authoritative)
# --------------------------------------------------------------------------
def grade_for(total):
    for minimum, grade, point, remark in config.GRADE_SCALE:
        if total >= minimum:
            return grade, point, remark
    return "F", 0.0, "Fail"


def parse_score(raw, maximum, label):
    try:
        value = float(raw)
    except ValueError:
        raise ValueError(f"{label} must be a number.")
    if not 0 <= value <= maximum:  # also rejects NaN
        raise ValueError(f"{label} must be between 0 and {maximum}.")
    return round(value, 2)


def valid_session(value):
    match = SESSION_RE.fullmatch(value or "")
    return bool(match) and int(match.group(2)) == int(match.group(1)) + 1


def session_options():
    now = datetime.now()
    start = now.year if now.month >= 9 else now.year - 1
    return [f"{y}/{y + 1}" for y in range(start + 1, start - 7, -1)], f"{start}/{start + 1}"


def summarise(rows):
    """Credit units, weighted grade points and GPA for rows with credit_unit/grade_point."""
    units = sum(r["credit_unit"] for r in rows)
    points = sum(r["grade_point"] * r["credit_unit"] for r in rows)
    return {"units": units, "points": round(points, 2),
            "gpa": round(points / units, 2) if units else None}


def cumulative_summary(student_id, up_to=None, published_only=True):
    sql = ("SELECT c.credit_unit, r.grade_point FROM results r "
           "JOIN courses c ON c.id = r.course_id WHERE r.student_id = ?")
    args = [student_id]
    if published_only:
        sql += " AND r.published = 1"
    if up_to:  # everything up to and including this session/semester
        sql += (" AND (r.academic_session < ? OR "
                "(r.academic_session = ? AND r.semester <= ?))")
        args += [up_to[0], up_to[0], up_to[1]]
    return summarise(query(sql, tuple(args)))


def result_context(student_id, academic_session, semester, published_only):
    student = query("SELECT * FROM students WHERE id = ?", (student_id,), one=True)
    if not student or not valid_session(academic_session) or semester not in config.SEMESTERS:
        return None
    sql = ("SELECT r.*, c.code, c.title, c.credit_unit FROM results r "
           "JOIN courses c ON c.id = r.course_id "
           "WHERE r.student_id = ? AND r.academic_session = ? AND r.semester = ?")
    if published_only:
        sql += " AND r.published = 1"
    rows = query(sql + " ORDER BY c.code", (student_id, academic_session, semester))
    flags = {r["published"] for r in rows}
    status = None
    if rows:
        status = "Published" if flags == {1} else "Draft" if flags == {0} else "Partly published"
    return {
        "student": student, "academic_session": academic_session, "semester": semester,
        "rows": rows, "term": summarise(rows), "status": status,
        "cumulative": cumulative_summary(student_id, (academic_session, semester), published_only),
    }


def fmt_score(value):
    if value is None or value == "":
        return ""
    try:
        return "%g" % float(value)
    except (TypeError, ValueError):
        return value


app.jinja_env.filters["score"] = fmt_score


# --------------------------------------------------------------------------
# Security, context and errors
# --------------------------------------------------------------------------
@app.before_request
def csrf_protect():
    if request.method == "POST":
        token = session.get("csrf_token")
        if not token or token != request.form.get("csrf_token"):
            abort(400)


@app.after_request
def security_headers(response):
    if request.endpoint != "static":
        response.headers["Cache-Control"] = "no-store"
    response.headers["Content-Security-Policy"] = CONTENT_SECURITY_POLICY
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "same-origin"
    return response


@app.context_processor
def inject_globals():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(16)
    return {
        "csrf_token": session["csrf_token"],
        "institution": config.INSTITUTION_NAME,
        "levels": config.LEVELS,
        "semesters": config.SEMESTERS,
        "max_ca": config.MAX_CA,
        "max_exam": config.MAX_EXAM,
        "min_password": config.MIN_PASSWORD_LENGTH,
        "max_attempts": config.MAX_LOGIN_ATTEMPTS,
        "lockout_minutes": config.LOCKOUT_SECONDS // 60,
        "session_minutes": config.SESSION_MINUTES,
    }


def handle_error(error):
    code = getattr(error, "code", 500)
    messages = {400: "The request could not be processed. Please refresh and try again.",
                403: "You do not have permission to view this page.",
                404: "The page you requested could not be found.",
                413: "The submitted data was too large.",
                500: "Something went wrong on our side."}
    return render_template("error.html", code=code, message=messages.get(code, "Error")), code


for _code in (400, 403, 404, 413, 500):
    app.register_error_handler(_code, handle_error)


def login_required(role=None):
    """Require a signed-in user. With a role, only that role may pass (RBAC)."""
    def decorator(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            if "user_id" not in session:
                flash("Please sign in to continue.", "error")
                return redirect(url_for("login"))
            if role and session.get("role") != role:
                abort(403)
            return view(*args, **kwargs)
        return wrapper
    return decorator


def current_student():
    student = query("SELECT * FROM students WHERE user_id = ?", (session["user_id"],), one=True)
    if not student:
        session.clear()
        abort(403)
    return student


# Failed-login throttling (kept in memory, so it resets when the server restarts).
FAILED_LOGINS = {}


def is_locked(key):
    entry = FAILED_LOGINS.get(key)
    return bool(entry and entry["until"] > time.time())


def record_failure(key):
    entry = FAILED_LOGINS.setdefault(key, {"count": 0, "until": 0})
    entry["count"] += 1
    if entry["count"] >= config.MAX_LOGIN_ATTEMPTS:
        entry["until"] = time.time() + config.LOCKOUT_SECONDS
        entry["count"] = 0


# --------------------------------------------------------------------------
# Public pages and authentication
# --------------------------------------------------------------------------
@app.route("/")
def index():
    if session.get("role") == "admin":
        return redirect(url_for("admin_dashboard"))
    if session.get("role") == "student":
        return redirect(url_for("student_dashboard"))
    return render_template("home.html")


@app.route("/security")
def security():
    return render_template("security.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("role"):
        return redirect(url_for("index"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        key = (request.remote_addr, username.lower())
        if is_locked(key):
            flash(f"Too many failed attempts. Try again in {config.LOCKOUT_SECONDS // 60} minutes.",
                  "error")
            return render_template("login.html")
        user = query("SELECT * FROM users WHERE username = ?", (username,), one=True)
        if user and check_password_hash(user["password_hash"], password):
            if user["role"] == "student":
                student = query("SELECT approved FROM students WHERE user_id = ?",
                                (user["id"],), one=True)
                if not student:
                    record_failure(key)
                    flash("Invalid login details. Please check and try again.", "error")
                    return render_template("login.html")
                if not student["approved"]:
                    flash("Your registration is awaiting administrator approval.", "error")
                    return render_template("login.html")
            FAILED_LOGINS.pop(key, None)
            session.clear()  # new session on login
            session.permanent = True
            session["user_id"] = user["id"]
            session["role"] = user["role"]
            return redirect(url_for("index"))
        record_failure(key)
        flash("Invalid login details. Please check and try again.", "error")
    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("role"):
        return redirect(url_for("index"))
    values = {}
    if request.method == "POST":
        values, password, errors = read_student_form(confirm=True)
        if not errors:
            if create_student(values, password, approved=0):
                flash("Registration received. You can sign in once an administrator approves "
                      "your account.", "success")
                return redirect(url_for("login"))
            errors.append("That matriculation number is already in use.")
        for message in errors:
            flash(message, "error")
    return render_template("register.html", values=values, departments=department_options())


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been signed out.", "success")
    return redirect(url_for("login"))


# --------------------------------------------------------------------------
# Profile (both roles)
# --------------------------------------------------------------------------
@app.route("/profile")
@login_required()
def profile():
    user = query("SELECT username, role FROM users WHERE id = ?", (session["user_id"],), one=True)
    if not user:
        session.clear()
        return redirect(url_for("login"))
    student = current_student() if user["role"] == "student" else None
    return render_template("profile.html", user=user, student=student)


@app.route("/profile/email", methods=["POST"])
@login_required("student")
def profile_email():
    email = request.form.get("email", "").strip()
    if not EMAIL_RE.fullmatch(email):
        flash("Enter a valid email address.", "error")
    else:
        get_db().execute("UPDATE students SET email = ? WHERE user_id = ?",
                         (email, session["user_id"]))
        get_db().commit()
        flash("Email address updated.", "success")
    return redirect(url_for("profile"))


@app.route("/profile/password", methods=["POST"])
@login_required()
def profile_password():
    user = query("SELECT * FROM users WHERE id = ?", (session["user_id"],), one=True)
    current = request.form.get("current_password", "")
    new = request.form.get("new_password", "")
    if not user or not check_password_hash(user["password_hash"], current):
        flash("Your current password is incorrect.", "error")
    elif len(new) < config.MIN_PASSWORD_LENGTH:
        flash(f"New password must be at least {config.MIN_PASSWORD_LENGTH} characters.", "error")
    elif new != request.form.get("confirm_password", ""):
        flash("The two new passwords do not match.", "error")
    else:
        get_db().execute("UPDATE users SET password_hash = ? WHERE id = ?",
                         (generate_password_hash(new), user["id"]))
        get_db().commit()
        flash("Password changed.", "success")
    return redirect(url_for("profile"))


# --------------------------------------------------------------------------
# Admin: dashboard
# --------------------------------------------------------------------------
@app.route("/admin")
@login_required("admin")
def admin_dashboard():
    stats = {
        "students": scalar("SELECT COUNT(*) FROM students"),
        "courses": scalar("SELECT COUNT(*) FROM courses"),
        "published": scalar("SELECT COUNT(*) FROM results WHERE published = 1"),
        "pending": scalar("SELECT COUNT(*) FROM students WHERE approved = 0"),
    }
    recent = query(
        "SELECT r.*, s.full_name, s.matric_no, c.code FROM results r "
        "JOIN students s ON s.id = r.student_id JOIN courses c ON c.id = r.course_id "
        "ORDER BY r.updated_at DESC, r.id DESC LIMIT 8")
    return render_template("admin_dashboard.html", stats=stats, recent=recent)


# --------------------------------------------------------------------------
# Admin: students
# --------------------------------------------------------------------------
def department_options():
    return [r[0] for r in query(
        "SELECT department FROM students UNION SELECT department FROM courses ORDER BY 1")]


def read_student_form(user_id=None, password_required=True, confirm=False):
    f = request.form
    values = {
        "full_name": f.get("full_name", "").strip(),
        "matric_no": f.get("matric_no", "").strip().upper(),
        "email": f.get("email", "").strip(),
        "department": f.get("department", "").strip(),
        "level": f.get("level", "").strip(),
    }
    password = f.get("password", "")
    errors = []
    if not values["full_name"]:
        errors.append("Full name is required.")
    elif len(values["full_name"]) > 100:
        errors.append("Full name must be 100 characters or fewer.")
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9/\-_.]{2,29}", values["matric_no"]):
        errors.append("Matriculation number must be 3-30 characters (letters, digits, / - _ .).")
    elif query("SELECT 1 FROM users WHERE username = ? AND id IS NOT ?",
               (values["matric_no"], user_id), one=True):
        errors.append("That matriculation number is already in use.")
    if not EMAIL_RE.fullmatch(values["email"]):
        errors.append("Enter a valid email address.")
    if not values["department"]:
        errors.append("Department is required.")
    elif len(values["department"]) > 100:
        errors.append("Department must be 100 characters or fewer.")
    if values["level"] not in config.LEVELS:
        errors.append("Select a valid level.")
    if (password_required or password) and len(password) < config.MIN_PASSWORD_LENGTH:
        errors.append(f"Password must be at least {config.MIN_PASSWORD_LENGTH} characters.")
    elif confirm and password != f.get("confirm_password", ""):
        errors.append("The two passwords do not match.")
    return values, password, errors


def create_student(values, password, approved):
    """Insert a user and student row together. Returns False on a duplicate matric number."""
    db = get_db()
    try:
        cur = db.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'student')",
            (values["matric_no"], generate_password_hash(password)))
        db.execute(
            "INSERT INTO students (user_id, full_name, matric_no, email, department, level, approved) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (cur.lastrowid, values["full_name"], values["matric_no"], values["email"],
             values["department"], values["level"], approved))
        db.commit()
        return True
    except sqlite3.IntegrityError:
        db.rollback()
        return False


@app.route("/admin/students")
@login_required("admin")
def admin_students():
    q = request.args.get("q", "").strip()
    pending = request.args.get("status") == "pending"
    conditions, args = [], []
    if q:
        conditions.append("(full_name LIKE ? OR matric_no LIKE ?)")
        args += [f"%{q}%", f"%{q}%"]
    if pending:
        conditions.append("approved = 0")
    sql = "SELECT * FROM students"
    if conditions:
        sql += " WHERE " + " AND ".join(conditions)  # fixed fragments only; values are bound
    students = query(sql + " ORDER BY full_name", tuple(args))
    return render_template("students.html", students=students, q=q, pending=pending)


@app.route("/admin/students/new", methods=["GET", "POST"])
@login_required("admin")
def admin_student_new():
    values = {}
    if request.method == "POST":
        values, password, errors = read_student_form()
        if not errors:
            if create_student(values, password, approved=1):
                flash(f"Student {values['full_name']} registered.", "success")
                return redirect(url_for("admin_students"))
            errors.append("That matriculation number is already in use.")
        for message in errors:
            flash(message, "error")
    return render_template("student_form.html", values=values, editing=False,
                           departments=department_options())


@app.route("/admin/students/<int:student_id>/edit", methods=["GET", "POST"])
@login_required("admin")
def admin_student_edit(student_id):
    student = query("SELECT * FROM students WHERE id = ?", (student_id,), one=True) or abort(404)
    values = dict(student)
    if request.method == "POST":
        values, password, errors = read_student_form(student["user_id"], password_required=False)
        if not errors:
            db = get_db()
            try:
                db.execute("UPDATE users SET username = ? WHERE id = ?",
                           (values["matric_no"], student["user_id"]))
                if password:
                    db.execute("UPDATE users SET password_hash = ? WHERE id = ?",
                               (generate_password_hash(password), student["user_id"]))
                db.execute(
                    "UPDATE students SET full_name = ?, matric_no = ?, email = ?, "
                    "department = ?, level = ? WHERE id = ?",
                    (values["full_name"], values["matric_no"], values["email"],
                     values["department"], values["level"], student_id))
                db.commit()
            except sqlite3.IntegrityError:
                db.rollback()
                errors.append("That matriculation number is already in use.")
            else:
                flash("Student details updated.", "success")
                return redirect(url_for("admin_students"))
        for message in errors:
            flash(message, "error")
    return render_template("student_form.html", values=values, editing=True,
                           student=student, departments=department_options())


@app.route("/admin/students/<int:student_id>/approve", methods=["POST"])
@login_required("admin")
def admin_student_approve(student_id):
    student = query("SELECT * FROM students WHERE id = ?", (student_id,), one=True) or abort(404)
    get_db().execute("UPDATE students SET approved = 1 WHERE id = ?", (student_id,))
    get_db().commit()
    flash(f"{student['full_name']} can now sign in.", "success")
    return redirect(url_for("admin_students"))


@app.route("/admin/students/<int:student_id>")
@login_required("admin")
def admin_student_profile(student_id):
    student = query("SELECT * FROM students WHERE id = ?", (student_id,), one=True) or abort(404)
    records = query(
        "SELECT academic_session, semester, COUNT(*) AS courses, SUM(published) AS published_count "
        "FROM results WHERE student_id = ? GROUP BY academic_session, semester "
        "ORDER BY academic_session DESC, semester DESC", (student_id,))
    return render_template("student_profile.html", student=student, records=records)


@app.route("/admin/students/<int:student_id>/delete", methods=["POST"])
@login_required("admin")
def admin_student_delete(student_id):
    student = query("SELECT * FROM students WHERE id = ?", (student_id,), one=True) or abort(404)
    db = get_db()
    db.execute("DELETE FROM users WHERE id = ?", (student["user_id"],))  # cascades
    db.commit()
    flash(f"Student {student['full_name']} and their results were deleted.", "success")
    return redirect(url_for("admin_students"))


# --------------------------------------------------------------------------
# Admin: courses
# --------------------------------------------------------------------------
def read_course_form(course_id=None):
    f = request.form
    values = {
        "code": f.get("code", "").strip().upper(),
        "title": f.get("title", "").strip(),
        "credit_unit": f.get("credit_unit", "").strip(),
        "department": f.get("department", "").strip(),
        "level": f.get("level", "").strip(),
        "semester": f.get("semester", "").strip(),
    }
    errors = []
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9 \-]{1,19}", values["code"]):
        errors.append("Course code must be 2-20 characters (letters, digits, space, hyphen).")
    elif query("SELECT 1 FROM courses WHERE code = ? AND id IS NOT ?",
               (values["code"], course_id), one=True):
        errors.append("That course code already exists.")
    if not values["title"]:
        errors.append("Course title is required.")
    elif len(values["title"]) > 150:
        errors.append("Course title must be 150 characters or fewer.")
    try:
        unit = int(values["credit_unit"])
        if not 1 <= unit <= config.MAX_CREDIT_UNIT:
            raise ValueError
    except ValueError:
        unit = None
        errors.append(f"Credit unit must be a whole number from 1 to {config.MAX_CREDIT_UNIT}.")
    if not values["department"]:
        errors.append("Department is required.")
    elif len(values["department"]) > 100:
        errors.append("Department must be 100 characters or fewer.")
    if values["level"] not in config.LEVELS:
        errors.append("Select a valid level.")
    if values["semester"] not in config.SEMESTERS:
        errors.append("Select a valid semester.")
    values["unit_int"] = unit
    return values, errors


@app.route("/admin/courses")
@login_required("admin")
def admin_courses():
    courses = query("SELECT * FROM courses ORDER BY level, semester, code")
    return render_template("courses.html", courses=courses)


@app.route("/admin/courses/new", methods=["GET", "POST"])
@login_required("admin")
def admin_course_new():
    values = {}
    if request.method == "POST":
        values, errors = read_course_form()
        if not errors:
            try:
                get_db().execute(
                    "INSERT INTO courses (code, title, credit_unit, department, level, semester) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (values["code"], values["title"], values["unit_int"], values["department"],
                     values["level"], values["semester"]))
                get_db().commit()
            except sqlite3.IntegrityError:
                get_db().rollback()
                errors.append("That course code already exists.")
            else:
                flash(f"Course {values['code']} added.", "success")
                return redirect(url_for("admin_courses"))
        for message in errors:
            flash(message, "error")
    return render_template("course_form.html", values=values, editing=False,
                           departments=department_options())


@app.route("/admin/courses/<int:course_id>/edit", methods=["GET", "POST"])
@login_required("admin")
def admin_course_edit(course_id):
    course = query("SELECT * FROM courses WHERE id = ?", (course_id,), one=True) or abort(404)
    values = dict(course)
    if request.method == "POST":
        values, errors = read_course_form(course_id)
        if not errors:
            try:
                get_db().execute(
                    "UPDATE courses SET code = ?, title = ?, credit_unit = ?, department = ?, "
                    "level = ?, semester = ? WHERE id = ?",
                    (values["code"], values["title"], values["unit_int"], values["department"],
                     values["level"], values["semester"], course_id))
                get_db().commit()
            except sqlite3.IntegrityError:
                get_db().rollback()
                errors.append("That course code already exists.")
            else:
                flash("Course updated. Existing results keep their recorded scores.", "success")
                return redirect(url_for("admin_courses"))
        for message in errors:
            flash(message, "error")
    return render_template("course_form.html", values=values, editing=True,
                           course=course, departments=department_options())


@app.route("/admin/courses/<int:course_id>/delete", methods=["POST"])
@login_required("admin")
def admin_course_delete(course_id):
    course = query("SELECT * FROM courses WHERE id = ?", (course_id,), one=True) or abort(404)
    try:
        get_db().execute("DELETE FROM courses WHERE id = ?", (course_id,))
        get_db().commit()
        flash(f"Course {course['code']} deleted.", "success")
    except sqlite3.IntegrityError:
        get_db().rollback()
        flash(f"{course['code']} has recorded results and cannot be deleted.", "error")
    return redirect(url_for("admin_courses"))


# --------------------------------------------------------------------------
# Admin: results
# --------------------------------------------------------------------------
def entry_context(student_id, academic_session, semester, show_all, submitted=None):
    sessions, default_session = session_options()
    selected_session = academic_session or default_session
    ctx = {
        "students": query("SELECT id, full_name, matric_no FROM students ORDER BY full_name"),
        "sessions": sorted(set(sessions + ([academic_session] if valid_session(academic_session) else [])),
                           reverse=True),
        "selected": {"student_id": student_id, "academic_session": selected_session,
                     "semester": semester},
        "student": None, "show_all": show_all,
    }
    if not (student_id and academic_session and semester):
        return ctx
    student = query("SELECT * FROM students WHERE id = ?", (student_id,), one=True)
    if not student or not valid_session(academic_session) or semester not in config.SEMESTERS:
        flash("Select a valid student, session and semester.", "error")
        return ctx

    args = (student_id, academic_session, semester)
    existing = {r["course_id"]: r for r in query(
        "SELECT * FROM results WHERE student_id = ? AND academic_session = ? AND semester = ?", args)}
    if show_all:
        courses = query("SELECT * FROM courses WHERE semester = ? ORDER BY code", (semester,))
    else:
        courses = query(
            "SELECT * FROM courses WHERE semester = ? AND ((LOWER(department) = LOWER(?) AND level = ?) "
            "OR id IN (SELECT course_id FROM results WHERE student_id = ? AND academic_session = ? "
            "AND semester = ?)) ORDER BY code",
            (semester, student["department"], student["level"], *args))
    values = {}
    for course in courses:
        cid = course["id"]
        if submitted is not None:
            values[cid] = {"ca": submitted.get(f"ca_{cid}", ""), "exam": submitted.get(f"exam_{cid}", "")}
        elif cid in existing:
            values[cid] = {"ca": existing[cid]["ca_score"], "exam": existing[cid]["exam_score"]}
        else:
            values[cid] = {"ca": "", "exam": ""}
    flags = {r["published"] for r in existing.values()}
    status = None
    if existing:
        status = "Published" if flags == {1} else "Draft" if flags == {0} else "Partly published"
    ctx.update(student=student, courses=courses, existing=existing, values=values, status=status)
    return ctx


@app.route("/admin/results")
@login_required("admin")
def admin_results():
    ctx = entry_context(request.args.get("student_id", type=int),
                        request.args.get("academic_session", "").strip(),
                        request.args.get("semester", "").strip(),
                        request.args.get("all") == "1")
    return render_template("results.html", **ctx)


UPSERT_RESULT = """
INSERT INTO results (student_id, course_id, academic_session, semester, ca_score, exam_score,
                     total_score, grade, grade_point, remark, published, updated_at)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON CONFLICT (student_id, course_id, academic_session, semester) DO UPDATE SET
    ca_score = excluded.ca_score, exam_score = excluded.exam_score,
    total_score = excluded.total_score, grade = excluded.grade,
    grade_point = excluded.grade_point, remark = excluded.remark,
    updated_at = excluded.updated_at
"""


@app.route("/admin/results/save", methods=["POST"])
@login_required("admin")
def admin_results_save():
    student_id = request.form.get("student_id", type=int)
    academic_session = request.form.get("academic_session", "").strip()
    semester = request.form.get("semester", "").strip()
    show_all = request.form.get("all") == "1"
    student = query("SELECT id FROM students WHERE id = ?", (student_id,), one=True)
    if not student or not valid_session(academic_session) or semester not in config.SEMESTERS:
        abort(400)

    existing = query("SELECT course_id, published FROM results WHERE student_id = ? "
                     "AND academic_session = ? AND semester = ?",
                     (student_id, academic_session, semester))
    existing_ids = {r["course_id"] for r in existing}
    set_published = 1 if existing and all(r["published"] for r in existing) else 0

    to_save, to_delete, errors = [], [], []
    for course_id in request.form.getlist("course_ids", type=int):
        course = query("SELECT * FROM courses WHERE id = ?", (course_id,), one=True)
        if not course or course["semester"] != semester:
            continue
        ca_raw = request.form.get(f"ca_{course_id}", "").strip()
        exam_raw = request.form.get(f"exam_{course_id}", "").strip()
        if not ca_raw and not exam_raw:
            if course_id in existing_ids:
                to_delete.append(course_id)
            continue
        try:
            ca = parse_score(ca_raw, config.MAX_CA, f"{course['code']} CA score")
            exam = parse_score(exam_raw, config.MAX_EXAM, f"{course['code']} exam score")
        except ValueError as error:
            errors.append(str(error))
            continue
        to_save.append((course_id, ca, exam))

    if errors:
        for message in errors:
            flash(message, "error")
        ctx = entry_context(student_id, academic_session, semester, show_all, submitted=request.form)
        return render_template("results.html", **ctx)
    if not to_save and not to_delete:
        flash("Enter at least one set of scores before saving.", "error")
    else:
        db = get_db()
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        for course_id, ca, exam in to_save:
            total = round(ca + exam, 2)
            grade, point, remark = grade_for(total)
            db.execute(UPSERT_RESULT, (student_id, course_id, academic_session, semester, ca, exam,
                                       total, grade, point, remark, set_published, now))
        for course_id in to_delete:
            db.execute("DELETE FROM results WHERE student_id = ? AND course_id = ? "
                       "AND academic_session = ? AND semester = ?",
                       (student_id, course_id, academic_session, semester))
        db.commit()
        flash(f"Results saved ({len(to_save)} saved, {len(to_delete)} removed).", "success")
    return redirect(url_for("admin_results", student_id=student_id,
                            academic_session=academic_session, semester=semester,
                            all="1" if show_all else None))


@app.route("/admin/results/publish", methods=["POST"])
@login_required("admin")
def admin_results_publish():
    student_id = request.form.get("student_id", type=int)
    academic_session = request.form.get("academic_session", "").strip()
    semester = request.form.get("semester", "").strip()
    action = request.form.get("action")
    if action not in ("publish", "unpublish") or not valid_session(academic_session) \
            or semester not in config.SEMESTERS:
        abort(400)
    cur = get_db().execute(
        "UPDATE results SET published = ? WHERE student_id = ? AND academic_session = ? AND semester = ?",
        (1 if action == "publish" else 0, student_id, academic_session, semester))
    get_db().commit()
    if cur.rowcount:
        flash("Results published. The student can now see them." if action == "publish"
              else "Results unpublished. They are hidden from the student.", "success")
    else:
        flash("There are no saved results to change.", "error")
    return redirect(url_for("admin_results", student_id=student_id,
                            academic_session=academic_session, semester=semester))


@app.route("/admin/results/view")
@login_required("admin")
def admin_result_view():
    ctx = result_context(request.args.get("student_id", type=int),
                         request.args.get("academic_session", "").strip(),
                         request.args.get("semester", "").strip(), published_only=False)
    if ctx is None:
        abort(404)
    return render_template("view_result.html", is_admin=True, **ctx)


# --------------------------------------------------------------------------
# Student
# --------------------------------------------------------------------------
def published_records(student_id):
    return query(
        "SELECT r.academic_session, r.semester, COUNT(*) AS courses, SUM(c.credit_unit) AS units, "
        "SUM(r.grade_point * c.credit_unit) AS points FROM results r "
        "JOIN courses c ON c.id = r.course_id WHERE r.student_id = ? AND r.published = 1 "
        "GROUP BY r.academic_session, r.semester "
        "ORDER BY r.academic_session DESC, r.semester DESC", (student_id,))


@app.route("/student")
@login_required("student")
def student_dashboard():
    student = current_student()
    return render_template("student_dashboard.html", student=student,
                           records=published_records(student["id"]),
                           cumulative=cumulative_summary(student["id"]))


@app.route("/student/results")
@login_required("student")
def student_results():
    student = current_student()  # always the logged-in student; no ID is accepted from the URL
    records = published_records(student["id"])
    academic_session = request.args.get("academic_session", "").strip()
    semester = request.args.get("semester", "").strip()
    if records and not academic_session and not semester:
        academic_session, semester = records[0]["academic_session"], records[0]["semester"]
    context = {"is_admin": False, "rows": [], "records": records,
               "sessions": sorted({r["academic_session"] for r in records}, reverse=True),
               "selected_session": academic_session, "selected_semester": semester}
    if records and academic_session and semester:
        result = result_context(student["id"], academic_session, semester, published_only=True)
        if result:
            context.update(result)
    context["student"] = student
    return render_template("view_result.html", **context)


if __name__ == "__main__":
    app.run(debug=config.DEBUG)