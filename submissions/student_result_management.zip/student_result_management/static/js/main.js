// Shared interface behaviour: confirmations, printing, auto-submitting selectors.
document.addEventListener("submit", function (event) {
  const message = event.target.dataset ? event.target.dataset.confirm : null;
  if (message && !window.confirm(message)) {
    event.preventDefault();
  }
});

document.addEventListener("click", function (event) {
  if (event.target.closest("[data-print]")) {
    window.print();
  }
});

document.querySelectorAll("form[data-autosubmit] select").forEach(function (select) {
  select.addEventListener("change", function () {
    select.form.submit();
  });
});