// Live preview of totals, grades and GPA on the result entry page.
// The Flask backend recalculates and validates everything on save.
(function () {
  const form = document.querySelector("[data-results-form]");
  if (!form) return;

  const MAX_CA = Number(form.dataset.maxCa);
  const MAX_EXAM = Number(form.dataset.maxExam);
  const SCALE = [
    [70, "A", 5, "Excellent"], [60, "B", 4, "Very Good"], [50, "C", 3, "Good"],
    [45, "D", 2, "Fair"], [40, "E", 1, "Pass"], [0, "F", 0, "Fail"],
  ];
  const rows = form.querySelectorAll("[data-result-row]");
  const warning = document.getElementById("score-warning");
  const round2 = (n) => String(Math.round(n * 100) / 100);

  function gradeFor(total) {
    return SCALE.find(function (entry) { return total >= entry[0]; });
  }

  function validScore(raw, max) {
    if (raw === "") return false;
    const value = Number(raw);
    return Number.isFinite(value) && value >= 0 && value <= max;
  }

  // Returns true when every filled row is valid.
  function refresh() {
    let units = 0, points = 0, allValid = true;

    rows.forEach(function (row) {
      const ca = row.querySelector(".js-ca");
      const exam = row.querySelector(".js-exam");
      const cells = {
        total: row.querySelector(".js-total"), grade: row.querySelector(".js-grade"),
        gp: row.querySelector(".js-gp"), remark: row.querySelector(".js-remark"),
      };
      const show = function (total, grade, gp, remark) {
        cells.total.textContent = total; cells.grade.textContent = grade;
        cells.gp.textContent = gp; cells.remark.textContent = remark;
      };
      const caValue = ca.value.trim(), examValue = exam.value.trim();
      ca.classList.remove("invalid");
      exam.classList.remove("invalid");

      if (caValue === "" && examValue === "") { show("—", "—", "—", "—"); return; }

      const caOk = validScore(caValue, MAX_CA);
      const examOk = validScore(examValue, MAX_EXAM);
      if (!caOk) ca.classList.add("invalid");
      if (!examOk) exam.classList.add("invalid");
      if (!caOk || !examOk) { allValid = false; show("—", "—", "—", "—"); return; }

      const total = Number(caValue) + Number(examValue);
      const result = gradeFor(total);
      const unit = Number(row.dataset.unit);
      show(round2(total), result[1], result[2].toFixed(1), result[3]);
      units += unit;
      points += result[2] * unit;
    });

    document.getElementById("js-units").textContent = units || "—";
    document.getElementById("js-points").textContent = units ? round2(points) : "—";
    document.getElementById("js-gpa").textContent = units ? (points / units).toFixed(2) : "—";
    return allValid;
  }

  form.addEventListener("input", function () {
    warning.hidden = true;
    refresh();
  });

  form.addEventListener("submit", function (event) {
    if (!refresh()) {
      event.preventDefault();
      warning.textContent = "Please correct the highlighted scores. CA must be 0-" + MAX_CA +
        " and exam must be 0-" + MAX_EXAM + ". Fill both fields or leave both blank.";
      warning.hidden = false;
      const firstBad = form.querySelector("input.invalid");
      if (firstBad) firstBad.focus();
    }
  });

  refresh();
})();