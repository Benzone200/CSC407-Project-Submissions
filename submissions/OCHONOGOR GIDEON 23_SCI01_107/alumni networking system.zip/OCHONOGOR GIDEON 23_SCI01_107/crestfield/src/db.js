const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const file = path.join(__dirname, '..', 'data', 'alumni.db');
fs.mkdirSync(path.dirname(file), { recursive: true });

const db = new Database(file);
db.pragma('foreign_keys = ON');
db.exec(fs.readFileSync(path.join(__dirname, '..', 'schema.sql'), 'utf8'));

module.exports = db;
