const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { z } = require('zod');
const db = require('../db');

const signup = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  full_name: z.string().min(2).max(100),
  grad_year: z.number().int().min(1950).max(new Date().getFullYear()),
});

router.post('/register', async (req, res) => {
  const parsed = signup.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });

  const { email, password, full_name, grad_year } = parsed.data;
  const hash = await bcrypt.hash(password, 10);
  try {
    const { lastInsertRowid } = db
      .prepare('INSERT INTO users (email, password_hash, full_name, grad_year) VALUES (?, ?, ?, ?)')
      .run(email.toLowerCase(), hash, full_name, grad_year);
    db.prepare('INSERT INTO profiles (user_id) VALUES (?)').run(lastInsertRowid);
    res.status(201).json({ message: 'Registered. An admin will review your account.' });
  } catch (e) {
    if (e.code === 'SQLITE_CONSTRAINT_UNIQUE') return res.status(409).json({ error: 'Email already registered' });
    throw e;
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email).toLowerCase());
  if (!user || !(await bcrypt.compare(String(password), user.password_hash)))
    return res.status(401).json({ error: 'Wrong email or password' });
  if (user.status !== 'approved')
    return res.status(403).json({ error: 'Your account is not approved yet' });

  const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, full_name: user.full_name, role: user.role } });
});

module.exports = router;
