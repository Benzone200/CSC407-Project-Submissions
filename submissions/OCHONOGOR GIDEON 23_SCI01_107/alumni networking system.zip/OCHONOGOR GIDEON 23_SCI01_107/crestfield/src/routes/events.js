const router = require('express').Router();
const { z } = require('zod');
const db = require('../db');
const { auth, admin } = require('../middleware/auth');

router.use(auth);

const eventSchema = z.object({
  title: z.string().min(3).max(150),
  description: z.string().max(2000).optional(),
  location: z.string().max(150).optional(),
  starts_at: z.string().datetime(),
});

router.get('/', (req, res) => {
  const offset = (Math.max(Number(req.query.page) || 1, 1) - 1) * 20;
  const rows = db.prepare(
    `SELECT e.*,
       (SELECT count(*) FROM event_rsvps WHERE event_id = e.id) AS rsvp_count,
       EXISTS (SELECT 1 FROM event_rsvps WHERE event_id = e.id AND user_id = @me) AS going
     FROM events e WHERE e.starts_at > @now
     ORDER BY e.starts_at LIMIT 20 OFFSET @offset`
  ).all({ me: req.user.id, now: new Date().toISOString(), offset });
  res.json(rows.map((r) => ({ ...r, going: !!r.going })));
});

router.post('/', admin, (req, res) => {
  const parsed = eventSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });

  const { title, description, location, starts_at } = parsed.data;
  const { lastInsertRowid } = db
    .prepare('INSERT INTO events (title, description, location, starts_at, created_by) VALUES (?, ?, ?, ?, ?)')
    .run(title, description ?? null, location ?? null, starts_at, req.user.id);
  res.status(201).json(db.prepare('SELECT * FROM events WHERE id = ?').get(lastInsertRowid));
});

router.post('/:id/rsvp', (req, res) => {
  if (!db.prepare('SELECT 1 FROM events WHERE id = ?').get(req.params.id)) return res.status(404).json({ error: 'Not found' });
  db.prepare('INSERT OR IGNORE INTO event_rsvps (event_id, user_id) VALUES (?, ?)').run(req.params.id, req.user.id);
  res.status(201).json({ message: 'See you there' });
});

router.delete('/:id/rsvp', (req, res) => {
  db.prepare('DELETE FROM event_rsvps WHERE event_id = ? AND user_id = ?').run(req.params.id, req.user.id);
  res.status(204).end();
});

module.exports = router;
