const router = require('express').Router();
const { z } = require('zod');
const db = require('../db');
const { auth } = require('../middleware/auth');

router.use(auth);

const text = z.string().max(150).nullish();
const profile = z.object({
  photo_url: z.string().url().startsWith('http').nullish(),
  degree: text,
  employer: text,
  job_title: text,
  industry: text,
  location: text,
  skills: z.array(z.string().max(40)).max(20).default([]),
  bio: z.string().max(1000).nullish(),
  linkedin: z.string().url().startsWith('http').nullish(),
});
const fields = Object.keys(profile.shape);
const withSkills = (row) => row && { ...row, skills: JSON.parse(row.skills || '[]') };

router.get('/', (req, res) => {
  const { q = '', year, industry, location, skill, page = 1 } = req.query;
  const limit = 20;
  const offset = (Math.max(Number(page) || 1, 1) - 1) * limit;

  const rows = db.prepare(
    `SELECT count(*) OVER () AS total, u.id, u.full_name, u.grad_year,
            p.job_title, p.employer, p.industry, p.location, p.skills, p.photo_url
     FROM users u JOIN profiles p ON p.user_id = u.id
     WHERE u.status = 'approved'
       AND (@q = '' OR (u.full_name || ' ' || coalesce(p.job_title, '') || ' ' || coalesce(p.employer, '')
            || ' ' || coalesce(p.location, '') || ' ' || p.skills) LIKE '%' || @q || '%')
       AND (@year IS NULL OR u.grad_year = @year)
       AND (@industry IS NULL OR p.industry = @industry COLLATE NOCASE)
       AND (@location IS NULL OR p.location LIKE '%' || @location || '%')
       AND (@skill IS NULL OR p.skills LIKE '%' || @skill || '%')
     ORDER BY u.full_name LIMIT @limit OFFSET @offset`
  ).all({
    q: String(q), year: year ? Number(year) : null, industry: industry || null,
    location: location || null, skill: skill || null, limit, offset,
  });
  res.json(rows.map(withSkills));
});

router.get('/filters', (req, res) => {
  const industries = db.prepare("SELECT DISTINCT industry FROM profiles WHERE industry IS NOT NULL AND industry <> '' ORDER BY 1").pluck().all();
  const years = db.prepare("SELECT DISTINCT grad_year FROM users WHERE status = 'approved' ORDER BY 1 DESC").pluck().all();
  res.json({ industries, years });
});

router.get('/me', (req, res) => {
  const row = db.prepare('SELECT u.full_name, u.grad_year, p.* FROM users u JOIN profiles p ON p.user_id = u.id WHERE u.id = ?').get(req.user.id);
  res.json(withSkills(row));
});

router.put('/me', (req, res) => {
  const parsed = profile.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0].message });

  const data = { ...parsed.data, skills: JSON.stringify(parsed.data.skills) };
  const sets = fields.map((f) => `${f} = @${f}`).join(', ');
  db.prepare(`UPDATE profiles SET ${sets} WHERE user_id = @id`).run({
    id: req.user.id,
    ...Object.fromEntries(fields.map((f) => [f, data[f] ?? null])),
  });
  res.json({ message: 'Profile saved' });
});

router.get('/:id', (req, res) => {
  const row = db.prepare(
    `SELECT u.id, u.full_name, u.grad_year, p.*
     FROM users u JOIN profiles p ON p.user_id = u.id
     WHERE u.id = ? AND u.status = 'approved'`
  ).get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found' });
  res.json(withSkills(row));
});

module.exports = router;
