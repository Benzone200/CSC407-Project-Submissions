const router = require('express').Router();
const db = require('../db');
const { auth } = require('../middleware/auth');

router.use(auth);

router.get('/', (req, res) => {
  const rows = db.prepare(
    `SELECT c.status, c.receiver_id = @me AS incoming, u.id, u.full_name, u.grad_year
     FROM connections c
     JOIN users u ON u.id = CASE WHEN c.requester_id = @me THEN c.receiver_id ELSE c.requester_id END
     WHERE @me IN (c.requester_id, c.receiver_id)`
  ).all({ me: req.user.id });
  res.json(rows.map((r) => ({ ...r, incoming: !!r.incoming })));
});

router.post('/:id', (req, res) => {
  const me = req.user.id;
  const other = Number(req.params.id);
  if (other === me) return res.status(400).json({ error: 'You cannot connect with yourself' });

  const target = db.prepare("SELECT id FROM users WHERE id = ? AND status = 'approved'").get(other);
  if (!target) return res.status(404).json({ error: 'Not found' });

  const exists = db.prepare(
    'SELECT 1 FROM connections WHERE (requester_id = @a AND receiver_id = @b) OR (requester_id = @b AND receiver_id = @a)'
  ).get({ a: me, b: other });
  if (!exists) db.prepare('INSERT INTO connections (requester_id, receiver_id) VALUES (?, ?)').run(me, other);
  res.status(201).json({ message: 'Request sent' });
});

router.post('/:id/accept', (req, res) => {
  const { changes } = db.prepare(
    "UPDATE connections SET status = 'accepted' WHERE requester_id = ? AND receiver_id = ?"
  ).run(req.params.id, req.user.id);
  if (!changes) return res.status(404).json({ error: 'No such request' });
  res.json({ message: 'Connected' });
});

router.delete('/:id', (req, res) => {
  db.prepare(
    'DELETE FROM connections WHERE (requester_id = @a AND receiver_id = @b) OR (requester_id = @b AND receiver_id = @a)'
  ).run({ a: req.user.id, b: Number(req.params.id) });
  res.status(204).end();
});

module.exports = router;
