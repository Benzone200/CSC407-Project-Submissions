const router = require('express').Router();
const db = require('../db');
const { auth, admin } = require('../middleware/auth');

router.use(auth, admin);

router.get('/pending', (req, res) => {
  res.json(db.prepare("SELECT id, full_name, email, grad_year, created_at FROM users WHERE status = 'pending' ORDER BY created_at").all());
});

const setStatus = (status) => (req, res) => {
  db.prepare('UPDATE users SET status = ? WHERE id = ?').run(status, req.params.id);
  res.json({ message: status });
};

router.post('/users/:id/approve', setStatus('approved'));
router.post('/users/:id/reject', setStatus('rejected'));

module.exports = router;
