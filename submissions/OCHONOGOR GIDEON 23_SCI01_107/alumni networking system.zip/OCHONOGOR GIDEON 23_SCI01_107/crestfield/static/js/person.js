requireLogin();
const id = Number(new URLSearchParams(location.search).get('id'));

async function load() {
  try {
    const [p, conns] = await Promise.all([api('/alumni/' + id), api('/connections')]);
    const c = conns.find((x) => x.id === p.id);
    const me = user();
    let action = '';
    if (me.role !== 'admin' && me.id !== p.id) {
      if (!c) action = '<button class="btn" data-act="connect">Connect</button>';
      else if (c.status === 'accepted') action = '<span class="ok">Connected</span>';
      else if (c.incoming) action = '<button class="btn" data-act="accept">Accept request</button>';
      else action = '<span class="muted">Request sent</span>';
    }
    $('#box').innerHTML = `<div class="card pf"><div class="ban"></div>${avatar(p.full_name, 88)}
      <h1>${esc(p.full_name)}</h1><p class="muted">Class of ${p.grad_year}</p>
      <div class="job">${esc([p.job_title, p.employer].filter(Boolean).join(' at ') || 'No job listed')}</div>
      <div class="meta">${ICON.pin}${esc([p.industry, p.location].filter(Boolean).join(', '))}</div>
      ${p.degree ? `<p class="muted">${esc(p.degree)}</p>` : ''}${p.bio ? `<p>${esc(p.bio)}</p>` : ''}
      ${(p.skills || []).map((s) => `<span class="tag">${esc(s)}</span>`).join('')}
      ${/^https?:/.test(p.linkedin || '') ? `<p><a href="${esc(p.linkedin)}" target="_blank" rel="noreferrer">LinkedIn</a></p>` : ''}
      <div style="margin-top:20px">${action}</div></div>`;
  } catch (err) {
    $('#box').innerHTML = `<p class="err">${esc(err.message)}</p>`;
  }
}

$('#box').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  await api(`/connections/${id}` + (btn.dataset.act === 'accept' ? '/accept' : ''), 'POST');
  load();
});
load();
