if (user()) location.href = 'home.html';

$('#form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target));
  data.grad_year = Number(data.grad_year);
  try {
    const res = await api('/auth/register', 'POST', data);
    $('#msg').className = 'ok';
    $('#msg').textContent = res.message;
    e.target.reset();
  } catch (err) {
    $('#msg').className = 'err';
    $('#msg').textContent = err.message;
  }
});
