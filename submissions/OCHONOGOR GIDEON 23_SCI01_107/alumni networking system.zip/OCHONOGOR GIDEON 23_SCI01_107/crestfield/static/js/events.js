requireLogin();
let page = 1;

async function load() {
  const list = await api('/events?page=' + page);
  $('#list').innerHTML = list.map(eventCard).join('') || '<p class="muted">No upcoming events.</p>';
  $('#prev').disabled = page === 1;
  $('#next').disabled = list.length < 20;
}

$('#list').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-act="rsvp"]');
  if (!btn) return;
  await toggleRsvp(btn);
  load();
});
$('#prev').addEventListener('click', () => { page--; load(); });
$('#next').addEventListener('click', () => { page++; load(); });
load();
