if (user()) location.href = 'home.html';

$('#form').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const { token, user } = await api('/auth/login', 'POST', Object.fromEntries(new FormData(e.target)));
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    location.href = 'home.html';
  } catch (err) {
    $('#msg').textContent = err.message;
  }
});
