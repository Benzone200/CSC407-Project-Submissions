requireLogin();
const me = user();
$('#welcome').textContent = 'Welcome back, ' + me.full_name.split(' ')[0];

const quick = [['directory.html', 'Find alumni', 'Search the directory.']];
quick.push(me.role === 'admin' ? ['admin.html', 'Approvals', 'Review new sign-ups and post events.'] : ['connections.html', 'Connections', 'Manage your requests and connections.']);
$('#quick').innerHTML = quick.map(([href, title, text]) => `<a class="card" href="${href}"><h3>${title}</h3><p class="muted">${text}</p></a>`).join('');

api('/events').then((list) => {
  $('#events').innerHTML = list.slice(0, 2).map(eventCard).join('') || '<p class="muted">No upcoming events.</p>';
});

$('#events').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-act="rsvp"]');
  if (!btn) return;
  await toggleRsvp(btn);
  location.reload();
});
