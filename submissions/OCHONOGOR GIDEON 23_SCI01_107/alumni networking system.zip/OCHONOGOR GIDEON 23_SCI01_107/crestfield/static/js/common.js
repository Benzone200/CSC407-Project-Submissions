const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const svg = (p) => `<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const ICON = {
  cap: svg('<path d="M12 4 2 9l10 5 10-5z"/><path d="M6 11.5V16c0 1.2 2.7 2.5 6 2.5s6-1.3 6-2.5v-4.5M22 9v5"/>'),
  pin: svg('<path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>'),
  clock: svg('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
  search: svg('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>'),
};

async function api(path, method = 'GET', body) {
  const token = localStorage.getItem('token');
  const res = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token && { Authorization: 'Bearer ' + token }) },
    body: body && JSON.stringify(body),
  });
  const data = res.status === 204 ? null : await res.json();
  if (res.status === 401 && token) return logout();
  if (!res.ok) throw new Error(data?.error || 'Request failed');
  return data;
}

const user = () => JSON.parse(localStorage.getItem('user') || 'null');

function logout() {
  localStorage.clear();
  location.href = 'index.html';
}

function requireLogin(adminOnly) {
  const u = user();
  if (!u) location.href = 'login.html';
  else if (adminOnly && u.role !== 'admin') location.href = 'home.html';
}

const avatar = (name, size = 48) =>
  `<div class="av" style="width:${size}px;height:${size}px;font-size:${Math.round(size * 0.36)}px">${esc(name.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase())}</div>`;

const logoHtml = `<a class="logo" href="index.html"><span class="ring">${ICON.cap}</span><span><b>CRESTFIELD</b><i>ALUMNI NETWORK</i></span></a>`;

function alumniCard(p) {
  return `<a class="card al" href="person.html?id=${p.id}"><div class="top">${avatar(p.full_name, 64)}<span class="cls">Class of ${p.grad_year}</span></div>
    <h3>${esc(p.full_name)}</h3><div class="job">${esc([p.industry, p.job_title].filter(Boolean).join(' · ') || 'No details yet')}</div>
    <div class="meta">${ICON.pin}${esc(p.location || 'Location not set')}</div>${(p.skills || []).map((s) => `<span class="tag">${esc(s)}</span>`).join('')}</a>`;
}

function eventCard(e) {
  const d = new Date(e.starts_at);
  return `<div class="card ev"><div class="who"><div class="dt"><b>${d.getDate()}</b><span>${d.toLocaleString([], { month: 'short' }).toUpperCase()}</span></div>
    <div><div class="cat">Alumni event</div><h3>${esc(e.title)}</h3></div></div>
    <p class="muted">${esc(e.description)}</p>
    <div class="meta">${ICON.clock}${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
    <div class="meta">${ICON.pin}${esc(e.location)}</div><div class="meta small">${e.rsvp_count} going</div>
    <button class="${e.going ? 'ghost' : 'btn'} full" data-act="rsvp" data-id="${e.id}" data-going="${e.going}">${e.going ? 'Cancel RSVP' : 'RSVP'}</button></div>`;
}

async function toggleRsvp(btn) {
  await api(`/events/${btn.dataset.id}/rsvp`, btn.dataset.going === 'true' ? 'DELETE' : 'POST');
}

function layout() {
  const u = user();
  const page = document.body.dataset.page;
  const a = (href, label, key) => `<a href="${href}" class="${page === key ? 'on' : ''}">${label}</a>`;
  const links = u
    ? a('home.html', 'Home', 'home') + a('directory.html', 'Directory', 'directory') + a('events.html', 'Events', 'events') +
      (u.role === 'admin' ? a('admin.html', 'Admin', 'admin') : a('connections.html', 'Connections', 'connections') + a('profile.html', 'My profile', 'profile')) +
      '<button class="linkbtn" id="logout">Log out</button>'
    : a('index.html', 'Home', 'landing') + a('login.html', 'Log in', 'login') + '<a class="gold" href="register.html">Create an account</a>';

  $('#site-header').innerHTML = `<div class="wrap bar">${logoHtml}<button class="burger" id="burger" aria-label="Menu"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 7h18M3 12h18M3 17h18"/></svg></button><nav class="menu" id="menu">${links}</nav></div>`;
  $('#site-footer').innerHTML = `<div class="wrap">${logoHtml}<p>Connecting generations of Crestfield graduates to opportunity, community and lifelong impact.</p>
    <div class="fcols"><div><h4>EXPLORE</h4><a href="directory.html">Alumni directory</a><a href="events.html">Events</a></div>
    <div><h4>PORTAL</h4><a href="home.html">Member dashboard</a><span>alumni@crestfield.edu</span></div></div>
    <div class="copy">© 2026 Crestfield Alumni Association.</div></div>`;

  $('#burger').addEventListener('click', () => $('#menu').classList.toggle('open'));
  $('#logout')?.addEventListener('click', logout);
}

layout();
