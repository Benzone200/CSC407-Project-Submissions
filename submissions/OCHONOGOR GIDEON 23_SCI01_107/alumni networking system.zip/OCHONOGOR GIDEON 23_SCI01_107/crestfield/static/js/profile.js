requireLogin();
const form = $('#form');

api('/alumni/me').then((p) => {
  $('#who').innerHTML = avatar(p.full_name, 56) + `<div><b>${esc(p.full_name)}</b><div class="muted small">Class of ${p.grad_year}</div></div>`;
  for (const el of form.elements) {
    if (el.name && el.name !== 'skills') el.value = p[el.name] ?? '';
  }
  form.skills.value = (p.skills || []).join(', ');
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form));
  for (const k in data) data[k] = data[k].trim() || null;
  data.skills = form.skills.value.split(',').map((s) => s.trim()).filter(Boolean);
  try {
    await api('/alumni/me', 'PUT', data);
    $('#msg').className = 'ok';
    $('#msg').textContent = 'Saved';
  } catch (err) {
    $('#msg').className = 'err';
    $('#msg').textContent = err.message;
  }
});
