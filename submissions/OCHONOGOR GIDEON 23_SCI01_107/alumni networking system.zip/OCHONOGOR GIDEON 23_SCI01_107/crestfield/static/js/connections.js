requireLogin();

const row = (c, buttons) => `<div class="card between"><a class="who" href="person.html?id=${c.id}" style="text-decoration:none">${avatar(c.full_name, 44)}
  <div><b>${esc(c.full_name)}</b><div class="muted small">Class of ${c.grad_year}</div></div></a><div class="row">${buttons}</div></div>`;
const btn = (act, id, label, cls) => `<button class="${cls} sm" data-act="${act}" data-id="${id}">${label}</button>`;

function section(title, items, buttons) {
  return `<h2 class="sub">${title} (${items.length})</h2>` + items.map((c) => row(c, buttons(c.id))).join('');
}

async function load() {
  const list = await api('/connections');
  $('#box').innerHTML =
    section('Requests for you', list.filter((c) => c.status === 'pending' && c.incoming), (id) => btn('accept', id, 'Accept', 'btn') + btn('remove', id, 'Decline', 'ghost')) +
    section('Connected', list.filter((c) => c.status === 'accepted'), (id) => btn('remove', id, 'Remove', 'ghost')) +
    section('Sent', list.filter((c) => c.status === 'pending' && !c.incoming), (id) => btn('remove', id, 'Cancel', 'ghost'));
}

$('#box').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-act]');
  if (!b) return;
  if (b.dataset.act === 'accept') await api(`/connections/${b.dataset.id}/accept`, 'POST');
  else await api(`/connections/${b.dataset.id}`, 'DELETE');
  load();
});
load();
