requireLogin(true);

async function load() {
  const list = await api('/admin/pending');
  $('#pending').innerHTML = list.map((u) => `<div class="card between"><div><b>${esc(u.full_name)}</b> <span class="muted">Class of ${u.grad_year}</span>
    <div class="muted small">${esc(u.email)}</div></div>
    <div class="row"><button class="btn sm" data-act="approve" data-id="${u.id}">Approve</button><button class="ghost sm" data-act="reject" data-id="${u.id}">Reject</button></div></div>`).join('')
    || '<p class="muted">Nobody is waiting.</p>';
}

$('#pending').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-act]');
  if (!b) return;
  await api(`/admin/users/${b.dataset.id}/${b.dataset.act}`, 'POST');
  load();
});

$('#form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  try {
    await api('/events', 'POST', { title: f.title, location: f.location, description: f.description, starts_at: new Date(f.when).toISOString() });
    e.target.reset();
    $('#msg').className = 'ok';
    $('#msg').textContent = 'Event posted';
  } catch (err) {
    $('#msg').className = 'err';
    $('#msg').textContent = err.message;
  }
});
load();
