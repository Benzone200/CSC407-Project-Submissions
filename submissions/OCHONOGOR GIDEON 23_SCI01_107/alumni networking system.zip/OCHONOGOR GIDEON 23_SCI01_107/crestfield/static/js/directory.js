requireLogin();
$('#search-icon').innerHTML = ICON.search;
let page = 1;

async function load() {
  const qs = new URLSearchParams({ page });
  for (const id of ['q', 'industry', 'year']) {
    const v = $('#' + id).value.trim();
    if (v) qs.set(id === 'q' ? 'q' : id, v);
  }
  const rows = await api('/alumni?' + qs);
  const total = rows[0] ? Number(rows[0].total) : 0;
  $('#count').innerHTML = `<b>${total}</b> verified alumni found`;
  $('#list').innerHTML = rows.map(alumniCard).join('') || '<p class="muted">No alumni match those filters.</p>';
  $('#prev').disabled = page === 1;
  $('#next').disabled = page * 20 >= total;
}

api('/alumni/filters').then(({ industries, years }) => {
  $('#industry').innerHTML += industries.map((i) => `<option>${esc(i)}</option>`).join('');
  $('#year').innerHTML += years.map((y) => `<option>${y}</option>`).join('');
});

for (const id of ['q', 'industry', 'year']) {
  $('#' + id).addEventListener('input', () => { page = 1; load(); });
}
$('#prev').addEventListener('click', () => { page--; load(); });
$('#next').addEventListener('click', () => { page++; load(); });
load();
