require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./src/db');

if (db.prepare('SELECT count(*) FROM users').pluck().get() > 0) {
  console.log('The database already has data. Delete the data folder to start fresh.');
  process.exit();
}

const people = [
  ['admin@school.edu', 'Admin User', 2005, 'admin', 'approved'],
  ['ada@example.com', 'Ada Okafor', 2018, 'alumni', 'approved', 'Software Engineer', 'Acme', 'Technology', 'Lagos', ['python', 'sql']],
  ['kwame@example.com', 'Kwame Boateng', 2015, 'alumni', 'approved', 'Civil Engineer', 'BuildCo', 'Construction', 'Accra', ['autocad']],
  ['ben@example.com', 'Ben Mensah', 2020, 'alumni', 'approved', 'Data Analyst', 'FinBank', 'Finance', 'London', ['excel', 'sql']],
  ['zainab@example.com', 'Zainab Bello', 2012, 'alumni', 'approved', 'Doctor', 'City Hospital', 'Healthcare', 'Abuja', ['research']],
  ['tunde@example.com', 'Tunde Adeyemi', 2018, 'alumni', 'approved', 'Product Designer', 'Pixel Studio', 'Technology', 'Lagos', ['figma', 'ux']],
  ['grace@example.com', 'Grace Nwosu', 2008, 'alumni', 'approved', 'Teacher', 'Hillcrest College', 'Education', 'Enugu', ['mentoring']],
  ['chidi@example.com', 'Chidi Eze', 2022, 'alumni', 'pending'],
];

const seedPassword = process.env.SEED_PASSWORD;
if (!seedPassword || seedPassword.length < 12) {
  console.error('Set SEED_PASSWORD in .env to a unique password of at least 12 characters before seeding.');
  process.exit(1);
}
const hash = bcrypt.hashSync(seedPassword, 10);
const addUser = db.prepare('INSERT INTO users (email, password_hash, full_name, grad_year, role, status) VALUES (?, ?, ?, ?, ?, ?)');
const addProfile = db.prepare('INSERT INTO profiles (user_id, job_title, employer, industry, location, skills) VALUES (?, ?, ?, ?, ?, ?)');

for (const [email, name, year, role, status, job, employer, industry, location, skills] of people) {
  const { lastInsertRowid } = addUser.run(email, hash, name, year, role, status);
  addProfile.run(lastInsertRowid, job ?? null, employer ?? null, industry ?? null, location ?? null, JSON.stringify(skills || []));
}

const inDays = (n) => new Date(Date.now() + n * 86400000).toISOString();
const addEvent = db.prepare('INSERT INTO events (title, description, location, starts_at, created_by) VALUES (?, ?, ?, ?, 1)');
addEvent.run('Annual Homecoming', 'Meet your old classmates and see what has changed on campus.', 'School hall', inDays(30));
addEvent.run('Careers evening', 'Alumni share how they built their careers, with time for questions.', 'Online', inDays(60));

console.log('Seeded. Log in with admin@school.edu or ada@example.com using your local SEED_PASSWORD.');
