"""Keystone - a small landlord management system (Flask + SQLite)."""
import calendar
import math
import re
import sqlite3
from datetime import date, datetime, timedelta, timezone
from functools import wraps
from urllib.parse import urlparse

from flask import Flask, abort, flash, g, redirect, render_template, request, session, url_for
from flask_wtf.csrf import CSRFError, CSRFProtect
from werkzeug.security import check_password_hash, generate_password_hash

import database as db
from config import Config

app = Flask(__name__)
app.config.from_object(Config)
CSRFProtect(app)
db.init_app(app)

PROPERTY_TYPES = ["Apartment Building", "House", "Duplex", "Townhouse", "Commercial", "Mixed Use", "Other"]
PAYMENT_METHODS = ["Cash", "Bank Transfer", "Cheque", "Mobile Money", "Card", "Other"]
PRIORITIES = ["Low", "Medium", "High"]
REQUEST_STATUSES = ["Pending", "In Progress", "Resolved"]
PAYMENT_STATUSES = ["Paid", "Partial", "Unpaid", "Overdue"]

ROLES = {"admin": "Administrator", "manager": "Manager", "viewer": "Viewer"}
WRITE_ROLES = ("admin", "manager")
PUBLIC_ENDPOINTS = {"home", "login", "register", "security", "static"}

PASSWORD_HASH_METHOD = "pbkdf2:sha256:600000"
# Used to spend the same time hashing when an email is unknown (prevents account discovery by timing).
DUMMY_HASH = generate_password_hash("not-a-real-password", method=PASSWORD_HASH_METHOD)

PERIOD_PATTERN = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")
EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_PATTERN = re.compile(r"^[0-9+()\-\s.]{5,40}$")

NAV_SECTIONS = {
    "dashboard": "dashboard",
    "properties": "properties",
    "property_detail": "properties",
    "tenants": "tenants",
    "tenant_detail": "tenants",
    "payments": "payments",
    "maintenance": "maintenance",
    "settings": "settings",
    "users": "users",
    "security": "security",
    "profile": "profile",
}

CONTENT_SECURITY_POLICY = (
    "default-src 'self'; "
    "script-src 'self' https://unpkg.com; "
    "style-src 'self'; "
    "img-src 'self' data:; "
    "font-src 'self'; "
    "connect-src 'self'; "
    "object-src 'none'; "
    "base-uri 'self'; "
    "form-action 'self'; "
    "frame-ancestors 'none'"
)


# ---------------------------------------------------------------------------
# Security: headers, authentication gate, role checks
# ---------------------------------------------------------------------------
@app.after_request
def set_security_headers(response):
    response.headers["Content-Security-Policy"] = CONTENT_SECURITY_POLICY
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Permissions-Policy"] = "geolocation=(), camera=(), microphone=()"
    if request.endpoint != "static":
        response.headers["Cache-Control"] = "no-store"
    if app.config["SESSION_COOKIE_SECURE"]:
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response


@app.before_request
def load_user_and_require_login():
    """Load the signed-in user on every request and deny everything not explicitly public."""
    g.user = None
    if request.endpoint == "static":
        return None
    user_id = session.get("uid")
    if user_id:
        user = db.query_one(
            "SELECT id, full_name, email, phone, role, is_active, created_at, last_login "
            "FROM users WHERE id = ?",
            (user_id,),
        )
        if user and user["is_active"]:
            g.user = user
        else:
            session.clear()
    if g.user is None and request.endpoint is not None and request.endpoint not in PUBLIC_ENDPOINTS:
        flash("Please sign in to continue.", "error")
        target = request.full_path.rstrip("?") if request.method == "GET" else None
        return redirect(url_for("login", next=target))
    return None


def roles_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            if g.user is None or g.user["role"] not in roles:
                abort(403)
            return view(*args, **kwargs)

        return wrapper

    return decorator


write_access = roles_required(*WRITE_ROLES)
admin_only = roles_required("admin")


def start_session(user_id):
    """Replace any existing session with a fresh one for this user."""
    session.clear()
    session["uid"] = user_id
    session.permanent = True


def clean_next(target):
    """Allow only same-site relative paths after sign-in (blocks open redirects)."""
    if not target or not target.startswith("/") or target.startswith("//") or "\\" in target:
        return ""
    parts = urlparse(target)
    return "" if parts.scheme or parts.netloc else target


def minutes_locked(user):
    if not user or not user.get("locked_until"):
        return 0
    remaining = datetime.fromisoformat(user["locked_until"]) - datetime.now(timezone.utc)
    return max(math.ceil(remaining.total_seconds() / 60), 0)


def record_failed_login(user):
    attempts = user["failed_attempts"] + 1
    locked_until = None
    if attempts >= app.config["MAX_LOGIN_ATTEMPTS"]:
        lock_time = datetime.now(timezone.utc) + timedelta(minutes=app.config["LOCKOUT_MINUTES"])
        locked_until = lock_time.isoformat()
        attempts = 0
    db.execute(
        "UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?",
        (attempts, locked_until, user["id"]),
    )


def password_errors(password):
    errors = []
    if len(password) < 10:
        errors.append("Your password must be at least 10 characters long.")
    if len(password) > 128:
        errors.append("Your password must be 128 characters or fewer.")
    if not (re.search(r"[a-z]", password) and re.search(r"[A-Z]", password) and re.search(r"\d", password)):
        errors.append("Use upper-case and lower-case letters and at least one number in your password.")
    return errors


def name_phone_errors(full_name, phone):
    errors = []
    if not 2 <= len(full_name) <= 120:
        errors.append("Enter your full name (at least 2 characters).")
    if phone and not PHONE_PATTERN.match(phone):
        errors.append("Enter a valid phone number or leave it blank.")
    return errors


# ---------------------------------------------------------------------------
# Template helpers
# ---------------------------------------------------------------------------
@app.context_processor
def inject_globals():
    user = g.get("user")
    return {
        "settings": db.get_settings(),
        "current_user": user,
        "can_write": bool(user and user["role"] in WRITE_ROLES),
        "is_admin": bool(user and user["role"] == "admin"),
        "role_labels": ROLES,
        "active_page": NAV_SECTIONS.get(request.endpoint),
        "today": date.today().isoformat(),
        "this_month": current_period(),
    }


@app.template_filter("money")
def money_filter(value):
    return f"{db.get_settings()['currency']}{(value or 0):,.2f}"


@app.template_filter("pretty_date")
def pretty_date_filter(value):
    try:
        return datetime.strptime(value, "%Y-%m-%d").strftime("%d %b %Y")
    except (ValueError, TypeError):
        return "—"


@app.template_filter("pretty_period")
def pretty_period_filter(value):
    try:
        return datetime.strptime(value, "%Y-%m").strftime("%B %Y")
    except (ValueError, TypeError):
        return "—"


@app.template_filter("pretty_datetime")
def pretty_datetime_filter(value):
    try:
        return datetime.fromisoformat(value).strftime("%d %b %Y, %H:%M")
    except (ValueError, TypeError):
        return "Never"


# ---------------------------------------------------------------------------
# Small utilities
# ---------------------------------------------------------------------------
def current_period():
    return date.today().strftime("%Y-%m")


def shift_period(period, months):
    year, month = int(period[:4]), int(period[5:])
    index = year * 12 + (month - 1) + months
    return f"{index // 12:04d}-{index % 12 + 1:02d}"


def field(name, max_length=200):
    return (request.form.get(name) or "").strip()[:max_length]


def parse_amount(raw):
    try:
        value = round(float(str(raw).replace(",", "").strip()), 2)
    except ValueError:
        return None
    return value if math.isfinite(value) and value >= 0 else None


def parse_date(raw):
    try:
        return datetime.strptime((raw or "").strip(), "%Y-%m-%d").date().isoformat()
    except ValueError:
        return None


def show_errors(errors):
    for message in errors:
        flash(message, "error")


def go_back(fallback_endpoint):
    referrer = request.referrer
    if referrer and urlparse(referrer).netloc == request.host:
        return redirect(referrer)
    return redirect(url_for(fallback_endpoint))


def fetch_or_404(sql, args=()):
    row = db.query_one(sql, args)
    if row is None:
        abort(404)
    return row


def all_properties():
    return db.query_all("SELECT id, name FROM properties ORDER BY name")


def unit_options():
    """Every unit with its property name and current active tenant (if any)."""
    return db.query_all(
        """SELECT u.id, u.name, u.monthly_rent, u.property_id, p.name AS property_name,
                  (SELECT t.id FROM tenants t WHERE t.unit_id = u.id AND t.is_active = 1) AS occupant_id
           FROM units u JOIN properties p ON p.id = u.property_id
           ORDER BY p.name, u.name"""
    )


def active_tenants():
    return db.query_all(
        """SELECT t.id, t.full_name, t.monthly_rent, u.name AS unit_name, p.name AS property_name
           FROM tenants t JOIN units u ON u.id = t.unit_id JOIN properties p ON p.id = u.property_id
           WHERE t.is_active = 1 ORDER BY t.full_name"""
    )


# ---------------------------------------------------------------------------
# Rent calculations
# ---------------------------------------------------------------------------
def build_ledger(period, tenant_id=None, property_id=None, status=None):
    """One row per active tenant whose lease covers `period`.

    due     = tenant's monthly rent
    paid    = sum of recorded payments for that tenant and period
    balance = what is still owed (never negative)
    status  = Paid / Partial / Unpaid (not yet due) / Overdue (past due date, nothing paid)
    """
    due_day = int(db.get_settings()["rent_due_day"])
    year, month = int(period[:4]), int(period[5:])
    last_day = calendar.monthrange(year, month)[1]
    first_of_period = date(year, month, 1).isoformat()
    last_of_period = date(year, month, last_day).isoformat()
    due_date = date(year, month, min(due_day, last_day))

    sql = """SELECT t.id AS tenant_id, t.full_name, t.monthly_rent AS due,
                    u.id AS unit_id, u.name AS unit_name, p.id AS property_id, p.name AS property_name,
                    COALESCE((SELECT SUM(r.amount) FROM rent_payments r
                              WHERE r.tenant_id = t.id AND r.period = ?), 0) AS paid
             FROM tenants t
             JOIN units u ON u.id = t.unit_id
             JOIN properties p ON p.id = u.property_id
             WHERE t.is_active = 1 AND t.lease_start <= ?
               AND (t.lease_end IS NULL OR t.lease_end = '' OR t.lease_end >= ?)"""
    args = [period, last_of_period, first_of_period]
    if tenant_id:
        sql += " AND t.id = ?"
        args.append(tenant_id)
    if property_id:
        sql += " AND p.id = ?"
        args.append(property_id)
    sql += " ORDER BY p.name, u.name"

    rows = db.query_all(sql, args)
    for row in rows:
        row["period"] = period
        row["due_date"] = due_date.isoformat()
        row["paid"] = round(row["paid"], 2)
        row["balance"] = max(round(row["due"] - row["paid"], 2), 0)
        if row["paid"] >= row["due"]:
            row["status"] = "Paid"
        elif row["paid"] > 0:
            row["status"] = "Partial"
        elif date.today() > due_date:
            row["status"] = "Overdue"
        else:
            row["status"] = "Unpaid"
    if status:
        rows = [row for row in rows if row["status"] == status]
    return rows


# ---------------------------------------------------------------------------
# Public pages and authentication
# ---------------------------------------------------------------------------
@app.route("/")
def home():
    return render_template("home.html")


@app.route("/security")
def security():
    return render_template("security.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("dashboard"))
    form = {"full_name": "", "email": "", "phone": ""}
    if request.method == "POST":
        form = {
            "full_name": field("full_name", 120),
            "email": field("email", 254).lower(),
            "phone": field("phone", 40),
        }
        password = request.form.get("password", "")
        errors = name_phone_errors(form["full_name"], form["phone"])
        if not EMAIL_PATTERN.match(form["email"]):
            errors.append("Enter a valid email address.")
        errors += password_errors(password)
        if password != request.form.get("confirm_password", ""):
            errors.append("The two passwords do not match.")
        if not errors and db.query_one("SELECT id FROM users WHERE email = ?", (form["email"],)):
            errors.append("An account with this email already exists.")
        if errors:
            show_errors(errors)
            return render_template("register.html", form=form), 400

        password_hash = generate_password_hash(password, method=PASSWORD_HASH_METHOD)
        try:
            # The very first account becomes the administrator (decided inside one SQL statement,
            # so two simultaneous sign-ups cannot both become admin). Everyone else starts as an
            # inactive viewer until an administrator approves them.
            db.execute(
                """INSERT INTO users (full_name, email, phone, password_hash, role, is_active)
                   SELECT ?, ?, ?, ?,
                          CASE WHEN COUNT(*) = 0 THEN 'admin' ELSE 'viewer' END,
                          CASE WHEN COUNT(*) = 0 THEN 1 ELSE 0 END
                   FROM users""",
                (form["full_name"], form["email"], form["phone"], password_hash),
            )
        except sqlite3.IntegrityError:
            flash("An account with this email already exists.", "error")
            return render_template("register.html", form=form), 400

        user = db.query_one("SELECT id, role, is_active FROM users WHERE email = ?", (form["email"],))
        if user["is_active"]:
            start_session(user["id"])
            flash("Your account is ready. You are the administrator, so you can approve other users later.", "success")
            return redirect(url_for("dashboard"))
        flash("Account created. An administrator must approve it before you can sign in.", "success")
        return redirect(url_for("login"))
    return render_template("register.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("dashboard"))
    next_url = clean_next(request.values.get("next", ""))
    if request.method == "POST":
        email = field("email", 254).lower()
        password = request.form.get("password", "")[:128]
        user = db.query_one("SELECT * FROM users WHERE email = ?", (email,))

        wait = minutes_locked(user)
        if wait:
            flash(f"Too many failed attempts. Try again in {wait} minute(s).", "error")
            return render_template("login.html", email=email, next_url=next_url), 429

        password_ok = check_password_hash(user["password_hash"] if user else DUMMY_HASH, password) and user is not None
        if not password_ok:
            if user:
                record_failed_login(user)
            app.logger.warning("Failed sign-in for %r from %s", email, request.remote_addr)
            flash("Incorrect email or password.", "error")
            return render_template("login.html", email=email, next_url=next_url), 401
        if not user["is_active"]:
            flash("Your account is not active yet. An administrator needs to approve it.", "error")
            return render_template("login.html", email=email, next_url=next_url), 403

        db.execute(
            "UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login = ? WHERE id = ?",
            (datetime.now(timezone.utc).isoformat(), user["id"]),
        )
        start_session(user["id"])
        flash(f"Welcome back, {user['full_name'].split(' ')[0]}.", "success")
        return redirect(next_url or url_for("dashboard"))
    return render_template("login.html", email="", next_url=next_url)


@app.post("/logout")
def logout():
    session.clear()
    flash("You have been signed out.", "success")
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Profile
# ---------------------------------------------------------------------------
@app.route("/profile")
def profile():
    return render_template("profile.html")


@app.post("/profile/update")
def update_profile():
    full_name, phone = field("full_name", 120), field("phone", 40)
    errors = name_phone_errors(full_name, phone)
    if errors:
        show_errors(errors)
        return redirect(url_for("profile"))
    db.execute("UPDATE users SET full_name = ?, phone = ? WHERE id = ?", (full_name, phone, g.user["id"]))
    flash("Your profile was updated.", "success")
    return redirect(url_for("profile"))


@app.post("/profile/password")
def change_password():
    current = request.form.get("current_password", "")[:128]
    new_password = request.form.get("new_password", "")
    row = db.query_one("SELECT password_hash FROM users WHERE id = ?", (g.user["id"],))
    errors = []
    if not check_password_hash(row["password_hash"], current):
        errors.append("Your current password is incorrect.")
    errors += password_errors(new_password)
    if new_password != request.form.get("confirm_password", ""):
        errors.append("The two new passwords do not match.")
    if new_password and new_password == current:
        errors.append("Choose a password different from your current one.")
    if errors:
        show_errors(errors)
        return redirect(url_for("profile"))
    db.execute(
        "UPDATE users SET password_hash = ? WHERE id = ?",
        (generate_password_hash(new_password, method=PASSWORD_HASH_METHOD), g.user["id"]),
    )
    start_session(g.user["id"])
    flash("Your password was changed.", "success")
    return redirect(url_for("profile"))


# ---------------------------------------------------------------------------
# User management (administrators only)
# ---------------------------------------------------------------------------
@app.route("/users")
@admin_only
def users():
    rows = db.query_all(
        """SELECT id, full_name, email, phone, role, is_active, last_login, created_at, locked_until
           FROM users ORDER BY is_active ASC, full_name"""
    )
    for row in rows:
        if row["is_active"]:
            row["state"] = "Active"
        else:
            row["state"] = "Disabled" if row["last_login"] else "Pending approval"
        row["locked"] = minutes_locked(row) > 0
    return render_template("users.html", rows=rows)


@app.post("/users/<int:user_id>/edit")
@admin_only
def edit_user(user_id):
    fetch_or_404("SELECT id FROM users WHERE id = ?", (user_id,))
    if user_id == g.user["id"]:
        flash("You cannot change your own role or status.", "error")
        return redirect(url_for("users"))
    role, status = field("role", 20), field("status", 20)
    if role not in ROLES or status not in ("active", "disabled"):
        flash("Choose a valid role and status.", "error")
        return redirect(url_for("users"))
    db.execute(
        "UPDATE users SET role = ?, is_active = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?",
        (role, 1 if status == "active" else 0, user_id),
    )
    flash("User updated.", "success")
    return redirect(url_for("users"))


@app.post("/users/<int:user_id>/delete")
@admin_only
def delete_user(user_id):
    target = fetch_or_404("SELECT id, full_name FROM users WHERE id = ?", (user_id,))
    if user_id == g.user["id"]:
        flash("You cannot delete your own account.", "error")
    else:
        db.execute("DELETE FROM users WHERE id = ?", (user_id,))
        flash(f"The account for {target['full_name']} was deleted.", "success")
    return redirect(url_for("users"))


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@app.route("/dashboard")
def dashboard():
    period = current_period()
    ledger = build_ledger(period)
    unit_counts = db.query_one(
        """SELECT COUNT(*) AS total,
                  COALESCE(SUM(EXISTS (SELECT 1 FROM tenants t
                                       WHERE t.unit_id = u.id AND t.is_active = 1)), 0) AS occupied
           FROM units u"""
    )
    total_units, occupied = unit_counts["total"], unit_counts["occupied"]
    today_iso = date.today().isoformat()

    stats = {
        "properties": db.query_one("SELECT COUNT(*) AS n FROM properties")["n"],
        "units": total_units,
        "occupied": occupied,
        "vacant": total_units - occupied,
        "tenants": db.query_one("SELECT COUNT(*) AS n FROM tenants WHERE is_active = 1")["n"],
        "collected": db.query_one(
            "SELECT COALESCE(SUM(amount), 0) AS n FROM rent_payments WHERE period = ?", (period,)
        )["n"],
        "expected": sum(row["due"] for row in ledger),
        "outstanding": sum(row["balance"] for row in ledger),
        "past_due": sum(1 for row in ledger if row["balance"] > 0 and row["due_date"] < today_iso),
    }
    occupancy_pct = round(occupied / total_units * 100) if total_units else 0

    recent_payments = db.query_all(
        """SELECT r.*, t.full_name, u.name AS unit_name, p.name AS property_name
           FROM rent_payments r
           JOIN tenants t ON t.id = r.tenant_id
           JOIN units u ON u.id = r.unit_id
           JOIN properties p ON p.id = u.property_id
           ORDER BY r.payment_date DESC, r.id DESC LIMIT 5"""
    )

    upcoming = [row for row in ledger if row["status"] == "Unpaid"]
    upcoming += [row for row in build_ledger(shift_period(period, 1)) if row["status"] == "Unpaid"]
    upcoming = sorted(upcoming, key=lambda row: row["due_date"])[:6]

    recent_maintenance = db.query_all(
        """SELECT m.*, p.name AS property_name, u.name AS unit_name
           FROM maintenance_requests m
           JOIN properties p ON p.id = m.property_id
           LEFT JOIN units u ON u.id = m.unit_id
           ORDER BY m.date_reported DESC, m.id DESC LIMIT 5"""
    )

    chart = []
    for offset in range(-5, 1):
        month_period = shift_period(period, offset)
        total = db.query_one(
            "SELECT COALESCE(SUM(amount), 0) AS n FROM rent_payments WHERE period = ?", (month_period,)
        )["n"]
        chart.append(
            {
                "label": datetime.strptime(month_period, "%Y-%m").strftime("%b"),
                "value": round(total, 2),
                "current": offset == 0,
            }
        )

    return render_template(
        "dashboard.html",
        period=period,
        stats=stats,
        occupancy_pct=occupancy_pct,
        recent_payments=recent_payments,
        upcoming=upcoming,
        recent_maintenance=recent_maintenance,
        chart=chart,
        chart_has_data=any(point["value"] > 0 for point in chart),
    )


# ---------------------------------------------------------------------------
# Properties
# ---------------------------------------------------------------------------
def parse_property():
    data = {
        "name": field("name", 120),
        "address": field("address", 250),
        "property_type": field("property_type", 40),
        "description": field("description", 1000),
    }
    errors = []
    if not data["name"]:
        errors.append("Property name is required.")
    if not data["address"]:
        errors.append("Property address is required.")
    if data["property_type"] not in PROPERTY_TYPES:
        errors.append("Choose a valid property type.")
    return data, errors


@app.route("/properties")
def properties():
    query = request.args.get("q", "").strip()
    rows = db.query_all(
        """SELECT p.*,
                  (SELECT COUNT(*) FROM units u WHERE u.property_id = p.id) AS unit_count,
                  (SELECT COUNT(*) FROM units u JOIN tenants t ON t.unit_id = u.id AND t.is_active = 1
                   WHERE u.property_id = p.id) AS occupied_count
           FROM properties p
           WHERE p.name LIKE ? OR p.address LIKE ?
           ORDER BY p.name""",
        (f"%{query}%", f"%{query}%"),
    )
    return render_template("properties.html", rows=rows, query=query, property_types=PROPERTY_TYPES)


@app.post("/properties/add")
@write_access
def add_property():
    data, errors = parse_property()
    if errors:
        show_errors(errors)
        return go_back("properties")
    db.execute(
        "INSERT INTO properties (name, address, property_type, description) "
        "VALUES (:name, :address, :property_type, :description)",
        data,
    )
    flash(f"Property “{data['name']}” was added.", "success")
    return redirect(url_for("properties"))


@app.route("/properties/<int:property_id>")
def property_detail(property_id):
    prop = fetch_or_404("SELECT * FROM properties WHERE id = ?", (property_id,))
    units = db.query_all(
        """SELECT u.*, t.id AS tenant_id, t.full_name AS tenant_name
           FROM units u
           LEFT JOIN tenants t ON t.unit_id = u.id AND t.is_active = 1
           WHERE u.property_id = ?
           ORDER BY u.name""",
        (property_id,),
    )
    summary = {
        "units": len(units),
        "occupied": sum(1 for unit in units if unit["tenant_id"]),
        "potential": sum(unit["monthly_rent"] for unit in units),
    }
    return render_template(
        "property_detail.html", prop=prop, units=units, summary=summary, property_types=PROPERTY_TYPES
    )


@app.post("/properties/<int:property_id>/edit")
@write_access
def edit_property(property_id):
    fetch_or_404("SELECT id FROM properties WHERE id = ?", (property_id,))
    data, errors = parse_property()
    if errors:
        show_errors(errors)
        return go_back("properties")
    data["id"] = property_id
    db.execute(
        "UPDATE properties SET name = :name, address = :address, property_type = :property_type, "
        "description = :description WHERE id = :id",
        data,
    )
    flash("Property details were updated.", "success")
    return go_back("properties")


@app.post("/properties/<int:property_id>/delete")
@write_access
def delete_property(property_id):
    prop = fetch_or_404("SELECT id, name FROM properties WHERE id = ?", (property_id,))
    active = db.query_one(
        """SELECT COUNT(*) AS n FROM tenants t JOIN units u ON u.id = t.unit_id
           WHERE u.property_id = ? AND t.is_active = 1""",
        (property_id,),
    )["n"]
    if active:
        flash("This property still has active tenants. Remove them before deleting the property.", "error")
        return go_back("properties")
    db.execute("DELETE FROM properties WHERE id = ?", (property_id,))
    flash(f"Property “{prop['name']}” was deleted.", "success")
    return redirect(url_for("properties"))


# ---------------------------------------------------------------------------
# Units
# ---------------------------------------------------------------------------
def parse_unit():
    data = {
        "name": field("name", 60),
        "monthly_rent": parse_amount(request.form.get("monthly_rent", "")),
        "description": field("description", 1000),
    }
    errors = []
    if not data["name"]:
        errors.append("Unit name or number is required.")
    if data["monthly_rent"] is None:
        errors.append("Enter a valid monthly rent (0 or more).")
    return data, errors


def unit_name_taken(property_id, name, ignore_id=0):
    return db.query_one(
        "SELECT id FROM units WHERE property_id = ? AND name = ? AND id != ?", (property_id, name, ignore_id)
    )


@app.post("/properties/<int:property_id>/units/add")
@write_access
def add_unit(property_id):
    fetch_or_404("SELECT id FROM properties WHERE id = ?", (property_id,))
    data, errors = parse_unit()
    if not errors and unit_name_taken(property_id, data["name"]):
        errors.append(f"This property already has a unit called “{data['name']}”.")
    if errors:
        show_errors(errors)
        return go_back("property_detail")
    data["property_id"] = property_id
    db.execute(
        "INSERT INTO units (property_id, name, monthly_rent, description) "
        "VALUES (:property_id, :name, :monthly_rent, :description)",
        data,
    )
    flash(f"Unit “{data['name']}” was added.", "success")
    return redirect(url_for("property_detail", property_id=property_id))


@app.post("/units/<int:unit_id>/edit")
@write_access
def edit_unit(unit_id):
    unit = fetch_or_404("SELECT * FROM units WHERE id = ?", (unit_id,))
    data, errors = parse_unit()
    if not errors and unit_name_taken(unit["property_id"], data["name"], unit_id):
        errors.append(f"This property already has a unit called “{data['name']}”.")
    if errors:
        show_errors(errors)
        return go_back("properties")
    data["id"] = unit_id
    db.execute(
        "UPDATE units SET name = :name, monthly_rent = :monthly_rent, description = :description WHERE id = :id",
        data,
    )
    flash("Unit details were updated.", "success")
    return redirect(url_for("property_detail", property_id=unit["property_id"]))


@app.post("/units/<int:unit_id>/delete")
@write_access
def delete_unit(unit_id):
    unit = fetch_or_404("SELECT * FROM units WHERE id = ?", (unit_id,))
    if db.query_one("SELECT id FROM tenants WHERE unit_id = ? AND is_active = 1", (unit_id,)):
        flash("This unit has an active tenant. Remove the tenant before deleting the unit.", "error")
    else:
        db.execute("DELETE FROM units WHERE id = ?", (unit_id,))
        flash(f"Unit “{unit['name']}” was deleted.", "success")
    return redirect(url_for("property_detail", property_id=unit["property_id"]))


# ---------------------------------------------------------------------------
# Tenants
# ---------------------------------------------------------------------------
def parse_tenant(tenant_id=0, check_unit_free=True):
    raw_end = field("lease_end")
    data = {
        "full_name": field("full_name", 120),
        "phone": field("phone", 40),
        "email": field("email", 120),
        "unit_id": request.form.get("unit_id", type=int),
        "lease_start": parse_date(request.form.get("lease_start")),
        "lease_end": parse_date(raw_end) if raw_end else None,
        "monthly_rent": parse_amount(request.form.get("monthly_rent", "")),
        "emergency_contact": field("emergency_contact", 200),
    }
    errors = []
    if not data["full_name"]:
        errors.append("Tenant full name is required.")
    if not data["phone"]:
        errors.append("Phone number is required.")
    if data["email"] and not EMAIL_PATTERN.match(data["email"]):
        errors.append("Enter a valid email address or leave it blank.")
    if data["monthly_rent"] is None:
        errors.append("Enter a valid monthly rent (0 or more).")
    if data["lease_start"] is None:
        errors.append("Enter a valid lease start date.")
    if raw_end and data["lease_end"] is None:
        errors.append("Enter a valid lease end date or leave it blank.")
    if data["lease_start"] and data["lease_end"] and data["lease_end"] < data["lease_start"]:
        errors.append("The lease end date must not be before the start date.")
    if not data["unit_id"] or not db.query_one("SELECT id FROM units WHERE id = ?", (data["unit_id"],)):
        errors.append("Choose a unit for this tenant.")
    elif check_unit_free and db.query_one(
        "SELECT id FROM tenants WHERE unit_id = ? AND is_active = 1 AND id != ?", (data["unit_id"], tenant_id)
    ):
        errors.append("That unit already has an active tenant.")
    return data, errors


TENANT_COLUMNS = (
    "full_name, phone, email, unit_id, lease_start, lease_end, monthly_rent, emergency_contact"
)


@app.route("/tenants")
def tenants():
    query = request.args.get("q", "").strip()
    status = request.args.get("status", "active")
    property_id = request.args.get("property", type=int)

    sql = """SELECT t.*, u.name AS unit_name, p.id AS property_id, p.name AS property_name
             FROM tenants t JOIN units u ON u.id = t.unit_id JOIN properties p ON p.id = u.property_id
             WHERE (t.full_name LIKE ? OR t.phone LIKE ? OR t.email LIKE ?)"""
    args = [f"%{query}%"] * 3
    if status == "active":
        sql += " AND t.is_active = 1"
    elif status == "former":
        sql += " AND t.is_active = 0"
    if property_id:
        sql += " AND p.id = ?"
        args.append(property_id)
    sql += " ORDER BY t.is_active DESC, t.full_name"

    vacant_units = [unit for unit in unit_options() if not unit["occupant_id"]]
    add_unit_id = request.args.get("add_unit", type=int)
    preselect = next((unit for unit in vacant_units if unit["id"] == add_unit_id), None)

    return render_template(
        "tenants.html",
        rows=db.query_all(sql, args),
        properties=all_properties(),
        modal_units=vacant_units,
        preselect=preselect,
        query=query,
        status=status,
        property_id=property_id,
    )


@app.post("/tenants/add")
@write_access
def add_tenant():
    data, errors = parse_tenant()
    if errors:
        show_errors(errors)
        return go_back("tenants")
    try:
        db.execute(
            f"INSERT INTO tenants ({TENANT_COLUMNS}) VALUES "
            "(:full_name, :phone, :email, :unit_id, :lease_start, :lease_end, :monthly_rent, :emergency_contact)",
            data,
        )
    except sqlite3.IntegrityError:
        flash("That unit already has an active tenant.", "error")
        return go_back("tenants")
    flash(f"{data['full_name']} was added and assigned to the unit.", "success")
    return redirect(url_for("tenants"))


@app.route("/tenants/<int:tenant_id>")
def tenant_detail(tenant_id):
    tenant = fetch_or_404(
        """SELECT t.*, u.name AS unit_name, p.id AS property_id, p.name AS property_name
           FROM tenants t JOIN units u ON u.id = t.unit_id JOIN properties p ON p.id = u.property_id
           WHERE t.id = ?""",
        (tenant_id,),
    )
    payment_rows = db.query_all(
        "SELECT * FROM rent_payments WHERE tenant_id = ? ORDER BY payment_date DESC, id DESC", (tenant_id,)
    )
    current = build_ledger(current_period(), tenant_id=tenant_id)
    modal_units = [
        unit for unit in unit_options() if not unit["occupant_id"] or unit["occupant_id"] == tenant_id
    ]
    return render_template(
        "tenant_detail.html",
        tenant=tenant,
        payment_rows=payment_rows,
        current=current[0] if current else None,
        modal_units=modal_units,
        preselect=None,
        total_paid=sum(row["amount"] for row in payment_rows),
    )


@app.post("/tenants/<int:tenant_id>/edit")
@write_access
def edit_tenant(tenant_id):
    tenant = fetch_or_404("SELECT * FROM tenants WHERE id = ?", (tenant_id,))
    data, errors = parse_tenant(tenant_id, check_unit_free=bool(tenant["is_active"]))
    if errors:
        show_errors(errors)
        return go_back("tenants")
    data["id"] = tenant_id
    try:
        db.execute(
            "UPDATE tenants SET full_name = :full_name, phone = :phone, email = :email, unit_id = :unit_id, "
            "lease_start = :lease_start, lease_end = :lease_end, monthly_rent = :monthly_rent, "
            "emergency_contact = :emergency_contact WHERE id = :id",
            data,
        )
    except sqlite3.IntegrityError:
        flash("That unit already has an active tenant.", "error")
        return go_back("tenants")
    flash("Tenant information was updated.", "success")
    return redirect(url_for("tenant_detail", tenant_id=tenant_id))


@app.post("/tenants/<int:tenant_id>/remove")
@write_access
def remove_tenant(tenant_id):
    tenant = fetch_or_404("SELECT * FROM tenants WHERE id = ?", (tenant_id,))
    db.execute(
        "UPDATE tenants SET is_active = 0, move_out_date = ? WHERE id = ?",
        (date.today().isoformat(), tenant_id),
    )
    flash(f"{tenant['full_name']} was removed. Their unit is now vacant and payment history is kept.", "success")
    return redirect(url_for("tenants"))


# ---------------------------------------------------------------------------
# Rent & payments
# ---------------------------------------------------------------------------
def parse_payment():
    data = {
        "tenant_id": request.form.get("tenant_id", type=int),
        "amount": parse_amount(request.form.get("amount", "")),
        "payment_date": parse_date(request.form.get("payment_date")),
        "period": field("period", 7),
        "method": field("method", 40),
        "reference": field("reference", 100),
        "notes": field("notes", 500),
    }
    errors = []
    tenant = None
    if data["tenant_id"]:
        tenant = db.query_one("SELECT id, unit_id FROM tenants WHERE id = ? AND is_active = 1", (data["tenant_id"],))
    if tenant is None:
        errors.append("Choose an active tenant.")
    else:
        data["unit_id"] = tenant["unit_id"]
    if not data["amount"]:
        errors.append("Enter an amount greater than zero.")
    if data["payment_date"] is None:
        errors.append("Enter a valid payment date.")
    if not PERIOD_PATTERN.match(data["period"]):
        errors.append("Enter the rent period as YYYY-MM.")
    if data["method"] not in PAYMENT_METHODS:
        errors.append("Choose a payment method.")
    return data, errors


@app.route("/payments")
def payments():
    period = request.args.get("period", "")
    if not PERIOD_PATTERN.match(period):
        period = current_period()
    tenant_id = request.args.get("tenant", type=int)
    property_id = request.args.get("property", type=int)
    status = request.args.get("status", "")
    if status not in PAYMENT_STATUSES:
        status = ""

    ledger = build_ledger(period, tenant_id, property_id, status)
    summary = {
        "due": sum(row["due"] for row in ledger),
        "paid": sum(min(row["paid"], row["due"]) for row in ledger),
        "outstanding": sum(row["balance"] for row in ledger),
    }

    sql = """SELECT r.*, t.full_name, u.name AS unit_name, p.id AS property_id, p.name AS property_name
             FROM rent_payments r
             JOIN tenants t ON t.id = r.tenant_id
             JOIN units u ON u.id = r.unit_id
             JOIN properties p ON p.id = u.property_id
             WHERE 1 = 1"""
    args = []
    if tenant_id:
        sql += " AND r.tenant_id = ?"
        args.append(tenant_id)
    if property_id:
        sql += " AND p.id = ?"
        args.append(property_id)
    sql += " ORDER BY r.payment_date DESC, r.id DESC LIMIT 200"

    tenant_choices = active_tenants()
    record_for = request.args.get("record_for", type=int)
    preselect = next((t for t in tenant_choices if t["id"] == record_for), None)

    return render_template(
        "payments.html",
        period=period,
        prev_period=shift_period(period, -1),
        next_period=shift_period(period, 1),
        ledger=ledger,
        summary=summary,
        history=db.query_all(sql, args),
        tenant_choices=tenant_choices,
        filter_tenants=db.query_all("SELECT id, full_name FROM tenants ORDER BY full_name"),
        properties=all_properties(),
        preselect=preselect,
        auto_open=bool(preselect or request.args.get("record")),
        filters={"tenant": tenant_id, "property": property_id, "status": status},
        payment_statuses=PAYMENT_STATUSES,
        payment_methods=PAYMENT_METHODS,
    )


@app.post("/payments/add")
@write_access
def add_payment():
    data, errors = parse_payment()
    if errors:
        show_errors(errors)
        return go_back("payments")
    db.execute(
        "INSERT INTO rent_payments (tenant_id, unit_id, amount, payment_date, period, method, reference, notes) "
        "VALUES (:tenant_id, :unit_id, :amount, :payment_date, :period, :method, :reference, :notes)",
        data,
    )
    flash("Payment recorded.", "success")
    return redirect(url_for("payments", period=data["period"]))


@app.post("/payments/<int:payment_id>/delete")
@write_access
def delete_payment(payment_id):
    fetch_or_404("SELECT id FROM rent_payments WHERE id = ?", (payment_id,))
    db.execute("DELETE FROM rent_payments WHERE id = ?", (payment_id,))
    flash("Payment record deleted.", "success")
    return go_back("payments")


# ---------------------------------------------------------------------------
# Maintenance
# ---------------------------------------------------------------------------
def parse_maintenance():
    data = {
        "property_id": request.form.get("property_id", type=int),
        "unit_id": request.form.get("unit_id", type=int),
        "tenant_id": request.form.get("tenant_id", type=int),
        "title": field("title", 150),
        "description": field("description", 2000),
        "date_reported": parse_date(request.form.get("date_reported")),
        "priority": field("priority", 20),
        "status": field("status", 20),
    }
    errors = []
    if not data["title"]:
        errors.append("An issue title is required.")
    if not data["property_id"] or not db.query_one("SELECT id FROM properties WHERE id = ?", (data["property_id"],)):
        errors.append("Choose a property.")
    elif data["unit_id"] and not db.query_one(
        "SELECT id FROM units WHERE id = ? AND property_id = ?", (data["unit_id"], data["property_id"])
    ):
        errors.append("The selected unit does not belong to that property.")
    if data["tenant_id"] and not db.query_one("SELECT id FROM tenants WHERE id = ?", (data["tenant_id"],)):
        errors.append("The selected tenant does not exist.")
    if data["date_reported"] is None:
        errors.append("Enter a valid date reported.")
    if data["priority"] not in PRIORITIES:
        errors.append("Choose a priority.")
    if data["status"] not in REQUEST_STATUSES:
        errors.append("Choose a status.")
    return data, errors


@app.route("/maintenance")
def maintenance():
    query = request.args.get("q", "").strip()
    status = request.args.get("status", "")
    priority = request.args.get("priority", "")
    property_id = request.args.get("property", type=int)

    sql = """SELECT m.*, p.name AS property_name, u.name AS unit_name, t.full_name AS tenant_name
             FROM maintenance_requests m
             JOIN properties p ON p.id = m.property_id
             LEFT JOIN units u ON u.id = m.unit_id
             LEFT JOIN tenants t ON t.id = m.tenant_id
             WHERE (m.title LIKE ? OR m.description LIKE ?)"""
    args = [f"%{query}%", f"%{query}%"]
    if status in REQUEST_STATUSES:
        sql += " AND m.status = ?"
        args.append(status)
    if priority in PRIORITIES:
        sql += " AND m.priority = ?"
        args.append(priority)
    if property_id:
        sql += " AND m.property_id = ?"
        args.append(property_id)
    sql += """ ORDER BY CASE m.status WHEN 'Resolved' THEN 1 ELSE 0 END,
                        CASE m.priority WHEN 'High' THEN 0 WHEN 'Medium' THEN 1 ELSE 2 END,
                        m.date_reported DESC"""

    return render_template(
        "maintenance.html",
        rows=db.query_all(sql, args),
        properties=all_properties(),
        unit_choices=unit_options(),
        tenant_choices=active_tenants(),
        query=query,
        status=status,
        priority=priority,
        property_id=property_id,
        priorities=PRIORITIES,
        statuses=REQUEST_STATUSES,
    )


@app.post("/maintenance/add")
@write_access
def add_maintenance():
    data, errors = parse_maintenance()
    if errors:
        show_errors(errors)
        return go_back("maintenance")
    db.execute(
        "INSERT INTO maintenance_requests (property_id, unit_id, tenant_id, title, description, "
        "date_reported, priority, status) VALUES (:property_id, :unit_id, :tenant_id, :title, "
        ":description, :date_reported, :priority, :status)",
        data,
    )
    flash("Maintenance request created.", "success")
    return redirect(url_for("maintenance"))


@app.post("/maintenance/<int:request_id>/edit")
@write_access
def edit_maintenance(request_id):
    fetch_or_404("SELECT id FROM maintenance_requests WHERE id = ?", (request_id,))
    data, errors = parse_maintenance()
    if errors:
        show_errors(errors)
        return go_back("maintenance")
    data["id"] = request_id
    db.execute(
        "UPDATE maintenance_requests SET property_id = :property_id, unit_id = :unit_id, tenant_id = :tenant_id, "
        "title = :title, description = :description, date_reported = :date_reported, priority = :priority, "
        "status = :status WHERE id = :id",
        data,
    )
    flash("Maintenance request updated.", "success")
    return go_back("maintenance")


@app.post("/maintenance/<int:request_id>/status")
@write_access
def update_maintenance_status(request_id):
    fetch_or_404("SELECT id FROM maintenance_requests WHERE id = ?", (request_id,))
    status = field("status", 20)
    if status not in REQUEST_STATUSES:
        flash("Choose a valid status.", "error")
    else:
        db.execute("UPDATE maintenance_requests SET status = ? WHERE id = ?", (status, request_id))
        flash(f"Request marked “{status}”.", "success")
    return go_back("maintenance")


@app.post("/maintenance/<int:request_id>/delete")
@write_access
def delete_maintenance(request_id):
    fetch_or_404("SELECT id FROM maintenance_requests WHERE id = ?", (request_id,))
    db.execute("DELETE FROM maintenance_requests WHERE id = ?", (request_id,))
    flash("Maintenance request deleted.", "success")
    return redirect(url_for("maintenance"))


# ---------------------------------------------------------------------------
# Settings (administrators only)
# ---------------------------------------------------------------------------
@app.route("/settings", methods=["GET", "POST"])
@admin_only
def settings():
    if request.method == "POST":
        landlord_name = field("landlord_name", 80)
        currency = field("currency", 5)
        due_day = request.form.get("rent_due_day", type=int)
        errors = []
        if not landlord_name:
            errors.append("Your name is required.")
        if not currency:
            errors.append("A currency symbol is required.")
        if due_day is None or not 1 <= due_day <= 28:
            errors.append("Rent due day must be between 1 and 28.")
        if errors:
            show_errors(errors)
            return redirect(url_for("settings"))
        db.save_setting("landlord_name", landlord_name)
        db.save_setting("currency", currency)
        db.save_setting("rent_due_day", str(due_day))
        flash("Settings saved.", "success")
        return redirect(url_for("settings"))
    return render_template("settings.html")


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------
@app.errorhandler(CSRFError)
def handle_csrf_error(error):
    flash("Your session expired. Please try that again.", "error")
    return go_back("home")


@app.errorhandler(403)
def handle_forbidden(error):
    return render_template("error.html", code=403, message="You do not have permission to do that."), 403


@app.errorhandler(404)
def handle_not_found(error):
    return render_template("error.html", code=404, message="That page could not be found."), 404


@app.errorhandler(413)
def handle_too_large(error):
    return render_template("error.html", code=413, message="That request was too large."), 413


@app.errorhandler(500)
def handle_server_error(error):
    return render_template("error.html", code=500, message="Something went wrong on our side."), 500


if __name__ == "__main__":
    app.run(host=app.config["HOST"], port=app.config["PORT"], debug=app.config["DEBUG"])