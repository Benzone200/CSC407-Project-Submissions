# Keystone: Landlord Management System

A small, self-hosted web app for landlords to manage properties, units, tenants, rent payments and
maintenance requests. Built with Flask, SQLite, Jinja2 and vanilla JavaScript. It includes account
registration, sign-in, role-based access control, user profiles and a Security page.

## Prerequisites

- Python 3.9 or newer
- An internet connection in the browser (Lucide icons load from a CDN; everything else is local)

## Installation

```bash
cd landlord-management-system

# 1. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Configure the environment
cp .env.example .env              # Windows: copy .env.example .env
# Edit .env and set SECRET_KEY to a long random string
```

## Database

Nothing to do. `instance/landlord.db` and all tables are created automatically on first start.

## Run

```bash
python app.py
```

Open http://127.0.0.1:5000

## First use

1. Click **Create account**. The first account becomes the **Administrator** and is signed in at once.
2. Anyone who registers later is created as an inactive **Viewer**. Approve them, and change their role
   if needed, under **Users** (administrators only).

## Roles

| Role | Can do |
|---|---|
| Administrator | Everything, plus manage users and business settings |
| Manager | View and edit properties, units, tenants, payments and maintenance |
| Viewer | Read-only access |

## Going live

Read the **Security** page in the app. In short: serve over HTTPS, set `SESSION_COOKIE_SECURE=1`,
use a strong `SECRET_KEY`, keep `FLASK_DEBUG=0`, run behind a production server (for example
`waitress` or `gunicorn`) and back up `instance/landlord.db`.