import os
import secrets
from datetime import timedelta
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

INSTANCE_DIR = BASE_DIR / "instance"
INSTANCE_DIR.mkdir(exist_ok=True)


def _load_secret_key():
    """Use SECRET_KEY from the environment; otherwise create and reuse a local key file."""
    key = os.environ.get("SECRET_KEY")
    if key:
        return key
    key_file = INSTANCE_DIR / ".secret_key"
    if not key_file.exists():
        key_file.write_text(secrets.token_hex(32))
    return key_file.read_text().strip()


class Config:
    SECRET_KEY = _load_secret_key()
    DATABASE = os.environ.get("DATABASE_PATH") or str(INSTANCE_DIR / "landlord.db")
    DEBUG = os.environ.get("FLASK_DEBUG", "0") == "1"
    HOST = os.environ.get("HOST", "127.0.0.1")
    PORT = int(os.environ.get("PORT", "5000"))

    # Sessions and cookies
    SESSION_COOKIE_NAME = "keystone_session"
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.environ.get("SESSION_COOKIE_SECURE", "0") == "1"
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)

    # Request hardening
    MAX_CONTENT_LENGTH = 1024 * 1024  # reject request bodies over 1 MB
    WTF_CSRF_TIME_LIMIT = None

    # Sign-in protection
    MAX_LOGIN_ATTEMPTS = 5
    LOCKOUT_MINUTES = 15