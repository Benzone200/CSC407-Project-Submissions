(function () {
  "use strict";

  // Occupancy meter width (set here because the page's security policy blocks inline style attributes).
  document.querySelectorAll(".meter span[data-width]").forEach(function (bar) {
    bar.style.width = Number(bar.dataset.width) + "%";
  });

  var container = document.getElementById("rent-chart");
  var dataElement = document.getElementById("chart-data");
  if (!container || !dataElement) { return; }

  var points = JSON.parse(dataElement.textContent);
  var currency = container.dataset.currency || "";
  var maxValue = Math.max.apply(null, points.map(function (point) { return point.value; }).concat([1]));

  function formatValue(value) {
    return currency + Number(value).toLocaleString(undefined, { maximumFractionDigits: 0 });
  }

  points.forEach(function (point) {
    var column = document.createElement("div");
    column.className = "chart-col" + (point.current ? " is-current" : "");
    column.title = point.label + ": " + formatValue(point.value);

    var value = document.createElement("span");
    value.className = "chart-value";
    value.textContent = point.value > 0 ? formatValue(point.value) : "";

    var bar = document.createElement("div");
    bar.className = "chart-bar";
    var height = point.value > 0 ? Math.max((point.value / maxValue) * 100, 3) : 0;
    bar.style.height = height * 0.78 + "%";

    column.appendChild(value);
    column.appendChild(bar);
    container.appendChild(column);
  });

  var labels = document.createElement("div");
  labels.className = "chart-labels";
  points.forEach(function (point) {
    var label = document.createElement("span");
    label.textContent = point.label;
    labels.appendChild(label);
  });
  container.insertAdjacentElement("afterend", labels);
})();