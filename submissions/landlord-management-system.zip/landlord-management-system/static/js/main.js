(function () {
  "use strict";

  var body = document.body;
  var activeModal = null;

  function renderIcons() {
    if (window.lucide) { window.lucide.createIcons(); }
  }
  // The icon library loads with `defer`, so it is ready by the time this runs.
  renderIcons();
  window.addEventListener("load", renderIcons);

  /* ---------- Mobile navigation ---------- */
  document.querySelectorAll("[data-nav-toggle]").forEach(function (button) {
    button.addEventListener("click", function () { body.classList.toggle("nav-open"); });
  });

  /* ---------- Modals ---------- */
  function syncDependents(form) {
    // Unit options only show for the selected property.
    form.querySelectorAll("select[data-depends-on]").forEach(function (select) {
      var parent = form.elements.namedItem(select.dataset.dependsOn);
      var parentValue = parent ? parent.value : "";
      Array.prototype.forEach.call(select.options, function (option) {
        var matches = !option.dataset.property || option.dataset.property === parentValue;
        option.hidden = !matches;
        option.disabled = !matches;
      });
      if (select.selectedOptions[0] && select.selectedOptions[0].disabled) { select.value = ""; }
    });
  }

  function fillForm(form, values) {
    Object.keys(values).forEach(function (key) {
      var input = form.elements.namedItem(key);
      if (!input || input.type === "hidden") { return; }
      var value = values[key];
      input.value = value === null || value === undefined ? "" : value;
    });
  }

  function openModal(modal, trigger) {
    if (!modal) { return; }
    var form = modal.querySelector("form");
    var title = modal.querySelector(".modal-head h2");
    if (trigger) {
      form.reset();
      form.action = trigger.dataset.action || form.dataset.defaultAction;
      title.textContent = trigger.dataset.title || title.dataset.default;
      if (trigger.dataset.values) { fillForm(form, JSON.parse(trigger.dataset.values)); }
    }
    syncDependents(form);
    modal.hidden = false;
    body.classList.add("modal-open");
    activeModal = modal;
    var first = form.querySelector("input:not([type=hidden]), select, textarea");
    if (first) { first.focus(); }
  }

  function closeModal() {
    if (!activeModal) { return; }
    activeModal.hidden = true;
    body.classList.remove("modal-open");
    activeModal = null;
  }

  document.addEventListener("click", function (event) {
    var opener = event.target.closest("[data-modal-open]");
    if (opener) {
      event.preventDefault();
      openModal(document.getElementById(opener.dataset.modalOpen), opener);
      return;
    }
    if (event.target.closest("[data-modal-close]")) {
      closeModal();
      return;
    }
    var dismiss = event.target.closest("[data-dismiss]");
    if (dismiss) { dismiss.closest(".flash").remove(); }
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
      closeModal();
      body.classList.remove("nav-open");
    }
  });

  var autoOpen = document.querySelector(".modal[data-auto-open]");
  if (autoOpen) { openModal(autoOpen, null); }

  /* ---------- Form behaviour ---------- */
  document.addEventListener("change", function (event) {
    var element = event.target;

    // Filters and inline status selects submit as soon as they change.
    if (element.matches("[data-autosubmit]") && element.form) {
      if (element.form.requestSubmit) { element.form.requestSubmit(); } else { element.form.submit(); }
      return;
    }

    // Choosing a unit or tenant fills in the related amount.
    if (element.matches("[data-fill]") && element.form) {
      var target = element.form.elements.namedItem(element.dataset.fill);
      var option = element.selectedOptions[0];
      if (target && option && option.dataset.rent !== undefined) { target.value = option.dataset.rent; }
    }

    if (element.form && element.form.querySelector("[data-depends-on]")) { syncDependents(element.form); }
  });

  // Confirm destructive actions and give feedback while a form is saving.
  document.addEventListener("submit", function (event) {
    var form = event.target;
    if (form.dataset.confirm && !window.confirm(form.dataset.confirm)) {
      event.preventDefault();
      return;
    }
    if (form.method.toLowerCase() === "post") {
      var button = form.querySelector("button[type=submit]");
      if (button) {
        setTimeout(function () {
          button.disabled = true;
          button.classList.add("is-loading");
        }, 0);
      }
    }
  });

  // Restore buttons if the browser shows this page again from its back/forward cache.
  window.addEventListener("pageshow", function () {
    document.querySelectorAll("button.is-loading").forEach(function (button) {
      button.disabled = false;
      button.classList.remove("is-loading");
    });
  });

  /* ---------- Flash messages ---------- */
  document.querySelectorAll(".flash-success").forEach(function (flash) {
    setTimeout(function () { flash.remove(); }, 5000);
  });
})();