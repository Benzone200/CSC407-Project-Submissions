import os
import sqlite3
from contextlib import closing

from flask import current_app, g

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name       TEXT NOT NULL,
    email           TEXT NOT NULL UNIQUE COLLATE NOCASE,
    phone           TEXT NOT NULL DEFAULT '',
    password_hash   TEXT NOT NULL,
    role            TEXT NOT NULL DEFAULT 'viewer' CHECK (role IN ('admin', 'manager', 'viewer')),
    is_active       INTEGER NOT NULL DEFAULT 0 CHECK (is_active IN (0, 1)),
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    locked_until    TEXT,
    last_login      TEXT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS properties (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT NOT NULL,
    address       TEXT NOT NULL,
    property_type TEXT NOT NULL DEFAULT 'Apartment Building',
    description   TEXT NOT NULL DEFAULT '',
    date_added    TEXT NOT NULL DEFAULT (date('now'))
);

CREATE TABLE IF NOT EXISTS units (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    property_id  INTEGER NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    name         TEXT NOT NULL,
    monthly_rent REAL NOT NULL CHECK (monthly_rent >= 0),
    description  TEXT NOT NULL DEFAULT '',
    UNIQUE (property_id, name)
);

CREATE TABLE IF NOT EXISTS tenants (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name         TEXT NOT NULL,
    phone             TEXT NOT NULL,
    email             TEXT NOT NULL DEFAULT '',
    unit_id           INTEGER NOT NULL REFERENCES units(id) ON DELETE CASCADE,
    lease_start       TEXT NOT NULL,
    lease_end         TEXT,
    monthly_rent      REAL NOT NULL CHECK (monthly_rent >= 0),
    emergency_contact TEXT NOT NULL DEFAULT '',
    is_active         INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    move_out_date     TEXT
);

-- A unit can never have two active tenants at once.
CREATE UNIQUE INDEX IF NOT EXISTS idx_one_active_tenant_per_unit
    ON tenants(unit_id) WHERE is_active = 1;

CREATE TABLE IF NOT EXISTS rent_payments (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id    INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    unit_id      INTEGER NOT NULL REFERENCES units(id) ON DELETE CASCADE,
    amount       REAL NOT NULL CHECK (amount > 0),
    payment_date TEXT NOT NULL,
    period       TEXT NOT NULL,
    method       TEXT NOT NULL,
    reference    TEXT NOT NULL DEFAULT '',
    notes        TEXT NOT NULL DEFAULT '',
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS maintenance_requests (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    property_id   INTEGER NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    unit_id       INTEGER REFERENCES units(id) ON DELETE SET NULL,
    tenant_id     INTEGER REFERENCES tenants(id) ON DELETE SET NULL,
    title         TEXT NOT NULL,
    description   TEXT NOT NULL DEFAULT '',
    date_reported TEXT NOT NULL,
    priority      TEXT NOT NULL DEFAULT 'Medium' CHECK (priority IN ('Low', 'Medium', 'High')),
    status        TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'In Progress', 'Resolved'))
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_units_property     ON units(property_id);
CREATE INDEX IF NOT EXISTS idx_tenants_unit       ON tenants(unit_id);
CREATE INDEX IF NOT EXISTS idx_payments_tenant    ON rent_payments(tenant_id, period);
CREATE INDEX IF NOT EXISTS idx_payments_period    ON rent_payments(period);
CREATE INDEX IF NOT EXISTS idx_maintenance_prop   ON maintenance_requests(property_id);
CREATE INDEX IF NOT EXISTS idx_maintenance_status ON maintenance_requests(status);
"""

DEFAULT_SETTINGS = {"landlord_name": "Landlord", "currency": "$", "rent_due_day": "1"}


def get_db():
    """Return the SQLite connection for the current request."""
    if "db" not in g:
        connection = sqlite3.connect(current_app.config["DATABASE"])
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        g.db = connection
    return g.db


def close_db(error=None):
    connection = g.pop("db", None)
    if connection is not None:
        connection.close()


def query_all(sql, args=()):
    return [dict(row) for row in get_db().execute(sql, args).fetchall()]


def query_one(sql, args=()):
    row = get_db().execute(sql, args).fetchone()
    return dict(row) if row else None


def execute(sql, args=()):
    """Run a write statement, commit, and return the new row id."""
    connection = get_db()
    cursor = connection.execute(sql, args)
    connection.commit()
    return cursor.lastrowid


def get_settings():
    if "settings" not in g:
        stored = {row["key"]: row["value"] for row in query_all("SELECT key, value FROM settings")}
        g.settings = {**DEFAULT_SETTINGS, **stored}
    return g.settings


def save_setting(key, value):
    execute(
        "INSERT INTO settings (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )
    g.pop("settings", None)


def init_db(app):
    """Create the database file, tables and default settings on first start."""
    path = app.config["DATABASE"]
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with closing(sqlite3.connect(path)) as connection:
        connection.execute("PRAGMA foreign_keys = ON")
        connection.executescript(SCHEMA)
        for key, value in DEFAULT_SETTINGS.items():
            connection.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (key, value))
        connection.commit()


def init_app(app):
    app.teardown_appcontext(close_db)
    init_db(app)