process.env.NODE_ENV = 'test';
process.env.DB_PATH = ':memory:';
process.env.SESSION_SECRET = 'x'.repeat(40);
process.env.ADMIN_EMAIL = 'admin@test.local';
process.env.ADMIN_PASSWORD = 'AdminPass12345';

const test = require('node:test');
const assert = require('node:assert');
const app = require('../server');

let server, base;
test.before(async () => {
  await new Promise((r) => { server = app.listen(0, r); });
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => server.close());

// Tiny HTTP client with a cookie jar and CSRF handling
function client() {
  const jar = {};
  async function req(path, opts = {}) {
    const cookie = Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await fetch(base + path, { redirect: 'manual', ...opts, headers: { ...(opts.headers || {}), cookie } });
    for (const c of res.headers.getSetCookie()) {
      const [kv] = c.split(';'); const i = kv.indexOf('=');
      jar[kv.slice(0, i)] = kv.slice(i + 1);
    }
    return res;
  }
  async function token(path) {
    const html = await (await req(path)).text();
    return /name="_csrf" value="([^"]+)"/.exec(html)[1];
  }
  async function post(path, form, tokenPath) {
    const _csrf = await token(tokenPath || path);
    return req(path, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ _csrf, ...form })
    });
  }
  return { req, post, token };
}

const good = { name: 'Test User', email: 'user@test.local', password: 'GoodPass12345', confirm: 'GoodPass12345' };

test('home page loads', async () => {
  const res = await client().req('/');
  assert.equal(res.status, 200);
});

test('security headers are present', async () => {
  const res = await client().req('/');
  assert.ok(res.headers.get('content-security-policy'));
  assert.ok(res.headers.get('x-frame-options'));
  assert.equal(res.headers.get('x-powered-by'), null);
});

test('registration validation rejects empty and weak input', async () => {
  const c = client();
  assert.equal((await c.post('/register', { name: '', email: '', password: '', confirm: '' })).status, 400);
  assert.equal((await c.post('/register', { ...good, password: 'abc', confirm: 'abc' })).status, 400);
});

test('register, access, logout, wrong password, SQL injection', async () => {
  const c = client();
  assert.equal((await c.post('/register', good)).status, 302);
  assert.equal((await c.req('/businesses/new')).status, 200);        // logged in
  await c.post('/logout', {}, '/businesses/new');
  assert.equal((await c.req('/businesses/new')).status, 302);        // redirected to login
  assert.equal((await c.post('/login', { email: good.email, password: 'WrongPass12345' })).status, 401);
  assert.equal((await c.post('/login', { email: "' OR 1=1 --", password: "' OR 1=1 --" })).status, 401);
  assert.equal((await c.post('/login', { email: good.email, password: good.password })).status, 302);
});

test('normal user cannot open admin; admin can', async () => {
  const u = client();
  await u.post('/login', { email: good.email, password: good.password });
  assert.equal((await u.req('/admin')).status, 403);
  const a = client();
  await a.post('/login', { email: 'admin@test.local', password: 'AdminPass12345' });
  assert.equal((await a.req('/admin')).status, 200);
});

test('POST without CSRF token is rejected', async () => {
  const res = await client().req('/login', {
    method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ email: 'a@b.co', password: 'x' })
  });
  assert.equal(res.status, 403);
});

test('XSS payload is escaped; other users cannot edit the listing', async () => {
  const u = client();
  await u.post('/login', { email: good.email, password: good.password });
  const payload = '<script>alert(1)</script>';
  const res = await u.post('/businesses', {
    name: payload, category: 'Retail', description: 'A valid description text',
    phone: '+234 801 234 5678', address: '1 Main Street', city: 'Lagos'
  }, '/businesses/new');
  assert.equal(res.status, 302);
  const loc = res.headers.get('location');
  const html = await (await u.req(loc)).text();
  assert.ok(!html.includes(payload));
  assert.ok(html.includes('&lt;script&gt;'));

  const other = client();
  await other.post('/register', { name: 'Other', email: 'other@test.local', password: 'GoodPass12345', confirm: 'GoodPass12345' });
  assert.equal((await other.req(loc + '/edit')).status, 403);
});

test('404 and invalid id are handled gracefully', async () => {
  const c = client();
  assert.equal((await c.req('/nonexistent')).status, 404);
  assert.equal((await c.req('/businesses/abc')).status, 404);
});
