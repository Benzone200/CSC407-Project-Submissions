const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

const dbPath = process.env.DB_PATH || './data/directory.db';
if (dbPath !== ':memory:') fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS businesses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT NOT NULL,
  city TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS security_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event TEXT NOT NULL,
  user_id INTEGER,
  ip TEXT,
  detail TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_biz_category ON businesses(category);
CREATE INDEX IF NOT EXISTS idx_biz_city ON businesses(city);
`);

// Audit logging helper (parameterised)
db.log = (event, userId, ip, detail = '') =>
  db.prepare('INSERT INTO security_log(event,user_id,ip,detail) VALUES(?,?,?,?)')
    .run(event, userId || null, ip || null, String(detail).slice(0, 200));

// Seed first admin from environment variables (never hard-coded)
if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
  const exists = db.prepare("SELECT 1 FROM users WHERE role='admin'").get();
  if (!exists) {
    db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')")
      .run('Administrator', process.env.ADMIN_EMAIL.toLowerCase(),
           bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12));
    console.log('Admin account created from environment variables.');
  }
}

module.exports = db;
