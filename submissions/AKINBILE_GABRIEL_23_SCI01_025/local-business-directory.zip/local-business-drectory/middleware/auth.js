const db = require('../db');

// Runs on every request: loads the user from the session and flash messages
function loadUser(req, res, next) {
  res.locals.user = null;
  res.locals.flash = null;
  if (req.session.flash) {
    res.locals.flash = req.session.flash;
    delete req.session.flash;
  }
  if (req.session.userId) {
    const u = db.prepare('SELECT id,name,email,role,created_at FROM users WHERE id=?').get(req.session.userId);
    if (u) { req.user = u; res.locals.user = u; }
    else delete req.session.userId; // account was deleted
  }
  next();
}

function requireLogin(req, res, next) {
  if (!req.user) {
    req.session.flash = { type: 'error', text: 'Please log in first.' };
    return res.redirect('/login');
  }
  next();
}

// Role-based access control
const requireRole = (role) => (req, res, next) => {
  if (!req.user) return requireLogin(req, res, next);
  if (req.user.role !== role) {
    db.log('access_denied', req.user.id, req.ip, req.originalUrl);
    return res.status(403).render('error', {
      title: 'Access denied', message: 'You do not have permission to view this page.'
    });
  }
  next();
};

module.exports = { loadUser, requireLogin, requireRole };
