require('dotenv').config();
const bcrypt = require('bcryptjs');
const db = require('./db'); // also creates the admin from .env if none exists

const DEMO_PASSWORD = 'Demo-Pass-123'; // demo only, never use in production

const users = [
  { name: 'Alice Johnson', email: 'alice@demo.local' },
{ name: 'Brian Okafor',  email: 'brian@demo.local' },
{ name: 'Chloe Martins', email: 'chloe@demo.local' },
{ name: 'David Mensah',  email: 'david@demo.local' }
];

// owner = index into the users array above
const businesses = [
  [0, 'Sunrise Bakery', 'Restaurant', 'Fresh bread, pastries and custom cakes baked every morning using local ingredients.', '+1 555 010 1001', '12 Market Street', 'Riverside'],
[0, 'Green Leaf Cafe', 'Restaurant', 'Cozy cafe serving organic coffee, smoothies and light vegetarian meals.', '+1 555 010 1002', '48 Garden Road', 'Hillview'],
[0, 'Spice Route Kitchen', 'Restaurant', 'Family-run kitchen with authentic regional dishes, dine-in and takeaway.', '+1 555 010 1003', '7 Harbour Lane', 'Lakeside'],
[1, 'City Hardware Store', 'Retail', 'Tools, paint, plumbing and electrical supplies for homes and contractors.', '+1 555 010 2001', '230 Main Avenue', 'Riverside'],
[1, 'Bookworm Corner', 'Retail', 'Independent bookstore with new and second-hand books, plus a kids reading area.', '+1 555 010 2002', '5 College Street', 'Hillview'],
[1, 'Fresh Basket Grocers', 'Retail', 'Neighbourhood grocery with fresh produce delivered daily from nearby farms.', '+1 555 010 2003', '91 Orchard Road', 'Lakeside'],
[2, 'CarePlus Clinic', 'Health', 'General practice clinic offering consultations, vaccinations and health screening.', '+1 555 010 3001', '3 Wellness Drive', 'Riverside'],
[2, 'SmileBright Dental', 'Health', 'Friendly dental care including check-ups, cleaning and whitening treatments.', '+1 555 010 3002', '18 Park Avenue', 'Hillview'],
[2, 'Vital Pharmacy', 'Health', 'Prescriptions, over-the-counter medicines and friendly pharmacist advice.', '+1 555 010 3003', '66 High Street', 'Lakeside'],
[3, 'QuickFix Plumbing', 'Services', 'Emergency and scheduled plumbing repairs, available 24 hours a day.', '+1 555 010 4001', '14 Industrial Way', 'Riverside'],
[3, 'Sparkle Cleaners', 'Services', 'Professional home and office cleaning with eco-friendly products.', '+1 555 010 4002', '29 Elm Street', 'Hillview'],
[3, 'BrightMinds Tutoring', 'Education', 'After-school tutoring in maths, science and English for primary and secondary students.', '+1 555 010 4003', '8 School Lane', 'Lakeside'],
[0, 'Code Academy Hub', 'Education', 'Beginner-friendly evening classes in web development and digital skills.', '+1 555 010 5001', '101 Tech Plaza', 'Riverside'],
[1, 'Glow Beauty Salon', 'Beauty', 'Hair styling, braiding, nails and skincare treatments by experienced stylists.', '+1 555 010 5002', '22 Rose Avenue', 'Hillview'],
[2, 'Gentleman Barbers', 'Beauty', 'Classic cuts, beard trims and hot-towel shaves in a relaxed setting.', '+1 555 010 5003', '40 Union Street', 'Lakeside'],
[3, 'AutoCare Garage', 'Automotive', 'Servicing, brake repairs, tyres and diagnostics for all vehicle makes.', '+1 555 010 6001', '77 Motor Way', 'Riverside'],
[0, 'Shine Car Wash', 'Automotive', 'Hand car wash, interior detailing and polishing while you wait.', '+1 555 010 6002', '15 Station Road', 'Hillview'],
[1, 'Local Print & Copy', 'Other', 'Printing, photocopying, binding and banners for students and small businesses.', '+1 555 010 6003', '33 Square Street', 'Lakeside']
];

const insertUser = db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'user')");
const findUser = db.prepare('SELECT id FROM users WHERE email=?');
const insertBiz = db.prepare(`INSERT INTO businesses(owner_id,name,category,description,phone,address,city)
VALUES(?,?,?,?,?,?,?)`);
const bizExists = db.prepare('SELECT 1 FROM businesses WHERE name=? AND owner_id=?');

db.transaction(() => {
  const ids = users.map((u) => {
    const row = findUser.get(u.email);
    if (row) return row.id;
    return insertUser.run(u.name, u.email, bcrypt.hashSync(DEMO_PASSWORD, 12)).lastInsertRowid;
  });

  let added = 0;
  for (const [owner, name, category, description, phone, address, city] of businesses) {
    if (!bizExists.get(name, ids[owner])) {
      insertBiz.run(ids[owner], name, category, description, phone, address, city);
      added++;
    }
  }
  console.log(`Seed complete. Users: ${users.length}, new businesses added: ${added}`);
})();

console.log(`Demo users log in with password: ${DEMO_PASSWORD}`);
