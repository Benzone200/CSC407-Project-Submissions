# 📍 Local Business Directory

A secure, responsive web application where people can discover local businesses and registered users can list and manage their own. Built as a web application security project: the focus is on **authentication, access control, input validation, and protection against common web attacks** (SQL injection, XSS, CSRF), together with testing, deployment, and evaluation.

---

## Table of Contents

1. [Features](#features)
2. [Tech Stack](#tech-stack)
3. [Project Structure](#project-structure)
4. [Getting Started](#getting-started)
5. [Configuration](#configuration)
6. [Demo Data and Accounts](#demo-data-and-accounts)
7. [Usage Guide](#usage-guide)
8. [Application Routes](#application-routes)
9. [Database Schema](#database-schema)
10. [Security Measures](#security-measures)
11. [Testing](#testing)
12. [Deployment](#deployment)
13. [Troubleshooting](#troubleshooting)
14. [Limitations](#limitations)
15. [Future Improvements](#future-improvements)
16. [Author and License](#author-and-license)

---

## Features

**For visitors**
- Home dashboard with statistics, search box, and latest listings
- Browse the directory with **search**, **category filter**, **city filter**, and **pagination**
- View full business details

**For registered users**
- Register, log in, and log out
- Profile page: update name and change password
- Add, edit, and delete **their own** business listings

**For administrators**
- Admin panel listing all users and their listing counts
- Promote/demote users (user ↔ admin) and delete users
- View recent security events (logins, failures, denied access, role changes)

**General**
- Responsive layout for phone and desktop (CSS-only mobile menu)
- Built-in pages documenting **Security**, **Testing**, **Deployment**, and **Project Review**
- Friendly error pages (no stack traces shown to users)

---

## Tech Stack

| Layer | Technology |
|---|---|
| Runtime | Node.js (18+; tested on Node 24) |
| Web framework | Express 4 |
| Templating | EJS (auto-escaped output) |
| Database | SQLite via `better-sqlite3` |
| Password hashing | `bcryptjs` (cost factor 12) |
| Sessions | `express-session` |
| Security headers | `helmet` |
| Rate limiting | `express-rate-limit` |
| Logging | `morgan` + custom `security_log` table |
| Config | `dotenv` |
| Testing | Node's built-in test runner (`node:test`) |

---

## Project Structure

```
local-business-directory/
├── server.js               # App setup: security headers, sessions, CSRF, routes, error handling
├── db.js                   # SQLite connection, schema, audit-log helper, admin seeding
├── seed.js                 # Optional demo users and businesses
├── package.json
├── .gitignore
├── middleware/
│   └── auth.js             # loadUser, requireLogin, requireRole
├── utils/
│   └── validate.js         # Input validation helpers
├── routes/
│   ├── pages.js            # Home + Security/Testing/Deployment/Review pages
│   ├── auth.js             # Register, login, logout
│   ├── account.js          # Profile and password change
│   ├── businesses.js       # Directory CRUD, search, filters
│   └── admin.js            # Admin panel
├── views/                  # EJS templates (+ partials/header, footer)
├── public/css/style.css    # Responsive styles
└── tests/app.test.js       # Automated functional + security tests
```

---

## Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) **18 or newer** (20 LTS or later recommended)
- npm (comes with Node)
- A terminal and a code editor such as VS Code

Check your versions:

```bash
node -v
npm -v
```

### Installation

```bash
# 1. Open the project folder
cd local-business-directory

# 2. Install dependencies
npm install

# 3. Create your environment file
cp .env.example .env          # Windows (cmd): copy .env.example .env

# 4. (Optional) Load demo users and businesses
npm run seed

# 5. Start the app
npm start
```

Open **http://localhost:3000** in your browser.

For development with auto-restart on file changes:

```bash
npm run dev
```

---

## Configuration

All settings are read from environment variables (in a `.env` file locally).

| Variable | Description | Example |
|---|---|---|
| `NODE_ENV` | `development` or `production`. Production enables Secure cookies, HSTS, and requires `SESSION_SECRET`. | `development` |
| `PORT` | Port the server listens on. | `3000` |
| `SESSION_SECRET` | Long random string used to sign session cookies. **Required in production.** | *(48+ random characters)* |
| `DB_PATH` | Location of the SQLite database file. | `./data/directory.db` |
| `ADMIN_EMAIL` | Email of the first admin account (created automatically if no admin exists). | `admin@example.com` |
| `ADMIN_PASSWORD` | Password of the first admin account. | `ChangeMe-Admin-123` |

Generate a strong secret:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

> ⚠️ Never commit your real `.env` file. It is listed in `.gitignore`.

> The admin account is only created when **no admin exists yet**. Changing `ADMIN_EMAIL` or `ADMIN_PASSWORD` later has no effect on an existing database.

---

## Demo Data and Accounts

`npm run seed` adds 4 demo users and 18 sample businesses across 8 categories and 3 cities. It is safe to run more than once (existing records are skipped).

| Account | Email | Password | Role |
|---|---|---|---|
| Admin | value of `ADMIN_EMAIL` | value of `ADMIN_PASSWORD` | admin |
| Alice | `alice@demo.local` | `Demo-Pass-123` | user |
| Brian | `brian@demo.local` | `Demo-Pass-123` | user |
| Chloe | `chloe@demo.local` | `Demo-Pass-123` | user |
| David | `david@demo.local` | `Demo-Pass-123` | user |

> ⚠️ The demo password is public. **Never run the seed script on a live deployment.**

**Reset everything:** stop the server, delete the `data/` folder, then run `npm run seed` and `npm start` again.

---

## Usage Guide

1. **Browse:** open the Directory, then search by keyword and filter by category or city.
2. **Register:** create an account (password needs 10+ characters with upper-case, lower-case, and a number).
3. **Add a business:** log in, click **Add business**, and fill in the form.
4. **Manage listings:** open your listing, then use **Edit** or **Delete** (only the owner or an admin sees these).
5. **Admin:** log in as admin and click **Admin** in the menu to manage users and view security events.

---

## Application Routes

| Method | Path | Access | Purpose |
|---|---|---|---|
| GET | `/` | Public | Home dashboard |
| GET | `/businesses` | Public | Search, filter, and list businesses |
| GET | `/businesses/:id` | Public | Business details |
| GET/POST | `/businesses/new`, `/businesses` | Logged in | Add a business |
| GET/POST | `/businesses/:id/edit` | Owner or admin | Edit a business |
| POST | `/businesses/:id/delete` | Owner or admin | Delete a business |
| GET/POST | `/register` | Public | Create account |
| GET/POST | `/login` | Public | Log in |
| POST | `/logout` | Logged in | Log out |
| GET/POST | `/profile` | Logged in | View/update profile |
| POST | `/profile/password` | Logged in | Change password |
| GET | `/admin` | Admin only | User list and security log |
| POST | `/admin/users/:id/role` | Admin only | Change a user's role |
| POST | `/admin/users/:id/delete` | Admin only | Delete a user |
| GET | `/security`, `/testing`, `/deployment`, `/review` | Public | Project documentation pages |

---

## Database Schema

SQLite database created automatically on first start.

**users**: `id`, `name`, `email` (unique), `password_hash`, `role` (`user`/`admin`), `created_at`

**businesses**: `id`, `owner_id` → users (cascade delete), `name`, `category`, `description`, `phone`, `address`, `city`, `created_at`

**security_log**: `id`, `event`, `user_id`, `ip`, `detail`, `created_at`

Foreign keys and WAL journaling are enabled. Indexes exist on `category` and `city`.

---

## Security Measures

| Area | Implementation |
|---|---|
| **Authentication** | Email and password login; logout destroys the session and clears the cookie; generic error messages prevent account enumeration |
| **Password hashing** | bcrypt, cost 12, per-password salt; passwords are never stored in plain text or logged |
| **Role-based access** | `user` and `admin` roles; `requireRole('admin')` guards all `/admin` routes; new sign-ups are always `user` |
| **Access-control checks** | Edit/delete limited to listing owner or admin (prevents IDOR); admins cannot change or delete their own account from the panel |
| **Input validation** | Server-side checks on every field (length, format, allow-lists, integer IDs); request body limited to 10 KB |
| **SQL injection** | Parameterised prepared statements everywhere; LIKE wildcards escaped |
| **XSS** | EJS escapes all output; Content-Security-Policy blocks inline and third-party scripts; HttpOnly cookies |
| **CSRF** | Per-session token required on every POST (timing-safe comparison); `SameSite=Lax` cookies |
| **Session management** | Session ID regenerated on login/register (prevents fixation); 30-minute idle timeout; `HttpOnly`, `SameSite`, `Secure` (production) |
| **Brute-force protection** | 10 login/registration attempts per 15 minutes per IP |
| **Security headers / HTTPS** | Helmet headers; HSTS and Secure cookies in production; TLS terminated by Nginx or the hosting platform |
| **Sensitive data** | Secrets in environment variables; generic error pages (no stack traces); passwords excluded from logs |
| **Auditing** | Logins, failures, rate limiting, role changes, deletions, and denied access are written to `security_log` |

Key code locations: `server.js` (headers, sessions, CSRF), `routes/auth.js` (hashing, login, rate limiting), `middleware/auth.js` (RBAC), `routes/businesses.js` (validation, ownership, SQL).

---

## Testing

### Automated tests

```bash
npm test
```

Runs 8 tests against an in-memory database covering: home page, security headers, registration validation, register/login/logout, wrong password, SQL injection attempt, admin access control, CSRF rejection, XSS escaping, ownership checks, and 404 handling.

### Manual tests

The **/testing** page in the app lists every test (functional, login/registration, form validation, security, usability, responsive, error handling, database) with expected results, and columns to record actual results and status. Key manual checks:

- SQL injection in search: `' OR '1'='1` returns no special results
- XSS: a business named `<script>alert(1)</script>` displays as text
- Missing CSRF token on a POST returns 403
- Normal user opening `/admin` gets "Access denied"
- 11 failed logins trigger "Too many attempts"
- 375px viewport: menu collapses, no horizontal scrolling

---

## Deployment

A full walkthrough is available in the app at **/deployment**. Summary:

1. **Set environment variables:** `NODE_ENV=production`, a strong `SESSION_SECRET`, `DB_PATH` on a persistent disk, and admin credentials.
2. **Install and run:**
   ```bash
   npm ci --omit=dev
   NODE_ENV=production pm2 start server.js --name directory
   pm2 save && pm2 startup
   ```
3. **HTTPS:** run Node behind Nginx and issue a certificate with Let's Encrypt (`sudo certbot --nginx -d yourdomain.com`). Redirect HTTP to HTTPS.
4. **Firewall:** allow only ports 22, 80, and 443.
5. **Backups:** schedule a daily `sqlite3 ... ".backup ..."` cron job and copy backups off-server.
6. **Monitoring:** use `logs/access.log`, `logs/error.log`, the `security_log` table, log rotation, and an uptime monitor.
7. **Do not** run `npm run seed` in production.

PaaS option (Render, Railway, Fly.io): set build command `npm install`, start command `npm start`, add the environment variables, and attach a persistent disk for the database.

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `npm test` fails with *Cannot find module '.../tests'* | Make sure the script is `"test": "node --test tests/app.test.js"` |
| `better-sqlite3` fails to install or load | Use Node 20 LTS or later, then run `npm install better-sqlite3@latest`. On Windows, install the C++ build tools if needed |
| Cannot log in as admin | Check that `.env` exists with `ADMIN_EMAIL`/`ADMIN_PASSWORD`. If the DB already existed, delete `data/` and restart (this wipes data) |
| Logged-out user is redirected to login on public pages | Ensure `routes/account.js` uses `router.use('/profile', requireLogin)` and not `router.use(requireLogin)` |
| "Invalid or missing security token" | Refresh the page and resubmit; the form must include the hidden `_csrf` field |
| Locked out by rate limiting | Wait 15 minutes or restart the server |
| Port 3000 already in use | Change `PORT` in `.env` |
| App exits in production with "SESSION_SECRET is required" | Set `SESSION_SECRET` in the environment |

---

## Limitations

- No email verification or password reset
- In-memory session store: sessions are lost on restart and the app supports a single instance only
- No multi-factor authentication; protection against guessing is IP-based rate limiting only
- SQLite is not ideal for heavy concurrent writes
- No image uploads, maps, ratings, or reviews

## Future Improvements

- Email verification, password reset, and TOTP two-factor authentication
- PostgreSQL and a persistent session store (Redis or SQLite store)
- Ratings and reviews, business photos (with upload validation), and map integration
- Admin approval workflow for new listings
- CI pipeline running `npm test` and `npm audit` on every commit

---

## Author and License

**Author:** _Your name_
**Course / Institution:** _Your course and institution_
**License:** _Choose a license, e.g. MIT, or state "For educational use"_

> This project is built for learning purposes. Review and harden it further (see Limitations) before using it for real users or real data.
