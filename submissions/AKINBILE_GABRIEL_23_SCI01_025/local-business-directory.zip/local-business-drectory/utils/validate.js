const clean = (s) => String(s ?? '').trim();
const isEmail = (s) => s.length <= 254 && /^[^\s@]{1,64}@[^\s@]+\.[^\s@]{2,}$/.test(s);

// Returns an error message, or null if the password is acceptable
function strongPassword(p) {
  if (p.length < 10) return 'Password must be at least 10 characters.';
  if (p.length > 72) return 'Password must be at most 72 characters.';
  if (!/[a-z]/.test(p) || !/[A-Z]/.test(p) || !/\d/.test(p))
    return 'Password needs an uppercase letter, a lowercase letter and a number.';
  return null;
}

module.exports = { clean, isEmail, strongPassword };
