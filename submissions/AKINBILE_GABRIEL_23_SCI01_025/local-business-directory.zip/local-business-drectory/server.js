require('dotenv').config();
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const session = require('express-session');
const morgan = require('morgan');
const { loadUser } = require('./middleware/auth');
require('./db');

const isProd = process.env.NODE_ENV === 'production';
const isTest = process.env.NODE_ENV === 'test';
const app = express();

if (isProd) {
  if (!process.env.SESSION_SECRET) { console.error('SESSION_SECRET is required in production.'); process.exit(1); }
  app.set('trust proxy', 1); // behind Nginx / a PaaS proxy
}
const secret = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.disable('x-powered-by');

// Security headers (CSP blocks inline scripts => strong XSS defence-in-depth)
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      ...helmet.contentSecurityPolicy.getDefaultDirectives(),
      'upgrade-insecure-requests': isProd ? [] : null
    }
  },
  strictTransportSecurity: isProd ? { maxAge: 15552000 } : false
}));

// Access logging
if (!isTest) {
  fs.mkdirSync('logs', { recursive: true });
  app.use(morgan('combined', { stream: fs.createWriteStream('logs/access.log', { flags: 'a' }) }));
  app.use(morgan('dev'));
}

app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Session management
app.use(session({
  name: 'sid',
  secret,
  resave: false,
  saveUninitialized: true,
  rolling: true,
  cookie: {
    httpOnly: true,           // JS cannot read the cookie
    sameSite: 'lax',          // CSRF mitigation
    secure: isProd,           // HTTPS only in production
    maxAge: 30 * 60 * 1000    // 30-minute idle timeout
  }
}));

app.use(loadUser);

// CSRF protection (synchroniser token)
app.use((req, res, next) => {
  if (!req.session.csrf) req.session.csrf = crypto.randomBytes(24).toString('hex');
  res.locals.csrfToken = req.session.csrf;
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    const sent = Buffer.from(String(req.body?._csrf || ''));
    const real = Buffer.from(req.session.csrf);
    if (sent.length !== real.length || !crypto.timingSafeEqual(sent, real)) {
      return res.status(403).render('error', {
        title: 'Forbidden',
        message: 'Invalid or missing security token. Go back, refresh the page and try again.'
      });
    }
  }
  next();
});

app.use('/', require('./routes/pages'));
app.use('/', require('./routes/auth'));
app.use('/', require('./routes/account'));
app.use('/businesses', require('./routes/businesses'));
app.use('/admin', require('./routes/admin'));

// 404
app.use((req, res) => res.status(404).render('error', { title: 'Not found', message: 'That page does not exist.' }));

// Central error handler: log details, show a generic message (no stack traces)
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  console.error(err);
  if (!isTest) fs.appendFileSync('logs/error.log', `${new Date().toISOString()} ${req.method} ${req.originalUrl} ${err.stack}\n`);
  res.status(500).render('error', { title: 'Server error', message: 'Something went wrong. Please try again later.' });
});

if (require.main === module) {
  const port = process.env.PORT || 3000;
  app.listen(port, () => console.log(`Running on http://localhost:${port}`));
}
module.exports = app;
