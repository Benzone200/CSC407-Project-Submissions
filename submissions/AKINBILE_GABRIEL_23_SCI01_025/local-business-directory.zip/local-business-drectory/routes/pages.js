const router = require('express').Router();
const db = require('../db');

router.get('/', (req, res) => {
  const stats = {
    businesses: db.prepare('SELECT COUNT(*) c FROM businesses').get().c,
    users: db.prepare('SELECT COUNT(*) c FROM users').get().c,
    categories: db.prepare('SELECT COUNT(DISTINCT category) c FROM businesses').get().c
  };
  const latest = db.prepare('SELECT * FROM businesses ORDER BY id DESC LIMIT 6').all();
  const mine = req.user
    ? db.prepare('SELECT * FROM businesses WHERE owner_id=? ORDER BY id DESC LIMIT 5').all(req.user.id) : [];
  res.render('index', { title: 'Home', stats, latest, mine });
});

for (const p of ['security', 'testing', 'deployment', 'review']) {
  router.get('/' + p, (req, res) => res.render(p, { title: p[0].toUpperCase() + p.slice(1) }));
}
module.exports = router;
