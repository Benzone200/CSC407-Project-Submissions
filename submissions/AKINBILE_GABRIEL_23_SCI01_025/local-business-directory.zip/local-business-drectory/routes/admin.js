const router = require('express').Router();
const db = require('../db');
const { requireRole } = require('../middleware/auth');

router.use(requireRole('admin')); // every admin route is protected

router.get('/', (req, res) => {
  const users = db.prepare(`SELECT u.id,u.name,u.email,u.role,u.created_at,
      (SELECT COUNT(*) FROM businesses b WHERE b.owner_id=u.id) AS listings FROM users u ORDER BY u.id`).all();
  const logs = db.prepare('SELECT * FROM security_log ORDER BY id DESC LIMIT 25').all();
  res.render('admin', { title: 'Admin', users, logs });
});

router.post('/users/:id/role', (req, res) => {
  const id = parseInt(req.params.id, 10);
  const role = req.body.role;
  if (!['user', 'admin'].includes(role) || !Number.isInteger(id) || id === req.user.id) {
    req.session.flash = { type: 'error', text: 'Invalid request (you cannot change your own role).' };
    return res.redirect('/admin');
  }
  db.prepare('UPDATE users SET role=? WHERE id=?').run(role, id);
  db.log('role_changed', req.user.id, req.ip, `user=${id} role=${role}`);
  req.session.flash = { type: 'success', text: 'Role updated.' };
  res.redirect('/admin');
});

router.post('/users/:id/delete', (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (!Number.isInteger(id) || id === req.user.id) {
    req.session.flash = { type: 'error', text: 'You cannot delete your own account here.' };
    return res.redirect('/admin');
  }
  db.prepare('DELETE FROM users WHERE id=?').run(id);
  db.log('user_deleted', req.user.id, req.ip, 'user=' + id);
  req.session.flash = { type: 'success', text: 'User deleted.' };
  res.redirect('/admin');
});

module.exports = router;
