const router = require('express').Router();
const db = require('../db');
const { requireLogin } = require('../middleware/auth');
const { clean } = require('../utils/validate');

const CATEGORIES = ['Restaurant', 'Retail', 'Health', 'Services', 'Education', 'Beauty', 'Automotive', 'Other'];
const esc = (s) => s.replace(/[\\%_]/g, '\\$&'); // escape LIKE wildcards in user input

// Access-control check: owner or admin only
const canManage = (user, biz) => !!user && (user.role === 'admin' || user.id === biz.owner_id);

function parse(body) {
  const v = {
    name: clean(body.name), category: clean(body.category), description: clean(body.description),
    phone: clean(body.phone), address: clean(body.address), city: clean(body.city)
  };
  const e = [];
  if (v.name.length < 2 || v.name.length > 80) e.push('Business name must be 2-80 characters.');
  if (!CATEGORIES.includes(v.category)) e.push('Choose a valid category.');
  if (v.description.length < 10 || v.description.length > 500) e.push('Description must be 10-500 characters.');
  if (!/^[+\d][\d\s()-]{6,19}$/.test(v.phone)) e.push('Enter a valid phone number (digits, spaces, + - ( ) only).');
  if (v.address.length < 3 || v.address.length > 120) e.push('Address must be 3-120 characters.');
  if (v.city.length < 2 || v.city.length > 60) e.push('City must be 2-60 characters.');
  return { v, e };
}

function load(req, res, next) {
  const id = parseInt(req.params.id, 10);
  const biz = Number.isInteger(id)
    ? db.prepare('SELECT b.*, u.name AS owner_name FROM businesses b JOIN users u ON u.id=b.owner_id WHERE b.id=?').get(id)
    : null;
  if (!biz) return res.status(404).render('error', { title: 'Not found', message: 'Business not found.' });
  req.biz = biz;
  next();
}

function guard(req, res, next) {
  if (!canManage(req.user, req.biz)) {
    db.log('access_denied', req.user?.id, req.ip, req.originalUrl);
    return res.status(403).render('error', { title: 'Access denied', message: 'You can only manage your own listings.' });
  }
  next();
}

// Search / filter / pagination
router.get('/', (req, res) => {
  const q = clean(req.query.q).slice(0, 60);
  const city = clean(req.query.city).slice(0, 60);
  const category = CATEGORIES.includes(req.query.category) ? req.query.category : '';
  const page = Math.max(1, parseInt(req.query.page, 10) || 1);
  const per = 9;

  // The WHERE text is a constant; all user input is bound as parameters (SQL injection safe)
  const where = `WHERE (name LIKE @like ESCAPE '\\' OR description LIKE @like ESCAPE '\\')
                 AND (@category='' OR category=@category) AND city LIKE @clike ESCAPE '\\'`;
  const p = { like: `%${esc(q)}%`, category, clike: `%${esc(city)}%` };
  const total = db.prepare(`SELECT COUNT(*) c FROM businesses ${where}`).get(p).c;
  const rows = db.prepare(`SELECT * FROM businesses ${where} ORDER BY id DESC LIMIT @per OFFSET @offset`)
    .all({ ...p, per, offset: (page - 1) * per });

  res.render('businesses', {
    title: 'Directory', rows, total, q, city, category, page,
    pages: Math.max(1, Math.ceil(total / per)), CATEGORIES
  });
});

router.get('/new', requireLogin, (req, res) =>
  res.render('business_form', { title: 'Add business', action: '/businesses', errors: [], v: {}, CATEGORIES }));

router.post('/', requireLogin, (req, res) => {
  const { v, e } = parse(req.body);
  if (e.length) return res.status(400).render('business_form', { title: 'Add business', action: '/businesses', errors: e, v, CATEGORIES });
  const info = db.prepare(`INSERT INTO businesses(owner_id,name,category,description,phone,address,city)
                           VALUES(?,?,?,?,?,?,?)`)
    .run(req.user.id, v.name, v.category, v.description, v.phone, v.address, v.city);
  req.session.flash = { type: 'success', text: 'Business added.' };
  res.redirect('/businesses/' + info.lastInsertRowid);
});

router.get('/:id', load, (req, res) =>
  res.render('business', { title: req.biz.name, b: req.biz, manage: canManage(req.user, req.biz) }));

router.get('/:id/edit', requireLogin, load, guard, (req, res) =>
  res.render('business_form', { title: 'Edit business', action: `/businesses/${req.biz.id}/edit`, errors: [], v: req.biz, CATEGORIES }));

router.post('/:id/edit', requireLogin, load, guard, (req, res) => {
  const { v, e } = parse(req.body);
  if (e.length) return res.status(400).render('business_form', { title: 'Edit business', action: `/businesses/${req.biz.id}/edit`, errors: e, v, CATEGORIES });
  db.prepare('UPDATE businesses SET name=?,category=?,description=?,phone=?,address=?,city=? WHERE id=?')
    .run(v.name, v.category, v.description, v.phone, v.address, v.city, req.biz.id);
  req.session.flash = { type: 'success', text: 'Business updated.' };
  res.redirect('/businesses/' + req.biz.id);
});

router.post('/:id/delete', requireLogin, load, guard, (req, res) => {
  db.prepare('DELETE FROM businesses WHERE id=?').run(req.biz.id);
  db.log('business_deleted', req.user.id, req.ip, 'id=' + req.biz.id);
  req.session.flash = { type: 'success', text: 'Business deleted.' };
  res.redirect('/businesses');
});

module.exports = router;
