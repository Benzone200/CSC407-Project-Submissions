const router = require('express').Router();
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const { clean, isEmail, strongPassword } = require('../utils/validate');

// Constant-time-ish login: compare against a dummy hash when the user doesn't exist
const DUMMY_HASH = bcrypt.hashSync('dummy-password-for-timing', 12);

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: process.env.NODE_ENV === 'test' ? 1000 : 10,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => {
    db.log('rate_limited', null, req.ip, req.originalUrl);
    res.status(429).render('error', { title: 'Too many attempts', message: 'Too many attempts. Please try again in 15 minutes.' });
  }
});

router.get('/register', (req, res) => res.render('register', { title: 'Register', errors: [], values: {} }));

router.post('/register', loginLimiter, (req, res, next) => {
  const name = clean(req.body.name);
  const email = clean(req.body.email).toLowerCase();
  const password = String(req.body.password || '');
  const confirm = String(req.body.confirm || '');
  const errors = [];

  if (name.length < 2 || name.length > 60) errors.push('Name must be 2-60 characters.');
  if (!isEmail(email)) errors.push('Enter a valid email address.');
  const pe = strongPassword(password);
  if (pe) errors.push(pe);
  if (password !== confirm) errors.push('Passwords do not match.');
  if (!errors.length && db.prepare('SELECT 1 FROM users WHERE email=?').get(email))
    errors.push('Could not register with these details.'); // no account enumeration

  if (errors.length) return res.status(400).render('register', { title: 'Register', errors, values: { name, email } });

  // Role is ALWAYS 'user' – never taken from the request (prevents privilege escalation)
  const info = db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'user')")
    .run(name, email, bcrypt.hashSync(password, 12));
  db.log('register', info.lastInsertRowid, req.ip);

  req.session.regenerate((err) => {
    if (err) return next(err);
    req.session.userId = info.lastInsertRowid;
    req.session.flash = { type: 'success', text: 'Welcome! Your account has been created.' };
    res.redirect('/');
  });
});

router.get('/login', (req, res) => res.render('login', { title: 'Login', error: null, email: '' }));

router.post('/login', loginLimiter, (req, res, next) => {
  const email = clean(req.body.email).toLowerCase();
  const password = String(req.body.password || '');
  const u = db.prepare('SELECT id,password_hash FROM users WHERE email=?').get(email); // parameterised
  const ok = bcrypt.compareSync(password, u ? u.password_hash : DUMMY_HASH) && !!u;

  if (!ok) {
    db.log('login_failed', u?.id, req.ip, email);
    return res.status(401).render('login', { title: 'Login', error: 'Invalid email or password.', email });
  }
  req.session.regenerate((err) => { // new session id => prevents session fixation
    if (err) return next(err);
    req.session.userId = u.id;
    req.session.flash = { type: 'success', text: 'Logged in successfully.' };
    db.log('login', u.id, req.ip);
    res.redirect('/');
  });
});

router.post('/logout', (req, res) => {
  const id = req.session.userId;
  req.session.destroy(() => {
    db.log('logout', id, req.ip);
    res.clearCookie('sid');
    res.redirect('/login');
  });
});

module.exports = router;
