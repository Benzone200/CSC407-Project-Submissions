const router = require('express').Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { requireLogin } = require('../middleware/auth');
const { clean, strongPassword } = require('../utils/validate');

router.use('/profile', requireLogin);

function show(req, res, errors = [], status = 200) {
  const mine = db.prepare('SELECT * FROM businesses WHERE owner_id=? ORDER BY id DESC').all(req.user.id);
  res.status(status).render('profile', { title: 'My profile', errors, mine });
}

router.get('/profile', (req, res) => show(req, res));

router.post('/profile', (req, res) => {
  const name = clean(req.body.name);
  if (name.length < 2 || name.length > 60) return show(req, res, ['Name must be 2-60 characters.'], 400);
  db.prepare('UPDATE users SET name=? WHERE id=?').run(name, req.user.id);
  req.session.flash = { type: 'success', text: 'Profile updated.' };
  res.redirect('/profile');
});

router.post('/profile/password', (req, res) => {
  const current = String(req.body.current || '');
  const next = String(req.body.password || '');
  const row = db.prepare('SELECT password_hash FROM users WHERE id=?').get(req.user.id);
  const errors = [];
  if (!bcrypt.compareSync(current, row.password_hash)) errors.push('Current password is incorrect.');
  const pe = strongPassword(next);
  if (pe) errors.push(pe);
  if (errors.length) return show(req, res, errors, 400);
  db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(bcrypt.hashSync(next, 12), req.user.id);
  db.log('password_changed', req.user.id, req.ip);
  req.session.flash = { type: 'success', text: 'Password changed.' };
  res.redirect('/profile');
});

module.exports = router;
