# Resolve: Complaint & Feedback Management System

CSC 407 course project for **Afe Babalola University (ABUAD)**. Students and visitors submit complaints, feedback or suggestions. Each one gets a ticket ID and is routed to the right office. Staff log in to assign, investigate, reply and resolve, and students follow the progress the whole way through.

- **Front end:** React 18 + Vite + React Router (`client/`)
- **Back end:** Node.js + Express REST API (`server/`)
- **Database:** SQLite, using Node's built-in `node:sqlite` module, so there is no database server to install
- **Auth:** JWT tokens for students and staff (kept separate), bcrypt-hashed passwords
- **Uploads:** Multer (images, PDF, Word, text; up to 5 files of 10 MB each)

---

## 1. Install Node.js (one time)

1. Go to <https://nodejs.org> and download the **LTS** version for Windows (it must be **22.13 or newer**).
2. Run the installer and accept the defaults.
3. Open a **new** terminal in VS Code (**Terminal → New Terminal**) and check it worked:

   ```bash
   node --version
   ```

   You should see `v22.13.0` or higher (e.g. `v24.x.x`).

## 2. Set up the project (one time)

Open the `CSC 407 Project` folder in VS Code, open a terminal and run:

```bash
npm run setup
```

This installs everything for the root, the server and the client.

**Optional:** add sample complaints so the dashboard isn't empty:

```bash
npm run seed:demo
```

It prints each sample ticket ID with its access code, so you can try them on the Track page, and creates a demo student account (below).

## 3. Run it

```bash
npm run dev
```

This starts both parts together:

| Part | Address |
| --- | --- |
| Website (React) | <http://localhost:5173> |
| API (Express) | <http://localhost:4000/api> |

Open **http://localhost:5173** in your browser. Press `Ctrl + C` in the terminal to stop.

### Staff logins (created automatically on first run)

| Role | Email | Password |
| --- | --- | --- |
| Administrator | `admin@resolve.test` | `Admin@123` |
| Hostel officer | `hostel@resolve.test` | `Officer@123` |
| Academic officer | `academics@resolve.test` | `Officer@123` |
| Bursary officer | `bursary@resolve.test` | `Officer@123` |
| ICT officer | `ict@resolve.test` | `Officer@123` |

Staff login is at **/staff/login** (or "Staff portal" in the header).

### Student accounts

Students create their own account at **/register** (name, matric number, email, password) and sign in at **/login** with their matric number *or* email. Accounts are optional: anyone can still submit as a guest and track with a ticket ID + access code.

`npm run seed:demo` also creates a demo student: **`student@resolve.test` / `Student@123`** (or matric `DEMO/0001`).

### Other commands

| Command | What it does |
| --- | --- |
| `npm run reset` | Deletes the database and uploaded files to start fresh |
| `npm run build` then `npm start` | Production mode: builds the React app and serves the whole site from <http://localhost:4000> |

---

## Features

**Students / public**
- Landing page with process overview and categories
- Optional student accounts (register with matric number, sign in with matric or email)
- **My complaints** page: every complaint the student has submitted, open/resolved counts, and a notice when an officer is waiting for their reply
- Signed-in students get the form pre-filled from their account
- Submit a complaint, feedback or suggestion: category, subject, details, location, incident date, urgency, file attachments
- Optional anonymous submission (name and matric number are not stored; for signed-in students the complaint still shows in *their* My complaints, but staff never see who sent it)
- Ticket ID + 6-character access code on submission; both are needed to view a ticket, so other people can't read it
- Tracking page: progress timeline, handling office/officer, conversation with the officer, reply with attachments
- Rate the resolution (1–5 stars), confirm and close, or reopen with a reason

**Staff**
- Secure login (JWT, bcrypt)
- Dashboard: open / new today / overdue / average resolution time and rating, open complaints by category
- Filter by status (incl. overdue), "Assigned to me", "Feedback & suggestions", search by ticket/subject/name/matric, pagination
- Export the current list to CSV
- Complaint detail: change status, assign officer, change priority, move/escalate to another department
- Reply to the student, or ask a question (sets status to "Awaiting student"), or add **internal notes** that students never see
- Response target of 5 working days, with overdue flagging
- Full activity log for every ticket

## How a complaint flows

```
New ──assign──▶ In progress ⇄ Awaiting student
                    │
                    ▼
                Resolved ──student confirms──▶ Closed
                    ▲                              │
                    └────────── reopen ◀───────────┘
```

Categories are routed to departments automatically (edit `CATEGORIES` in `server/src/config.js`):

| Category | Department |
| --- | --- |
| Academics | Academic Affairs |
| Hostel & facilities | Hostel Management |
| Fees & finance | Bursary |
| Staff conduct | Registry |
| IT & student portal | ICT Unit |
| General feedback / Other | Complaints Office |

---

## Project structure

```
CSC 407 Project/
├── package.json            root scripts (setup, dev, build, start…)
├── server/
│   ├── src/
│   │   ├── index.js         Express app, error handling, serves client/dist in production
│   │   ├── config.js        port, JWT secret, categories → departments, limits
│   │   ├── db.js            SQLite schema + default staff accounts
│   │   ├── complaints.js    shared data access (create, views, messages, activity)
│   │   ├── auth.js          JWT sign/verify middleware
│   │   ├── uploads.js       Multer file upload rules
│   │   ├── seedDemo.js      sample data
│   │   ├── reset.js         wipe database
│   │   └── routes/
│   │       ├── public.js    submit, track, reply, rate, close, reopen
│   │       ├── staff.js     login, stats, list, detail, update, messages, CSV
│   │       ├── students.js  student register, login, my complaints
│   │       └── attachments.js
│   └── data/               created at runtime: resolve.db + uploads/
└── client/
    ├── index.html
    ├── vite.config.js       dev proxy /api → :4000
    └── src/
        ├── main.jsx, App.jsx   routing
        ├── api.js, auth.jsx    API calls + staff session
        ├── styles.css          design tokens (colours, Sora font) + all styles
        ├── components/         header, footer, pills, timeline, staff layout
        └── pages/              Landing, Submit, Track, StudentLogin, Register, MyComplaints,
                                Login (staff), Dashboard, Detail
```

## Database tables

| Table | Purpose |
| --- | --- |
| `departments` | Offices that handle complaints |
| `users` | Staff accounts (`admin` or `officer`) |
| `students` | Student accounts (name, matric, email, department, password hash) |
| `complaints` | Tickets: type, category, details, priority, status, submitter, linked student (optional), department, officer, due date, rating |
| `messages` | Conversation per ticket (`student`, `staff`, `system`); `internal = 1` for staff-only notes |
| `attachments` | Uploaded files linked to a ticket or a message |
| `activity` | Audit log of every change |

## API endpoints

Public

| Method | Path | Description |
| --- | --- | --- |
| GET | `/api/meta` | Categories, types, priorities |
| POST | `/api/complaints` | Submit (multipart form, `files` field for attachments) |
| GET | `/api/track/:ticket?code=` | View a ticket |
| POST | `/api/track/:ticket/messages` | Student reply |
| POST | `/api/track/:ticket/rating` | Rate 1–5 (resolved tickets only) |
| POST | `/api/track/:ticket/close` | Confirm resolution |
| POST | `/api/track/:ticket/reopen` | Reopen with a reason |
| GET | `/api/attachments/:id?ticket=&code=` | Download an attachment |

Students (send `Authorization: Bearer <token>`)

| Method | Path | Description |
| --- | --- | --- |
| POST | `/api/students/register` | `{ name, matric, email, department?, password }` → token |
| POST | `/api/students/login` | `{ identifier (matric or email), password }` → token |
| GET | `/api/me` | Current signed-in student or staff member |
| GET | `/api/students/complaints` | The student's own complaints (with access codes) |

Submitting a complaint with a student token links it to that student's account.

Staff (send `Authorization: Bearer <token>`)

| Method | Path | Description |
| --- | --- | --- |
| POST | `/api/auth/login` | Returns a token |
| GET | `/api/staff/me` | Current user |
| GET | `/api/staff/stats` | Dashboard figures |
| GET | `/api/staff/complaints` | List: `status`, `view=mine\|feedback`, `q`, `page`, `pageSize` |
| GET | `/api/staff/complaints/:id` | Full detail incl. internal notes + activity |
| PATCH | `/api/staff/complaints/:id` | Update `status`, `priority`, `assignedTo`, `departmentId` |
| POST | `/api/staff/complaints/:id/messages` | `{ body, internal, awaitStudent }` |
| GET | `/api/staff/export.csv` | CSV of the filtered list |
| GET | `/api/staff/officers`, `/api/staff/departments` | Dropdown data |

---

## Customizing

- **Colours and font:** change the variables at the top of `client/src/styles.css`.
- **Institution name:** `INSTITUTION` at the top of `client/src/components/ui.jsx`.
- **Campus security number:** replace `[PHONE NUMBER]` in `client/src/pages/Submit.jsx`.
- **Response target:** `TARGET_WORKING_DAYS` in `server/src/config.js`.
- **Before deploying anywhere public:** set a `JWT_SECRET` environment variable and change the default passwords.

## Not included (ideas for extension)

- Email notifications (the email field is stored; plug in Nodemailer to send updates)
- An admin screen to add/remove staff accounts (currently seeded in `server/src/db.js`)
- Password reset for students (needs email sending)

## Troubleshooting

- **`'npm' is not recognized`**: Node.js isn't installed, or the terminal was open before installing it. Close VS Code completely and reopen it.
- **"Resolve needs Node.js 22.13 or newer"**: install the current LTS from nodejs.org.
- **Port already in use**: something else is using 4000 or 5173. Close the other terminal running the app, or restart VS Code.
- **"Cannot reach the server"** on the website: the API isn't running. Use `npm run dev` (not just the client).
- **`Error: spawn UNKNOWN`** from Vite: Windows (often Smart App Control or antivirus) blocked `esbuild.exe`. This project already uses the WebAssembly build of esbuild (`overrides` in `client/package.json`) to avoid it. If it reappears, delete `client/node_modules` and run `npm install` in `client` again.
- **Opening http://localhost:4000 shows "This is the Resolve API"**: in development the website is on http://localhost:5173.
