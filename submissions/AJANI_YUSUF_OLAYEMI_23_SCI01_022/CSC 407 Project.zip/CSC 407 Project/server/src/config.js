import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

export const ROOT = path.resolve(here, '..');
export const DATA_DIR = path.join(ROOT, 'data');
export const DB_FILE = path.join(DATA_DIR, 'resolve.db');
export const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
export const CLIENT_DIST = path.resolve(ROOT, '..', 'client', 'dist');

export const PORT = Number(process.env.PORT) || 4000;

// Change this (or set JWT_SECRET) before deploying anywhere public.
export const JWT_SECRET = process.env.JWT_SECRET || 'change-me-csc407-resolve-dev-secret';
export const TOKEN_TTL = '8h';

// Response target: complaints are due this many working days after submission.
export const TARGET_WORKING_DAYS = 5;

export const MAX_FILE_MB = 10;
export const MAX_FILES = 5;

// Category -> department that handles it.
export const CATEGORIES = [
  { name: 'Academics', department: 'Academic Affairs' },
  { name: 'Hostel & facilities', department: 'Hostel Management' },
  { name: 'Fees & finance', department: 'Bursary' },
  { name: 'Staff conduct', department: 'Registry' },
  { name: 'IT & student portal', department: 'ICT Unit' },
  { name: 'General feedback', department: 'Complaints Office' },
  { name: 'Other', department: 'Complaints Office' }
];

export const KINDS = ['Complaint', 'Feedback', 'Suggestion'];
export const PRIORITIES = ['Low', 'Normal', 'Urgent'];
export const STATUSES = ['New', 'In progress', 'Awaiting student', 'Resolved', 'Closed'];
