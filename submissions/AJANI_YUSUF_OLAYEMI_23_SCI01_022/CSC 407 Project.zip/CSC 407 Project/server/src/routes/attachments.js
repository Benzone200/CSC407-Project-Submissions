// Download an attachment. Staff use their token; students use ticket + access code.
import { Router } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { db } from '../db.js';
import { UPLOAD_DIR } from '../config.js';
import { optionalAuth } from '../auth.js';
import { HttpError, wrap, clean } from '../util.js';

const router = Router();

router.get('/attachments/:id', optionalAuth, wrap((req, res) => {
  const a = db
    .prepare(
      `SELECT a.*, c.ticket, c.access_code FROM attachments a JOIN complaints c ON c.id = a.complaint_id WHERE a.id = ?`
    )
    .get(Number(req.params.id));
  if (!a) throw new HttpError(404, 'File not found.');

  const studentOk =
    clean(req.query.ticket, 40).toUpperCase() === a.ticket &&
    clean(req.query.code, 20).toUpperCase() === a.access_code;
  if (!req.user && !studentOk) throw new HttpError(403, 'You do not have access to this file.');

  const file = path.join(UPLOAD_DIR, path.basename(a.stored_name));
  if (!fs.existsSync(file)) throw new HttpError(404, 'File is missing on the server.');
  res.setHeader('Content-Type', a.mime || 'application/octet-stream');
  res.setHeader('Content-Disposition', `inline; filename="${a.original_name.replace(/["\\\r\n]/g, '_')}"`);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  fs.createReadStream(file).pipe(res);
}));

export default router;
