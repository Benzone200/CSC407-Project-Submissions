// Routes for signed-in staff: login, dashboard, complaint handling.
import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { db } from '../db.js';
import { STATUSES, PRIORITIES } from '../config.js';
import { requireStaff, signToken, publicUser, findUser } from '../auth.js';
import { clean, HttpError, wrap, sqlNow, iso } from '../util.js';
import {
  getComplaintRow, summary, staffView, addMessage, logActivity, OPEN_CLAUSE
} from '../complaints.js';

const router = Router();

router.post('/auth/login', wrap((req, res) => {
  const email = clean(req.body.email, 160);
  const password = String(req.body.password || '');
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    throw new HttpError(401, 'Incorrect email or password.');
  }
  res.json({ token: signToken(user), user: publicUser(findUser(user.id)) });
}));

router.use('/staff', requireStaff);

router.get('/staff/me', (req, res) => res.json(publicUser(req.user)));

router.get('/staff/officers', (_req, res) => {
  const rows = db
    .prepare('SELECT u.id, u.name, u.role, d.name AS department FROM users u LEFT JOIN departments d ON d.id = u.department_id ORDER BY u.name')
    .all();
  res.json(rows);
});

router.get('/staff/departments', (_req, res) => {
  res.json(db.prepare('SELECT id, name FROM departments ORDER BY name').all());
});

// Builds the WHERE clause for the complaints list from query-string filters.
function filters(req) {
  const where = [];
  const params = [];
  const { status, q, view, kind } = req.query;
  if (status === 'Overdue') {
    where.push(`c.${OPEN_CLAUSE} AND c.due_at < ?`);
    params.push(sqlNow());
  } else if (status && STATUSES.includes(status)) {
    where.push('c.status = ?');
    params.push(status);
  }
  if (view === 'mine') {
    where.push('c.assigned_to = ?');
    params.push(req.user.id);
  }
  if (view === 'feedback') where.push("c.kind != 'Complaint'");
  if (kind) {
    where.push('c.kind = ?');
    params.push(kind);
  }
  if (q) {
    where.push('(c.ticket LIKE ? OR c.subject LIKE ? OR c.name LIKE ? OR c.matric LIKE ?)');
    const like = `%${clean(q, 100)}%`;
    params.push(like, like, like, like);
  }
  return { sql: where.length ? 'WHERE ' + where.join(' AND ') : '', params };
}

const LIST_SELECT = `
  SELECT c.*, d.name AS department, u.name AS officer_name
  FROM complaints c
  LEFT JOIN departments d ON d.id = c.department_id
  LEFT JOIN users u ON u.id = c.assigned_to`;

router.get('/staff/complaints', wrap((req, res) => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const pageSize = Math.min(100, Math.max(5, Number(req.query.pageSize) || 10));
  const { sql, params } = filters(req);
  const total = db.prepare(`SELECT COUNT(*) AS n FROM complaints c ${sql}`).get(...params).n;
  const rows = db
    .prepare(`${LIST_SELECT} ${sql} ORDER BY c.id DESC LIMIT ? OFFSET ?`)
    .all(...params, pageSize, (page - 1) * pageSize);
  res.json({ items: rows.map(summary), total, page, pageSize });
}));

router.get('/staff/stats', wrap((req, res) => {
  const now = sqlNow();
  const today = now.slice(0, 10);
  const one = (sql, ...p) => db.prepare(sql).get(...p).n;
  const avg = db
    .prepare(`SELECT AVG(julianday(resolved_at) - julianday(created_at)) AS d FROM complaints WHERE resolved_at IS NOT NULL`)
    .get().d;
  const ratingAvg = db.prepare('SELECT AVG(rating) AS r, COUNT(rating) AS n FROM complaints WHERE rating IS NOT NULL').get();
  res.json({
    open: one(`SELECT COUNT(*) AS n FROM complaints WHERE ${OPEN_CLAUSE}`),
    newToday: one(`SELECT COUNT(*) AS n FROM complaints WHERE substr(created_at, 1, 10) = ?`, today),
    overdue: one(`SELECT COUNT(*) AS n FROM complaints WHERE ${OPEN_CLAUSE} AND due_at < ?`, now),
    total: one('SELECT COUNT(*) AS n FROM complaints'),
    mine: one(`SELECT COUNT(*) AS n FROM complaints WHERE ${OPEN_CLAUSE} AND assigned_to = ?`, req.user.id),
    feedback: one("SELECT COUNT(*) AS n FROM complaints WHERE kind != 'Complaint'"),
    avgResolutionDays: avg == null ? null : Math.round(avg * 100) / 100,
    avgRating: ratingAvg.r == null ? null : Math.round(ratingAvg.r * 10) / 10,
    ratingCount: ratingAvg.n,
    byStatus: Object.fromEntries(
      db.prepare('SELECT status, COUNT(*) AS n FROM complaints GROUP BY status').all().map((r) => [r.status, r.n])
    ),
    openByCategory: db
      .prepare(`SELECT category, COUNT(*) AS n FROM complaints WHERE ${OPEN_CLAUSE} GROUP BY category ORDER BY n DESC`)
      .all()
      .map((r) => ({ category: r.category, count: r.n }))
  });
}));

// CSV export of the current filter.
router.get('/staff/export.csv', wrap((req, res) => {
  const { sql, params } = filters(req);
  const rows = db.prepare(`${LIST_SELECT} ${sql} ORDER BY c.id DESC`).all(...params);
  const head = ['Ticket', 'Type', 'Category', 'Subject', 'Priority', 'Status', 'Overdue', 'Department', 'Officer', 'Submitted', 'Due', 'Resolved', 'Rating'];
  const esc = (v) => {
    const s = v == null ? '' : String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = rows.map((r) => {
    const s = summary(r);
    return [s.ticket, s.kind, s.category, s.subject, s.priority, s.status, s.overdue ? 'Yes' : 'No', s.department,
      s.officerName || 'Unassigned', s.createdAt, s.dueAt, iso(r.resolved_at) || '', r.rating || ''].map(esc).join(',');
  });
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="complaints-${sqlNow().slice(0, 10)}.csv"`);
  res.send([head.join(','), ...lines].join('\n'));
}));

function loadOr404(id) {
  const row = getComplaintRow('c.id = ?', Number(id));
  if (!row) throw new HttpError(404, 'Complaint not found.');
  return row;
}

router.get('/staff/complaints/:id', wrap((req, res) => {
  res.json(staffView(loadOr404(req.params.id)));
}));

router.patch('/staff/complaints/:id', wrap((req, res) => {
  const row = loadOr404(req.params.id);
  const actor = req.user.name;
  const sets = [];
  const params = [];
  const now = sqlNow();
  const { status, priority, assignedTo, departmentId } = req.body;

  if (status !== undefined && status !== row.status) {
    if (!STATUSES.includes(status)) throw new HttpError(400, 'Unknown status.');
    sets.push('status = ?');
    params.push(status);
    if (status === 'Resolved') {
      sets.push('resolved_at = ?');
      params.push(now);
    } else if (status !== 'Closed') {
      sets.push('resolved_at = NULL');
    }
    logActivity(row.id, actor, `Status → ${status}`);
    if (status === 'Resolved') addMessage(row.id, { authorType: 'system', body: 'Marked as resolved. Please rate the resolution, or reopen it if the problem is not fixed.' });
  }
  if (priority !== undefined && priority !== row.priority) {
    if (!PRIORITIES.includes(priority)) throw new HttpError(400, 'Unknown priority.');
    sets.push('priority = ?');
    params.push(priority);
    logActivity(row.id, actor, `Priority → ${priority}`);
  }
  if (assignedTo !== undefined && (assignedTo || null) !== row.assigned_to) {
    const officer = assignedTo ? findUser(Number(assignedTo)) : null;
    if (assignedTo && !officer) throw new HttpError(400, 'Unknown officer.');
    sets.push('assigned_to = ?');
    params.push(officer ? officer.id : null);
    logActivity(row.id, actor, officer ? `Assigned to ${officer.name}` : 'Unassigned');
    if (officer && row.status === 'New' && status === undefined) {
      sets.push("status = 'In progress'");
      logActivity(row.id, 'System', 'Status → In progress');
    }
  }
  if (departmentId !== undefined && Number(departmentId) !== row.department_id) {
    const dept = db.prepare('SELECT id, name FROM departments WHERE id = ?').get(Number(departmentId));
    if (!dept) throw new HttpError(400, 'Unknown department.');
    sets.push('department_id = ?');
    params.push(dept.id);
    logActivity(row.id, actor, `Escalated / moved to ${dept.name}`);
  }

  if (sets.length) {
    sets.push('updated_at = ?');
    params.push(now);
    db.prepare(`UPDATE complaints SET ${sets.join(', ')} WHERE id = ?`).run(...params, row.id);
  }
  res.json(staffView(loadOr404(row.id)));
}));

router.post('/staff/complaints/:id/messages', wrap((req, res) => {
  const row = loadOr404(req.params.id);
  const body = clean(req.body.body, 5000);
  const internal = !!req.body.internal;
  if (!body) throw new HttpError(400, 'Write a message first.');
  addMessage(row.id, { authorType: 'staff', authorId: req.user.id, body, internal });
  logActivity(row.id, req.user.name, internal ? 'Internal note added' : 'Replied to student');
  if (!internal && req.body.awaitStudent) {
    db.prepare("UPDATE complaints SET status = 'Awaiting student' WHERE id = ?").run(row.id);
    logActivity(row.id, req.user.name, 'Status → Awaiting student');
  } else if (!internal && row.status === 'New') {
    db.prepare("UPDATE complaints SET status = 'In progress' WHERE id = ?").run(row.id);
    logActivity(row.id, 'System', 'Status → In progress');
  }
  res.status(201).json(staffView(loadOr404(row.id)));
}));

export default router;
