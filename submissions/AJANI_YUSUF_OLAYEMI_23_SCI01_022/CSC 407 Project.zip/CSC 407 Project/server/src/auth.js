import jwt from 'jsonwebtoken';
import { db } from './db.js';
import { JWT_SECRET, TOKEN_TTL } from './config.js';
import { HttpError } from './util.js';

// Tokens carry `kind` so a student token can never be used as a staff token (or the reverse).
export function signToken(user, kind = 'staff') {
  return jwt.sign({ sub: user.id, kind, role: kind === 'student' ? 'student' : user.role }, JWT_SECRET, {
    expiresIn: TOKEN_TTL
  });
}

export function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email, role: u.role, departmentId: u.department_id, department: u.department };
}

export function publicStudent(s) {
  return { id: s.id, name: s.name, email: s.email, matric: s.matric, department: s.department, role: 'student' };
}

export function findUser(id) {
  return db
    .prepare('SELECT u.*, d.name AS department FROM users u LEFT JOIN departments d ON d.id = u.department_id WHERE u.id = ?')
    .get(id);
}

export function findStudent(id) {
  return db.prepare('SELECT * FROM students WHERE id = ?').get(id);
}

function readToken(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return null;
  try {
    return jwt.verify(header.slice(7), JWT_SECRET);
  } catch {
    return 'expired';
  }
}

// Requires a signed-in staff member; puts them on req.user.
export function requireStaff(req, _res, next) {
  const payload = readToken(req);
  if (!payload) return next(new HttpError(401, 'Please sign in.'));
  if (payload === 'expired') return next(new HttpError(401, 'Your session has expired. Please sign in again.'));
  if (payload.kind === 'student') return next(new HttpError(403, 'This area is for staff only.'));
  const user = findUser(payload.sub);
  if (!user) return next(new HttpError(401, 'Account no longer exists.'));
  req.user = user;
  next();
}

// Requires a signed-in student; puts them on req.student.
export function requireStudent(req, _res, next) {
  const payload = readToken(req);
  if (!payload) return next(new HttpError(401, 'Please sign in.'));
  if (payload === 'expired') return next(new HttpError(401, 'Your session has expired. Please sign in again.'));
  if (payload.kind !== 'student') return next(new HttpError(403, 'This area is for students only.'));
  const student = findStudent(payload.sub);
  if (!student) return next(new HttpError(401, 'Account no longer exists.'));
  req.student = student;
  next();
}

// Optional: sets req.user (staff) or req.student when a valid token is present.
export function optionalAuth(req, _res, next) {
  const payload = readToken(req);
  if (payload && payload !== 'expired') {
    if (payload.kind === 'student') req.student = findStudent(payload.sub) || undefined;
    else req.user = findUser(payload.sub) || undefined;
  }
  next();
}

export function requireAdmin(req, _res, next) {
  if (req.user?.role !== 'admin') return next(new HttpError(403, 'Only administrators can do that.'));
  next();
}
