// Deletes the database and uploaded files so you can start fresh. Run: npm run reset
import fs from 'node:fs';
import { DATA_DIR } from './config.js';

fs.rmSync(DATA_DIR, { recursive: true, force: true });
console.log('Database and uploads deleted. The next `npm run dev` creates a fresh database with the default staff accounts.');
