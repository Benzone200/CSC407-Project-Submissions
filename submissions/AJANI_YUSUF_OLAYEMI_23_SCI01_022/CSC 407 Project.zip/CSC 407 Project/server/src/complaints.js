// Shared data access for complaints, used by both the public and staff routes.
import { db, tx } from './db.js';
import { CATEGORIES } from './config.js';
import { sqlNow, iso, addWorkingDays, ticketFor, accessCode } from './util.js';

const OPEN = "status NOT IN ('Resolved', 'Closed')";

export function isOverdue(row) {
  return !['Resolved', 'Closed'].includes(row.status) && new Date(iso(row.due_at)) < new Date();
}

export function logActivity(complaintId, actor, text) {
  db.prepare('INSERT INTO activity (complaint_id, actor, text, created_at) VALUES (?, ?, ?, ?)').run(
    complaintId, actor, text, sqlNow()
  );
}

export function addMessage(complaintId, { authorType, authorId = null, body, internal = false }) {
  const now = sqlNow();
  const { lastInsertRowid } = db
    .prepare('INSERT INTO messages (complaint_id, author_type, author_id, body, internal, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(complaintId, authorType, authorId, body, internal ? 1 : 0, now);
  db.prepare('UPDATE complaints SET updated_at = ? WHERE id = ?').run(now, complaintId);
  return Number(lastInsertRowid);
}

export function addAttachments(complaintId, files = [], messageId = null) {
  const stmt = db.prepare(
    'INSERT INTO attachments (complaint_id, message_id, original_name, stored_name, mime, size) VALUES (?, ?, ?, ?, ?, ?)'
  );
  for (const f of files) stmt.run(complaintId, messageId, f.originalname, f.filename, f.mimetype, f.size);
}

export function createComplaint(input, files, createdAt = new Date()) {
  const category = CATEGORIES.find((c) => c.name === input.category);
  const dept = db.prepare('SELECT id, name FROM departments WHERE name = ?').get(category.department);
  const code = accessCode();
  const now = sqlNow(createdAt);

  return tx(() => {
    const { lastInsertRowid } = db
      .prepare(
        `INSERT INTO complaints (access_code, kind, category, subject, details, location, incident_date, priority,
          anonymous, name, matric, email, department_id, student_id, due_at, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        code, input.kind, input.category, input.subject, input.details, input.location || null,
        input.incidentDate || null, input.priority, input.anonymous ? 1 : 0,
        input.anonymous ? null : input.name || null, input.anonymous ? null : input.matric || null,
        input.email || null, dept.id, input.studentId || null, sqlNow(addWorkingDays(createdAt)), now, now
      );
    const id = Number(lastInsertRowid);
    const ticket = ticketFor(id, createdAt);
    db.prepare('UPDATE complaints SET ticket = ? WHERE id = ?').run(ticket, id);
    addAttachments(id, files);
    db.prepare(
      'INSERT INTO messages (complaint_id, author_type, body, created_at) VALUES (?, ?, ?, ?)'
    ).run(id, 'system', `Ticket created and sent to ${dept.name}.`, now);
    db.prepare('INSERT INTO activity (complaint_id, actor, text, created_at) VALUES (?, ?, ?, ?)').run(
      id, 'System', 'Ticket created', now
    );
    return { id, ticket, accessCode: code };
  });
}

const BASE_SELECT = `
  SELECT c.*, d.name AS department, u.name AS officer_name
  FROM complaints c
  LEFT JOIN departments d ON d.id = c.department_id
  LEFT JOIN users u ON u.id = c.assigned_to`;

export function getComplaintRow(where, ...params) {
  return db.prepare(`${BASE_SELECT} WHERE ${where}`).get(...params);
}

function attachmentsFor(id) {
  return db
    .prepare('SELECT id, message_id, original_name, mime, size FROM attachments WHERE complaint_id = ? ORDER BY id')
    .all(id)
    .map((a) => ({ id: a.id, messageId: a.message_id, name: a.original_name, mime: a.mime, size: a.size }));
}

function messagesFor(id, includeInternal) {
  return db
    .prepare(
      `SELECT m.*, u.name AS staff_name FROM messages m LEFT JOIN users u ON u.id = m.author_id
       WHERE m.complaint_id = ? ${includeInternal ? '' : 'AND m.internal = 0'} ORDER BY m.id`
    )
    .all(id)
    .map((m) => ({
      id: m.id,
      authorType: m.author_type,
      staffName: m.staff_name,
      body: m.body,
      internal: !!m.internal,
      createdAt: iso(m.created_at)
    }));
}

// Shape for list views.
export function summary(row) {
  return {
    id: row.id,
    ticket: row.ticket,
    kind: row.kind,
    category: row.category,
    subject: row.subject,
    priority: row.priority,
    status: row.status,
    overdue: isOverdue(row),
    department: row.department,
    assignedTo: row.assigned_to,
    officerName: row.officer_name,
    createdAt: iso(row.created_at),
    updatedAt: iso(row.updated_at),
    dueAt: iso(row.due_at)
  };
}

// What a student sees on the tracking page: no internal notes, no staff email addresses.
export function publicView(row) {
  return {
    ...summary(row),
    details: row.details,
    location: row.location,
    incidentDate: row.incident_date,
    anonymous: !!row.anonymous,
    rating: row.rating,
    resolvedAt: iso(row.resolved_at),
    messages: messagesFor(row.id, false),
    attachments: attachmentsFor(row.id)
  };
}

// What staff see on the detail page.
export function staffView(row) {
  return {
    ...publicView(row),
    name: row.name,
    matric: row.matric,
    email: row.email,
    departmentId: row.department_id,
    messages: messagesFor(row.id, true),
    activity: db
      .prepare('SELECT actor, text, created_at FROM activity WHERE complaint_id = ? ORDER BY id DESC')
      .all(row.id)
      .map((a) => ({ actor: a.actor, text: a.text, createdAt: iso(a.created_at) }))
  };
}

export const OPEN_CLAUSE = OPEN;
