// Uses Node's built-in SQLite module (Node 22.13+), so there is no database server to install.
import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import bcrypt from 'bcryptjs';
import { DATA_DIR, DB_FILE, UPLOAD_DIR, CATEGORIES } from './config.js';

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

export const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;');

db.exec(`
CREATE TABLE IF NOT EXISTS departments (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL CHECK (role IN ('admin', 'officer')),
  department_id INTEGER REFERENCES departments(id),
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS complaints (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket        TEXT UNIQUE,
  access_code   TEXT NOT NULL,
  kind          TEXT NOT NULL,
  category      TEXT NOT NULL,
  subject       TEXT NOT NULL,
  details       TEXT NOT NULL,
  location      TEXT,
  incident_date TEXT,
  priority      TEXT NOT NULL DEFAULT 'Normal',
  status        TEXT NOT NULL DEFAULT 'New',
  anonymous     INTEGER NOT NULL DEFAULT 0,
  name          TEXT,
  matric        TEXT,
  email         TEXT,
  department_id INTEGER REFERENCES departments(id),
  assigned_to   INTEGER REFERENCES users(id),
  rating        INTEGER CHECK (rating BETWEEN 1 AND 5),
  due_at        TEXT NOT NULL,
  resolved_at   TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS messages (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  complaint_id  INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  author_type   TEXT NOT NULL CHECK (author_type IN ('student', 'staff', 'system')),
  author_id     INTEGER REFERENCES users(id),
  body          TEXT NOT NULL,
  internal      INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS attachments (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  complaint_id  INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  message_id    INTEGER REFERENCES messages(id) ON DELETE CASCADE,
  original_name TEXT NOT NULL,
  stored_name   TEXT NOT NULL,
  mime          TEXT,
  size          INTEGER,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS activity (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  complaint_id  INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  actor         TEXT NOT NULL,
  text          TEXT NOT NULL,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status);
CREATE INDEX IF NOT EXISTS idx_messages_complaint ON messages(complaint_id);
CREATE INDEX IF NOT EXISTS idx_activity_complaint ON activity(complaint_id);
`);

// Student accounts (optional: students can still submit as guests).
db.exec(`
CREATE TABLE IF NOT EXISTS students (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  matric        TEXT NOT NULL UNIQUE COLLATE NOCASE,
  email         TEXT NOT NULL UNIQUE COLLATE NOCASE,
  department    TEXT,
  password_hash TEXT NOT NULL,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

// Migration for databases created before student accounts existed.
const complaintCols = db.prepare('PRAGMA table_info(complaints)').all().map((c) => c.name);
if (!complaintCols.includes('student_id')) {
  db.exec('ALTER TABLE complaints ADD COLUMN student_id INTEGER REFERENCES students(id)');
}
db.exec('CREATE INDEX IF NOT EXISTS idx_complaints_student ON complaints(student_id)');

// Run a function inside a transaction.
export function tx(fn) {
  db.exec('BEGIN');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

// First run: create departments and the default staff accounts.
function seedBasics() {
  const insertDept = db.prepare('INSERT OR IGNORE INTO departments (name) VALUES (?)');
  for (const d of new Set(CATEGORIES.map((c) => c.department))) insertDept.run(d);

  const { n } = db.prepare('SELECT COUNT(*) AS n FROM users').get();
  if (n > 0) return;

  const dept = (name) => db.prepare('SELECT id FROM departments WHERE name = ?').get(name).id;
  const insertUser = db.prepare(
    'INSERT INTO users (name, email, password_hash, role, department_id) VALUES (?, ?, ?, ?, ?)'
  );
  const hash = (p) => bcrypt.hashSync(p, 10);
  tx(() => {
    insertUser.run('System Admin', 'admin@resolve.test', hash('Admin@123'), 'admin', dept('Complaints Office'));
    insertUser.run('Hostel Officer', 'hostel@resolve.test', hash('Officer@123'), 'officer', dept('Hostel Management'));
    insertUser.run('Academic Officer', 'academics@resolve.test', hash('Officer@123'), 'officer', dept('Academic Affairs'));
    insertUser.run('Bursary Officer', 'bursary@resolve.test', hash('Officer@123'), 'officer', dept('Bursary'));
    insertUser.run('ICT Officer', 'ict@resolve.test', hash('Officer@123'), 'officer', dept('ICT Unit'));
  });
  console.log('Created default staff accounts (see README for logins).');
}

seedBasics();
