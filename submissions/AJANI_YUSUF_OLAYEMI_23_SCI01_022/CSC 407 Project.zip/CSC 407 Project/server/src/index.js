const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 13)) {
  console.error(`\nResolve needs Node.js 22.13 or newer (you have ${process.versions.node}).`);
  console.error('Install the current LTS from https://nodejs.org and try again.\n');
  process.exit(1);
}

const { default: express } = await import('express');
const { default: cors } = await import('cors');
const fs = await import('node:fs');
const path = await import('node:path');
const { PORT, CLIENT_DIST } = await import('./config.js');
await import('./db.js');
const { default: publicRoutes } = await import('./routes/public.js');
const { default: staffRoutes } = await import('./routes/staff.js');
const { default: attachmentRoutes } = await import('./routes/attachments.js');
const { default: studentRoutes } = await import('./routes/students.js');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.use('/api', publicRoutes);
app.use('/api', staffRoutes);
app.use('/api', attachmentRoutes);
app.use('/api', studentRoutes);
app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found.' }));

// In production (after `npm run build`), serve the React app from the same server.
if (fs.existsSync(path.join(CLIENT_DIST, 'index.html'))) {
  app.use(express.static(CLIENT_DIST));
  app.get('*', (_req, res) => res.sendFile(path.join(CLIENT_DIST, 'index.html')));
} else {
  // Development: the website runs on Vite (port 5173), not here.
  app.get('*', (_req, res) => {
    res.type('html').send(`<!doctype html><meta charset="utf-8"><title>Resolve API</title>
      <body style="font-family:system-ui,sans-serif;max-width:560px;margin:80px auto;padding:0 16px;line-height:1.6">
      <h1 style="font-size:24px">This is the Resolve API (port ${PORT})</h1>
      <p>The website runs on <a href="http://localhost:5173">http://localhost:5173</a> while you use <code>npm run dev</code>.</p>
      <p>To serve the whole site from this port instead, run <code>npm run build</code> and then <code>npm start</code>.</p>
      </body>`);
  });
}

// Errors -> JSON
app.use((err, _req, res, _next) => {
  if (err.code === 'LIMIT_FILE_SIZE') return res.status(400).json({ error: 'A file is larger than the 10 MB limit.' });
  if (err.code === 'LIMIT_FILE_COUNT') return res.status(400).json({ error: 'You can attach up to 5 files.' });
  const status = err.status || 500;
  if (status === 500) console.error(err);
  res.status(status).json({ error: status === 500 ? 'Something went wrong on the server.' : err.message });
});

app.listen(PORT, () => {
  console.log(`Resolve API running on http://localhost:${PORT}`);
});
