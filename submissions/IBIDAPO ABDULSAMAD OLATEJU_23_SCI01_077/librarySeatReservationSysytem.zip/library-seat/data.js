// shared by the student page and the admin page

const FIRST_HOUR = 8;     // first slot starts at 08:00
const LAST_HOUR = 19;     // last slot is 19:00 - 20:00
const MAX_PER_DAY = 3;    // most slots one student can book per day

function pad(n) {
  return String(n).padStart(2, '0');
}

function dateToString(d) {
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}

function todayString() {
  return dateToString(new Date());
}

function slotLabel(hour) {
  return pad(hour) + ':00 - ' + pad(hour + 1) + ':00';
}

// stops typed text from being read as HTML
function safe(text) {
  return String(text).replace(/[&<>"']/g, c => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

// 40 seats: floor 1 has tables A-D, floor 2 has tables E-H, 5 seats each
function makeDefaultSeats() {
  const layout = { 1: ['A', 'B', 'C', 'D'], 2: ['E', 'F', 'G', 'H'] };
  const seats = [];
  for (const floor in layout) {
    layout[floor].forEach(table => {
      for (let n = 1; n <= 5; n++) {
        seats.push({ id: table + n, floor: Number(floor), table: table });
      }
    });
  }
  return seats;
}

function getSeats() {
  const saved = localStorage.getItem('lib_seats');
  if (saved) return JSON.parse(saved);
  const seats = makeDefaultSeats();
  saveSeats(seats);
  return seats;
}

function saveSeats(list) {
  localStorage.setItem('lib_seats', JSON.stringify(list));
}

function getReservations() {
  return JSON.parse(localStorage.getItem('lib_reservations') || '[]');
}

function saveReservations(list) {
  localStorage.setItem('lib_reservations', JSON.stringify(list));
}