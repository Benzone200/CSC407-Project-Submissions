let selectedSeat = null;

function el(id) {
  return document.getElementById(id);
}

function setupDate() {
  const input = el('date');
  const last = new Date();
  last.setDate(last.getDate() + 14); // bookings open for 14 days ahead
  input.min = todayString();
  input.max = dateToString(last);
  input.value = todayString();
}

// time slots that have already passed today are hidden
function fillTimes() {
  const date = el('date').value;
  const now = new Date();
  const previous = el('time').value;
  let html = '';

  for (let h = FIRST_HOUR; h <= LAST_HOUR; h++) {
    if (date === todayString() && h < now.getHours()) continue;
    html += `<option value="${h}">${slotLabel(h)}</option>`;
  }

  el('time').innerHTML = html || '<option value="">No slots left</option>';
  if (previous && el('time').querySelector(`option[value="${previous}"]`)) {
    el('time').value = previous;
  }
}

function clearSelection() {
  selectedSeat = null;
  el('formPanel').hidden = true;
}

// draws the seat map from the list of seats
function showMap() {
  const date = el('date').value;
  const hour = el('time').value;

  if (!date || hour === '') {
    el('map').innerHTML = '<p class="empty">No time slots left for this date. Pick another date.</p>';
    return;
  }

  const taken = getReservations()
    .filter(r => r.date === date && r.hour === Number(hour))
    .map(r => r.seatId);

  const seats = getSeats();
  const floors = [...new Set(seats.map(s => s.floor))].sort((a, b) => a - b);

  el('map').innerHTML = floors.map(floor => {
    const tables = [...new Set(seats.filter(s => s.floor === floor).map(s => s.table))];

    const tablesHtml = tables.map(table => {
      const seatsHtml = seats
        .filter(s => s.floor === floor && s.table === table)
        .map(s => {
          const isTaken = taken.includes(s.id);
          const status = isTaken ? 'taken' : (s.id === selectedSeat ? 'selected' : 'free');
          return `<button class="seat ${status}" data-id="${safe(s.id)}" ${isTaken ? 'disabled' : ''}>${safe(s.id)}</button>`;
        }).join('');

      return `<div class="table"><div class="table-name">Table ${safe(table)}</div><div class="seats">${seatsHtml}</div></div>`;
    }).join('');

    return `<h3>Floor ${floor}</h3><div class="floor">${tablesHtml}</div>`;
  }).join('');
}

function showMine() {
  const id = el('lookup').value.trim().toUpperCase();
  if (!id) {
    el('mine').innerHTML = '';
    return;
  }

  const mine = getReservations()
    .filter(r => r.studentId === id)
    .sort((a, b) => a.date.localeCompare(b.date) || a.hour - b.hour);

  if (mine.length === 0) {
    el('mine').innerHTML = '<p class="empty">No reservations found for this ID.</p>';
    return;
  }

  el('mine').innerHTML = mine.map(r => `
    <div class="row">
      <div>
        <strong>Seat ${safe(r.seatId)}</strong> · ${safe(r.date)} · ${slotLabel(r.hour)}<br>
        <small>Reference: ${safe(r.id)}</small>
      </div>
      <button class="btn danger small" data-cancel="${safe(r.id)}">Cancel</button>
    </div>`).join('');
}

/* ---------- events ---------- */

el('date').addEventListener('change', function () {
  fillTimes();
  clearSelection();
  showMap();
});

el('time').addEventListener('change', function () {
  clearSelection();
  showMap();
});

el('map').addEventListener('click', function (e) {
  const btn = e.target.closest('.seat');
  if (!btn || btn.disabled) return;

  selectedSeat = btn.dataset.id;
  showMap();

  el('seatInfo').textContent =
    'Seat ' + selectedSeat + ' · ' + el('date').value + ' · ' + slotLabel(Number(el('time').value));
  el('error').textContent = '';
  el('message').hidden = true;
  el('formPanel').hidden = false;
  el('name').focus();
});

el('cancelForm').onclick = function () {
  clearSelection();
  showMap();
};

el('form').addEventListener('submit', function (e) {
  e.preventDefault();

  const name = el('name').value.trim();
  const studentId = el('studentId').value.trim().toUpperCase();
  const date = el('date').value;
  const hour = Number(el('time').value);

  if (!name) {
    el('error').textContent = 'Enter your full name.';
    return;
  }
  if (!/^[A-Z0-9\/-]{3,20}$/.test(studentId)) {
    el('error').textContent = 'Enter a valid student ID (letters, numbers, / or -).';
    return;
  }

  const reservations = getReservations();

  // someone may have taken the seat while this page was open
  if (reservations.some(r => r.seatId === selectedSeat && r.date === date && r.hour === hour)) {
    el('error').textContent = 'That seat was just taken. Please pick another one.';
    showMap();
    return;
  }
  if (reservations.some(r => r.studentId === studentId && r.date === date && r.hour === hour)) {
    el('error').textContent = 'You already have a seat for this time slot.';
    return;
  }
  if (reservations.filter(r => r.studentId === studentId && r.date === date).length >= MAX_PER_DAY) {
    el('error').textContent = 'You can book at most ' + MAX_PER_DAY + ' slots per day.';
    return;
  }

  const reservation = {
    id: 'RES-' + Date.now().toString(36).toUpperCase(),
    createdAt: new Date().toISOString(),
    seatId: selectedSeat,
    date: date,
    hour: hour,
    name: name,
    studentId: studentId
  };

  reservations.push(reservation);
  saveReservations(reservations);

  el('message').textContent =
    'Seat ' + reservation.seatId + ' reserved for ' + date + ', ' + slotLabel(hour) +
    '. Your reference is ' + reservation.id + '.';
  el('message').hidden = false;

  el('form').reset();
  clearSelection();
  showMap();
  showMine();
});

el('lookupForm').addEventListener('submit', function (e) {
  e.preventDefault();
  showMine();
});

el('mine').addEventListener('click', function (e) {
  const btn = e.target.closest('[data-cancel]');
  if (!btn) return;
  if (!confirm('Cancel this reservation?')) return;

  saveReservations(getReservations().filter(r => r.id !== btn.dataset.cancel));
  showMine();
  showMap();
});

/* ---------- start ---------- */
setupDate();
fillTimes();
showMap();