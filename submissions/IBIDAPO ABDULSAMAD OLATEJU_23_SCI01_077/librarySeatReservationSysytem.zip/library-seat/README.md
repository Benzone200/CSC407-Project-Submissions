Library Seat Reservation System

A simple web app for booking library seats, built with HTML, CSS, and JavaScript.

What It Does

Student Page (index.html): Students can pick a date and time slot, select an available seat on the map, reserve it with their name and Student ID, and view or cancel their bookings.

Admin Page (admin.html): Admins can view all reservations by date, cancel bookings, and add or remove library seats.

Files Included

index.html - Student reservation page

admin.html - Admin management page

style.css - Page styling

script.js - Student booking logic

data.js - Seat layout and localStorage functions

How to Run

Unzip the project folder.

Double-click index.html to open it in any web browser.

Click Admin in the top-right corner to open the admin dashboard.

Notes

No installations or internet connection required.

Data is saved in the browser's localStorage.