# Flask portal test results

Run the suite from the project directory with `python -m unittest discover -s tests -v`. It exercises the Flask request routes and templates through Flask’s test client and uses temporary SQLite files.

## Automated checks

**19 passed, 0 failed** on Windows with Python 3.14.7 and Flask 3.1.3. The recorded run took 34.2 seconds.

| Test | Expected result | Actual result | Status |
| --- | --- | --- | --- |
| Public pages and assets | Homepage, noticeboard, Security, Project Review, CSS and photo load | Pages and assets returned 200 with the expected content or file type. | Pass |
| Guest access | Account pages redirect to login and the admin page is denied | Account pages redirected with 303. The admin page returned 403. | Pass |
| Valid registration | Register as a resident and rotate the anonymous session | Resident dashboard loaded. The session changed and the old cookie did not grant access. | Pass |
| Invalid registration | Reject empty fields and duplicate email | Both returned 422. Empty fields displayed validation feedback. | Pass |
| Password and session storage | Store salted password hashes and a hash of the session identifier | scrypt verified the stored hash. Identical passwords had distinct hashes, and the stored session hash differed from the browser token. | Pass |
| Login | Correct credentials open the dashboard. Wrong credentials receive a generic error. | Valid login redirected to dashboard. Both invalid credential cases returned 401 with the same message. | Pass |
| Profile | Save a valid name and require the current password for an email change | Name changed. The email change failed without the password and succeeded with it. | Pass |
| Notice form | Reject missing or incorrect CSRF, duplicate fields and invalid data | Incorrect CSRF returned 403, duplicate fields returned 400 and the invalid title and date returned 422. | Pass |
| Pending notice and ownership | Only the author and admin can see a pending notice | Author and admin saw the notice. Another resident and the public could not see it. | Pass |
| Admin authorization | A resident cannot view the review queue or change a notice’s status | Both resident requests returned 403. | Pass |
| Publishing and output escaping | Approval publishes the notice once. User markup is displayed as text. | Public detail returned 200. Second approval returned 409. Markup stayed escaped in public and admin views. | Pass |
| Search and filter | Treat apostrophes as ordinary text and combine search with the category filter | Same keyword returned one Events result and zero Services results. | Pass |
| Decline | Author sees the new status and the notice remains private | Dashboard showed Declined. Public detail returned 404. | Pass |
| Logout and expiry | Reject revoked and expired sessions | Both sessions were denied admin access. | Pass |
| Request limits and errors | Handle repeated authentication requests, unknown pages, wrong methods and oversized forms | Returned 429 after 15 attempts. Observed expected responses for 404, 405, 415 and 413. Registration supported HEAD. | Pass |
| SQLite integrity and persistence | Saved notices survive recreating the app and foreign keys are enforced | Published notice remained public. SQLite reported an intact database with zero foreign-key violations and rejected an invalid author. | Pass |
| Accessibility and responsive source | Provide labelled inputs, keyboard focus styles and layout breakpoints | The generated HTML and CSS contained the expected controls and rules. | Pass |
| HTTPS configuration | Set Secure cookies and HSTS and reject unknown hostnames | HTTPS-mode responses contained the expected headers. An untrusted host returned 400. | Pass |
| Demo provisioning | Re-running setup preserves the same sample rows and creates a working admin login | After two runs, the database had two accounts and three notices. The demo admin signed in and opened the review queue. | Pass |

## Browser walkthrough

Live layout and keyboard usability are pending. Run these checks after starting the demo.

| Test | Expected result | Actual result | Status |
| --- | --- | --- | --- |
| Desktop browser | Top navigation, search and notice details are readable. Tab reaches the skip link and form controls in order. | Browser observation pending. | Pending |
| Phone viewport at 375 px | Navigation stays reachable, notice cards stack, and fields and buttons fit without horizontal scrolling. | Browser observation pending. | Pending |
| Online TLS | A valid certificate and an HTTP-to-HTTPS redirect are present on the hosted domain. | The local demo uses HTTP. Automated verification covered only HTTPS-mode headers and hostname checks. | Hosting check |
