# Maple Junction Community Portal

A Flask and SQLite community portal for a fictional neighbourhood. It uses Python on the server and Jinja templates, HTML and CSS in the browser.

## Run in VS Code

1. Open the `maple-junction-flask` folder in VS Code.
2. Open `portal.py` and click **▶ Run Python File** in the top-right corner. Flask sets up the demo database on the first run.
3. Open [http://127.0.0.1:5000](http://127.0.0.1:5000) in your browser. Keep the VS Code terminal open while using the portal.

You can also select **Run Maple Junction** in VS Code’s **Run and Debug** panel. Press **Ctrl+C** in the terminal or click **Stop** on the debug toolbar to stop the server.

### First-time setup on a new computer

Use Python 3.11 or later with SQLite 3.35 or later and install Microsoft’s Python extension for VS Code. Use **Python: Select Interpreter** in the command palette to choose your environment. If it does not have Flask, install the project dependencies once in that Python environment with `python -m pip install -r requirements.txt`. On systems where Python is called `python3`, use `python3` in that command.

On Windows, if VS Code cannot find your per-user Python 3.14 installation, choose **Enter interpreter path** and select `AppData\Local\Programs\Python\Python314\python.exe` under your Windows profile folder. [VS Code Python setup](https://code.visualstudio.com/docs/python/python-tutorial)

| Account | Email | Demo password |
| --- | --- | --- |
| Resident | resident@maple.example | Maple-Demo-Resident!24 |
| Administrator | admin@maple.example | Maple-Demo-Admin!24 |

The demo credentials are for the local example database. Your saved notices survive restarts. To start with a fresh demo, stop Flask, rename the project's `instance` directory, and click **Run Python File** again.

## Submit on GitHub

Extract the ZIP and upload the contents of the `maple-junction-flask` folder to the repository root, so `README.md` and `portal.py` are visible together. Include `.gitignore`. If you use GitHub's web uploader after running locally, leave out `.venv`, `instance`, `__pycache__`, and any `.env` file. Flask creates the database on the machine where it runs.

## Assignment demonstration

1. Search for **market** from the homepage, then filter the noticeboard to **Services**.
2. Register a new fictional resident account and update its name in **Profile**.
3. Submit a notice. Show **Pending review** on the dashboard and search for it on the public noticeboard.
4. Visit **/admin** while signed in as a resident to show access denial. Log out.
5. Sign in as the demo administrator, open **Review queue**, and publish the notice.
6. Find the published notice on the public noticeboard. Open **Security** and **Project review** from the footer.

## Submission files

| File | Contents |
| --- | --- |
| portal.py and schema.sql | Flask routes and CLI, security controls and SQLite schema |
| templates/ and static/ | Jinja templates, responsive CSS and an illustrative AI-generated market photograph |
| tests/ | Automated tests using Flask’s test client and a temporary SQLite database |
| TEST-RESULTS.md | Test results and browser checks to run during the demonstration |
| DEPLOYMENT.md | Local and production configuration, HTTPS, backups and monitoring |
| PROJECT-REVIEW.md | Evaluation, limitations and future improvements |

Run the test suite with `python -m unittest discover -s tests -v` using the same Python environment that has Flask installed.
