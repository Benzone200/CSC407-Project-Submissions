# Deployment guide

## Local demonstration

Run `portal.py` in VS Code or with `python portal.py`. The demo creates the SQLite schema, adds example accounts and notices, and binds to `127.0.0.1:5000` with Flask debugging disabled.

## Environment variables

| Variable | Purpose |
| --- | --- |
| PORTAL_MODE | Set to `production` for Secure cookies, HSTS and a host allowlist. Use `portal:create_app` as the production entry point. |
| PORTAL_DATABASE | SQLite path. Defaults to `instance/portal.sqlite`. Use an absolute path on persistent storage in production. |
| PORTAL_SECRET_KEY | Flask signing key. Generate a long random value with a password manager or `python -c "import secrets; print(secrets.token_hex(32))"`. Store it in the host’s secret store. Local mode generates an ephemeral key if this is unset. |
| PORTAL_TRUSTED_HOSTS | Comma-separated hostnames accepted in production. Set it to the domain forwarded by the reverse proxy. |

## Deploy to an online host

1. Choose a host that supports Python, a persistent SQLite directory and a TLS reverse proxy. Configure a dedicated service account with filesystem access to the database directory. Install `requirements.txt` and the production WSGI server Waitress in the service’s virtual environment.
2. Set the production variables. Use a fresh database and provision an administrator with `python -m flask --app portal create-admin`. The command prompts for the password without displaying it. Use separate production credentials.
3. Start a supervised process with `waitress-serve --host=127.0.0.1 --port=8000 --call portal:create_app`. Flask's development server is for the local demo. [Flask’s Waitress deployment instructions](https://flask.palletsprojects.com/en/stable/deploying/waitress/)
4. Point your domain’s DNS at the reverse proxy. Obtain a certificate for that domain, redirect public HTTP to HTTPS, and forward HTTPS requests to the loopback Waitress port. Forward the approved public Host header. Keep the application port private. At the proxy, add per-client request limiting for the authentication endpoints. The application’s connection-based limit sees the proxy address in this setup.
5. From the public URL, repeat registration, login, logout and publication. In your browser, check that the certificate is valid, HTTP redirects to HTTPS, HSTS is present, and the session cookie has Secure, HttpOnly and SameSite=Lax attributes.

## Backup and monitoring

Use a SQLite-consistent backup via SQLite’s `.backup` command or the standard Python `sqlite3.Connection.backup` API. Schedule encrypted, access-restricted backups and restore one into a test directory to verify its contents. Preserve the signing key securely. Rotating it invalidates sessions signed with the old key.

Send the service and reverse proxy logs to your host’s retained logging system. Check the homepage for availability and monitor 5xx responses, authentication throttling, disk use, restarts and certificate expiry. Keep session cookies, passwords and submitted form bodies out of log records. Back up the database before releases, test changes on a separate environment, and retain the previous release for rollback.

The delivered assignment is a local demonstration. The hosting instructions cover the transition to public HTTPS.
