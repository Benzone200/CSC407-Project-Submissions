import re
import sqlite3
import tempfile
import unittest
from pathlib import Path

from werkzeug.datastructures import MultiDict
from werkzeug.security import check_password_hash

from portal import create_app, get_db, hash_password


PASSWORD = "A classroom passphrase 24!"
RESIDENT = "resident@assignment.example"
ADMIN = "admin@assignment.example"
TITLE = "Neighbour's garden workshop"
NOTICE = {
    "title": TITLE, "category": "Events", "location": "Community garden",
    "body": "Bring gloves and meet us by the <b>green table</b> at the entrance.",
    "event_date": "2027-01-16",
}


class PortalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.directory.cleanup)
        cls.db_path = Path(cls.directory.name) / "test.sqlite"
        cls.config = {"TESTING": True, "PRODUCTION": False, "DATABASE": cls.db_path}
        cls.app = create_app(cls.config)
        cls.admin_password = hash_password(PASSWORD)

    def setUp(self):
        with self.app.app_context():
            db = get_db()
            with db:
                for table in ("auth_limits", "notices", "sessions", "users"):
                    db.execute(f"DELETE FROM {table}")  # fixed test fixture names
                db.execute(
                    "INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'admin')",
                    ("Test administrator", ADMIN, self.admin_password),
                )
        self.visitor = self.app.test_client()
        self.resident = self.app.test_client()
        self.admin = self.app.test_client()

    def token(self, client, route):
        page = client.get(route)
        self.assertEqual(page.status_code, 200)
        return re.search(r'name="csrf" value="([a-f0-9]{64})"', page.text)[1]

    def register(self, client=None, email=RESIDENT, **more):
        client = client or self.resident
        return client.post("/register", data={
            "csrf": self.token(client, "/register"), "name": "Test resident",
            "email": email, "password": PASSWORD, **more,
        })

    def sign_in(self, client, email=ADMIN, password=PASSWORD):
        return client.post("/login", data={
            "csrf": self.token(client, "/login"), "email": email, "password": password,
        })

    def submit(self, **overrides):
        response = self.resident.post("/submit", data={
            "csrf": self.token(self.resident, "/submit"), **NOTICE, **overrides,
        })
        self.assertEqual(response.status_code, 303)
        with self.app.app_context():
            return get_db().execute("SELECT id FROM notices ORDER BY id DESC").fetchone()["id"]

    def moderation(self, notice_id, decision):
        return self.admin.post(f"/admin/notices/{notice_id}", data={
            "csrf": self.token(self.admin, "/admin"), "decision": decision,
        })

    def test_public_pages_and_assets(self):
        for path, text in (
            ("/", "Close to home"), ("/notices", "No notices match"),
            ("/security", "scrypt"), ("/review", "Performance observations"),
        ):
            with self.subTest(path=path):
                page = self.visitor.get(path)
                self.assertEqual(page.status_code, 200)
                self.assertIn(text, page.text)
        for asset, content_type in (("styles.css", "text/css"), ("market.jpg", "image/jpeg")):
            with self.visitor.get(f"/static/{asset}") as response:
                self.assertEqual(response.status_code, 200)
                self.assertEqual(response.mimetype, content_type)

    def test_guest_requires_login_for_private_pages(self):
        for path in ("/dashboard", "/profile", "/submit"):
            page = self.visitor.get(path)
            self.assertEqual((page.status_code, page.location), (303, "/login"))
        self.assertEqual(self.visitor.get("/admin").status_code, 403)

    def test_valid_registration_rotates_session_and_ignores_role(self):
        self.token(self.resident, "/register")
        anonymous_cookie = self.resident.get_cookie("maple").value
        registered = self.register(role="admin")
        self.assertEqual((registered.status_code, registered.location), (303, "/dashboard"))
        self.assertNotEqual(anonymous_cookie, self.resident.get_cookie("maple").value)
        self.assertIn("Welcome, Test resident", self.resident.get("/dashboard").text)
        old = self.app.test_client()
        old.set_cookie("maple", anonymous_cookie)
        self.assertEqual(old.get("/dashboard").status_code, 303)
        self.assertEqual(self.resident.get("/admin").status_code, 403)

    def test_empty_and_duplicate_registration(self):
        bad = self.register(name="", email="", password="")
        self.assertEqual(bad.status_code, 422)
        self.assertIn("Enter a valid email address", bad.text)
        self.assertEqual(self.register(email=ADMIN).status_code, 422)

    def test_salted_passwords_and_hashed_session_identifier(self):
        self.assertEqual(self.register().status_code, 303)
        with self.resident.session_transaction() as browser_session:
            token = browser_session["sid"]
        with self.app.app_context():
            db = get_db()
            person = db.execute("SELECT * FROM users WHERE email = ?", (RESIDENT,)).fetchone()
            self.assertEqual(person["role"], "resident")
            self.assertTrue(person["password_hash"].startswith("scrypt:"))
            self.assertTrue(check_password_hash(person["password_hash"], PASSWORD))
            self.assertNotEqual(person["password_hash"], self.admin_password)
            stored = db.execute("SELECT token_hash FROM sessions WHERE user_id = ?", (person["id"],)).fetchone()
            self.assertRegex(stored["token_hash"], r"^[a-f0-9]{64}$")
            self.assertNotEqual(stored["token_hash"], token)

    def test_login_success_and_generic_failure(self):
        for email, password in ((ADMIN, "incorrect password"), ("no@assignment.example", PASSWORD)):
            wrong = self.sign_in(self.admin, email, password)
            self.assertEqual(wrong.status_code, 401)
            self.assertIn("The email address or password is incorrect.", wrong.text)
        correct = self.sign_in(self.admin)
        self.assertEqual((correct.status_code, correct.location), (303, "/dashboard"))
        self.assertIn("Welcome, Test administrator", self.admin.get("/dashboard").text)

    def test_profile_validates_email_change_and_saves_name(self):
        self.register()
        csrf = self.token(self.resident, "/profile")
        changed = self.resident.post("/profile", data={"csrf": csrf, "name": "New name", "email": RESIDENT})
        self.assertEqual(changed.status_code, 303)
        self.assertIn("Welcome, New name", self.resident.get("/dashboard").text)
        data = {"csrf": csrf, "name": "New name", "email": "updated@assignment.example"}
        denied = self.resident.post("/profile", data=data)
        self.assertEqual(denied.status_code, 422)
        self.assertIn("Enter your current password", denied.text)
        self.assertEqual(self.resident.post("/profile", data={**data, "password": PASSWORD}).status_code, 303)
        self.assertIn("updated@assignment.example", self.resident.get("/profile").text)

    def test_notice_validation_csrf_and_duplicate_fields(self):
        self.register()
        csrf = self.token(self.resident, "/submit")
        denied = self.resident.post("/submit", data={**NOTICE, "csrf": "incorrect"})
        self.assertEqual(denied.status_code, 403)
        invalid = self.resident.post("/submit", data={**NOTICE, "csrf": csrf, "title": "", "event_date": "2027-02-30"})
        self.assertEqual(invalid.status_code, 422)
        self.assertIn("Enter a valid calendar date", invalid.text)
        self.assertIn("Enter a title", invalid.text)
        duplicate = self.resident.post("/submit", data=MultiDict([("csrf", csrf), ("title", "One"), ("title", "Two")]))
        self.assertEqual(duplicate.status_code, 400)

    def test_pending_notice_visible_only_to_owner_and_admin(self):
        self.register()
        notice_id = self.submit()
        self.assertIn("Pending review", self.resident.get("/dashboard").text)
        second = self.app.test_client()
        self.register(second, email="other@assignment.example")
        self.assertNotIn("garden workshop", second.get("/dashboard").text)
        self.assertEqual(self.visitor.get(f"/notices/{notice_id}").status_code, 404)
        self.assertIn("0 notices", self.visitor.get("/notices?q=workshop").text)
        self.sign_in(self.admin)
        self.assertIn("garden workshop", self.admin.get("/admin").text)

    def test_resident_cannot_open_queue_or_moderate(self):
        self.register()
        notice_id = self.submit()
        csrf = self.token(self.resident, "/submit")
        self.assertEqual(self.resident.get("/admin").status_code, 403)
        self.assertEqual(self.resident.post(
            f"/admin/notices/{notice_id}", data={"csrf": csrf, "decision": "publish"},
        ).status_code, 403)

    def test_publication_escapes_user_text_and_prevents_duplicate_decision(self):
        self.register()
        notice_id = self.submit()
        self.sign_in(self.admin)
        self.assertIn("&lt;b&gt;green table&lt;/b&gt;", self.admin.get("/admin").text)
        self.assertEqual(self.moderation(notice_id, "publish").status_code, 303)
        self.assertEqual(self.moderation(notice_id, "publish").status_code, 409)
        page = self.visitor.get(f"/notices/{notice_id}")
        self.assertEqual(page.status_code, 200)
        self.assertIn("&lt;b&gt;green table&lt;/b&gt;", page.text)
        self.assertNotIn("<b>green table</b>", page.text)
        self.assertIn("default-src 'none'", page.headers["Content-Security-Policy"])

    def test_search_and_category_filters_treat_apostrophes_as_text(self):
        self.register()
        notice_id = self.submit()
        self.sign_in(self.admin)
        self.moderation(notice_id, "publish")
        results = self.visitor.get("/notices", query_string={"q": "Neighbour's", "category": "Events"})
        self.assertIn("1 notice</h2>", results.text)
        self.assertIn("Neighbour&#39;s garden workshop", results.text)
        results = self.visitor.get("/notices", query_string={"q": "Neighbour's", "category": "Services"})
        self.assertIn("0 notices</h2>", results.text)

    def test_declined_notice_remains_private(self):
        self.register()
        notice_id = self.submit()
        self.sign_in(self.admin)
        self.assertEqual(self.moderation(notice_id, "decline").status_code, 303)
        self.assertIn("Declined", self.resident.get("/dashboard").text)
        self.assertEqual(self.visitor.get(f"/notices/{notice_id}").status_code, 404)

    def test_logout_and_expired_session(self):
        self.sign_in(self.admin)
        csrf = self.token(self.admin, "/admin")
        before_logout = self.admin.get_cookie("maple").value
        self.assertEqual(self.admin.post("/logout", data={"csrf": csrf}).status_code, 303)
        retry = self.app.test_client()
        retry.set_cookie("maple", before_logout)
        self.assertEqual(retry.get("/admin").status_code, 403)
        self.sign_in(self.admin)
        with self.app.app_context():
            db = get_db()
            with db:
                db.execute("UPDATE sessions SET expires_at = 0")
        self.assertEqual(self.admin.get("/admin").status_code, 403)

    def test_rate_limit_and_error_responses(self):
        csrf = self.token(self.visitor, "/login")
        for _ in range(15):
            self.assertEqual(self.visitor.post("/login", data={"csrf": csrf, "password": "short"}).status_code, 401)
        self.assertEqual(self.visitor.post("/login", data={"csrf": csrf, "password": "short"}).status_code, 429)
        self.assertEqual(self.visitor.put("/").status_code, 405)
        self.assertEqual(self.visitor.head("/register").status_code, 200)
        error = self.visitor.get("/missing")
        self.assertEqual(error.status_code, 404)
        self.assertIn("Return to the homepage", error.text)
        self.assertEqual(self.visitor.post("/login", json={}).status_code, 415)
        excessive = self.visitor.post("/login", data={"csrf": csrf, "password": "x" * 21_000})
        self.assertEqual(excessive.status_code, 413)

    def test_database_integrity_and_persistence_across_app_factory(self):
        self.register()
        notice_id = self.submit()
        self.sign_in(self.admin)
        self.moderation(notice_id, "publish")
        restarted = create_app(self.config)
        self.assertEqual(restarted.test_client().get(f"/notices/{notice_id}").status_code, 200)
        with restarted.app_context():
            db = get_db()
            self.assertEqual(db.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(db.execute("PRAGMA foreign_key_check").fetchall(), [])
            with self.assertRaises(sqlite3.IntegrityError):
                db.execute("UPDATE notices SET author_id = -1 WHERE id = ?", (notice_id,))

    def test_usable_labels_and_responsive_source(self):
        home = self.visitor.get("/")
        self.assertIn('name="viewport"', home.text)
        self.assertIn('class="skip" href="#main"', home.text)
        self.assertIn('aria-label="Main navigation"', home.text)
        self.assertIn('<label for="home-search">', home.text)
        register = self.visitor.get("/register")
        self.assertIn('<label for="email">', register.text)
        with self.visitor.get("/static/styles.css") as css:
            self.assertIn("@media (max-width: 720px)", css.text)
            self.assertIn("@media (max-width: 480px)", css.text)
            self.assertIn(":focus-visible", css.text)

    def test_https_settings_and_trusted_hosts(self):
        production = create_app({
            **self.config, "PRODUCTION": True, "SECRET_KEY": "local-test-key-" + "x" * 32,
            "SESSION_COOKIE_SECURE": True, "SESSION_COOKIE_NAME": "__Host-maple",
            "TRUSTED_HOSTS": ["portal.example"],
        })
        client = production.test_client()
        self.assertEqual(client.get("/", base_url="https://untrusted.example").status_code, 400)
        page = client.get("/login", base_url="https://portal.example")
        self.assertEqual(page.status_code, 200)
        self.assertEqual(page.headers["Strict-Transport-Security"], "max-age=31536000")
        cookie = page.headers["Set-Cookie"]
        for text in ("__Host-maple=", "Secure", "HttpOnly", "Path=/", "SameSite=Lax"):
            self.assertIn(text, cookie)

    def test_demo_command_is_repeatable_and_seeds_usable_accounts(self):
        with tempfile.TemporaryDirectory() as work:
            demo = create_app({**self.config, "DATABASE": Path(work) / "demo.sqlite"})
            runner = demo.test_cli_runner()
            for _ in range(2):
                result = runner.invoke(args=["init-demo"])
                self.assertEqual(result.exit_code, 0, result.output or result.exception)
            with demo.app_context():
                db = get_db()
                self.assertEqual(db.execute("SELECT count(*) FROM users").fetchone()[0], 2)
                self.assertEqual(db.execute("SELECT count(*) FROM notices").fetchone()[0], 3)
            admin = demo.test_client()
            self.assertEqual(self.sign_in(admin, "admin@maple.example", "Maple-Demo-Admin!24").status_code, 303)
            self.assertEqual(admin.get("/admin").status_code, 200)


if __name__ == "__main__":
    unittest.main()
