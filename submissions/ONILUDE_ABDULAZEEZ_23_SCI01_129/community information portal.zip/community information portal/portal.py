import os
import re
import secrets
import sqlite3
import time
from datetime import date, timedelta
from functools import wraps
from hashlib import sha256
from pathlib import Path

import click
from flask import (
    Flask, abort, current_app, flash, g, redirect, render_template, request,
    session, url_for,
)
from flask.cli import with_appcontext
from werkzeug.exceptions import HTTPException
from werkzeug.security import check_password_hash, generate_password_hash


CATEGORIES = ("Announcements", "Events", "Services")
HASH_METHOD = "scrypt:65536:8:2"
HERE = Path(__file__).resolve().parent
PUBLIC_NOTICES = "SELECT * FROM notices WHERE status = 'published'"
LATEST_FIRST = " ORDER BY published_at DESC, id DESC"


def create_app(config=None):
    app = Flask(__name__)
    production = os.environ.get("PORTAL_MODE") == "production"
    app.config.from_mapping(
        PRODUCTION=production,
        SECRET_KEY=os.environ.get("PORTAL_SECRET_KEY"),
        DATABASE=os.environ.get("PORTAL_DATABASE") or Path(app.instance_path) / "portal.sqlite",
        TRUSTED_HOSTS=os.environ.get("PORTAL_TRUSTED_HOSTS", "").split(",") if production else None,
        MAX_CONTENT_LENGTH=20 * 1024,
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
        SESSION_REFRESH_EACH_REQUEST=False,
        SESSION_COOKIE_NAME="__Host-maple" if production else "maple",
        SESSION_COOKIE_PATH="/",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=production,
    )
    if config:
        app.config.update(config)
    if app.config["PRODUCTION"]:
        if len(app.config["SECRET_KEY"] or "") < 32 or app.config["TRUSTED_HOSTS"] in (None, [""]):
            raise RuntimeError("Production needs PORTAL_SECRET_KEY and PORTAL_TRUSTED_HOSTS.")
    elif not app.config["SECRET_KEY"]:
        app.config["SECRET_KEY"] = secrets.token_hex(32)

    app.config["DUMMY_HASH"] = hash_password(secrets.token_urlsafe(32))
    app.teardown_appcontext(close_db)
    with app.app_context():
        db = get_db()
        db.execute("PRAGMA journal_mode = WAL")
        db.executescript((HERE / "schema.sql").read_text(encoding="utf-8"))
    app.before_request(load_session)
    app.after_request(security_headers)
    app.context_processor(lambda: {"user": getattr(g, "user", None), "categories": CATEGORIES})
    app.jinja_env.filters["notice_date"] = format_date
    app.register_error_handler(HTTPException, error_page)
    app.cli.add_command(init_demo)
    app.cli.add_command(create_admin)
    register_routes(app)
    return app


def create_demo_app():
    if os.environ.get("PORTAL_MODE") == "production":
        raise RuntimeError("Choose a local environment for the demo database.")
    return create_app({"DATABASE": HERE / "instance" / "demo.sqlite"})


def get_db():
    if "db" not in g:
        path = Path(current_app.config["DATABASE"])
        path.parent.mkdir(parents=True, exist_ok=True)
        g.db = sqlite3.connect(path, timeout=5)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def hash_password(value):
    return generate_password_hash(value, method=HASH_METHOD)


def valid_password(value):
    return 12 <= len(value) <= 128


def valid_email(value):
    return len(value) <= 254 and bool(re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value))


def token_hash(value):
    return sha256(value.encode("ascii")).hexdigest()


def lookup_session():
    token = session.get("sid")
    if not isinstance(token, str) or not re.fullmatch(r"[0-9a-f]{64}", token):
        return None
    return get_db().execute(
        """SELECT s.token_hash, s.csrf, s.user_id, u.name, u.email, u.role
           FROM sessions AS s LEFT JOIN users AS u ON s.user_id = u.id
           WHERE s.token_hash = ? AND s.expires_at > ?""",
        (token_hash(token), int(time.time())),
    ).fetchone()


def new_session(user_id=None):
    token, csrf = secrets.token_hex(32), secrets.token_hex(32)
    now = int(time.time())
    db = get_db()
    with db:
        db.execute("DELETE FROM sessions WHERE expires_at <= ?", (now,))
        if g.login_session:
            db.execute("DELETE FROM sessions WHERE token_hash = ?", (g.login_session["token_hash"],))
        db.execute("INSERT INTO sessions VALUES (?, ?, ?, ?)",
                   (token_hash(token), csrf, user_id, now + (28800 if user_id else 3600)))
    session.clear()
    session.permanent = True
    session["sid"] = token
    return csrf


def csrf_token():
    if g.login_session:
        return g.login_session["csrf"]
    return new_session()


def load_session():
    g.login_session = None
    g.user = None
    if request.routing_exception is not None or request.endpoint == "static":
        return
    g.login_session = lookup_session()
    if g.login_session and g.login_session["user_id"] is not None:
        g.user = g.login_session


def verify_form():
    if request.mimetype != "application/x-www-form-urlencoded":
        abort(415, "Submit the form from this website.")
    form = request.form
    if any(len(form.getlist(key)) != 1 for key in form):
        abort(400, "A form field was submitted more than once.")
    value = form.get("csrf", "")
    active = lookup_session()
    if not active or not re.fullmatch(r"[0-9a-f]{64}", value) or not secrets.compare_digest(value, active["csrf"]):
        abort(403, "This form has expired. Open the form again and retry.")
    return form


def signed_in(view):
    @wraps(view)
    def require_session(*args, **kwargs):
        if g.user is None:
            return redirect(url_for("login"), code=303)
        return view(*args, **kwargs)
    return require_session


def administrator(view):
    @wraps(view)
    def require_admin(*args, **kwargs):
        if g.user is None or g.user["role"] != "admin":
            abort(403, "Only administrators can access the review queue.")
        return view(*args, **kwargs)
    return require_admin


def limit_auth_attempts():
    now = int(time.time())
    db = get_db()
    with db:
        db.execute("DELETE FROM auth_limits WHERE expires_at <= ?", (now,))
        row = db.execute(
            """INSERT INTO auth_limits VALUES (?, 1, ?)
               ON CONFLICT(address) DO UPDATE SET attempts = min(auth_limits.attempts + 1, 16)
               RETURNING attempts""", (request.remote_addr or "unknown", now + 60)
        ).fetchall()[0]
    if row["attempts"] > 15:
        abort(429, "Too many attempts. Please wait a minute and try again.")


def account_data(form):
    data = {"name": form.get("name", "").strip(), "email": form.get("email", "").strip().lower()}
    errors = []
    if not 2 <= len(data["name"]) <= 80:
        errors.append("Enter a name between 2 and 80 characters.")
    if not valid_email(data["email"]):
        errors.append("Enter a valid email address.")
    return data, errors


def notice_data(form):
    data = {key: form.get(key, "").strip() for key in ("title", "category", "location", "body", "event_date")}
    errors = []
    if not 5 <= len(data["title"]) <= 100:
        errors.append("Enter a title between 5 and 100 characters.")
    if data["category"] not in CATEGORIES:
        errors.append("Choose a category.")
    if not 1 <= len(data["location"]) <= 100:
        errors.append("Enter a location up to 100 characters.")
    if not 20 <= len(data["body"]) <= 2000:
        errors.append("Enter details between 20 and 2,000 characters.")
    if data["event_date"]:
        try:
            event = date.fromisoformat(data["event_date"])
            if event.isoformat() != data["event_date"] or event.year < 1000:
                raise ValueError
        except ValueError:
            errors.append("Enter a valid calendar date.")
    elif data["category"] == "Events":
        errors.append("Enter a date for the event.")
    return data, errors


def format_date(value):
    return date.fromisoformat(value[:10]).strftime("%d %b %Y").lstrip("0")


def form_page(mode, data=None, errors=(), status=200):
    return render_template("form.html", mode=mode, values=dict(data or {}), errors=errors, csrf=csrf_token()), status


def security_headers(response):
    response.headers["Content-Security-Policy"] = (
        "default-src 'none'; style-src 'self'; img-src 'self'; "
        "form-action 'self'; frame-ancestors 'none'; base-uri 'none'"
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    if request.endpoint != "static":
        response.headers["Cache-Control"] = "no-store"
    if current_app.config["SESSION_COOKIE_SECURE"]:
        response.headers["Strict-Transport-Security"] = "max-age=31536000"
    return response


def error_page(error):
    description = "Please try again in a moment." if error.code == 500 else error.description
    response = error.get_response()
    response.set_data(render_template("error.html", title=error.name, intro=description))
    response.content_type = "text/html; charset=utf-8"
    return response


def register_routes(app):
    @app.get("/")
    def home():
        notices = get_db().execute(PUBLIC_NOTICES + LATEST_FIRST + " LIMIT 3").fetchall()
        return render_template("home.html", notices=notices)

    @app.get("/notices")
    def noticeboard():
        query = request.args.get("q", "").strip()[:100]
        category = request.args.get("category", "")
        if category not in CATEGORIES:
            category = ""
        notices = get_db().execute(
            PUBLIC_NOTICES +
            """ AND (? = '' OR category = ?)
                AND instr(lower(title || ' ' || location || ' ' || body), lower(?)) > 0""" +
            LATEST_FIRST, (category, category, query),
        ).fetchall()
        return render_template("notices.html", notices=notices, query=query, category=category)

    @app.get("/notices/<int:notice_id>")
    def notice_detail(notice_id):
        if notice_id > 2**63 - 1:
            abort(404)
        notice = get_db().execute(PUBLIC_NOTICES + " AND id = ?", (notice_id,)).fetchone()
        if not notice:
            abort(404, "The requested notice could not be found.")
        return render_template("notice.html", notice=notice)

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if g.user:
            return redirect(url_for("dashboard"), code=303)
        if request.method != "POST":
            return form_page("register")
        form = verify_form()
        limit_auth_attempts()
        data, errors = account_data(form)
        password = form.get("password", "")
        if not valid_password(password):
            errors.append("Enter a password between 12 and 128 characters.")
        if errors:
            return form_page("register", data, errors, 422)
        db = get_db()
        digest = hash_password(password)
        with db:
            created = db.execute(
                "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?) ON CONFLICT(email) DO NOTHING",
                (data["name"], data["email"], digest),
            )
        if not created.rowcount:
            return form_page("register", data, ["Unable to create an account with those details."], 422)
        new_session(created.lastrowid)
        flash("Your account is ready.")
        return redirect(url_for("dashboard"), code=303)

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if g.user:
            return redirect(url_for("dashboard"), code=303)
        if request.method != "POST":
            return form_page("login")
        form = verify_form()
        limit_auth_attempts()
        email = form.get("email", "").strip().lower()
        password = form.get("password", "")
        account = get_db().execute("SELECT id, password_hash FROM users WHERE email = ?", (email,)).fetchone()
        digest = account["password_hash"] if account else app.config["DUMMY_HASH"]
        matches = valid_password(password) and check_password_hash(digest, password)
        if not matches or not account:
            return form_page("login", {"email": email}, ["The email address or password is incorrect."], 401)
        new_session(account["id"])
        return redirect(url_for("dashboard"), code=303)

    @app.post("/logout")
    @signed_in
    def logout():
        verify_form()
        db = get_db()
        with db:
            db.execute("DELETE FROM sessions WHERE token_hash = ?", (g.login_session["token_hash"],))
        session.clear()
        flash("You have been logged out.")
        return redirect(url_for("home"), code=303)

    @app.get("/dashboard")
    @signed_in
    def dashboard():
        notices = get_db().execute(
            "SELECT * FROM notices WHERE author_id = ? ORDER BY id DESC", (g.user["user_id"],)
        ).fetchall()
        return render_template("dashboard.html", notices=notices)

    @app.route("/profile", methods=["GET", "POST"])
    @signed_in
    def profile():
        if request.method != "POST":
            return form_page("profile", g.user)
        form = verify_form()
        data, errors = account_data(form)
        db = get_db()
        if not errors and data["email"] != g.user["email"]:
            limit_auth_attempts()
            password = form.get("password", "")
            account = db.execute("SELECT password_hash FROM users WHERE id = ?", (g.user["user_id"],)).fetchone()
            if not valid_password(password) or not check_password_hash(account["password_hash"], password):
                errors.append("Enter your current password to change your email address.")
        if not errors:
            try:
                with db:
                    db.execute("UPDATE users SET name = ?, email = ? WHERE id = ?",
                               (data["name"], data["email"], g.user["user_id"]))
            except sqlite3.IntegrityError:
                errors.append("That email address is unavailable.")
        if errors:
            return form_page("profile", data, errors, 422)
        flash("Your profile has been updated.")
        return redirect(url_for("profile"), code=303)

    @app.route("/submit", methods=["GET", "POST"])
    @signed_in
    def submit_notice():
        if request.method != "POST":
            return form_page("submit")
        data, errors = notice_data(verify_form())
        if errors:
            return form_page("submit", data, errors, 422)
        db = get_db()
        with db:
            db.execute(
                "INSERT INTO notices (author_id, title, category, location, body, event_date) VALUES (?, ?, ?, ?, ?, ?)",
                (g.user["user_id"], data["title"], data["category"], data["location"],
                 data["body"], data["event_date"] or None),
            )
        flash("Your notice was sent for review.")
        return redirect(url_for("dashboard"), code=303)

    @app.get("/admin")
    @administrator
    def admin():
        notices = get_db().execute(
            """SELECT n.*, u.name AS author FROM notices AS n JOIN users AS u ON n.author_id = u.id
               WHERE n.status = 'pending' ORDER BY n.id"""
        ).fetchall()
        return render_template("admin.html", notices=notices)

    @app.post("/admin/notices/<int:notice_id>")
    @administrator
    def review_notice(notice_id):
        if notice_id > 2**63 - 1:
            abort(404)
        decision = verify_form().get("decision")
        if decision not in ("publish", "decline"):
            abort(422, "Choose a valid review decision.")
        status = "published" if decision == "publish" else "declined"
        db = get_db()
        with db:
            changed = db.execute(
                """UPDATE notices SET status = ?,
                   published_at = CASE WHEN ? = 'published' THEN CURRENT_TIMESTAMP END
                   WHERE id = ? AND status = 'pending'""",
                (status, status, notice_id),
            ).rowcount
        if not changed:
            abort(409, "This notice is no longer waiting for review.")
        flash(f"The notice was {status}.")
        return redirect(url_for("admin"), code=303)

    @app.get("/security")
    def security():
        return render_template("security.html")

    @app.get("/review")
    def project_review():
        sections = []
        for block in (HERE / "PROJECT-REVIEW.md").read_text(encoding="utf-8").strip().split("\n\n")[1:]:
            sections.append((block.startswith("## "), block.removeprefix("## ")))
        return render_template("info.html", title="Project review",
                               intro="Evaluation of the Maple Junction community portal.", sections=sections)


def seed_demo_data():
    if current_app.config["PRODUCTION"] or Path(current_app.config["DATABASE"]).name != "demo.sqlite":
        raise click.ClickException("Use a local demo.sqlite database for the demonstration.")
    db = get_db()
    admin_email = "admin@maple.example"
    resident_email = "resident@maple.example"
    with db:
        db.execute("BEGIN IMMEDIATE")
        for name, email, password, role in (
            ("Portal Administrator", admin_email, "Maple-Demo-Admin!24", "admin"),
            ("Sam Taylor", resident_email, "Maple-Demo-Resident!24", "resident"),
        ):
            existing = db.execute("SELECT role FROM users WHERE email = ?", (email,)).fetchone()
            if existing and existing["role"] != role:
                raise click.ClickException("A demo account email is already in use with a different role.")
            if not existing:
                db.execute("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)",
                           (name, email, hash_password(password), role))
        if not db.execute("SELECT 1 FROM notices LIMIT 1").fetchone():
            admin_id = db.execute("SELECT id FROM users WHERE email = ?", (admin_email,)).fetchone()["id"]
            now = date.today()
            next_saturday = now + timedelta(days=(5 - now.weekday()) % 7 or 7)
            db.executemany(
                """INSERT INTO notices (author_id, title, category, location, body, event_date, status, published_at)
                   VALUES (?, ?, ?, ?, ?, ?, 'published', CURRENT_TIMESTAMP)""",
                [
                    (admin_id, "Library hours extended", "Services", "Maple Community Library",
                     "The library is now open until 7 p.m. on Tuesdays and Thursdays. The reading room and lending desk are available during the extended hours.", None),
                    (admin_id, "Roadworks on Station Road", "Announcements", "Station Road",
                     "Allow extra time while drainage work is underway. Follow the posted signs and use the marked pedestrian crossings.", None),
                    (admin_id, "Saturday farmers’ market", "Events", "Maple Square",
                     "Shop for fresh produce and meet your neighbours. The market runs from 9 a.m. to 2 p.m. Bring a reusable bag.", next_saturday.isoformat()),
                ],
            )


@click.command("init-demo")
@with_appcontext
def init_demo():
    seed_demo_data()
    click.echo("Demo accounts and sample notices are ready.")


@click.command("create-admin")
@click.option("--email", prompt="Administrator email")
@click.password_option(confirmation_prompt=True)
@with_appcontext
def create_admin(email, password):
    email = email.strip().lower()
    if not valid_email(email) or not valid_password(password):
        raise click.ClickException("Provide a valid email and a password of 12–128 characters.")
    db = get_db()
    with db:
        created = db.execute(
            """INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'admin')
               ON CONFLICT(email) DO NOTHING""",
            ("Portal Administrator", email, hash_password(password)),
        )
    if not created.rowcount:
        raise click.ClickException("That email is already in use.")
    click.echo("Administrator account created.")


if __name__ == "__main__":
    demo_app = create_demo_app()
    with demo_app.app_context():
        seed_demo_data()
    demo_app.run(host="127.0.0.1", port=5000, debug=False)
