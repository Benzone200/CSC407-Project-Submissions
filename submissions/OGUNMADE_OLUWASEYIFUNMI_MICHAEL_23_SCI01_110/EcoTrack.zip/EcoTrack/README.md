# EcoTrack – Waste Management System (Flask Edition)

EcoTrack is a Flask web application for managing residents, waste collection vehicles, staff, collection requests, schedules, reports, and user accounts.

## 1. Requirements
- Python 3.10 or newer
- Flask 3.x

## 2. Installation
Open a terminal in this project folder and run:

```bash
python -m venv venv
```

Activate the environment:

**Windows Command Prompt**
```bat
venv\Scripts\activate
```

**Windows PowerShell**
```powershell
.\venv\Scripts\Activate.ps1
```

Install dependencies:
```bash
pip install -r requirements.txt
```

## 3. Run the website
```bash
python app.py
```
Then open http://127.0.0.1:5000 in your browser.

## 4. First-time setup
1. Select the administrator setup link on the sign-in page.
2. Create the first administrator account.
3. Sign in and add residents, vehicles, and staff.
4. Use **User Management** to create normal user accounts.

Only the first administrator can be registered through the public setup page. Further normal accounts are created by an administrator.

## 5. Access levels
**Administrator:** full access to dashboard, residents, vehicles, staff, collection requests, schedule, reports, CSV export, and user management.

**Normal user:** dashboard, submit collection requests, view only their own requests, and view their own collection schedule. Normal users cannot edit/delete requests, assign staff/vehicles, or access administration pages.

## 6. Database
The app uses SQLite through `database.py`. The database file `waste_collection.db` is created in the project folder on first run. Keep `app.py` and `database.py` in the same folder. Do not delete the database if you need to preserve your existing records.

The Flask version uses the same tables and password hash format as the Tkinter edition, so it can use the existing `waste_collection.db` file. Copy your existing database file into this project folder before starting the Flask app if you want to use your existing data.

## 7. Deployment note
This project is configured for local development. Before deploying publicly, set a long random `ECOTRACK_SECRET` environment variable and run behind a production WSGI server. Do not use Flask's development server or debug mode for production.
