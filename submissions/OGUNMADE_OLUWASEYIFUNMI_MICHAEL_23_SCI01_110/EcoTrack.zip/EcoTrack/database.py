import os
import sqlite3

# The database file always lives next to this script, no matter where the
# program is launched from. Set WASTE_DB to use a different file (handy for tests).
DB_PATH = os.environ.get(
    "WASTE_DB",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "waste_collection.db"),
)


def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def query(sql, params=()):
    """Run a SELECT and return all rows."""
    conn = connect_db()
    try:
        return conn.execute(sql, params).fetchall()
    finally:
        conn.close()


def execute(sql, params=()):
    """Run an INSERT / UPDATE / DELETE, commit, and return the last row id."""
    conn = connect_db()
    try:
        cursor = conn.execute(sql, params)
        conn.commit()
        return cursor.lastrowid
    finally:
        conn.close()


def create_tables():
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS admins (
            admin_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Active',
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS residents (
            resident_id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT,
            address TEXT NOT NULL,
            area TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS vehicles (
            vehicle_id INTEGER PRIMARY KEY AUTOINCREMENT,
            registration_number TEXT UNIQUE NOT NULL,
            vehicle_type TEXT NOT NULL,
            capacity TEXT,
            status TEXT DEFAULT 'Available'
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS staff (
            staff_id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            phone TEXT NOT NULL,
            email TEXT,
            role TEXT NOT NULL,
            status TEXT DEFAULT 'Active'
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS collection_requests (
            request_id INTEGER PRIMARY KEY AUTOINCREMENT,
            resident_id INTEGER NOT NULL,
            waste_type TEXT NOT NULL,
            collection_address TEXT NOT NULL,
            request_date TEXT NOT NULL,
            scheduled_date TEXT NOT NULL,
            scheduled_time TEXT NOT NULL,
            vehicle_id INTEGER,
            staff_id INTEGER,
            status TEXT DEFAULT 'Pending',
            created_by_user_id INTEGER,

            FOREIGN KEY (resident_id) REFERENCES residents(resident_id),
            FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id),
            FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
        )
    """)

    # Safe migration for databases created before user accounts were introduced.
    request_columns = {
        row[1] for row in cursor.execute("PRAGMA table_info(collection_requests)").fetchall()
    }
    if "created_by_user_id" not in request_columns:
        cursor.execute("ALTER TABLE collection_requests ADD COLUMN created_by_user_id INTEGER")

    # Indexes keep searching and filtering fast as the data grows
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_requests_user ON collection_requests(created_by_user_id)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_requests_date ON collection_requests(scheduled_date)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_requests_status ON collection_requests(status)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_requests_resident ON collection_requests(resident_id)")

    conn.commit()
    conn.close()


if __name__ == "__main__":
    create_tables()
    print("Database and tables created successfully!")
