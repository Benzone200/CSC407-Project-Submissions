"""EcoTrack Flask web application."""
import csv
import datetime as dt
import hashlib
import hmac
import io
import os
import re
import secrets
import time
from functools import wraps

from flask import Flask, flash, make_response, redirect, render_template, request, session, url_for
from database import create_tables, execute, query

app = Flask(__name__)
app.secret_key = os.environ.get("ECOTRACK_SECRET", "change-this-secret-key-before-deployment")
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
create_tables()

STATUSES = ["Pending", "Scheduled", "Completed", "Cancelled"]
OPEN_STATUSES = ("Pending", "Scheduled")
WASTE_TYPES = ["Household Waste", "Plastic Waste", "Organic Waste", "Metal Waste", "Paper Waste", "Construction Waste", "Electronic Waste", "Other"]
DATE_FILTERS = ["All Dates", "Today", "This Week", "Upcoming", "Overdue"]
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^\+?\d{7,15}$")

# Reuse the exact PBKDF2 format used by the Tkinter edition.
def hash_password(password):
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 260000).hex()
    return salt + "$" + digest


def verify_password(password, stored):
    try:
        salt, saved = stored.split("$")
        digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 260000).hex()
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(digest, saved)


def scalar(sql, params=()):
    rows = query(sql, params)
    return rows[0][0] if rows else 0


def current_role():
    return session.get("role")


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("username"):
            flash("Please sign in to continue.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if current_role() != "admin":
            flash("You do not have permission to access that page.", "danger")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped


@app.context_processor
def inject_globals():
    return {"username": session.get("username"), "role": session.get("role"), "today": dt.date.today().isoformat()}


@app.route("/")
def index():
    return redirect(url_for("dashboard" if session.get("username") else "login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("username"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        locked_until = float(session.get("locked_until", 0))
        if time.time() < locked_until:
            flash(f"Too many failed attempts. Try again in {int(locked_until-time.time())+1} seconds.", "danger")
            return render_template("auth.html", mode="login", admin_exists=scalar("SELECT COUNT(*) FROM admins") > 0)
        identifier = request.form.get("identifier", "").strip()
        password = request.form.get("password", "")
        admin = query("SELECT username, password FROM admins WHERE username = ? OR email = ?", (identifier, identifier))
        if admin and verify_password(password, admin[0][1]):
            session.clear(); session.update(username=admin[0][0], role="admin", user_id=None)
            return redirect(url_for("dashboard"))
        user = query("SELECT user_id, username, password, status FROM users WHERE username = ? OR email = ?", (identifier, identifier))
        if user and user[0][3] == "Active" and verify_password(password, user[0][2]):
            session.clear(); session.update(username=user[0][1], role="user", user_id=user[0][0])
            return redirect(url_for("dashboard"))
        failures = int(session.get("login_failures", 0)) + 1
        if failures >= 5:
            session["login_failures"] = 0
            session["locked_until"] = time.time() + 30
            flash("Too many failed attempts. Sign-in is locked for 30 seconds.", "danger")
        else:
            session["login_failures"] = failures
            flash("Invalid username/email or password, or your account is inactive.", "danger")
    return render_template("auth.html", mode="login", admin_exists=scalar("SELECT COUNT(*) FROM admins") > 0)


@app.route("/setup-admin", methods=["GET", "POST"])
def setup_admin():
    if scalar("SELECT COUNT(*) FROM admins") > 0:
        flash("Administrator setup is closed. Ask an administrator to create an account for you.", "info")
        return redirect(url_for("login"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        if len(username) < 3 or not EMAIL_RE.match(email) or len(password) < 8 or password != confirm:
            flash("Use a username of at least 3 characters, a valid email, and matching passwords of at least 8 characters.", "danger")
        else:
            try:
                execute("INSERT INTO admins (username,email,password) VALUES (?,?,?)", (username,email,hash_password(password)))
                flash("Administrator account created. You can now sign in.", "success")
                return redirect(url_for("login"))
            except Exception:
                flash("That username or email is already registered.", "danger")
    return render_template("auth.html", mode="setup", admin_exists=False)


@app.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    flash("You have been signed out.", "success")
    return redirect(url_for("login"))


REQUEST_SELECT = """SELECT cr.request_id, r.full_name, cr.waste_type, cr.collection_address, cr.request_date, cr.scheduled_date, cr.scheduled_time, COALESCE(v.registration_number,'Not Assigned'), COALESCE(s.full_name,'Not Assigned'), cr.status, cr.resident_id, cr.vehicle_id, cr.staff_id
FROM collection_requests cr JOIN residents r ON cr.resident_id=r.resident_id LEFT JOIN vehicles v ON cr.vehicle_id=v.vehicle_id LEFT JOIN staff s ON cr.staff_id=s.staff_id"""

def request_rows(keyword="", status="All", date_filter="All Dates", owner_id=None, order="cr.scheduled_date ASC, cr.scheduled_time ASC"):
    clauses=[]; params=[]
    if keyword:
        clauses.append("(r.full_name LIKE ? OR cr.waste_type LIKE ? OR cr.collection_address LIKE ? OR cr.scheduled_date LIKE ? OR cr.status LIKE ? OR COALESCE(v.registration_number,'') LIKE ? OR COALESCE(s.full_name,'') LIKE ?)")
        params += [f"%{keyword}%"]*7
    if owner_id is not None:
        clauses.append("cr.created_by_user_id=?"); params.append(owner_id)
    if status != "All": clauses.append("cr.status=?"); params.append(status)
    today=dt.date.today()
    if date_filter == "Today": clauses.append("cr.scheduled_date=?"); params.append(today.isoformat())
    elif date_filter == "This Week": clauses.append("cr.scheduled_date BETWEEN ? AND ?"); params += [today.isoformat(), (today+dt.timedelta(days=6)).isoformat()]
    elif date_filter == "Upcoming": clauses.append("cr.scheduled_date>=?"); params.append(today.isoformat())
    elif date_filter == "Overdue": clauses.append("cr.scheduled_date<? AND cr.status IN ('Pending','Scheduled')"); params.append(today.isoformat())
    sql=REQUEST_SELECT + (" WHERE " + " AND ".join(clauses) if clauses else "") + " ORDER BY " + order
    return query(sql, params)


def dashboard_data():
    role=current_role(); owner=session.get("user_id") if role == "user" else None
    if owner is None:
        counts=dict(query("SELECT status,COUNT(*) FROM collection_requests GROUP BY status"))
        residents=scalar("SELECT COUNT(*) FROM residents"); vehicles=scalar("SELECT COUNT(*) FROM vehicles WHERE status='Available'"); staff=scalar("SELECT COUNT(*) FROM staff WHERE status='Active'")
        total=scalar("SELECT COUNT(*) FROM collection_requests")
    else:
        counts=dict(query("SELECT status,COUNT(*) FROM collection_requests WHERE created_by_user_id=? GROUP BY status",(owner,)))
        residents=vehicles=staff=None; total=sum(counts.values())
    upcoming=[r for r in request_rows(date_filter="Upcoming", owner_id=owner) if r[9] in OPEN_STATUSES][:8]
    return dict(counts=counts, residents=residents, vehicles=vehicles, staff=staff, total=total, upcoming=upcoming)


@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", data=dashboard_data())

# Admin CRUD configuration: fields and labels are used to render safe generic forms.
CRUD = {
 "residents": {"title":"Residents", "pk":"resident_id", "fields":[("full_name","Full name","text",True),("phone","Phone number","text",True),("email","Email address","email",False),("address","Residential address","text",True),("area","Area / location","text",True)]},
 "vehicles": {"title":"Vehicles", "pk":"vehicle_id", "fields":[("registration_number","Registration number","text",True),("vehicle_type","Vehicle type","text",True),("capacity","Capacity","text",True),("status","Vehicle status","select:Available|In Use|Under Maintenance",True)]},
 "staff": {"title":"Staff", "pk":"staff_id", "fields":[("full_name","Full name","text",True),("phone","Phone number","text",True),("email","Email address","email",False),("role","Staff role","text",True),("status","Staff status","select:Active|Inactive",True)]}
}

@app.route("/manage/<entity>", methods=["GET","POST"])
@admin_required
def manage(entity):
    if entity not in CRUD: return redirect(url_for("dashboard"))
    cfg=CRUD[entity]; table=entity; pk=cfg["pk"]; fields=cfg["fields"]
    if request.method == "POST":
        action=request.form.get("action"); record_id=request.form.get("record_id")
        if action in ("save","update"):
            vals={f[0]:request.form.get(f[0],"").strip() for f in fields}
            if any(required and not vals[name] for name,_,_,required in fields):
                flash("Please complete all required fields.","danger")
            elif vals.get("email") and not EMAIL_RE.match(vals["email"]): flash("Enter a valid email address.","danger")
            elif vals.get("phone") and not PHONE_RE.match(re.sub(r"[\s\-()]","",vals["phone"])): flash("Enter a valid phone number (7–15 digits).","danger")
            else:
                if "registration_number" in vals: vals["registration_number"]=vals["registration_number"].upper()
                cols=[f[0] for f in fields]
                try:
                    if action=="update" and record_id:
                        execute(f"UPDATE {table} SET " + ",".join(c+"=?" for c in cols)+f" WHERE {pk}=?", [vals[c] for c in cols]+[record_id])
                        flash(f"{cfg['title'][:-1]} updated successfully.","success")
                    else:
                        execute(f"INSERT INTO {table} ("+",".join(cols)+") VALUES ("+",".join("?" for _ in cols)+")",[vals[c] for c in cols])
                        flash(f"{cfg['title'][:-1]} added successfully.","success")
                except Exception: flash("Could not save this record. Check for duplicate values or linked records.","danger")
                return redirect(url_for("manage",entity=entity))
        elif action=="delete" and record_id:
            try:
                execute(f"DELETE FROM {table} WHERE {pk}=?",(record_id,)); flash("Record deleted.","success")
            except Exception: flash("This record is linked to a collection request and cannot be deleted.","danger")
            return redirect(url_for("manage",entity=entity))
    search=request.args.get("q","").strip(); cols=[f[0] for f in fields]
    where=" OR ".join(c+" LIKE ?" for c in cols)
    rows=query(f"SELECT {pk},"+",".join(cols)+f" FROM {table}"+(" WHERE "+where if search else "")+f" ORDER BY {pk} DESC",([f"%{search}%"]*len(cols) if search else []))
    return render_template("manage.html",entity=entity,cfg=cfg,rows=rows,search=search)


def validate_request_form(form, is_admin, exclude_id=None):
    resident_id=form.get("resident_id",""); waste=form.get("waste_type",""); address=form.get("collection_address","").strip(); date=form.get("scheduled_date",""); time=form.get("scheduled_time","")
    if not all([resident_id,waste,address,date,time]): return None,"Complete all required collection request fields."
    try: dt.datetime.strptime(date,"%Y-%m-%d"); dt.datetime.strptime(time,"%H:%M")
    except ValueError: return None,"Use a valid date and time."
    resident=query("SELECT resident_id FROM residents WHERE resident_id=?",(resident_id,))
    if not resident: return None,"Select a valid resident."
    vehicle_id=form.get("vehicle_id") if is_admin else None; staff_id=form.get("staff_id") if is_admin else None
    status=form.get("status","Pending") if is_admin else "Pending"
    if is_admin:
        for col,rid,noun in (("vehicle_id",vehicle_id,"vehicle"),("staff_id",staff_id,"staff member")):
            if rid:
                table="vehicles" if col=="vehicle_id" else "staff"; pk=col
                row=query(f"SELECT status FROM {table} WHERE {pk}=?",(rid,))
                if not row: return None,f"Select a valid {noun}."
                if row[0][0] in ("Under Maintenance","Inactive"): return None,f"This {noun} is not available for assignment."
                clash=query(f"SELECT request_id FROM collection_requests WHERE {col}=? AND scheduled_date=? AND scheduled_time=? AND status IN ('Pending','Scheduled') AND request_id != ?",(rid,date,time,exclude_id or -1))
                if clash: return None,f"This {noun} is already assigned to request #{clash[0][0]} at that time."
    return (int(resident_id),waste,address,date,time,vehicle_id or None,staff_id or None,status),None


@app.route("/requests",methods=["GET","POST"])
@login_required
def requests_page():
    is_admin=current_role()=="admin"; owner=session.get("user_id") if not is_admin else None
    if request.method=="POST":
        action=request.form.get("action"); rid=request.form.get("request_id")
        if action in ("create","update"):
            if action=="update" and not is_admin: flash("Only administrators can edit requests.","danger")
            else:
                data,error=validate_request_form(request.form,is_admin,rid)
                if error: flash(error,"danger")
                else:
                    resident,waste,address,date,time,vehicle,staff,status=data
                    if action=="create":
                        execute("INSERT INTO collection_requests (resident_id,waste_type,collection_address,request_date,scheduled_date,scheduled_time,vehicle_id,staff_id,status,created_by_user_id) VALUES (?,?,?,?,?,?,?,?,?,?)",(resident,waste,address,dt.date.today().isoformat(),date,time,vehicle,staff,status,session.get("user_id") if not is_admin else None))
                        flash("Collection request submitted successfully.","success")
                    else:
                        execute("UPDATE collection_requests SET resident_id=?,waste_type=?,collection_address=?,scheduled_date=?,scheduled_time=?,vehicle_id=?,staff_id=?,status=? WHERE request_id=?",(resident,waste,address,date,time,vehicle,staff,status,rid)); flash("Request updated.","success")
                    return redirect(url_for("requests_page"))
        elif action=="delete" and is_admin and rid:
            execute("DELETE FROM collection_requests WHERE request_id=?",(rid,)); flash("Request deleted.","success"); return redirect(url_for("requests_page"))
    keyword=request.args.get("q","").strip(); status=request.args.get("status","All")
    rows=request_rows(keyword,status,owner_id=owner,order="cr.request_id DESC")
    residents=query("SELECT resident_id,full_name,address FROM residents ORDER BY full_name")
    vehicles=query("SELECT vehicle_id,registration_number FROM vehicles WHERE status='Available' ORDER BY registration_number")
    staff=query("SELECT staff_id,full_name FROM staff WHERE status='Active' ORDER BY full_name")
    return render_template("requests.html",rows=rows,residents=residents,vehicles=vehicles,staff=staff,waste_types=WASTE_TYPES,statuses=STATUSES,is_admin=is_admin,keyword=keyword,status_filter=status)


@app.route("/requests/<int:request_id>/edit", methods=["GET", "POST"])
@admin_required
def edit_request(request_id):
    record = query("SELECT request_id,resident_id,waste_type,collection_address,scheduled_date,scheduled_time,vehicle_id,staff_id,status FROM collection_requests WHERE request_id=?", (request_id,))
    if not record:
        flash("Collection request not found.", "warning")
        return redirect(url_for("requests_page"))
    record = record[0]
    if request.method == "POST":
        data, error = validate_request_form(request.form, True, request_id)
        if error:
            flash(error, "danger")
        else:
            resident,waste,address,date,time_value,vehicle,staff,status = data
            execute("UPDATE collection_requests SET resident_id=?,waste_type=?,collection_address=?,scheduled_date=?,scheduled_time=?,vehicle_id=?,staff_id=?,status=? WHERE request_id=?", (resident,waste,address,date,time_value,vehicle,staff,status,request_id))
            flash("Collection request updated successfully.", "success")
            return redirect(url_for("requests_page"))
    residents=query("SELECT resident_id,full_name FROM residents ORDER BY full_name")
    vehicles=query("SELECT vehicle_id,registration_number FROM vehicles WHERE status='Available' OR vehicle_id=? ORDER BY registration_number",(record[6],))
    staff=query("SELECT staff_id,full_name FROM staff WHERE status='Active' OR staff_id=? ORDER BY full_name",(record[7],))
    values = {"resident_id":record[1],"waste_type":record[2],"collection_address":record[3],"scheduled_date":record[4],"scheduled_time":record[5],"vehicle_id":record[6],"staff_id":record[7],"status":record[8]}
    return render_template("request_edit.html", request_id=request_id, values=values, residents=residents, vehicles=vehicles, staff=staff, waste_types=WASTE_TYPES, statuses=STATUSES)


@app.route("/schedule",methods=["GET","POST"])
@login_required
def schedule():
    is_admin=current_role()=="admin"; owner=session.get("user_id") if not is_admin else None
    if request.method=="POST" and is_admin:
        rid=request.form.get("request_id"); new_status=request.form.get("status")
        if rid and new_status in STATUSES:
            execute("UPDATE collection_requests SET status=? WHERE request_id=?",(new_status,rid)); flash("Collection status updated.","success")
        return redirect(url_for("schedule"))
    rows=request_rows(request.args.get("q",""),request.args.get("status","All"),request.args.get("date","All Dates"),owner_id=owner)
    return render_template("schedule.html",rows=rows,statuses=STATUSES,date_filters=DATE_FILTERS,is_admin=is_admin)


@app.route("/reports")
@admin_required
def reports():
    rows=request_rows(request.args.get("q",""),request.args.get("status","All"),request.args.get("date","All Dates"),order="cr.scheduled_date DESC,cr.scheduled_time DESC")
    counts=dict(query("SELECT status,COUNT(*) FROM collection_requests GROUP BY status")); total=sum(counts.values()); waste=query("SELECT waste_type,COUNT(*) FROM collection_requests GROUP BY waste_type ORDER BY COUNT(*) DESC")
    return render_template("reports.html",rows=rows,counts=counts,total=total,waste=waste,date_filters=DATE_FILTERS,statuses=STATUSES)


@app.route("/reports/export")
@admin_required
def export_report():
    rows=request_rows(order="cr.scheduled_date DESC,cr.scheduled_time DESC")
    output=io.StringIO(); writer=csv.writer(output); writer.writerow(["ID","Resident","Waste Type","Address","Requested","Scheduled Date","Time","Vehicle","Staff","Status"])
    for row in rows: writer.writerow(row[:10])
    response=make_response("\ufeff"+output.getvalue()); response.headers["Content-Type"]="text/csv; charset=utf-8"; response.headers["Content-Disposition"]=f"attachment; filename=ecotrack_report_{dt.date.today().isoformat()}.csv"
    return response


@app.route("/users",methods=["GET","POST"])
@admin_required
def users_page():
    if request.method=="POST":
        action=request.form.get("action")
        if action=="create":
            username=request.form.get("username","").strip(); email=request.form.get("email","").strip().lower(); password=request.form.get("password","")
            if len(username)<3 or not EMAIL_RE.match(email) or len(password)<8: flash("Enter a username (3+ characters), valid email and password (8+ characters).","danger")
            else:
                try: execute("INSERT INTO users (username,email,password) VALUES (?,?,?)",(username,email,hash_password(password))); flash("User account created.","success")
                except Exception: flash("That username or email is already registered.","danger")
        elif action=="delete":
            uid=request.form.get("user_id")
            if uid: execute("DELETE FROM users WHERE user_id=?",(uid,)); flash("User account deleted. Existing requests are retained.","success")
        return redirect(url_for("users_page"))
    users=query("SELECT user_id,username,email,status,created_at FROM users ORDER BY user_id DESC")
    return render_template("users.html",users=users)


@app.errorhandler(404)
def not_found(_): return render_template("error.html",code=404,message="The page you requested could not be found."),404

if __name__ == "__main__":
    app.run(debug=True)
