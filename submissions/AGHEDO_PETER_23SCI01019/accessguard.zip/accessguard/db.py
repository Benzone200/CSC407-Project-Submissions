"""Database layer: schema, connection helper, and demo seed data.

Portability note: this uses SQLite for the demo, but every query in the app is
written with placeholders (?) and goes through the same helper, so swapping in
PostgreSQL (psycopg) or MySQL (mysql-connector) requires no changes to the
security model - only the driver and the placeholder style.
"""
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

from werkzeug.security import generate_password_hash

SCHEMA = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    email             TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    password_hash     TEXT    NOT NULL,
    full_name         TEXT    NOT NULL,
    role              TEXT    NOT NULL DEFAULT 'user'
                      CHECK (role IN ('admin', 'manager', 'user')),
    department        TEXT    DEFAULT '',
    phone             TEXT    DEFAULT '',
    bio               TEXT    DEFAULT '',
    is_active         INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    failed_attempts   INTEGER NOT NULL DEFAULT 0,
    locked_until      TEXT,
    last_login_at     TEXT,
    last_login_ip     TEXT,
    password_changed_at TEXT,
    created_at        TEXT    NOT NULL,
    updated_at        TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    token_hash    TEXT NOT NULL UNIQUE,   -- we store a SHA-256 hash, never the raw token
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at    TEXT NOT NULL,
    last_seen_at  TEXT NOT NULL,
    expires_at    TEXT NOT NULL,
    ip            TEXT,
    user_agent    TEXT,
    revoked       INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS audit_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at  TEXT NOT NULL,
    actor_id    INTEGER,
    actor_email TEXT,
    action      TEXT NOT NULL,
    target      TEXT,
    detail      TEXT,
    ip          TEXT,
    severity    TEXT NOT NULL DEFAULT 'info'
                     CHECK (severity IN ('info', 'warning', 'critical'))
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_actor   ON audit_log(actor_id);
"""


def now() -> str:
    """UTC timestamp, second precision, always stored as an ISO-8601 string."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def connect(path: str) -> sqlite3.Connection:
    Path(path).parent.mkdir(exist_ok=True, parents=True)
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(path: str) -> None:
    conn = connect(path)
    with conn:
        conn.executescript(SCHEMA)
    conn.close()


DEMO_USERS = [
    # email, password, full name, role, department, phone
    ("admin@accessguard.test", "Admin!Passw0rd123", "Ada Obi", "admin", "IT Operations", "+234 801 000 0001"),
    ("manager@accessguard.test", "Manager!Passw0rd123", "Chidi Bello", "manager", "Client Services", "+234 801 000 0002"),
    ("user@accessguard.test", "User!Passw0rd123", "Fatima Yusuf", "user", "Finance", "+234 801 000 0003"),
    ("tunde.adeyemi@accessguard.test", "User!Passw0rd123", "Tunde Adeyemi", "user", "Marketing", "+234 801 000 0004"),
    ("grace.eze@accessguard.test", "User!Passw0rd123", "Grace Eze", "manager", "Human Resources", "+234 801 000 0005"),
    ("ibrahim.sani@accessguard.test", "User!Passw0rd123", "Ibrahim Sani", "user", "Logistics", "+234 801 000 0006"),
    ("zainab.k@accessguard.test", "User!Passw0rd123", "Zainab Kabir", "user", "Finance", "+234 801 000 0007"),
    ("emeka.n@accessguard.test", "User!Passw0rd123", "Emeka Nwosu", "user", "Engineering", "+234 801 000 0008"),
]


def seed(path: str, force: bool = False) -> bool:
    """Create demo data once. Returns True if seeding happened."""
    conn = connect(path)
    existing = conn.execute("SELECT COUNT(*) AS c FROM users").fetchone()["c"]
    if existing and not force:
        conn.close()
        return False

    ts = now()
    with conn:
        for email, password, name, role, dept, phone in DEMO_USERS:
            conn.execute(
                """INSERT OR IGNORE INTO users
                   (email, password_hash, full_name, role, department, phone,
                    is_active, created_at, updated_at, password_changed_at)
                   VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?)""",
                (email, generate_password_hash(password, method="scrypt"),
                 name, role, dept, phone, ts, ts, ts),
            )

        conn.execute(
            """INSERT INTO audit_log
                 (created_at, actor_id, actor_email, action, target, detail, ip, severity)
               VALUES (?, NULL, 'system', 'system.seeded', 'database',
                       'Demo dataset created (8 users across 3 roles)', '-', 'info')""",
            (ts,),
        )

        # A little history so the audit page is not empty on first run.
        events = [
            ("auth.login_success", "user", "Signed in successfully", "info"),
            ("rbac.role_changed", "user", "Role changed", "warning"),
            ("auth.login_failed", "user", "Invalid credentials", "warning"),
            ("rbac.access_denied", "admin-only page", "Blocked by access-control check", "critical"),
        ]
        for i, (action, target, detail, severity) in enumerate(events, start=1):
            conn.execute(
                """INSERT INTO audit_log
                     (created_at, actor_id, actor_email, action, target, detail, ip, severity)
                   VALUES (?, 3, 'user@accessguard.test', ?, ?, ?, '127.0.0.1', ?)""",
                ((datetime.now(timezone.utc) - timedelta(minutes=10 * i)).replace(microsecond=0).isoformat(),
                 action, target, detail, severity),
            )
    conn.close()
    return True
