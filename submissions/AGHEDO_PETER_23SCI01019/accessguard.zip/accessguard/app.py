"""AccessGuard - a user access management system with a demonstrable security model.

Run:  python3 app.py        (see README.md for production notes)
"""
import sqlite3
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse

from flask import (Flask, abort, flash, g, redirect, render_template, request,
                   session, url_for)

import security as sec
from config import Config
from db import connect, init_db, now, seed

PAGE_SIZE = 8
ROLES = ("admin", "manager", "user")

app = Flask(__name__)
app.config.from_object(Config)
app.json.sort_keys = False


# ---------------------------------------------------------------------------
# Database plumbing
# ---------------------------------------------------------------------------
def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = connect(app.config["DATABASE"])
    return g.db


@app.teardown_appcontext
def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


# ---------------------------------------------------------------------------
# Per-request authentication + authorisation context
# ---------------------------------------------------------------------------
def load_session_user():
    """Resolve the signed cookie -> server-side session row -> user row.

    Server-side sessions are what make instant revocation possible: deleting or
    revoking the row kills the cookie even though the cookie itself is validly
    signed.
    """
    g.user = None
    g.session_row = None
    raw = session.get("sid")
    if not raw:
        return
    db = get_db()
    row = db.execute(
        """SELECT * FROM sessions
           WHERE token_hash = ? AND revoked = 0""",
        (sec.sha256(raw),),
    ).fetchone()
    if not row:
        session.clear()
        return

    ts = datetime.now(timezone.utc)
    if sec.parse_ts(row["expires_at"]) <= ts:
        session.clear()
        return

    user = db.execute("SELECT * FROM users WHERE id = ?", (row["user_id"],)).fetchone()
    if not user or not user["is_active"]:
        db.execute("UPDATE sessions SET revoked = 1 WHERE id = ?", (row["id"],))
        db.commit()
        session.clear()
        return

    # Idle timeout: slide the window forward but never past the absolute cap.
    absolute = sec.parse_ts(session.get("abs")) or (ts + timedelta(hours=app.config["ABSOLUTE_TIMEOUT_HOURS"]))
    new_expiry = min(ts + timedelta(minutes=app.config["IDLE_TIMEOUT_MINUTES"]), absolute)
    db.execute("UPDATE sessions SET last_seen_at = ?, expires_at = ? WHERE id = ?",
               (now(), new_expiry.replace(microsecond=0).isoformat(), row["id"]))
    db.commit()

    g.user = user
    g.session_row = row


@app.before_request
def before_request():
    # Refuse oversized or non-form bodies early (cheap DoS guard).
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        if request.content_length and request.content_length > app.config["MAX_CONTENT_LENGTH"]:
            abort(413)

    load_session_user()

    # CSRF check on every state-changing request.
    if request.method == "POST":
        if not sec.verify_csrf():
            sec.audit("security.csrf_failure", target=request.path,
                      detail="Missing or invalid CSRF token", severity="critical")
            session.clear()
            abort(400)


@app.after_request
def security_headers(response):
    """Defence in depth at the HTTP layer."""
    csp = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self'; "
        "img-src 'self' data:; "
        "font-src 'self'; "
        "connect-src 'self'; "
        "form-action 'self'; "
        "base-uri 'none'; "
        "object-src 'none'; "
        "frame-ancestors " + ("*" if app.config["PREVIEW_MODE"] else "'self'")
    )
    response.headers["Content-Security-Policy"] = csp
    if not app.config["PREVIEW_MODE"]:
        response.headers["X-Frame-Options"] = "SAMEORIGIN"   # clickjacking
    response.headers["X-Content-Type-Options"] = "nosniff"   # MIME sniffing
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
    response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
    if request.is_secure or request.headers.get("X-Forwarded-Proto") == "https":
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    if g.get("user"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, private"
        response.headers["Pragma"] = "no-cache"
    response.headers.pop("X-Powered-By", None)
    return response


@app.context_processor
def inject_globals():
    return {
        "current_user": g.get("user"),
        "can": sec.can,
        "csrf_field": sec.csrf_field,
        "ROLE_LABELS": sec.ROLE_LABELS,
        "ROLES": ROLES,
        "CONFIG": app.config,
        "now": datetime.now(timezone.utc),
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def paginate(total: int, page: int, size: int = PAGE_SIZE) -> dict:
    pages = max(1, (total + size - 1) // size)
    page = min(max(1, page), pages)
    return {"page": page, "pages": pages, "size": size,
            "offset": (page - 1) * size, "total": total,
            "has_prev": page > 1, "has_next": page < pages}


def get_user_or_404(user_id: int):
    row = get_db().execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if not row:
        abort(404)
    return row


def active_admin_count() -> int:
    return get_db().execute(
        "SELECT COUNT(*) AS c FROM users WHERE role = 'admin' AND is_active = 1"
    ).fetchone()["c"]


def start_session(user_row):
    """Rotate the session identifier on login (defeats session fixation)."""
    db = get_db()
    raw, hashed = sec.new_session_token()
    ts = datetime.now(timezone.utc).replace(microsecond=0)
    expires = ts + timedelta(minutes=app.config["IDLE_TIMEOUT_MINUTES"])
    db.execute(
        """INSERT INTO sessions
             (token_hash, user_id, created_at, last_seen_at, expires_at, ip, user_agent)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (hashed, user_row["id"], ts.isoformat(), ts.isoformat(), expires.isoformat(),
         sec.client_ip(), sec.clean_text(request.headers.get("User-Agent", ""), 200)),
    )
    db.execute(
        """UPDATE users SET failed_attempts = 0, locked_until = NULL,
                            last_login_at = ?, last_login_ip = ?, updated_at = ?
           WHERE id = ?""",
        (ts.isoformat(), sec.client_ip(), ts.isoformat(), user_row["id"]),
    )
    db.commit()

    session.clear()  # fresh identifier every login
    session.permanent = True
    session["sid"] = raw
    session["uid"] = user_row["id"]
    session["abs"] = (ts + timedelta(hours=app.config["ABSOLUTE_TIMEOUT_HOURS"])).isoformat()


def end_session():
    if g.get("session_row"):
        db = get_db()
        db.execute("UPDATE sessions SET revoked = 1 WHERE id = ?", (g.session_row["id"],))
        db.commit()
    session.clear()


# Simple in-memory throttle: complements per-account lockout for
# password-spraying across many accounts from one address.
_IP_HITS: dict[str, list] = {}
IP_WINDOW_SECONDS = 300
IP_MAX_ATTEMPTS = 15


def ip_throttled(ip: str) -> bool:
    cutoff = time.time() - IP_WINDOW_SECONDS
    hits = [t for t in _IP_HITS.get(ip, []) if t > cutoff]
    _IP_HITS[ip] = hits
    return len(hits) >= IP_MAX_ATTEMPTS


def note_ip_failure(ip: str):
    _IP_HITS.setdefault(ip, []).append(time.time())


# ---------------------------------------------------------------------------
# Public pages
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    if g.get("user"):
        return redirect(url_for("dashboard"))
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if g.get("user"):
        return redirect(url_for("dashboard"))

    values = {"email": "", "full_name": "", "department": "", "phone": ""}
    errors = []
    if request.method == "POST":
        values, errors = sec.validate_registration(request.form)
        if not errors:
            db = get_db()
            if db.execute("SELECT 1 FROM users WHERE email = ?", (values["email"],)).fetchone():
                errors.append("An account with that email already exists.")
            else:
                ts = now()
                try:
                    with db:
                        db.execute(
                            """INSERT INTO users
                                 (email, password_hash, full_name, role, department, phone,
                                  is_active, created_at, updated_at, password_changed_at)
                               VALUES (?, ?, ?, 'user', ?, ?, 1, ?, ?, ?)""",
                            (values["email"], sec.hash_password(values["password"]),
                             values["full_name"], values["department"], values["phone"],
                             ts, ts, ts),
                        )
                    sec.audit("auth.register", target=values["email"],
                              detail="Self-registration (role: user)")
                    flash("Account created. Please sign in.", "success")
                    return redirect(url_for("login"))
                except sqlite3.IntegrityError:
                    errors.append("An account with that email already exists.")
        if errors:
            sec.audit("auth.register_rejected", target=values.get("email", ""),
                      detail="; ".join(errors)[:300], severity="warning")

    return render_template("register.html", values=values, errors=errors)


@app.route("/login", methods=["GET", "POST"])
def login():
    if g.get("user"):
        return redirect(url_for("dashboard"))

    error = None
    email = ""
    next_url = sec.safe_next(request.values.get("next"))

    if request.method == "POST":
        email = sec.clean_text(request.form.get("email", ""), 120).lower()
        password = request.form.get("password", "")
        ip = sec.client_ip()

        if ip_throttled(ip):
            sec.audit("auth.ip_throttled", target=email,
                      detail=f"More than {IP_MAX_ATTEMPTS} attempts in {IP_WINDOW_SECONDS}s",
                      severity="critical")
            error = "Too many sign-in attempts from this device. Please wait a few minutes."
            return render_template("login.html", error=error, email=email, next_url=next_url), 429

        db = get_db()
        user = db.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()

        if not user:
            sec.burn_time()          # equalise timing: no account enumeration
            note_ip_failure(ip)
            sec.audit("auth.login_failed", target=email,
                      detail="Unknown email", severity="warning")
            error = "Invalid email or password."
        elif sec.lockout_remaining(user):
            remaining = sec.lockout_remaining(user)
            note_ip_failure(ip)
            sec.audit("auth.login_blocked", target=email,
                      detail=f"Account locked for another {remaining}s", severity="critical")
            error = (f"Account temporarily locked after {app.config['MAX_LOGIN_ATTEMPTS']} failed attempts. "
                     f"Try again in {max(1, remaining // 60)} minute(s).")
        elif not user["is_active"]:
            sec.burn_time()
            note_ip_failure(ip)
            sec.audit("auth.login_failed", target=email,
                      detail="Account deactivated", severity="warning")
            error = "This account has been deactivated. Contact an administrator."
        elif not sec.verify_password(user["password_hash"], password):
            note_ip_failure(ip)
            attempts = user["failed_attempts"] + 1
            locked_until = None
            if attempts >= app.config["MAX_LOGIN_ATTEMPTS"]:
                locked_until = (datetime.now(timezone.utc)
                                + timedelta(minutes=app.config["LOCKOUT_MINUTES"])).replace(microsecond=0).isoformat()
                sec.audit("auth.account_locked", target=email,
                          detail=f"Locked after {attempts} failed attempts", severity="critical")
            db.execute("UPDATE users SET failed_attempts = ?, locked_until = ?, updated_at = ? WHERE id = ?",
                       (attempts, locked_until, now(), user["id"]))
            db.commit()
            sec.audit("auth.login_failed", target=email,
                      detail=f"Wrong password (attempt {attempts}/{app.config['MAX_LOGIN_ATTEMPTS']})",
                      severity="warning")
            left = app.config["MAX_LOGIN_ATTEMPTS"] - attempts
            error = "Invalid email or password."
            if 0 < left <= 2:
                error += f" {left} attempt(s) left before the account is locked."
        else:
            start_session(user)
            fresh = db.execute("SELECT * FROM users WHERE id = ?", (user["id"],)).fetchone()
            g.user = fresh
            sec.audit("auth.login_success", target=email,
                      detail=f"Role: {user['role']}", severity="info", actor=fresh)
            return redirect(next_url)

    return render_template("login.html", error=error, email=email, next_url=next_url)


@app.route("/logout", methods=["POST"])
def logout():
    if g.get("user"):
        sec.audit("auth.logout", target=g.user["email"], detail="User signed out")
    end_session()
    flash("You have been signed out.", "success")
    return redirect(url_for("login"))


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------
@app.route("/dashboard")
@sec.login_required
def dashboard():
    db = get_db()
    role = g.user["role"]
    stats = None
    if role in ("admin", "manager"):
        q = db.execute
        stats = {
            "total": q("SELECT COUNT(*) c FROM users").fetchone()["c"],
            "active": q("SELECT COUNT(*) c FROM users WHERE is_active = 1").fetchone()["c"],
            "admins": q("SELECT COUNT(*) c FROM users WHERE role = 'admin'").fetchone()["c"],
            "managers": q("SELECT COUNT(*) c FROM users WHERE role = 'manager'").fetchone()["c"],
            "users": q("SELECT COUNT(*) c FROM users WHERE role = 'user'").fetchone()["c"],
            "locked": q("SELECT COUNT(*) c FROM users WHERE locked_until IS NOT NULL AND locked_until > ?",
                        (now(),)).fetchone()["c"],
        }

    if role in ("admin", "manager"):
        activity = db.execute(
            "SELECT * FROM audit_log ORDER BY id DESC LIMIT 8").fetchall()
    else:
        activity = db.execute(
            "SELECT * FROM audit_log WHERE actor_id = ? ORDER BY id DESC LIMIT 8",
            (g.user["id"],)).fetchall()

    my_sessions = db.execute(
        """SELECT * FROM sessions WHERE user_id = ? AND revoked = 0 AND expires_at > ?
           ORDER BY last_seen_at DESC""",
        (g.user["id"], now()),
    ).fetchall()

    return render_template("dashboard.html", stats=stats, activity=activity,
                           my_sessions=my_sessions, permissions=sorted(sec.user_permissions(g.user)))


# ---------------------------------------------------------------------------
# Profile
# ---------------------------------------------------------------------------
@app.route("/profile")
@sec.login_required
def profile():
    db = get_db()
    history = db.execute(
        "SELECT * FROM audit_log WHERE actor_id = ? ORDER BY id DESC LIMIT 10",
        (g.user["id"],)).fetchall()
    my_sessions = db.execute(
        """SELECT * FROM sessions WHERE user_id = ? AND revoked = 0 AND expires_at > ?
           ORDER BY last_seen_at DESC""",
        (g.user["id"], now())).fetchall()
    return render_template("profile.html", history=history, my_sessions=my_sessions,
                           current_session_id=(g.session_row["id"] if g.get("session_row") else None))


@app.route("/profile", methods=["POST"])
@sec.login_required
def update_profile():
    if not sec.can("profile.edit"):
        abort(403)
    full_name = sec.clean_text(request.form.get("full_name", ""), 80)
    department = sec.clean_text(request.form.get("department", ""), 60)
    phone = sec.clean_text(request.form.get("phone", ""), 20)
    bio = sec.clean_text(request.form.get("bio", ""), 300)

    errors = []
    if not sec.NAME_RE.match(full_name):
        errors.append("Full name must be 2-80 letters, spaces, apostrophes, hyphens or dots.")
    if phone and not sec.PHONE_RE.match(phone):
        errors.append("Phone number may only contain digits, spaces, +, ( and ).")

    if errors:
        for e in errors:
            flash(e, "error")
        return redirect(url_for("profile"))

    db = get_db()
    db.execute("UPDATE users SET full_name = ?, department = ?, phone = ?, bio = ?, updated_at = ? WHERE id = ?",
               (full_name, department, phone, bio, now(), g.user["id"]))
    db.commit()
    sec.audit("profile.updated", target=g.user["email"], detail="Profile details changed")
    flash("Profile updated.", "success")
    return redirect(url_for("profile"))


@app.route("/profile/password", methods=["POST"])
@sec.login_required
def change_password():
    current = request.form.get("current_password", "")
    new = request.form.get("new_password", "")
    confirm = request.form.get("confirm_password", "")
    db = get_db()

    if not sec.verify_password(g.user["password_hash"], current):
        sec.audit("auth.password_change_failed", target=g.user["email"],
                  detail="Wrong current password", severity="warning")
        flash("Your current password is incorrect.", "error")
        return redirect(url_for("profile"))

    problems = sec.password_problems(new, g.user["email"], g.user["full_name"])
    if new != confirm:
        problems.append("New passwords do not match.")
    if current == new:
        problems.append("Choose a password different from your current one.")
    if problems:
        for p in problems:
            flash(p, "error")
        return redirect(url_for("profile"))

    db.execute("UPDATE users SET password_hash = ?, password_changed_at = ?, updated_at = ? WHERE id = ?",
               (sec.hash_password(new), now(), now(), g.user["id"]))
    # Every other session is revoked: a changed password must evict old devices.
    db.execute("UPDATE sessions SET revoked = 1 WHERE user_id = ? AND id != ?",
               (g.user["id"], g.session_row["id"] if g.get("session_row") else -1))
    db.commit()
    sec.audit("auth.password_changed", target=g.user["email"],
              detail="Password changed; other sessions revoked", severity="warning")
    flash("Password changed. All other devices were signed out.", "success")
    return redirect(url_for("profile"))


# ---------------------------------------------------------------------------
# User management (RBAC-protected)
# ---------------------------------------------------------------------------
@app.route("/users")
@sec.require_permission("user.view")
def users():
    db = get_db()
    q = sec.clean_text(request.args.get("q", ""), 100)
    role = request.args.get("role", "")
    status = request.args.get("status", "")
    page = max(1, int(request.args.get("page", 1) or 1))

    where, params = [], []
    if q:
        where.append("(email LIKE ? OR full_name LIKE ? OR department LIKE ?)")
        like = f"%{q}%"
        params += [like, like, like]
    if role in ROLES:
        where.append("role = ?")
        params.append(role)
    if status in ("active", "inactive", "locked"):
        if status == "active":
            where.append("is_active = 1 AND (locked_until IS NULL OR locked_until <= ?)")
            params.append(now())
        elif status == "inactive":
            where.append("is_active = 0")
        else:
            where.append("locked_until IS NOT NULL AND locked_until > ?")
            params.append(now())

    clause = (" WHERE " + " AND ".join(where)) if where else ""
    total = db.execute(f"SELECT COUNT(*) c FROM users{clause}", params).fetchone()["c"]
    meta = paginate(total, page)
    rows = db.execute(
        f"""SELECT * FROM users{clause}
            ORDER BY CASE role WHEN 'admin' THEN 0 WHEN 'manager' THEN 1 ELSE 2 END,
                     full_name COLLATE NOCASE
            LIMIT ? OFFSET ?""",
        params + [meta["size"], meta["offset"]],
    ).fetchall()

    return render_template("users.html", users=rows, q=q, role=role, status=status, meta=meta)


@app.route("/users/<int:user_id>")
@sec.require_permission("user.view")
def user_detail(user_id):
    row = get_user_or_404(user_id)
    db = get_db()
    history = db.execute(
        "SELECT * FROM audit_log WHERE actor_id = ? OR target = ? ORDER BY id DESC LIMIT 20",
        (user_id, row["email"])).fetchall()
    sessions = db.execute(
        """SELECT * FROM sessions WHERE user_id = ? AND revoked = 0 AND expires_at > ?
           ORDER BY last_seen_at DESC""", (user_id, now())).fetchall()
    return render_template("user_detail.html", u=row, history=history, sessions=sessions)


@app.route("/users/create", methods=["POST"])
@sec.require_permission("user.create")
def create_user():
    db = get_db()
    email = sec.clean_text(request.form.get("email", ""), 120).lower()
    full_name = sec.clean_text(request.form.get("full_name", ""), 80)
    department = sec.clean_text(request.form.get("department", ""), 60)
    role = request.form.get("role", "user")
    password = request.form.get("password", "")

    errors = []
    if not sec.EMAIL_RE.match(email):
        errors.append("Enter a valid email address.")
    if not sec.NAME_RE.match(full_name):
        errors.append("Enter the user's full name (letters only).")
    # A manager may only ever create standard users - enforced server-side,
    # not just by hiding options in the form.
    if role not in ROLES or (g.user["role"] != "admin" and role != "user"):
        errors.append("You are not allowed to assign that role.")
    errors.extend(sec.password_problems(password, email, full_name))

    if errors:
        for e in errors:
            flash(e, "error")
        return redirect(url_for("users"))
    if db.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
        flash("A user with that email already exists.", "error")
        return redirect(url_for("users"))

    ts = now()
    try:
        with db:
            db.execute(
                """INSERT INTO users (email, password_hash, full_name, role, department,
                                      is_active, created_at, updated_at, password_changed_at)
                   VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)""",
                (email, sec.hash_password(password), full_name, role, department, ts, ts, ts))
    except sqlite3.IntegrityError:
        flash("A user with that email already exists.", "error")
        return redirect(url_for("users"))

    sec.audit("user.created", target=email, detail=f"Role: {role}", severity="warning")
    flash(f"Account created for {full_name}.", "success")
    return redirect(url_for("users"))


@app.route("/users/<int:user_id>/role", methods=["POST"])
@sec.require_permission("user.role.change")
def change_role(user_id):
    row = get_user_or_404(user_id)
    new_role = request.form.get("role", "")
    if not sec.can_manage(row):
        sec.audit("rbac.access_denied", target=row["email"],
                  detail="Role change blocked by object-level check", severity="critical")
        abort(403)
    if new_role not in ROLES:
        flash("Invalid role.", "error")
        return redirect(url_for("users"))
    if row["role"] == "admin" and new_role != "admin" and active_admin_count() <= 1:
        flash("Cannot demote the last active administrator.", "error")
        return redirect(url_for("users"))
    if row["role"] == new_role:
        flash("That user already has that role.", "warning")
        return redirect(url_for("users"))

    db = get_db()
    db.execute("UPDATE users SET role = ?, updated_at = ? WHERE id = ?", (new_role, now(), user_id))
    db.commit()
    sec.audit("rbac.role_changed", target=row["email"],
              detail=f"{row['role']} -> {new_role}", severity="warning")
    flash(f"{row['full_name']} is now a {sec.ROLE_LABELS[new_role]}.", "success")
    return redirect(request.form.get("back") or url_for("users"))


@app.route("/users/<int:user_id>/status", methods=["POST"])
@sec.require_permission("user.deactivate")
def toggle_status(user_id):
    row = get_user_or_404(user_id)
    if not sec.can_manage(row):
        sec.audit("rbac.access_denied", target=row["email"],
                  detail="Status change blocked by object-level check", severity="critical")
        abort(403)
    if row["role"] == "admin" and row["is_active"] and active_admin_count() <= 1:
        flash("Cannot deactivate the last active administrator.", "error")
        return redirect(url_for("users"))

    db = get_db()
    new_state = 0 if row["is_active"] else 1
    db.execute("UPDATE users SET is_active = ?, failed_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?",
               (new_state, now(), user_id))
    if not new_state:
        db.execute("UPDATE sessions SET revoked = 1 WHERE user_id = ?", (user_id,))
    db.commit()
    sec.audit("user.deactivated" if not new_state else "user.reactivated", target=row["email"],
              detail="Account disabled; sessions revoked" if not new_state else "Account enabled",
              severity="warning" if not new_state else "info")
    flash(f"{row['full_name']} was {'deactivated' if not new_state else 'reactivated'}.", "success")
    return redirect(request.form.get("back") or url_for("users"))


@app.route("/users/<int:user_id>/unlock", methods=["POST"])
@sec.require_permission("user.deactivate")
def unlock_user(user_id):
    row = get_user_or_404(user_id)
    if not sec.can_manage(row):
        abort(403)
    db = get_db()
    db.execute("UPDATE users SET failed_attempts = 0, locked_until = NULL, updated_at = ? WHERE id = ?",
               (now(), user_id))
    db.commit()
    sec.audit("user.unlocked", target=row["email"], detail="Lockout cleared by staff")
    flash(f"Lockout cleared for {row['full_name']}.", "success")
    return redirect(request.form.get("back") or url_for("users"))


@app.route("/users/<int:user_id>/delete", methods=["POST"])
@sec.require_permission("user.delete")
def delete_user(user_id):
    row = get_user_or_404(user_id)
    if not sec.can_manage(row):
        abort(403)
    if row["role"] == "admin" and active_admin_count() <= 1:
        flash("Cannot delete the last active administrator.", "error")
        return redirect(url_for("users"))
    db = get_db()
    db.execute("DELETE FROM users WHERE id = ?", (user_id,))
    db.commit()
    sec.audit("user.deleted", target=row["email"],
              detail=f"Deleted account ({row['role']})", severity="critical")
    flash(f"{row['full_name']}'s account was deleted.", "success")
    return redirect(url_for("users"))


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------
@app.route("/sessions/<int:session_id>/revoke", methods=["POST"])
@sec.login_required
def revoke_session(session_id):
    db = get_db()
    row = db.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
    if not row:
        abort(404)
    if row["user_id"] != g.user["id"] and not sec.can("session.revoke.any"):
        sec.audit("rbac.access_denied", target=f"session:{session_id}",
                  detail="Attempted to revoke another user's session", severity="critical")
        abort(403)
    db.execute("UPDATE sessions SET revoked = 1 WHERE id = ?", (session_id,))
    db.commit()
    sec.audit("session.revoked", target=f"session:{session_id}",
              detail=f"Revoked session for user #{row['user_id']}", severity="warning")
    flash("Session revoked.", "success")
    return redirect(request.form.get("back") or url_for("profile"))


# ---------------------------------------------------------------------------
# Audit log + security centre
# ---------------------------------------------------------------------------
@app.route("/audit")
@sec.require_permission("audit.view")
def audit_log():
    db = get_db()
    q = sec.clean_text(request.args.get("q", ""), 100)
    severity = request.args.get("severity", "")
    page = max(1, int(request.args.get("page", 1) or 1))

    where, params = [], []
    if q:
        where.append("(action LIKE ? OR actor_email LIKE ? OR target LIKE ? OR detail LIKE ?)")
        like = f"%{q}%"
        params += [like, like, like, like]
    if severity in ("info", "warning", "critical"):
        where.append("severity = ?")
        params.append(severity)
    clause = (" WHERE " + " AND ".join(where)) if where else ""

    total = db.execute(f"SELECT COUNT(*) c FROM audit_log{clause}", params).fetchone()["c"]
    meta = paginate(total, page, PAGE_SIZE * 2)
    rows = db.execute(f"SELECT * FROM audit_log{clause} ORDER BY id DESC LIMIT ? OFFSET ?",
                      params + [meta["size"], meta["offset"]]).fetchall()
    return render_template("audit.html", rows=rows, q=q, severity=severity, meta=meta)


@app.route("/security")
@sec.require_permission("security.view")
def security_center():
    db = get_db()
    locked = db.execute(
        "SELECT * FROM users WHERE locked_until IS NOT NULL AND locked_until > ? ORDER BY locked_until",
        (now(),)).fetchall()
    active_sessions = db.execute(
        """SELECT s.*, u.email FROM sessions s JOIN users u ON u.id = s.user_id
           WHERE s.revoked = 0 AND s.expires_at > ? ORDER BY s.last_seen_at DESC LIMIT 20""",
        (now(),)).fetchall()
    critical = db.execute(
        "SELECT * FROM audit_log WHERE severity = 'critical' ORDER BY id DESC LIMIT 10").fetchall()
    return render_template("security.html", locked=locked,
                           active_sessions=active_sessions, critical=critical)


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------
def render_error(code, title, message):
    return render_template("error.html", code=code, title=title, message=message), code


@app.errorhandler(400)
def bad_request(e):
    return render_error(400, "Bad request",
                        "The form could not be verified (missing or expired CSRF token). Please reload the page and try again.")


@app.errorhandler(403)
def forbidden(e):
    return render_error(403, "Access denied",
                        "Your role does not include permission for this action. The attempt has been logged.")


@app.errorhandler(404)
def not_found(e):
    return render_error(404, "Not found", "That page or record does not exist.")


@app.errorhandler(413)
def too_large(e):
    return render_error(413, "Payload too large", "The request exceeded the 1 MB limit.")


@app.errorhandler(429)
def too_many(e):
    return render_error(429, "Too many requests", "Slow down and try again shortly.")


@app.errorhandler(500)
def server_error(e):  # pragma: no cover
    return render_error(500, "Something went wrong",
                        "An unexpected error occurred. No sensitive details are shown here.")


# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------
def create_tables():
    init_db(app.config["DATABASE"])


if __name__ == "__main__":
    create_tables()
    if seed(app.config["DATABASE"]):
        print("Seeded demo users.")
    print("AccessGuard running on http://0.0.0.0:8000")
    app.run(host="0.0.0.0", port=8000, debug=False, threaded=True)
