# AccessGuard — Security Report

Project: user access management system
Topic area: web application security
Artefact: `accessguard/` (Flask + SQLite), tests in `tests/security_check.py`

This report explains the security model of the application, the attack each control defends
against, where the control lives in the code, and the evidence that it works.

---

## 1. Threat model

| # | Threat | Attacker goal | Mitigation in this system |
|---|---|---|---|
| T1 | Credential stuffing / brute force | Guess passwords | Lockout after 5 failures, per-IP throttle, generic errors, audit |
| T2 | Account enumeration | Discover valid emails | Identical error text for unknown email and wrong password, dummy-hash timing |
| T3 | SQL injection | Bypass auth, dump data | 100 % parameterised queries, no dynamic SQL from user input |
| T4 | Cross-site scripting (stored/reflected) | Run script in another user's session | Jinja2 autoescaping, strict CSP without `unsafe-inline`, no `|safe` |
| T5 | Cross-site request forgery | Make an admin perform an action | Synchroniser token on every POST + `SameSite=Lax` |
| T6 | Broken access control / privilege escalation | Reach admin data as a normal user | Permission matrix + `@require_permission` + row-level `can_manage` checks |
| T7 | Session theft / fixation | Hijack a session | HttpOnly/Secure/SameSite cookie, ID rotation on login, server-side revocation, idle+absolute timeouts |
| T8 | Sensitive data exposure | Read passwords or PII | scrypt hashing, no hashes in UI, `no-store`, no stack traces |
| T9 | Clickjacking | Trick a user into clicking | `X-Frame-Options: SAMEORIGIN` + CSP `frame-ancestors 'self'` |
| T10 | Open redirect | Use the app as a phishing hop | `?next=` restricted to same-site relative paths |
| T11 | Log/CSV injection, header splitting | Corrupt logs | Control characters stripped from every string before storage |
| T12 | DoS via large uploads | Exhaust memory | 1 MB `MAX_CONTENT_LENGTH`, 413 handler |

Non-goals (out of scope for this build): phishing, malware on the client, physical access,
insider tampering with the server itself, and availability at scale.

---

## 2. Control-by-control evidence

Every claim below is exercised by `python3 tests/security_check.py`, which prints one PASS/FAIL
line per check. Current result: **46/46 passing**.

### 2.1 Authentication (login / logout)

* `POST /login` looks the user up with a parameterised query, verifies the scrypt hash, and on
  success calls `start_session()` (`app.py`), which:
  * creates a random 32-byte token, stores only its SHA-256 hash in `sessions`,
  * calls `session.clear()` first — the pre-login cookie value is discarded, defeating
    **session fixation**,
  * sets `session.permanent = True` and records an absolute expiry.
* `POST /logout` (**POST only**, so a link/`<img>` cannot force it) revokes the row in `sessions`
  and clears the cookie. A stale cookie is useless because the server row is authoritative.
* Password change revokes **every other session** for that user (`change_password`), so a
  compromised device is evicted immediately.
* `before_request` re-validates the session on every request, slides the idle timer forward and
  refuses anything past the absolute cap.

### 2.2 Password hashing

```python
def hash_password(raw):
    return generate_password_hash(raw, method="scrypt")
```

Werkzeug's `scrypt` is memory-hard and salted per password, so identical passwords produce
different hashes and GPU cracking gains little. `check_password_hash` compares in constant time.
Hashes are never selected into templates; the profile page prints `current_user['password_hash']`
nowhere (asserted by the test *"Password hash is never rendered in HTML"*).

### 2.3 Password policy

`security.password_problems()` enforces: ≥ 10 characters (≤ 128), at least 3 of 4 character
classes, not in a blocklist of common passwords, no 4+ repeated characters, and no substring
match with the user's name or email. The same function is used at registration, admin user
creation and password change, so the policy cannot be bypassed by picking a different form.

### 2.4 Role-based access control

Permissions are **data**, declared once:

```python
PERMISSIONS = {
  "user":    {"dashboard.view", "profile.view", "profile.edit", "session.manage"},
  "manager": {..., "user.view", "user.create", "user.deactivate", "audit.view"},
  "admin":   {..., "user.edit", "user.delete", "user.role.change",
              "audit.view", "security.view", "session.revoke.any"},
}
```

Routes are gated with `@sec.require_permission("user.delete")` etc. Blocked attempts are written
to the audit log with `severity='critical'` and answered with a 403 page that reveals nothing
about the protected resource.

**Coarse + fine grained.** Holding `user.deactivate` is not enough: `can_manage()` refuses
actions on a user whose role ranks at or above the actor's, and refuses self-targeting. So a
manager can deactivate a standard user but can never touch an administrator or themselves, and
nobody can demote/delete the last active administrator (checked in the route as well).

The navigation is *also* role-aware, but only as a convenience — the server never relies on the
UI hiding a link.

### 2.5 Input validation

* Every field goes through `clean_text()` (length cap + control-character stripping) and then a
  whitelist regex: `EMAIL_RE`, `NAME_RE`, `PHONE_RE`. Free text (`bio`, `department`) is capped
  and stored as plain text.
* Numeric IDs are typed by Flask's `<int:>` converter, so `POST /users/abc/role` 404s.
* `role` must be one of the three known roles; `severity` and `status` filters are whitelisted.
* Requests over 1 MB are rejected before parsing.

### 2.6 SQL injection

Every query is a constant SQL string with placeholders; user data only ever arrives as bound
parameters:

```python
where.append("(email LIKE ? OR full_name LIKE ? OR department LIKE ?)")
params += [like, like, like]
...
db.execute(f"SELECT COUNT(*) c FROM users{clause}", params)
```

The only f-string interpolation is of the *clause template* assembled from hard-coded fragments,
never of user input — so `' OR 1=1 --` is matched literally as an email address and returns "no
results". Injection attempts at login, in the user search box, in the audit search and in the
filters are all covered by tests.

### 2.7 Cross-site scripting (XSS)

Four layers:

1. **Autoescaping.** Jinja2 escapes `{{ }}` in every template; the codebase contains no `|safe`
   and no `Markup` of user data (the only `Markup` is the CSRF hidden input).
2. **Output context.** Values are only ever placed in element text or quoted attributes, never
   into `<script>`, `on*=` handlers or `href="javascript:…"`.
3. **Content-Security-Policy.** `default-src 'self'; script-src 'self'; style-src 'self'; …
   object-src 'none'; base-uri 'none'` — an injected `<script>` or `onerror=` cannot execute even
   if escaping were bypassed, because inline script is not allowed at all. All JS lives in
   `static/js/app.js`, which is why the policy needs no `unsafe-inline`.
4. **Input hygiene.** Control characters are stripped, and name/email/phone are whitelisted
   patterns, so angle brackets cannot even reach those columns.

Test evidence: a `<script>alert('xss')</script>` string saved into `bio` renders as
`&lt;script&gt;…`; an `<img onerror>` typed into `department` renders inert; a reflected payload in
`?q=` comes back escaped.

### 2.8 CSRF

Synchroniser-token pattern. `session["csrf_token"]` is generated with `secrets.token_urlsafe(32)`
the first time a page renders and injected as a hidden field through the `csrf_field()` template
helper. `before_request` rejects **any** POST whose token is missing or does not match
(`hmac.compare_digest`), logs `security.csrf_failure` as critical and clears the session.
`SameSite=Lax` on the cookie is the second layer. `GET` routes never mutate state, so links
cannot be weaponised.

### 2.9 Session management

| Setting | Value |
|---|---|
| Cookie flags | `HttpOnly`, `SameSite=Lax`, `Secure` (production), path `/` |
| Rotation | New identifier on every login (`session.clear()` then new token) |
| Idle timeout | 30 minutes (`expires_at` slides on each request) |
| Absolute timeout | 8 hours (stored in the signed cookie, cannot be extended by the client) |
| Revocation | Row deleted/flagged server-side → cookie instantly worthless |
| Transport | `Secure` + HSTS means it is never sent over plain HTTP |
| Visibility | Users can see every device/IP and revoke each one from `/profile` |

The token itself is random (`secrets`, not `random`), and only its hash is persisted — a stolen
database backup therefore cannot be used to impersonate anyone.

### 2.10 Access-control checks

Three checks happen on every sensitive request: *authenticated?* (`@login_required`),
*permitted action?* (`@require_permission`), *permitted target?* (`can_manage` inside the route,
because the target row is only known after it is loaded). Failure of any of them produces 403,
an audit entry, and no state change. The tests confirm that a standard user gets 403 on
`/users`, `/audit`, `/security` and `POST /users/1/role`, and that a manager gets 403 when
targeting an administrator.

### 2.11 Secure handling of sensitive information

* Passwords: scrypt hashes only; never logged, never rendered, never in the audit `detail`.
* Personal data: a user sees their own record; staff see directory fields but not credentials.
* Errors: a single generic 500 page, `debug=False`, no tracebacks or paths to the browser.
* Enumeration: one message for every failed-login cause, equalised timing.
* Caching: `no-store` + `Pragma: no-cache` on authenticated responses.
* Secrets: `SECRET_KEY` from the environment, with a 0600 local fallback file; nothing secret is
  committed to the repository.
* Headers: `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`,
  `Permissions-Policy`, `Cross-Origin-Opener-Policy`.
* Log injection: every stored string passes `clean_text()` (control characters removed) so
  newline-based log forging is impossible.

### 2.12 HTTPS / transport configuration

The app itself can serve plain HTTP for development; in production it sits behind the TLS
terminator in `deploy/nginx.conf`:

* HTTP → HTTPS 301 redirect, TLS 1.2/1.3 only, modern cipher suite, session tickets off,
  OCSP stapling.
* `Strict-Transport-Security: max-age=31536000; includeSubDomains` (the app adds HSTS itself when
  it detects `X-Forwarded-Proto: https`).
* `proxy_set_header X-Forwarded-For / X-Forwarded-Proto` so the app logs real client IPs and
  knows the request arrived over TLS.
* `COOKIE_SECURE=1` so the session cookie is never transmitted in clear text.
* Static assets served with long cache lifetimes; the app itself is `no-store`.

### 2.13 Auditability

`audit_log` records the actor, target, IP, timestamp, severity and a short detail for:
`auth.login_success`, `auth.login_failed`, `auth.account_locked`, `auth.login_blocked`,
`auth.logout`, `auth.register`, `auth.password_changed`, `auth.password_change_failed`,
`auth.ip_throttled`, `rbac.role_changed`, `rbac.access_denied`, `user.created`,
`user.deactivated`, `user.reactivated`, `user.unlocked`, `user.deleted`, `session.revoked`,
`security.csrf_failure`, `profile.updated`. The log is visible to staff at `/audit`
(searchable, filterable, paginated) and critical entries are summarised in `/security`.

### 2.14 Brute-force and abuse resistance

* **Per-account lockout** — 5 consecutive failures set `locked_until = now + 15 min` in the
  database, so the lock survives a restart and is visible to administrators. While locked, even
  the *correct* password is refused (asserted by a test), which prevents an attacker from
  "confirming" a guess.
* **Per-IP throttle** — 15 failed attempts from one address in 5 minutes returns HTTP 429 and a
  critical audit entry; this blunts password spraying across many accounts from one host.
* **Progressive feedback** — from the third failure the user is told how many attempts remain,
  which is good usability and no help to a remote attacker who cannot see it.
* **Recovery** — administrators clear a lockout from the user directory or the security centre;
  a successful login resets the counter.
* **Timing** — unknown email addresses trigger a dummy scrypt verification
  (`burn_time()`), so "user does not exist" and "wrong password" take about the same time.

---

## 3. Interface and usability details that are also security details

* Generic authentication errors never say whether the account exists, and
  `burn_time()` runs a dummy hash comparison when the email is unknown so response timing does
  not leak either.
* The **honeypot** field `website` is positioned off-screen; humans never fill it, bots usually
  do, and registration is refused if it is populated.
* `Cache-Control: no-store` on authenticated pages prevents a shared machine from re-displaying
  a profile from history.
* Error pages never echo the submitted value back (reflected-XSS-by-construction) and never show
  tracebacks.
* Success messages auto-dismiss; the password field has a show/hide toggle that is purely local
  and does not send anything.
* The UI is keyboard-navigable: real `<label for>`, `:focus` rings, `aria-live` on flash
  messages, `aria-expanded` on the mobile menu, `prefers-reduced-motion` respected.

---

## 4. Production hardening checklist

| Item | Status in this build |
|---|---|
| TLS via nginx (`deploy/nginx.conf`), HTTP→HTTPS redirect, TLS 1.2/1.3 only | Configuration provided; app sends HSTS when it sees HTTPS |
| `COOKIE_SECURE=1` | Default; must stay on in production |
| Random `SECRET_KEY` from the environment | `config.py` refuses to invent one silently — it generates and persists a 0600 file only for local runs |
| Gunicorn/uWSGI instead of the dev server | Documented (`gunicorn -w 4 -b 127.0.0.1:8000 app:app`) |
| Least-privilege DB user, parameterised access, WAL journal | SQLite here; driver-agnostic queries |
| Audit log retention/export to append-only storage | Application writes entries; shipping is deployment work |
| Dependency updates / pip-audit | Not automated in this build |
| Monitoring and alerting on `critical` audit entries | Security centre surfaces them; alerting is deployment work |

---

## 5. Limitations and future work

1. **E-mail verification and password reset** — a reset token table (single-use, short TTL,
   hashed) would slot into `security.py`; the mailer is intentionally not included.
2. **MFA (TOTP / WebAuthn)** — add `users.totp_secret` and a second verification step in `login()`.
3. **SSO** — SAML/OIDC via an identity provider, keeping the local permission matrix and mapping
   IdP groups to roles, plus SCIM for provisioning.
4. **Audit log as a chained hash** (each row hashing the previous) would make tampering
   detectable; today the table is append-only by convention.
5. **Automated browser tests** for the UI flows (the current suite drives the app through
   Flask's test client, which covers HTTP + templates but not CSS/JS behaviour).

---

## 6. Conclusion

The system separates the three questions a user-access management system must answer:

1. **Who are you?** — scrypt-hashed credentials, server-side sessions, lockout, no enumeration.
2. **What may you do?** — a permission matrix checked on the server for every route, backed by
   row-level rules that prevent escalation and self-lockout.
3. **What happened?** — an append-only audit log covering authentication, authorisation failures
   and account changes, surfaced to administrators.

All of it is demonstrated by 46 automated checks and 14 screenshots in `docs/screens/`.
