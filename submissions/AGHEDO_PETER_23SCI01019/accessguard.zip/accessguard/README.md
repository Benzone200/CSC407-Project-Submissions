# AccessGuard — User Access Management System

A complete, runnable user access management system: registration, sign-in, profiles, a
searchable user directory, role-based access control (Admin / Manager / User), an
append-only audit trail, and a demonstrable set of web-application security controls.

Built with **Python 3 + Flask + SQLite**, server-rendered templates and a single hand-written
stylesheet — no CDN, no framework, no external JavaScript, so the app works offline and can
enforce a strict Content-Security-Policy.

```
python3 -m pip install -r requirements.txt
python3 app.py          # http://localhost:8000
```

---

## 1. Demo accounts

| Role | Email | Password | What they can do |
|---|---|---|---|
| Administrator | `admin@accessguard.test` | `Admin!Passw0rd123` | Everything: manage all users, change roles, delete accounts, view audit log + security centre |
| Manager | `manager@accessguard.test` | `Manager!Passw0rd123` | View the directory, create standard users, deactivate/activate standard users, view audit log |
| Standard user | `user@accessguard.test` | `User!Passw0rd123` | Own dashboard and profile only |

Five more seeded accounts exist so that search, filtering and pagination have something to show.

---

## 2. What the app does (feature walk-through)

**Frontend / interface**

| Requirement | Where |
|---|---|
| Home / dashboard | `/` (public landing) → `/dashboard` (role-aware: stats + activity for staff, account summary for standard users) |
| Registration page | `/register` — full validation, password-strength meter, honeypot |
| Login page | `/login` — generic errors, lockout messaging, show/hide password |
| User profile | `/profile` — edit details, change password, see permissions, see & revoke signed-in devices |
| Navigation menu | Top bar, role-aware (admin links are not even rendered for standard users), collapses to a hamburger on phones |
| Forms for entering data | Registration, login, profile, password change, admin "Add user" dialog, role/status changes |
| Search / filter | `/users` — free-text search across name, email and department; role filter; status filter (active / deactivated / locked); pagination. `/audit` — search + severity filter + pagination |
| Responsive design | Fluid layout, breakpoints at 940 / 800 / 720 px; tables transform into labelled cards on phones; tested at 390 × 844 |

**Security** — summarised below, documented in depth in [`docs/security-report.md`](docs/security-report.md).

| Control | Implementation |
|---|---|
| Authentication | Server-side session store, session-ID rotation on login, logout, idle (30 min) + absolute (8 h) timeouts |
| Password hashing | `scrypt` via Werkzeug `generate_password_hash`; plaintext never stored or logged |
| Role-based access | Permission matrix in `security.py`, `@require_permission` on routes, **plus** row-level checks (`can_manage`) |
| Input validation | Server-side validators for every field (`security.validate_registration`, `NAME_RE`, `EMAIL_RE`, `PHONE_RE`), length caps, control-character stripping, 1 MB body cap |
| SQL injection | 100 % parameterised queries; no string interpolation of user data into SQL |
| XSS | Jinja2 autoescaping everywhere, no `|safe`, strict CSP with no `unsafe-inline`, no inline event handlers |
| Session management | HttpOnly + SameSite=Lax (+ Secure in production) cookie, server-side revocation, "revoke this device" and "revoke on password change" |
| Access-control checks | Enforced in the view *and* verified by tests (403 + audit entry on every blocked attempt) |
| Sensitive information | Generic login errors (no account enumeration), equalised timing, no stack traces, no hashes in the UI, `Cache-Control: no-store` |
| HTTPS / transport | Nginx TLS config, HSTS when served over HTTPS, secure-cookie flag, `X-Forwarded-Proto` handling |
| Extras | CSRF tokens on every POST, account lockout after 5 failures + IP throttle, audit log, security headers, open-redirect protection, clickjacking protection |

---

## 3. Project layout

```
accessguard/
├── app.py                  # routes, request lifecycle, error handlers, security headers
├── config.py               # every security knob in one place (env-overridable)
├── db.py                   # schema, connection helper, demo seed data
├── security.py             # hashing, password policy, validation, CSRF, RBAC, audit
├── templates/              # 11 Jinja2 templates (autoescaped)
│   ├── base.html           #   shell: role-aware nav, flash messages, footer
│   ├── index.html login.html register.html
│   ├── dashboard.html profile.html users.html user_detail.html
│   ├── audit.html security.html error.html
├── static/
│   ├── css/style.css       # single responsive stylesheet (no framework)
│   └── js/app.js           # small progressive-enhancement script (no framework)
├── tests/security_check.py # 46 automated attack/defence checks
├── tools/capture_screens.py# regenerates the screenshots in docs/screens
├── deploy/nginx.conf       # TLS + reverse-proxy hardening
├── docs/
│   ├── security-report.md  # threat model, control-by-control evidence, test results
│   └── screens/            # 14 screenshots (desktop + mobile, admin + user)
├── requirements.txt
└── run.sh                  # convenience launcher
```

### Data model

```
users(id, email UNIQUE, password_hash, full_name, role, department, phone, bio,
      is_active, failed_attempts, locked_until, last_login_at, last_login_ip,
      password_changed_at, created_at, updated_at)

sessions(id, token_hash UNIQUE, user_id → users.id, created_at, last_seen_at,
         expires_at, ip, user_agent, revoked)

audit_log(id, created_at, actor_id, actor_email, action, target, detail, ip, severity)
```

Only a **SHA-256 hash** of the session token is stored, so a database leak cannot be
replayed as a live session.

---

## 4. Run it

```bash
python3 -m pip install -r requirements.txt
python3 app.py
# open http://localhost:8000
```

Environment variables (all optional):

| Variable | Default | Purpose |
|---|---|---|
| `SECRET_KEY` | generated to `instance/.secret_key` (0600) | Flask cookie signing key — **always set this in production** |
| `DATABASE_PATH` | `instance/accessguard.db` | SQLite file location |
| `COOKIE_SECURE` | `1` | Send the session cookie over HTTPS only. Set `0` for plain-HTTP local demos |
| `PREVIEW_MODE` | `0` | Relaxes only the framing headers so the app can run inside an embedded preview iframe |
| `ENV_LABEL` | `development` | Shown in the footer |

> The sandbox/demo launcher uses `COOKIE_SECURE=0 PREVIEW_MODE=1`. A real deployment keeps both at `1`/`0`.

### Run the security test suite

```bash
python3 tests/security_check.py
```

```
46/46 checks passed
```

The suite attacks the running code with a Flask test client: SQL injection in login and search
boxes, stored and reflected XSS, missing/forged CSRF tokens, role escalation, object-level
bypasses, password-policy bypasses, session fixation and revocation, open redirects, header
checks, lockout behaviour and audit-log coverage. It runs against a throwaway database, so your
demo data is untouched.

---

## 5. Production notes

* **Serve with a real WSGI server** — `gunicorn -w 4 -b 127.0.0.1:8000 app:app` (the Flask dev
  server is for development only).
* **Put TLS in front** — see `deploy/nginx.conf`, then set `COOKIE_SECURE=1` and a strong
  `SECRET_KEY`.
* **Use a server database** — swap `db.connect()` for PostgreSQL/MySQL; every query is already
  parameterised.
* **Run as a non-root user**, keep the SQLite file (`instance/`) out of the web root and
  backed up, and ship the audit log to append-only storage.
* **Not included** (deliberately out of scope, listed for honesty): e-mail verification and
  password-reset mail, MFA/TOTP, SSO (SAML/OIDC), and a WAF. `docs/security-report.md`
  describes where each would slot in.

---

## 6. Screenshots

| | |
|---|---|
| ![Landing](docs/screens/01-landing.png) | ![Sign in](docs/screens/02-login.png) |
| ![Admin dashboard](docs/screens/03-dashboard-admin.png) | ![User directory](docs/screens/04-users.png) |
| ![Search and filters](docs/screens/05-users-filtered.png) | ![Profile](docs/screens/06-profile.png) |
| ![Audit log](docs/screens/07-audit.png) | ![Security centre](docs/screens/08-security.png) |
| ![Mobile dashboard](docs/screens/10-mobile-dashboard.png) | ![Mobile directory](docs/screens/11-mobile-users.png) |
| ![Standard user dashboard](docs/screens/12-dashboard-user.png) | ![403 access denied](docs/screens/13-access-denied.png) |
