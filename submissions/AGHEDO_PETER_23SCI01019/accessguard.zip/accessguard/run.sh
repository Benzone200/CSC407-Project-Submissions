#!/usr/bin/env bash
# Start AccessGuard locally.
#   ./run.sh              -> production-ish defaults (Secure cookie, strict framing)
#   DEMO=1 ./run.sh       -> plain-HTTP demo mode (Secure cookie off, iframe framing allowed)
set -euo pipefail
cd "$(dirname "$0")"

if [ "${DEMO:-0}" = "1" ]; then
  export COOKIE_SECURE=0
  export PREVIEW_MODE=1
  export ENV_LABEL=demo
  echo "Starting in DEMO mode (plain HTTP, relaxed framing headers)."
else
  export COOKIE_SECURE=1
  export PREVIEW_MODE=0
  echo "Starting in PRODUCTION-style mode: serve behind HTTPS (see deploy/nginx.conf)."
fi

python3 -m pip install -q -r requirements.txt
exec python3 app.py
