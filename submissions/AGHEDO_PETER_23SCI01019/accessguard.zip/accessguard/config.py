"""Central configuration for AccessGuard.

Every security-relevant knob lives here so it can be reviewed in one place and
overridden with environment variables in production.
"""
import os
import pathlib
import secrets
from datetime import timedelta

BASE_DIR = pathlib.Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"


def _load_secret_key() -> str:
    """Never hard-code a SECRET_KEY.

    In production set SECRET_KEY in the environment (see deploy/nginx.conf).
    For local/demo runs we generate one and persist it with 0600 permissions.
    """
    env = os.environ.get("SECRET_KEY")
    if env:
        return env
    INSTANCE_DIR.mkdir(exist_ok=True)
    key_file = INSTANCE_DIR / ".secret_key"
    if key_file.exists():
        return key_file.read_text().strip()
    key = secrets.token_urlsafe(48)
    key_file.write_text(key)
    key_file.chmod(0o600)
    return key


def _env_bool(name: str, default: bool = False) -> bool:
    return os.environ.get(name, "1" if default else "0") in ("1", "true", "yes", "on")


class Config:
    # --- Core ---------------------------------------------------------------
    SECRET_KEY = _load_secret_key()
    DATABASE = os.environ.get("DATABASE_PATH", str(INSTANCE_DIR / "accessguard.db"))
    MAX_CONTENT_LENGTH = 1 * 1024 * 1024  # 1 MB request cap (DoS guard)

    # --- Session / cookie hardening ----------------------------------------
    SESSION_COOKIE_NAME = "ag_session"
    SESSION_COOKIE_HTTPONLY = True      # JavaScript cannot read the cookie
    SESSION_COOKIE_SAMESITE = "Lax"     # blocks most CSRF via cross-site POSTs
    # Set COOKIE_SECURE=1 in production (HTTPS only). Defaults to 1 so a
    # production deploy is secure-by-default; the demo runner sets it to 0
    # because it is served over plain HTTP inside the sandbox.
    SESSION_COOKIE_SECURE = _env_bool("COOKIE_SECURE", default=True)
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)

    # --- Session policy -----------------------------------------------------
    IDLE_TIMEOUT_MINUTES = 30     # logout after inactivity
    ABSOLUTE_TIMEOUT_HOURS = 8    # hard cap, even if active
    REMEMBER_ME_HOURS = 0         # not offered: reduces stolen-cookie risk

    # --- Brute force / lockout ---------------------------------------------
    MAX_LOGIN_ATTEMPTS = 5
    LOCKOUT_MINUTES = 15

    # --- Password policy ----------------------------------------------------
    PASSWORD_MIN_LENGTH = 10
    PASSWORD_MAX_LENGTH = 128
    PASSWORD_CLASSES_REQUIRED = 3   # of: lower, upper, digit, symbol
    PASSWORD_HASH_METHOD = "scrypt"  # scrypt > pbkdf2, memory-hard

    # --- Demo / preview mode -----------------------------------------------
    # PREVIEW_MODE=1 relaxes ONLY the framing headers so the app can be shown
    # inside the Arena preview iframe. Leave it 0 in real deployments.
    PREVIEW_MODE = _env_bool("PREVIEW_MODE", default=False)
    ENV_LABEL = os.environ.get("ENV_LABEL", "development")
