"""Security primitives: passwords, validation, CSRF, RBAC, audit, lockout.

This module is the "security section" of the project in code form. Each
function carries a short comment explaining the attack it defends against.
"""
import hashlib
import hmac
import re
import secrets
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import abort, flash, g, redirect, request, session, url_for
from markupsafe import Markup
from werkzeug.security import check_password_hash, generate_password_hash

from config import Config
from db import now

# ---------------------------------------------------------------------------
# Role-based access control (RBAC)
# ---------------------------------------------------------------------------
# Permissions are data, not scattered `if role == 'admin'` checks in views.
PERMISSIONS = {
    "user": {
        "dashboard.view",
        "profile.view",
        "profile.edit",
        "session.manage",       # see / revoke own sessions
    },
    "manager": {
        "dashboard.view",
        "profile.view",
        "profile.edit",
        "session.manage",
        "user.view",
        "user.create",          # may create 'user' accounts only
        "user.deactivate",      # may deactivate plain users only
        "audit.view",
    },
    "admin": {
        "dashboard.view",
        "profile.view",
        "profile.edit",
        "session.manage",
        "user.view",
        "user.create",
        "user.edit",
        "user.deactivate",
        "user.delete",
        "user.role.change",
        "audit.view",
        "security.view",
        "session.revoke.any",
    },
}

ROLE_LABELS = {"admin": "Administrator", "manager": "Manager", "user": "Standard user"}
ROLE_ORDER = {"admin": 0, "manager": 1, "user": 2}


def user_permissions(user) -> set:
    if not user:
        return set()
    return PERMISSIONS.get(user["role"], set())


def can(permission: str) -> bool:
    """Permission check used by templates and views."""
    user = getattr(g, "user", None)
    if not user or not user["is_active"]:
        return False
    return permission in user_permissions(user)


def rank(role: str) -> int:
    return ROLE_ORDER.get(role, 99)


def can_manage(target_row) -> bool:
    """Object-level (row-level) authorisation.

    A permission is necessary but not sufficient: a manager holds
    `user.deactivate` yet must never be able to act on an administrator, and
    nobody may lock themselves out of their own account.
    """
    me = getattr(g, "user", None)
    if not me or not target_row:
        return False
    if target_row["id"] == me["id"]:
        return False                      # no self-sabotage
    if me["role"] == "admin":
        return True
    if rank(me["role"]) >= rank(target_row["role"]):
        return False                      # only manage roles below your own
    return True


# ---------------------------------------------------------------------------
# Password hashing
# ---------------------------------------------------------------------------
def hash_password(raw: str) -> str:
    """scrypt: memory-hard, salted per-password, constant-time verified.

    Plaintext passwords are never stored, logged, or written to the audit log.
    """
    return generate_password_hash(raw, method=Config.PASSWORD_HASH_METHOD)


def verify_password(password_hash: str, raw: str) -> bool:
    return check_password_hash(password_hash, raw)


# A known hash used to burn the same CPU time when an email does not exist,
# so response timing does not reveal which accounts are registered.
_DUMMY_HASH = generate_password_hash("this-password-is-never-used", method=Config.PASSWORD_HASH_METHOD)


def burn_time():
    check_password_hash(_DUMMY_HASH, "wrong-password")


COMMON_PASSWORDS = {
    "password", "password1", "password123", "12345678", "123456789", "1234567890",
    "qwerty123", "qwertyuiop", "letmein123", "iloveyou", "admin123", "administrator",
    "welcome123", "abc123456", "monkey123", "dragon123", "football1", "passw0rd",
    "changeme", "changeme123", "sunshine1", "princess1", "trustno1", "accessguard",
}


def password_problems(password: str, email: str = "", full_name: str = "") -> list:
    """Policy check. Returns a list of human-readable problems (empty = OK)."""
    problems = []
    if len(password) < Config.PASSWORD_MIN_LENGTH:
        problems.append(f"Use at least {Config.PASSWORD_MIN_LENGTH} characters.")
    if len(password) > Config.PASSWORD_MAX_LENGTH:
        problems.append(f"Use at most {Config.PASSWORD_MAX_LENGTH} characters.")
    if password.lower() in COMMON_PASSWORDS:
        problems.append("That password is on the list of most-used passwords.")

    classes = sum(bool(re.search(p, password)) for p in (r"[a-z]", r"[A-Z]", r"\d", r"[^A-Za-z0-9]"))
    if classes < Config.PASSWORD_CLASSES_REQUIRED:
        problems.append(
            f"Mix at least {Config.PASSWORD_CLASSES_REQUIRED} of: lowercase, uppercase, number, symbol."
        )
    if re.search(r"(.)\1{3,}", password):
        problems.append("Avoid repeating the same character 4+ times.")

    local = (email.split("@")[0] if email else "").lower()
    if local and len(local) > 2 and local in password.lower():
        problems.append("Do not include your email address in the password.")
    first = (full_name.split()[0] if full_name else "").lower()
    if first and len(first) > 2 and first in password.lower():
        problems.append("Do not include your name in the password.")
    return problems


# ---------------------------------------------------------------------------
# Input validation / sanitisation
# ---------------------------------------------------------------------------
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
NAME_RE = re.compile(r"^[A-Za-z\u00C0-\u024F' .\-]{2,80}$")
PHONE_RE = re.compile(r"^\+?[0-9 ()]{7,20}$")
# Control characters are stripped: they enable log injection and header tricks.
CONTROL_CHARS_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def clean_text(value: str, max_len: int = 200) -> str:
    value = CONTROL_CHARS_RE.sub("", (value or "").strip())
    return value[:max_len]


def validate_registration(form) -> tuple[dict, list]:
    errors = []
    email = clean_text(form.get("email", ""), 120).lower()
    full_name = clean_text(form.get("full_name", ""), 80)
    department = clean_text(form.get("department", ""), 60)
    phone = clean_text(form.get("phone", ""), 20)
    password = form.get("password", "")
    confirm = form.get("confirm_password", "")

    if not EMAIL_RE.match(email) or len(email) > 120:
        errors.append("Enter a valid email address (e.g. name@company.com).")
    if not NAME_RE.match(full_name):
        errors.append("Full name must be 2-80 letters, spaces, apostrophes, hyphens or dots.")
    if phone and not PHONE_RE.match(phone):
        errors.append("Phone number may only contain digits, spaces, +, ( and ).")
    if password != confirm:
        errors.append("Passwords do not match.")
    errors.extend(password_problems(password, email, full_name))

    # Honeypot: bots fill hidden fields, humans leave them empty.
    if form.get("website", ""):
        errors.append("Registration rejected.")

    return (
        {"email": email, "full_name": full_name, "department": department,
         "phone": phone, "password": password},
        errors,
    )


# ---------------------------------------------------------------------------
# CSRF protection (synchroniser token pattern)
# ---------------------------------------------------------------------------
def csrf_token() -> str:
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return session["csrf_token"]


def csrf_field() -> Markup:
    """Hidden input to drop into every state-changing form."""
    return Markup(f'<input type="hidden" name="csrf_token" value="{csrf_token()}">')


def verify_csrf() -> bool:
    sent = request.form.get("csrf_token", "")
    expected = session.get("csrf_token", "")
    return bool(sent) and bool(expected) and hmac.compare_digest(sent, expected)


# ---------------------------------------------------------------------------
# Session tokens
# ---------------------------------------------------------------------------
def new_session_token() -> tuple[str, str]:
    """Return (raw token for the cookie, SHA-256 hash for the database).

    Storing only the hash means a database leak cannot be replayed to hijack
    live sessions.
    """
    raw = secrets.token_urlsafe(32)
    return raw, hashlib.sha256(raw.encode()).hexdigest()


def sha256(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


# ---------------------------------------------------------------------------
# Audit logging
# ---------------------------------------------------------------------------
def audit(action: str, target: str = "", detail: str = "", severity: str = "info",
          actor=None, db=None):
    """Append-only record of security-relevant events (accountability).

    `detail` is written as plain text by the views and escaped on render, so a
    payload typed into a form can never become markup in the audit table.
    """
    from flask import current_app
    if db is None:
        from app import get_db
        db = get_db()
    me = actor if actor is not None else getattr(g, "user", None)
    db.execute(
        """INSERT INTO audit_log
             (created_at, actor_id, actor_email, action, target, detail, ip, severity)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (now(),
         me["id"] if me else None,
         me["email"] if me else "anonymous",
         action, clean_text(target, 120), clean_text(detail, 300),
         client_ip(), severity),
    )
    try:
        db.commit()
    except Exception:  # pragma: no cover - commit already applied by caller
        pass


def client_ip() -> str:
    # Behind nginx we read X-Forwarded-For only because the proxy is trusted;
    # in production configure it with `proxy_set_header X-Forwarded-For`.
    forwarded = request.headers.get("X-Forwarded-For", "")
    if forwarded:
        return forwarded.split(",")[0].strip()[:45]
    return (request.remote_addr or "unknown")[:45]


# ---------------------------------------------------------------------------
# Decorators (route protection)
# ---------------------------------------------------------------------------
def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if not getattr(g, "user", None):
            flash("Please sign in to continue.", "warning")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapper


def require_permission(permission: str):
    """Coarse-grained RBAC gate. Returns 403 (and audits the attempt)."""
    def decorator(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            if not getattr(g, "user", None):
                flash("Please sign in to continue.", "warning")
                return redirect(url_for("login", next=request.path))
            if not can(permission):
                audit("rbac.access_denied", target=request.path,
                      detail=f"Missing permission: {permission}", severity="critical")
                abort(403)
            return view(*args, **kwargs)
        return wrapper
    return decorator


def safe_next(target: str | None) -> str:
    """Only allow same-site relative redirects (blocks open-redirect abuse)."""
    if not target or not target.startswith("/") or target.startswith("//"):
        return url_for("dashboard")
    return target


# ---------------------------------------------------------------------------
# Lockout helpers
# ---------------------------------------------------------------------------
def parse_ts(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def lockout_remaining(row) -> int:
    """Seconds until the account unlocks (0 = not locked)."""
    until = parse_ts(row["locked_until"])
    if not until:
        return 0
    delta = (until - datetime.now(timezone.utc)).total_seconds()
    return max(0, int(delta))
