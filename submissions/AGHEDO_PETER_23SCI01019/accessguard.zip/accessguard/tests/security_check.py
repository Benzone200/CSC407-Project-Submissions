"""AccessGuard security test suite.

Proves the controls work by attacking the app with a Flask test client.
Run:  python3 tests/security_check.py

Each check prints PASS/FAIL. Exit code is 0 only if every check passes.
A throwaway database is used, so your real demo data is untouched.
"""
import os
import re
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

TMP_DB = Path(tempfile.mkdtemp(prefix="accessguard-test-")) / "test.db"
os.environ["DATABASE_PATH"] = str(TMP_DB)
os.environ["COOKIE_SECURE"] = "0"
os.environ["PREVIEW_MODE"] = "0"
os.environ["SECRET_KEY"] = "test-key-not-for-production"

import app as appmod            # noqa: E402
from db import seed             # noqa: E402

appmod.create_tables()
seed(appmod.app.config["DATABASE"])

ADMIN = ("admin@accessguard.test", "Admin!Passw0rd123")
MANAGER = ("manager@accessguard.test", "Manager!Passw0rd123")
USER = ("user@accessguard.test", "User!Passw0rd123")

results = []


def check(name, condition, detail=""):
    results.append((bool(condition), name, detail))
    print(("PASS  " if condition else "FAIL  ") + name + (f"  [{detail}]" if detail and not condition else ""))


def csrf(client, path):
    html = client.get(path).get_data(as_text=True)
    m = re.search(r'name="csrf_token" value="([^"]+)"', html)
    return m.group(1) if m else None


def login(client, email, password, expect_ok=True):
    token = csrf(client, "/login")
    r = client.post("/login", data={"email": email, "password": password, "csrf_token": token},
                    follow_redirects=False)
    ok = r.status_code == 302 and "/dashboard" in (r.headers.get("Location") or "")
    if expect_ok and not ok:
        pass
    return ok


def main():
    # ---------------------------------------------------------------- 1. auth
    c = appmod.app.test_client()
    check("Anonymous visitor is redirected to /login", 
          c.get("/dashboard").status_code == 302)

    check("Valid credentials sign the user in", login(c, *ADMIN))
    check("Signed-in user reaches the dashboard", c.get("/dashboard").status_code == 200)
    check("Password hash is never rendered in HTML",
          "scrypt:" not in c.get("/profile").get_data(as_text=True))

    # ---------------------------------------------------------------- 2. SQLi
    c2 = appmod.app.test_client()
    token = csrf(c2, "/login")
    r = c2.post("/login", data={"email": "' OR 1=1 --", "password": "anything",
                                "csrf_token": token})
    body = r.get_data(as_text=True)
    still_anonymous = c2.get("/dashboard").status_code == 302
    check("SQL injection in the email field cannot authenticate",
          r.status_code == 200 and "Invalid email or password" in body and still_anonymous)

    token = csrf(c2, "/login")
    r = c2.post("/login", data={"email": "admin@accessguard.test' --", "password": "x",
                                "csrf_token": token})
    check("Comment-truncation SQL injection is rejected",
          "Invalid email or password" in r.get_data(as_text=True))

    # authenticated search injection
    token = csrf(c, "/login")
    r = c.get("/users?q=%27+OR+%271%27%3D%271&role=user")
    body = r.get_data(as_text=True)
    check("SQL injection in the search box returns no rows and no error",
          r.status_code == 200 and "Server error" not in body and "no users match" in body.lower())

    # ---------------------------------------------------------------- 3. XSS
    cu = appmod.app.test_client()
    login(cu, *USER)
    payload = "< script >alert('xss')</script>".replace(" ", "")
    token = csrf(cu, "/profile")
    cu.post("/profile", data={"full_name": "Fatima Yusuf", "department": "<img src=x onerror=alert(1)>",
                              "phone": "", "bio": payload, "csrf_token": token})
    body = cu.get("/profile").get_data(as_text=True)
    check("Stored XSS payload in bio is rendered escaped",
          "<script>alert('xss')</script>" not in body and "&lt;script&gt;" in body)
    check("Stored XSS payload in department is escaped",
          "<img src=x onerror=alert(1)>" not in body and "&lt;img" in body)

    token = csrf(c, "/users?q=%3Cscript%3Ealert(1)%3C/script%3E")
    body = c.get("/users?q=%3Cscript%3Ealert(1)%3C/script%3E").get_data(as_text=True)
    check("Reflected XSS in the search box is escaped",
          "<script>alert(1)</script>" not in body)

    # ---------------------------------------------------------------- 4. CSRF
    c3 = appmod.app.test_client()
    login(c3, *USER)
    r = c3.post("/profile", data={"full_name": "Hacker"})   # no token
    check("POST without a CSRF token is refused with 400", r.status_code == 400)
    r = c3.post("/profile", data={"full_name": "Hacker", "csrf_token": "forged-value"})
    check("POST with a forged CSRF token is refused with 400", r.status_code == 400)

    # ---------------------------------------------------------------- 5. RBAC
    check("Standard user is blocked from /users (403)", cu.get("/users").status_code == 403)
    check("Standard user is blocked from /audit (403)", cu.get("/audit").status_code == 403)
    check("Standard user is blocked from /security (403)", cu.get("/security").status_code == 403)
    check("Standard user cannot open the admin API-style route",
          cu.post("/users/1/role", data={"role": "admin", "csrf_token": csrf(cu, "/profile")}).status_code == 403)

    cm = appmod.app.test_client()
    login(cm, *MANAGER)
    check("Manager can view the user directory", cm.get("/users").status_code == 200)
    r = cm.post("/users/1/role", data={"role": "user", "csrf_token": csrf(cm, "/users")})
    check("Manager cannot demote an administrator (object-level check, 403)", r.status_code == 403)
    r = cm.post("/users/1/status", data={"csrf_token": csrf(cm, "/users")})
    check("Manager cannot deactivate an administrator (403)", r.status_code == 403)

    token = csrf(c, "/users")
    r = c.post("/users/1/status", data={"csrf_token": token})
    conn = appmod.connect(appmod.app.config["DATABASE"])
    admin_active = conn.execute("SELECT is_active FROM users WHERE id = 1").fetchone()["is_active"]
    conn.close()
    check("Administrator cannot deactivate their own account (403, account unchanged)",
          r.status_code == 403 and admin_active == 1, detail=f"status={r.status_code} active={admin_active}")

    # ---------------------------------------------------------------- 6. lockout
    appmod._IP_HITS.clear()
    cl = appmod.app.test_client()
    for _ in range(appmod.app.config["MAX_LOGIN_ATTEMPTS"]):
        token = csrf(cl, "/login")
        cl.post("/login", data={"email": USER[0], "password": "WrongPass!123",
                                "csrf_token": token})
    token = csrf(cl, "/login")
    r = cl.post("/login", data={"email": USER[0], "password": USER[1], "csrf_token": token})
    body = r.get_data(as_text=True).lower()
    check("Account locks after repeated failures (correct password also refused)",
          "locked" in body and "invalid email or password" not in body)
    conn = appmod.connect(appmod.app.config["DATABASE"])
    row = conn.execute("SELECT failed_attempts, locked_until FROM users WHERE email = ?",
                       (USER[0],)).fetchone()
    check("Lockout is persisted with failed-attempt counter",
          row["locked_until"] and row["failed_attempts"] >= appmod.app.config["MAX_LOGIN_ATTEMPTS"])
    conn.close()

    # admin unlocks
    token = csrf(c, "/users")
    uid = 3
    c.post(f"/users/{uid}/unlock", data={"csrf_token": token})
    conn = appmod.connect(appmod.app.config["DATABASE"])
    row = conn.execute("SELECT locked_until FROM users WHERE id = ?", (uid,)).fetchone()
    conn.close()
    check("Administrator can clear a lockout", row["locked_until"] is None)

    # ---------------------------------------------------------------- 7. enumeration
    appmod._IP_HITS.clear()
    ce = appmod.app.test_client()
    token = csrf(ce, "/login")
    a = ce.post("/login", data={"email": "nobody@example.com", "password": "Whatever!123",
                                "csrf_token": token}).get_data(as_text=True)
    token = csrf(ce, "/login")
    b = ce.post("/login", data={"email": "tunde.adeyemi@accessguard.test",
                                "password": "Whatever!123", "csrf_token": token}).get_data(as_text=True)
    check("Unknown email and wrong password give the same message",
          "Invalid email or password" in a and "Invalid email or password" in b
          and "unknown email" not in a.lower() and "not found" not in a.lower(),
          detail=f"A={re.findall(r'flash-error[^>]*>([^<]*)', a)[:1]} B={re.findall(r'flash-error[^>]*>([^<]*)', b)[:1]}")

    # ---------------------------------------------------------------- 8. password policy
    cp = appmod.app.test_client()
    token = csrf(cp, "/register")
    r = cp.post("/register", data={"email": "weak@example.com", "full_name": "Weak Person",
                                   "password": "password123", "confirm_password": "password123",
                                   "csrf_token": token})
    body = r.get_data(as_text=True)
    check("Weak password is rejected at registration",
          "most-used passwords" in body or "Mix at least" in body)

    token = csrf(cp, "/register")
    r = cp.post("/register", data={"email": "mismatch@example.com", "full_name": "Mismatch Person",
                                   "password": "Str0ng!Passphrase", "confirm_password": "Different!1",
                                   "csrf_token": token})
    check("Mismatched confirmation is rejected", "do not match" in r.get_data(as_text=True))

    token = csrf(cp, "/register")
    r = cp.post("/register", data={"email": "good@example.com", "full_name": "Good Person",
                                   "password": "Str0ng!Passphrase", "confirm_password": "Str0ng!Passphrase",
                                   "csrf_token": token})
    check("A policy-compliant password is accepted (redirect to login)", r.status_code == 302,
          detail=f"status={r.status_code} {re.findall(r'flash[^>]*>([^<]*)', r.get_data(as_text=True))[:3]}")

    token = csrf(cp, "/register")
    r = cp.post("/register", data={"email": "bot@example.com", "full_name": "Bot Person",
                                   "password": "Str0ng!Passphrase", "confirm_password": "Str0ng!Passphrase",
                                   "website": "http://spam.example", "csrf_token": token})
    check("Honeypot field blocks automated registrations",
          "rejected" in r.get_data(as_text=True).lower())

    # ---------------------------------------------------------------- 9. sessions
    s1 = appmod.app.test_client()
    s2 = appmod.app.test_client()
    login(s1, "tunde.adeyemi@accessguard.test", "User!Passw0rd123")
    login(s2, "tunde.adeyemi@accessguard.test", "User!Passw0rd123")
    r1 = s1.get("/dashboard"); r2 = s2.get("/dashboard")
    check("Two independent sessions both work",
          r1.status_code == 200 and r2.status_code == 200,
          detail=f"s1={r1.status_code} s2={r2.status_code}")

    token = csrf(s1, "/profile")
    s1.post("/profile/password", data={"current_password": "User!Passw0rd123",
                                       "new_password": "N3w!Passphrase-2026",
                                       "confirm_password": "N3w!Passphrase-2026",
                                       "csrf_token": token})
    s2.get("/dashboard")
    check("Password change revokes the other device's session",
          s2.get("/dashboard").status_code == 302)
    check("The device that changed the password stays signed in",
          s1.get("/dashboard").status_code == 200)

    s3 = appmod.app.test_client()
    login(s3, "grace.eze@accessguard.test", "User!Passw0rd123")
    token = csrf(s3, "/dashboard")
    s3.post("/logout", data={"csrf_token": token})
    check("Logout invalidates the server-side session",
          s3.get("/dashboard").status_code == 302)

    # ---------------------------------------------------------------- 10. redirects
    co = appmod.app.test_client()
    token = csrf(co, "/login")
    r = co.post("/login?next=//evil.example/steal",
                data={"email": ADMIN[0], "password": ADMIN[1], "csrf_token": token,
                      "next": "//evil.example/steal"})
    check("Open redirect via ?next= is neutralised",
          "evil.example" not in (r.headers.get("Location") or ""))

    # ---------------------------------------------------------------- 11. headers
    token = csrf(appmod.app.test_client(), "/login")
    r = appmod.app.test_client().get("/login")
    h = r.headers
    check("Content-Security-Policy header is set", "default-src 'self'" in h.get("Content-Security-Policy", ""))
    check("CSP forbids inline script", "script-src 'self'" in h.get("Content-Security-Policy", ""))
    check("X-Content-Type-Options: nosniff is set", h.get("X-Content-Type-Options") == "nosniff")
    check("X-Frame-Options blocks framing in production mode", h.get("X-Frame-Options") == "SAMEORIGIN")
    check("Referrer-Policy is set", bool(h.get("Referrer-Policy")))

    r = appmod.app.test_client()
    token = csrf(r, "/login")
    r.post("/login", data={"email": ADMIN[0], "password": ADMIN[1], "csrf_token": token})
    resp = r.get("/dashboard")
    dash_login = appmod.app.test_client()
    t = csrf(dash_login, "/login")
    login_resp = dash_login.post("/login", data={"email": ADMIN[0], "password": ADMIN[1], "csrf_token": t})
    sc = login_resp.headers.get("Set-Cookie", "")
    check("Session cookie is HttpOnly and SameSite=Lax",
          "HttpOnly" in sc and "SameSite=Lax" in sc, detail=sc[:120])
    check("Authenticated responses are not cached", "no-store" in resp.headers.get("Cache-Control", ""))

    # ---------------------------------------------------------------- 12. audit
    conn = appmod.connect(appmod.app.config["DATABASE"])
    actions = {r["action"] for r in conn.execute("SELECT action FROM audit_log")}
    conn.close()
    for expected in ("auth.login_success", "auth.login_failed", "auth.account_locked",
                     "rbac.role_changed", "auth.password_changed", "auth.register"):
        check(f"Audit log records {expected}", expected in actions)

    # ---------------------------------------------------------------- summary
    passed = sum(1 for ok, _, _ in results if ok)
    failed = [(n, d) for ok, n, d in results if not ok]
    print("\n" + "=" * 66)
    print(f"{passed}/{len(results)} checks passed")
    if failed:
        print("Failures:")
        for n, d in failed:
            print("  -", n, d)
    print("=" * 66)
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
