/* AccessGuard client script.
   Deliberately tiny: the server owns every security decision. Nothing here is
   required for the app to work, so the CSP can stay strict (no inline JS).
   Progressive enhancement only: mobile nav, password reveal, strength hint,
   confirm-before-destructive-action, dialogs. */
(function () {
  'use strict';

  /* ---- mobile navigation ------------------------------------------------ */
  var toggle = document.querySelector('[data-nav-toggle]');
  var nav = document.getElementById('primary-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  /* ---- show / hide password -------------------------------------------- */
  document.querySelectorAll('[data-reveal]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = btn.parentElement.querySelector('[data-password-input]');
      if (!input) return;
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.textContent = show ? 'Hide' : 'Show';
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });
  });

  /* ---- password strength meter (advisory only; server re-validates) ----- */
  var COMMON = ['password', 'qwerty', 'letmein', 'welcome', 'admin', 'iloveyou', '123456'];
  document.querySelectorAll('input[data-strength-for]').forEach(function (input) {
    var meter = document.getElementById(input.getAttribute('data-strength-for'));
    if (!meter) return;
    var label = meter.querySelector('[data-strength-label]');
    input.addEventListener('input', function () {
      var v = input.value || '';
      var classes = 0;
      if (/[a-z]/.test(v)) classes++;
      if (/[A-Z]/.test(v)) classes++;
      if (/[0-9]/.test(v)) classes++;
      if (/[^A-Za-z0-9]/.test(v)) classes++;

      var score = 0;
      if (v.length >= 8) score++;
      if (v.length >= 10 && classes >= 2) score++;
      if (v.length >= 12 && classes >= 3) score++;
      if (v.length >= 14 && classes >= 3 && !COMMON.some(function (c) { return v.toLowerCase().indexOf(c) !== -1; })) score++;
      if (!v) score = 0;

      meter.setAttribute('data-score', String(score));
      if (label) {
        label.textContent = ['Strength', 'Weak', 'Fair', 'Good', 'Strong'][score] || 'Strength';
      }
    });
  });

  /* ---- confirmation before destructive submits -------------------------- */
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!window.confirm(form.getAttribute('data-confirm'))) {
        event.preventDefault();
      }
    });
  });

  /* ---- native <dialog> handling ---------------------------------------- */
  document.querySelectorAll('[data-dialog-open]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var dlg = document.getElementById(btn.getAttribute('data-dialog-open'));
      if (dlg && typeof dlg.showModal === 'function') dlg.showModal();
    });
  });
  document.querySelectorAll('[data-dialog-close]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var dlg = btn.closest('dialog');
      if (dlg) dlg.close();
    });
  });
  document.querySelectorAll('dialog').forEach(function (dlg) {
    dlg.addEventListener('click', function (event) {
      if (event.target === dlg) dlg.close();  /* click on backdrop */
    });
  });

  /* ---- auto-dismiss success flashes ------------------------------------ */
  document.querySelectorAll('.flash-success').forEach(function (el) {
    setTimeout(function () {
      el.style.transition = 'opacity .4s';
      el.style.opacity = '0';
      setTimeout(function () { el.remove(); }, 450);
    }, 5000);
  });
}());
