"""Capture screenshots of the running app for the report / README."""
import asyncio
import pathlib
import sys

from playwright.async_api import async_playwright

BASE = "http://127.0.0.1:8000"
OUT = pathlib.Path("/home/user/accessguard/docs/screens")
OUT.mkdir(parents=True, exist_ok=True)


async def shot(page, name, full=True):
    await page.wait_for_timeout(350)
    await page.screenshot(path=str(OUT / name), full_page=full)
    print("saved", name)


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        ctx = await browser.new_context(viewport={"width": 1280, "height": 900},
                                        device_scale_factor=2)
        page = await ctx.new_page()

        await page.goto(BASE + "/")
        await shot(page, "01-landing.png")

        await page.goto(BASE + "/login")
        await shot(page, "02-login.png", full=False)

        await page.fill("#email", "admin@accessguard.test")
        await page.fill("#password", "Admin!Passw0rd123")
        await page.click("button[type=submit]")
        await page.wait_for_url("**/dashboard")
        await shot(page, "03-dashboard-admin.png")

        await page.goto(BASE + "/users")
        await shot(page, "04-users.png")

        await page.goto(BASE + "/users?q=user&role=user")
        await shot(page, "05-users-filtered.png")

        await page.goto(BASE + "/profile")
        await shot(page, "06-profile.png")

        await page.goto(BASE + "/audit")
        await shot(page, "07-audit.png")

        await page.goto(BASE + "/security")
        await shot(page, "08-security.png")

        await page.goto(BASE + "/users/4")
        await shot(page, "09-user-detail.png")

        # mobile view of the directory
        mob = await browser.new_context(viewport={"width": 390, "height": 844},
                                        device_scale_factor=2, is_mobile=True,
                                        has_touch=True)
        mpage = await mob.new_page()
        await mpage.goto(BASE + "/login")
        await mpage.fill("#email", "manager@accessguard.test")
        await mpage.fill("#password", "Manager!Passw0rd123")
        await mpage.click("button[type=submit]")
        await mpage.wait_for_url("**/dashboard")
        await shot(mpage, "10-mobile-dashboard.png")
        await mpage.goto(BASE + "/users")
        await shot(mpage, "11-mobile-users.png")

        # standard-user view: nav is smaller, no admin links
        uctx = await browser.new_context(viewport={"width": 1280, "height": 900},
                                         device_scale_factor=2)
        upage = await uctx.new_page()
        await upage.goto(BASE + "/login")
        await upage.fill("#email", "user@accessguard.test")
        await upage.fill("#password", "User!Passw0rd123")
        await upage.click("button[type=submit]")
        await upage.wait_for_url("**/dashboard")
        await shot(upage, "12-dashboard-user.png")
        r = await upage.goto(BASE + "/users")
        print("standard user /users ->", r.status)
        await shot(upage, "13-access-denied.png", full=False)

        # registration page with validation errors (fresh, signed-out context)
        await ctx.clear_cookies()
        await page.goto(BASE + "/register")
        await page.fill("#full_name", "New Person")
        await page.fill("#email", "new.person@example.com")
        await page.fill("#password", "password123")
        await page.fill("#confirm_password", "password123")
        await page.click("button[type=submit]")
        await shot(page, "14-register-validation.png")

        await browser.close()


asyncio.run(main())
