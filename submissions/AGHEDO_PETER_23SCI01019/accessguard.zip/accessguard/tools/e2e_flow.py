"""Browser end-to-end walkthrough of the main user journeys.

Requires the app to be running on http://127.0.0.1:8000 (see run.sh).
Run:  python3 tools/e2e_flow.py
"""
import asyncio
import sys

from playwright.async_api import async_playwright

BASE = "http://127.0.0.1:8000"
steps = []


def record(name, ok, extra=""):
    steps.append((name, ok))
    print(("PASS  " if ok else "FAIL  ") + name + (f"  [{extra}]" if extra and not ok else ""))


async def flash_text(page):
    el = await page.query_selector(".flash")
    return (await el.inner_text()).strip() if el else ""


async def sign_in(page, email, password):
    await page.goto(BASE + "/login")
    await page.fill("#email", email)
    await page.fill("#password", password)
    await page.click("button[type=submit]")
    await page.wait_for_url("**/dashboard")


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        ctx = await browser.new_context(viewport={"width": 1280, "height": 900})
        page = await ctx.new_page()
        page.on("dialog", lambda d: asyncio.ensure_future(d.accept()))

        # ---- administrator: create -> promote -> deactivate -> delete -------
        await sign_in(page, "admin@accessguard.test", "Admin!Passw0rd123")
        record("Admin signs in and lands on the dashboard", "/dashboard" in page.url)

        await page.goto(BASE + "/users")
        await page.click('[data-dialog-open="add-user"]')
        await page.fill("#nu-name", "Test Person")
        await page.fill("#nu-email", "test.person@example.com")
        await page.fill("#nu-dept", "Quality")
        await page.select_option("#nu-role", "user")
        await page.fill("#nu-password", "T3st!Passphrase")
        await page.click('#add-user button[type="submit"]')
        await page.wait_for_load_state()
        record("Admin creates a user from the dialog",
               "created" in (await flash_text(page)).lower())

        await page.fill("#q", "Test Person")
        await page.click(".filters button[type=submit]")
        await page.wait_for_load_state()
        rows = await page.query_selector_all(".table-users tbody tr")
        record("New user appears in the search results", len(rows) == 1)

        await page.select_option(".table-users tbody tr select[name=role]", "manager")
        await page.click(".table-users tbody tr button[type=submit]")
        await page.wait_for_load_state()
        record("Admin promotes the user to Manager",
               "manager" in (await flash_text(page)).lower())

        await page.goto(BASE + "/users?q=test.person")
        await page.click('button:has-text("Deactivate")')
        await page.wait_for_load_state()
        record("Admin deactivates the account",
               "deactivated" in (await flash_text(page)).lower())

        await page.goto(BASE + "/users?q=test.person")
        await page.click('button:has-text("Delete")')
        await page.wait_for_load_state()
        record("Delete (with confirmation) removes the account",
               "deleted" in (await flash_text(page)).lower())

        # ---- new registration -> standard user -----------------------------
        ctx2 = await browser.new_context(viewport={"width": 1280, "height": 900})
        p2 = await ctx2.new_page()
        await p2.goto(BASE + "/register")
        await p2.fill("#full_name", "Ngozi Adeleke")
        await p2.fill("#email", "ngozi.adeleke@example.com")
        await p2.fill("#department", "Legal")
        await p2.fill("#password", "Corr3ct!HorseBattery")
        await p2.fill("#confirm_password", "Corr3ct!HorseBattery")
        await p2.click("button[type=submit]")
        await p2.wait_for_url("**/login*")
        record("Self-registration creates an account and redirects to sign-in",
               "created" in (await flash_text(p2)).lower())

        await sign_in(p2, "ngozi.adeleke@example.com", "Corr3ct!HorseBattery")
        record("New user can sign in", "/dashboard" in p2.url)
        nav = await p2.inner_text("#primary-nav")
        record("Standard user's navigation hides admin links",
               "Users" not in nav and "Audit log" not in nav and "Security" not in nav,
               extra=nav.replace("\n", " | "))

        await p2.goto(BASE + "/users")
        record("Standard user is refused the directory (403 page)",
               "403" in await p2.inner_text(".error-code"))

        # ---- profile edit + password change -------------------------------
        await p2.goto(BASE + "/profile")
        await p2.fill("#bio", "Paralegal, Lagos office.")
        await p2.click('form[action="/profile"] button[type=submit]')
        await p2.wait_for_load_state()
        record("Profile update is saved", "updated" in (await flash_text(p2)).lower())

        await p2.fill("#current_password", "Corr3ct!HorseBattery")
        await p2.fill("#new_password", "Ev3n!B3tterPassphrase")
        await p2.fill("#confirm_password", "Ev3n!B3tterPassphrase")
        await p2.click('form[action="/profile/password"] button[type=submit]')
        await p2.wait_for_load_state()
        record("Password change is accepted",
               "password changed" in (await flash_text(p2)).lower())

        # ---- sign out -----------------------------------------------------
        await p2.click('form[action="/logout"] button')
        await p2.wait_for_url("**/login*")
        await p2.goto(BASE + "/dashboard")
        record("After sign-out the session is dead",
               "/login" in p2.url)

        await browser.close()

    failed = [n for n, ok in steps if not ok]
    print("\n" + "=" * 60)
    print(f"{len(steps) - len(failed)}/{len(steps)} UI steps passed")
    if failed:
        print("Failed:", ", ".join(failed))
    print("=" * 60)
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
