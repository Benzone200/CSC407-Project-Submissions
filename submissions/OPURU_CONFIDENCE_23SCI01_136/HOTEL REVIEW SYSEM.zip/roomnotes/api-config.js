'use strict';

// Set this to your deployed Apps Script web app URL. Use 'PASTE' for browser-only demo mode.
window.ROOMNOTES_API_URL = 'https://script.google.com/macros/s/AKfycbwbmI1LWrB7mwUf-uJ8hEuiUy145w1uvNo1QnqSMEMpIkJgtb_ZwXpVf7E3Gobs20wZ/exec';
