# Roomnotes – hotel review website

HTML + CSS + JavaScript frontend, Google Apps Script backend, Google Sheets database.

## 1. Open in VS Code (works immediately, in demo mode)
1. **File > Open Folder** and choose the `roomnotes` folder.
2. Install the **Live Server** extension, right-click `index.html`, choose **Open with Live Server**.
   (Or double-click `index.html`.)

In demo mode the sample hotels load and reviews are saved only in your browser.
The demo has 19 sample hotels: page 1 shows nine and page 2 shows the remaining ten. In Apps Script mode, rerun `setup` once after updating `Code.gs` to add the eleven extra sample hotels; it skips hotels that are already present.

## 2. Share reviews between visitors (Sheets + Apps Script)
1. Create a Google Sheet. Open **Extensions > Apps Script**.
2. Delete the default code and paste all of `Code.gs`. Change `SALT` to any long random text.
3. In the function dropdown pick **setup** and press **Run**. Approve the permissions.
   It creates the `hotels` and `reviews` tabs with sample data.
4. **Deploy > New deployment > Web app**. Execute as: **Me**. Who has access: **Anyone**. Copy the `/exec` URL.
5. Paste the URL into `ROOMNOTES_API_URL` in `api-config.js`. Reload the page: the "Demo mode" tag disappears.
6. If you edit `Code.gs` later: **Deploy > Manage deployments > edit > Version: New version**.

## Accounts
The **Log in** and **Sign up** links use the Apps Script API. Registration stores the account name, email, a unique salt, and a repeatedly hashed password in the `users` sheet; session-token hashes are stored in the `sessions` sheet. Running `setup` creates these tabs if they do not exist. Deploy a new Apps Script version after updating `Code.gs` so the account actions are available. In demo mode (when `API_URL` contains `PASTE`), demo accounts are stored only in that browser and are not shared between visitors.

These accounts currently provide sign-in/sign-out UI; they do not require a login to read or post reviews. For a production site, use a dedicated identity provider and add rate limiting, email verification, and account recovery.

To add a hotel, add a row to the `hotels` tab. Columns: id (no spaces), name, city, price, tags (comma separated),
blurb, scene (waves, skyline, mountain, savanna, palm, garden, arches or hills), hue (0 to 360, sets the colours).
Enter `price` as a whole-number amount in Nigerian naira (NGN); the site formats it with the ₦ symbol. Sample prices are estimates and should be adjusted to match each hotel's actual nightly rate.
If you already have a populated sample sheet, paste the updated `Code.gs` into Apps Script and run `updateSampleHotelPricesToNaira` once from the function dropdown; it updates only the built-in sample hotel rows, not your other hotels.

## 3. Put it online (optional)
Push the folder to GitHub, then Settings > Pages > Source: main branch.

## How it is protected
- All user text is inserted as text, never HTML (blocks XSS).
- The server re-checks every field (name, rating 1 to 5, review length), not just the browser.
- Text starting with = + - @ is prefixed with an apostrophe before it reaches the Sheet (blocks formula injection).
- Each browser has a secret key. The server stores only a salted hash of it, so only the author's browser can delete its review, and one browser can review a hotel once.
- Not covered: there are no accounts, so someone can clear their storage and post again. No rate limiting.
