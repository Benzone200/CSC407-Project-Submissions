'use strict';

const AUTH_API_URL = window.ROOMNOTES_API_URL;
const AUTH_DEMO = AUTH_API_URL.includes('PASTE');
const AUTH_KEY = 'roomnotes.auth.v1';
const ACCOUNTS_KEY = 'roomnotes.demo.accounts.v1';
const authForm = document.querySelector('#authForm');
const authError = document.querySelector('#authError');
const submitButton = authForm.querySelector('[type="submit"]');

function readAccounts() {
  try { return JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || '{}'); }
  catch (e) { return {}; }
}

function toHex(bytes) {
  return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function demoPasswordHash(password, salt) {
  if (!crypto.subtle) throw new Error('Demo accounts need a secure local server such as Live Server.');
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name:'PBKDF2', salt:new TextEncoder().encode(salt), iterations:120000, hash:'SHA-256' }, key, 256);
  return toHex(bits);
}

async function demoAuth(mode, values) {
  const accounts = readAccounts(), email = values.email.toLowerCase();
  if (mode === 'register') {
    if (accounts[email]) throw new Error('An account with this email already exists.');
    const salt = toHex(crypto.getRandomValues(new Uint8Array(16)));
    accounts[email] = { name:values.name, salt, hash:await demoPasswordHash(values.password, salt) };
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
  } else {
    const account = accounts[email];
    if (!account || await demoPasswordHash(values.password, account.salt) !== account.hash) throw new Error('Email or password is incorrect.');
    values.name = account.name;
  }
  return { token:'demo-' + crypto.randomUUID(), email, name:values.name, expires:Date.now() + 30 * 24 * 60 * 60 * 1000 };
}

async function requestAuth(mode, values) {
  if (AUTH_DEMO) return demoAuth(mode, values);
  const response = await fetch(AUTH_API_URL, {
    method:'POST',
    headers:{ 'Content-Type':'text/plain;charset=utf-8' },
    body:JSON.stringify({ action:mode, ...values })
  });
  const result = await response.json();
  if (!result.ok) throw new Error(result.error || 'Could not complete the request.');
  return result.data;
}

authForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  authError.textContent = '';
  const mode = authForm.dataset.mode;
  const values = {
    name:document.querySelector('#name')?.value.trim() || '',
    email:document.querySelector('#email').value.trim(),
    password:document.querySelector('#password').value
  };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
    authError.textContent = 'Enter a valid email address.';
    return;
  }
  if (mode === 'register') {
    const confirm = document.querySelector('#confirmPassword').value;
    if (values.name.length < 2) { authError.textContent = 'Your name must be at least 2 characters.'; return; }
    if (values.password.length < 10) { authError.textContent = 'Use a password with at least 10 characters.'; return; }
    if (values.password !== confirm) { authError.textContent = 'Your passwords do not match.'; return; }
  }
  submitButton.disabled = true;
  submitButton.textContent = mode === 'register' ? 'Creating account…' : 'Logging in…';
  try {
    const session = await requestAuth(mode, values);
    localStorage.setItem(AUTH_KEY, JSON.stringify(session));
    location.replace('./index.html');
  } catch (error) {
    authError.textContent = error.message || 'Something went wrong. Please try again.';
    submitButton.disabled = false;
    submitButton.textContent = mode === 'register' ? 'Create account' : 'Log in';
  }
});
