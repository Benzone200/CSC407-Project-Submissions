'use strict';

const API_URL = window.ROOMNOTES_API_URL;
const DEMO = API_URL.includes('PASTE');

// ---------- sample data (used in demo mode) ----------
const SEED_HOTELS = [
  { id:'lagoon-house',  name:'Lagoon House',   city:'Lagos',     price:125000, hue:190, scene:'waves',    tags:['Pool','Wi-Fi','Breakfast','Gym'],   blurb:'Waterfront rooms with balconies over the lagoon, a rooftop pool and a quiet business lounge.' },
  { id:'savanna-court', name:'Savanna Court',  city:'Abuja',     price:95000,  hue:30,  scene:'skyline',  tags:['Wi-Fi','Parking','Restaurant'],      blurb:'A calm, central stay with big desks, strong Wi-Fi and a garden restaurant.' },
  { id:'table-bay-inn', name:'Table Bay Inn',  city:'Cape Town', price:180000, hue:215, scene:'mountain', tags:['Sea view','Bar','Breakfast','Spa'],  blurb:'Harbour views, a small spa and a short walk to the waterfront.' },
  { id:'mara-ridge',    name:'Mara Ridge',     city:'Nairobi',   price:110000, hue:140, scene:'savanna',  tags:['Garden','Pool','Safari tours'],      blurb:'Lodge-style rooms on the edge of the city with early safari pick-ups.' },
  { id:'coral-gate',    name:'Coral Gate',     city:'Zanzibar',  price:220000, hue:8,   scene:'palm',     tags:['Beach','Pool','Diving','Breakfast'], blurb:'Beachfront bungalows, a dive centre and sunset dinners on the sand.' },
  { id:'osu-garden',    name:'Osu Garden',     city:'Accra',     price:100000, hue:88,  scene:'garden',   tags:['Wi-Fi','Restaurant','Bar'],          blurb:'Friendly boutique hotel near the nightlife, with a leafy courtyard.' },
  { id:'atlas-riad',    name:'Atlas Riad',     city:'Marrakech', price:135000, hue:340, scene:'arches',   tags:['Courtyard','Breakfast','Hammam'],    blurb:'A tiled courtyard house inside the medina with a rooftop terrace.' },
  { id:'hillside-lodge',name:'Hillside Lodge', city:'Kigali',    price:90000,  hue:265, scene:'hills',    tags:['Views','Wi-Fi','Gym','Breakfast'],   blurb:'Modern rooms on a hill with a gym and a sunrise breakfast terrace.' },
  { id:'garden-city-suites', name:'Garden City Suites', city:'Ibadan', price:85000, hue:112, scene:'garden', tags:['Garden','Wi-Fi','Breakfast'], blurb:'A relaxed city stay with leafy courtyards, comfortable rooms and easy access to local markets.' },
  { id:'cedar-view-hotel', name:'Cedar View Hotel', city:'Jos', price:78000, hue:152, scene:'hills', tags:['Mountain views','Restaurant','Parking'], blurb:'A cool-climate retreat with hillside views, hearty meals and a quiet terrace.' },
  { id:'royal-palm-lodge', name:'Royal Palm Lodge', city:'Calabar', price:105000, hue:34, scene:'palm', tags:['Pool','Garden','Airport shuttle'], blurb:'A tropical lodge with a garden pool and welcoming spaces for unwinding after a day out.' },
  { id:'blue-creek-inn', name:'Blue Creek Inn', city:'Ilorin', price:72000, hue:198, scene:'waves', tags:['Wi-Fi','Breakfast','Parking'], blurb:'A simple, comfortable base with bright rooms and a laid-back breakfast area.' },
  { id:'acacia-house', name:'Acacia House', city:'Kampala', price:118000, hue:78, scene:'savanna', tags:['Restaurant','Garden','Wi-Fi'], blurb:'Boutique rooms, a peaceful garden and a restaurant serving regional favourites.' },
  { id:'harbour-light-hotel', name:'Harbour Light Hotel', city:'Lagos', price:160000, hue:208, scene:'waves', tags:['Sea view','Bar','Pool'], blurb:'A contemporary waterfront stay with sunset views and a lively dining room.' },
  { id:'sunstone-riad', name:'Sunstone Riad', city:'Fes', price:145000, hue:348, scene:'arches', tags:['Courtyard','Hammam','Breakfast'], blurb:'A restored courtyard home with tiled details, quiet rooms and a rooftop breakfast spot.' },
  { id:'misty-hills-retreat', name:'Misty Hills Retreat', city:'Entebbe', price:132000, hue:160, scene:'hills', tags:['Lake view','Garden','Restaurant'], blurb:'A peaceful hillside hideaway with green views and a breezy outdoor dining area.' },
  { id:'golden-dune-hotel', name:'Golden Dune Hotel', city:'Dakar', price:175000, hue:26, scene:'savanna', tags:['Pool','Restaurant','Wi-Fi'], blurb:'Warmly styled rooms, a sunny pool deck and easy access to the city.' },
  { id:'moonrise-bay-resort', name:'Moonrise Bay Resort', city:'Mombasa', price:205000, hue:186, scene:'palm', tags:['Beach','Pool','Spa'], blurb:'A coastal escape with breezy rooms, a palm-lined pool and evenings by the shore.' },
];
const HIDDEN_HOTEL_IDS = new Set(['copper-lane-hotel']);
const SEED_REVIEWS = [
  ['lagoon-house','Ada O.',5,'Woke up to the lagoon from the balcony. Staff remembered my name by day two.','2026-09-14',12],
  ['lagoon-house','Tunde B.',4,'Great pool and breakfast. The lift was slow at rush hour.','2026-08-02',5],
  ['savanna-court','Chidi E.',4,'Quiet, clean, and the desk was big enough for real work.','2026-10-01',7],
  ['savanna-court','Hauwa S.',5,'Best Wi-Fi I have had in a hotel. Dinner in the garden was lovely.','2026-07-19',9],
  ['table-bay-inn','Liam P.',5,'The harbour view is worth the price. Spa was small but excellent.','2026-10-11',15],
  ['table-bay-inn','Ravi D.',2,'Room was ready late and the bar was loud until midnight.','2026-05-27',6],
  ['mara-ridge','Wanjiru N.',5,'Left at 5am for the safari and breakfast was packed for us. Perfect.','2026-08-15',11],
  ['coral-gate','Amara F.',5,'Dived in the morning, dinner on the sand at night. Felt like a holiday film.','2026-10-20',18],
  ['coral-gate','Jonas H.',3,'Beautiful beach but pricey, and the Wi-Fi only works at reception.','2026-09-09',8],
  ['osu-garden','Kofi A.',4,'Fun location and kind staff. Walls are thin so bring earplugs.','2026-10-05',6],
  ['atlas-riad','Sofia R.',5,'Got lost finding it, then never wanted to leave the rooftop.','2026-10-17',14],
  ['atlas-riad','Omar L.',4,'Authentic and beautiful. Stairs are steep, so pack light.','2026-09-22',5],
  ['hillside-lodge','Grace U.',5,'Sunrise breakfast over the hills was the highlight of my trip.','2026-10-08',10],
  ['hillside-lodge','Eric M.',3,'Good gym and views, but the room felt small for the price.','2026-07-30',2]
].map((r, i) => ({ id:'s' + i, hotel_id:r[0], name:r[1], rating:r[2], text:r[3], ts:Date.parse(r[4]), helpful:r[5] }));

// ---------- helpers ----------
const $ = (s) => document.querySelector(s);

// Builds elements from text nodes only, so user text can never run as HTML
function h(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v != null && v !== false) e.setAttribute(k, v === true ? '' : v);
  }
  kids.flat().filter((c) => c != null && c !== false).forEach((c) => e.append(c));
  return e;
}
const fmtDate = (ts) => new Date(ts).toLocaleDateString(undefined, { year:'numeric', month:'short', day:'numeric' });
const fmtNaira = (v) => new Intl.NumberFormat('en-NG', { style:'currency', currency:'NGN', maximumFractionDigits:0 }).format(Number(v));
const starsEl = (n) => h('span', { class:'stars', style:'--p:' + (n / 5 * 100) + '%', 'aria-label':n.toFixed(1) + ' out of 5' }, '★★★★★');
const hueOf = (s) => [...s].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 360, 7);

function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2600);
}

function renderAuthNav() {
  const nav = $('#authNav');
  let session;
  try { session = JSON.parse(localStorage.getItem('roomnotes.auth.v1') || 'null'); } catch (e) {}
  if (!session || session.expires <= Date.now()) {
    nav.replaceChildren(h('a', { class:'auth-link', href:'login.html' }, 'Log in'), h('a', { class:'auth-cta', href:'register.html' }, 'Sign up'));
    return;
  }
  local.name = session.name;
  persist();
  nav.replaceChildren(h('span', { class:'auth-greeting' }, 'Hi, ' + session.name), h('button', { class:'auth-signout', type:'button', onclick:async () => {
    try {
      if (!session.token.startsWith('demo-')) {
        await fetch(API_URL, { method:'POST', headers:{ 'Content-Type':'text/plain;charset=utf-8' }, body:JSON.stringify({ action:'logout', token:session.token }) });
      }
    } catch (e) {}
    localStorage.removeItem('roomnotes.auth.v1'); renderAuthNav(); toast('You are logged out.');
  } }, 'Log out'));
}

// ---------- illustrated covers (fixed shapes, colours come from a number) ----------
const pal = (hue) => ({ bg:`hsl(${hue} 75% 66%)`, sun:'#ffe27a', a:`hsl(${hue} 60% 44%)`, b:`hsl(${hue} 55% 26%)`, c:`hsl(${(hue + 28) % 360} 80% 80%)` });
const SCENES = {
  waves:   (p) => `<circle cx="300" cy="78" r="42" fill="${p.sun}"/><rect x="58" y="64" width="28" height="80" fill="${p.b}"/><rect x="92" y="86" width="24" height="58" fill="${p.a}"/><path d="M0 128Q50 108 100 128T200 128T300 128T400 128V220H0Z" fill="${p.c}"/><path d="M0 160Q50 140 100 160T200 160T300 160T400 160V220H0Z" fill="${p.a}"/><path d="M0 192Q50 174 100 192T200 192T300 192T400 192V220H0Z" fill="${p.b}"/>`,
  skyline: (p) => `<circle cx="320" cy="70" r="38" fill="${p.sun}"/><rect x="30" y="92" width="50" height="130" fill="${p.c}"/><rect x="90" y="58" width="60" height="164" fill="${p.a}"/><rect x="160" y="100" width="46" height="122" fill="${p.c}"/><rect x="216" y="48" width="56" height="174" fill="${p.b}"/><rect x="282" y="112" width="50" height="110" fill="${p.a}"/><rect x="342" y="86" width="40" height="136" fill="${p.c}"/>`,
  mountain:(p) => `<circle cx="318" cy="60" r="34" fill="${p.sun}"/><path d="M0 150L110 48L200 130L270 78L400 160V220H0Z" fill="${p.a}"/><path d="M110 48L88 80L132 80Z" fill="#fff" opacity=".85"/><path d="M0 178Q100 150 220 176T400 168V220H0Z" fill="${p.c}"/><rect y="186" width="400" height="34" fill="${p.b}"/>`,
  savanna: (p) => `<circle cx="96" cy="124" r="52" fill="${p.sun}"/><path d="M0 170Q120 122 240 165T400 150V220H0Z" fill="${p.a}"/><path d="M0 198Q150 164 400 192V220H0Z" fill="${p.b}"/><rect x="288" y="96" width="7" height="76" fill="${p.b}"/><ellipse cx="291" cy="92" rx="60" ry="16" fill="${p.b}"/><ellipse cx="250" cy="102" rx="28" ry="8" fill="${p.b}"/>`,
  palm:    (p) => `<circle cx="96" cy="70" r="40" fill="${p.sun}"/><rect y="128" width="400" height="50" fill="${p.c}"/><path d="M0 176Q120 150 260 178T400 170V220H0Z" fill="${p.b}"/><path d="M296 190Q306 132 272 72" stroke="${p.b}" stroke-width="8" fill="none"/><g fill="${p.a}"><ellipse cx="272" cy="72" rx="46" ry="10" transform="rotate(-25 272 72)"/><ellipse cx="272" cy="72" rx="46" ry="10" transform="rotate(20 272 72)"/><ellipse cx="272" cy="72" rx="46" ry="10" transform="rotate(-70 272 72)"/><ellipse cx="272" cy="72" rx="46" ry="10" transform="rotate(65 272 72)"/><ellipse cx="272" cy="72" rx="46" ry="10" transform="rotate(5 272 72)"/></g>`,
  garden:  (p) => `<circle cx="330" cy="62" r="34" fill="${p.sun}"/><circle cx="70" cy="140" r="64" fill="${p.a}"/><circle cx="170" cy="164" r="52" fill="${p.c}"/><circle cx="266" cy="136" r="72" fill="${p.b}"/><circle cx="360" cy="168" r="48" fill="${p.a}"/><rect y="180" width="400" height="40" fill="${p.b}"/>`,
  arches:  (p) => `<path d="M120 112a80 80 0 0 1 160 0Z" fill="${p.sun}"/><g><path d="M20 220V120a34 34 0 0 1 68 0V220Z" fill="${p.a}"/><path d="M112 220V110a34 34 0 0 1 68 0V220Z" fill="${p.b}"/><path d="M204 220V110a34 34 0 0 1 68 0V220Z" fill="${p.a}"/><path d="M296 220V120a34 34 0 0 1 68 0V220Z" fill="${p.b}"/></g><rect y="196" width="400" height="24" fill="${p.c}"/>`,
  hills:   (p) => `<circle cx="84" cy="68" r="38" fill="${p.sun}"/><path d="M0 150Q100 80 210 140T400 110V220H0Z" fill="${p.c}"/><path d="M0 180Q120 120 250 176T400 150V220H0Z" fill="${p.a}"/><path d="M0 206Q160 172 400 200V220H0Z" fill="${p.b}"/>`
};
const HOTEL_IMAGES = {
  'lagoon-house':'https://tse3.mm.bing.net/th/id/OIP.fsJwIMmAceOI4a9dNi26VQHaHa?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
  'savanna-court':'https://tse1.mm.bing.net/th/id/OIP.vZWk9KNWTEpVqx9noSyqXwHaE7?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
  'mara-ridge':'https://th.bing.com/th/id/OIP.z7AEG2bjPcKnmh9m379tMAHaE8?w=254&h=180&c=7&r=0&o=7&dpr=1.5&pid=1.7&rm=3',
  'atlas-riad':'https://th.bing.com/th/id/OIP.-7RzKxNbIvUcTPzcFQ8_ngHaEK?w=329&h=185&c=7&r=0&o=7&dpr=1.5&pid=1.7&rm=3',
  'coral-gate':'https://tse3.mm.bing.net/th/id/OIP.Z4BT5OSqJzld70ZwGl2_mgHaE8?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
  'osu-garden':'https://tse2.mm.bing.net/th/id/OIP.8i6xZN5d85k7RD3Qe1B9SQHaDj?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
  'hillside-lodge':'https://tse1.mm.bing.net/th/id/OIP.hV70Q3CkwmdDOzfF3Xb4oAHaFj?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
  'table-bay-inn':'https://tse4.mm.bing.net/th/id/OIP.UERVUSmXTW8DYPPH1T-cMQHaDt?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
  'garden-city-suites':'https://tse1.explicit.bing.net/th/id/OIP.VfGeYTbHeYRIDV36veG59QHaE7?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
  'cedar-view-hotel':'https://media-cdn.tripadvisor.com/media/photo-s/1c/35/91/b6/best-health-farm-and.jpg',
  'royal-palm-lodge':'https://tse1.mm.bing.net/th/id/OIP.jehtfVpsTA0ONQognR51YAHaEu?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
  'blue-creek-inn':'https://th.bing.com/th/id/OIP.uK2t0brZcJ1uxE0EWpaiSgHaEH?r=0&o=7rm=3&rs=1&pid=ImgDetMain&o=7&rm=3',
  'acacia-house':'https://th.bing.com/th/id/OIP.DQ2XmNPrQG4JWlWD8INtHAHaE6?r=0&o=7rm=3&rs=1&pid=ImgDetMain&o=7&rm=3',
  'harbour-light-hotel':'https://tse1.mm.bing.net/th/id/OIP.tlUoa1-pLNijjYn_gUaflAHaEN?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
  'sunstone-riad':'https://tse1.mm.bing.net/th/id/OIP.WQFspgXOibx9IEJ0XeSZbQHaE2?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
  'misty-hills-retreat':'https://tse4.mm.bing.net/th/id/OIP.J3VoTXogwU3NN6en1o4apAHaEK?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
  'golden-dune-hotel':'https://tse3.mm.bing.net/th/id/OIP.APQLPh0CwijJ8TVFrLNwQAHaHa?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
  'moonrise-bay-resort':'https://tse4.mm.bing.net/th/id/OIP.iRk9_jhdWz5UFnLQWK5PEQHaEp?r=0&rs=1&pid=ImgDetMain&o=7&rm=3'
};
function sceneEl(x) {
  const image = HOTEL_IMAGES[x.id];
  if (image) return h('div', { class:'scene' }, h('img', { src:image, alt:x.name, loading:'lazy' }));
  const p = pal(Number(x.hue) || 200);
  const d = h('div', { class:'scene', style:'background:' + p.bg });
  d.innerHTML = '<svg viewBox="0 0 400 220" preserveAspectRatio="xMidYMid slice" aria-hidden="true">' + (SCENES[x.scene] || SCENES.hills)(p) + '</svg>'; // fixed shapes + numeric colours only
  return d;
}

// ---------- local (per-browser) state ----------
const LKEY = 'roomnotes.local.v2';
const local = { saved:[], helped:[], mine:[], name:'', key:'' };
try { Object.assign(local, JSON.parse(localStorage.getItem(LKEY) || '{}')); } catch (e) {}
if (!local.key) local.key = (window.crypto && crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2)) + '-' + Math.random().toString(36).slice(2) + Date.now();
const persist = () => { try { localStorage.setItem(LKEY, JSON.stringify(local)); } catch (e) {} };
persist();
const flip = (arr, v) => { const i = arr.indexOf(v); i > -1 ? arr.splice(i, 1) : arr.push(v); };

// ---------- data layer: Apps Script, or a local stand-in in demo mode ----------
const DKEY = 'roomnotes.demo.v2';
const demoStore = () => { try { const d = JSON.parse(localStorage.getItem(DKEY)); if (d && d.reviews) return d; } catch (e) {} return { reviews:SEED_REVIEWS.map((r) => ({ ...r, owner:'' })) }; };
const demoSave = (d) => localStorage.setItem(DKEY, JSON.stringify(d));
const pub = ({ owner, ...r }) => r;
const demo = {
  load: () => ({ hotels:SEED_HOTELS, reviews:demoStore().reviews.map(pub) }),
  addReview(p) {
    const d = demoStore();
    if (d.reviews.some((r) => r.hotel_id === p.hotel_id && r.owner === p.key)) throw new Error('You already reviewed this hotel. Delete your review to post a new one.');
    const r = { id:'u' + Date.now(), hotel_id:p.hotel_id, name:p.name, rating:p.rating, text:p.text, ts:Date.now(), helpful:0, owner:p.key };
    d.reviews.push(r); demoSave(d); return pub(r);
  },
  deleteReview(p) {
    const d = demoStore(), n = d.reviews.length;
    d.reviews = d.reviews.filter((r) => !(r.id === p.id && r.owner && r.owner === p.key));
    if (d.reviews.length === n) throw new Error('You can only delete your own review');
    demoSave(d); return true;
  },
  voteHelpful(p) {
    const d = demoStore(), r = d.reviews.find((x) => x.id === p.id);
    if (!r) throw new Error('Review not found');
    r.helpful = Math.max(0, r.helpful + (p.on ? 1 : -1)); demoSave(d); return r.helpful;
  }
};

async function api(action, payload = {}) {
  if (DEMO) return demo[action](payload);
  // text/plain avoids a CORS preflight, which Apps Script does not answer
  const res = await fetch(API_URL, { method:'POST', headers:{ 'Content-Type':'text/plain;charset=utf-8' }, body:JSON.stringify({ action, ...payload }) });
  const j = await res.json();
  if (!j.ok) throw new Error(j.error);
  return j.data;
}

// ---------- app state ----------
let data = { hotels:[], reviews:[] };
const filters = { q:'', city:'', saved:false, sort:'top' };
let currentPage = 1;

const reviewsOf = (id) => data.reviews.filter((r) => r.hotel_id === id);
function stats(id) {
  const rs = reviewsOf(id), dist = [0, 0, 0, 0, 0];
  rs.forEach((r) => dist[r.rating - 1]++);
  return { n:rs.length, avg:rs.length ? rs.reduce((a, r) => a + r.rating, 0) / rs.length : 0, dist };
}
function validateReview(name, rating, text) {
  if (name.length < 2) return 'Add your name (2 characters or more).';
  if (!rating) return 'Pick a star rating.';
  if (text.length < 10) return 'Write at least 10 characters.';
  return '';
}

// ---------- rendering: page ----------
function refresh() { renderChips(); renderFeature(); renderGrid(); }

function pageCountFor(total) { return total <= 9 ? (total ? 1 : 0) : 1 + Math.ceil((total - 9) / 10); }
function pageSlice(list, page) {
  const start = page === 1 ? 0 : 9 + (page - 2) * 10;
  const size = page === 1 ? 9 : 10;
  return list.slice(start, start + size);
}

function renderPagination(pageCount) {
  const nav = $('#pagination');
  if (!nav) return;
  if (pageCount <= 1) { nav.replaceChildren(); nav.hidden = true; return; }
  nav.hidden = false;
  const buttons = [h('button', { class:'page-step', type:'button', 'aria-label':'Previous page', disabled:currentPage === 1, onclick:() => changePage(currentPage - 1) }, '← Previous')];
  for (let page = 1; page <= pageCount; page++) {
    buttons.push(h('button', { class:'page-number', type:'button', 'aria-label':'Page ' + page, 'aria-current':page === currentPage ? 'page' : null, onclick:() => changePage(page) }, String(page)));
  }
  buttons.push(h('button', { class:'page-step', type:'button', 'aria-label':'Next page', disabled:currentPage === pageCount, onclick:() => changePage(currentPage + 1) }, 'Next →'));
  nav.replaceChildren(...buttons);
}

function changePage(page) {
  currentPage = page;
  renderGrid();
  $('#grid').scrollIntoView({ behavior:'smooth', block:'start' });
}

function renderChips() {
  const cities = [...new Set(data.hotels.map((x) => x.city))].sort();
  const mk = (label, val) => h('button', { class:'chip', 'aria-pressed':String(filters.city === val), onclick:() => { filters.city = val; currentPage = 1; refresh(); } }, label);
  $('#chips').replaceChildren(mk('All cities', ''), ...cities.map((c) => mk(c, c)));
}

function renderFeature() {
  const box = $('#feature');
  const ranked = data.hotels.filter((x) => !HIDDEN_HOTEL_IDS.has(String(x.id)) && reviewsOf(x.id).length).sort((a, b) => stats(b.id).avg - stats(a.id).avg || stats(b.id).n - stats(a.id).n);
  if (!ranked.length) { box.hidden = true; return; }
  const x = ranked[0], st = stats(x.id);
  box.hidden = false; box.href = '#' + x.id;
  box.replaceChildren(sceneEl(x), h('div', { class:'cap' },
    h('div', {}, h('h2', {}, x.name), h('span', { class:'muted' }, 'Top rated right now in ' + x.city)),
    h('div', { class:'stamp', style:'position:static' }, st.avg.toFixed(1))));
}

function renderGrid() {
  const q = filters.q.toLowerCase();
  const list = data.hotels.filter((x) => !HIDDEN_HOTEL_IDS.has(String(x.id)) &&
    (!filters.city || x.city === filters.city) && (!filters.saved || local.saved.includes(x.id)) &&
    (!q || (x.name + ' ' + x.city + ' ' + x.tags.join(' ')).toLowerCase().includes(q)));
  const s = {}; list.forEach((x) => (s[x.id] = stats(x.id)));
  const by = { top:(a, b) => s[b.id].avg - s[a.id].avg, most:(a, b) => s[b.id].n - s[a.id].n, low:(a, b) => a.price - b.price, high:(a, b) => b.price - a.price };
  list.sort(by[filters.sort]);
  const pageCount = pageCountFor(list.length);
  currentPage = Math.max(1, Math.min(currentPage, pageCount || 1));
  const pageHotels = pageSlice(list, currentPage);

  $('#grid').replaceChildren(...pageHotels.map((x) => {
    const st = s[x.id];
    const heart = h('button', { class:'heart', 'aria-pressed':String(local.saved.includes(x.id)), 'aria-label':'Save ' + x.name, onclick:() => {
      flip(local.saved, x.id); persist();
      heart.setAttribute('aria-pressed', String(local.saved.includes(x.id)));
      heart.classList.remove('pop'); void heart.offsetWidth; heart.classList.add('pop');
      if (filters.saved) renderGrid();
    } }, '♥');
    return h('article', { class:'card' },
      h('div', { class:'cover' }, sceneEl(x), heart, h('div', { class:'stamp' + (st.n ? '' : ' new') }, st.n ? st.avg.toFixed(1) : 'New')),
      h('div', { class:'body' },
        h('h2', {}, h('a', { href:'#' + x.id }, x.name)),
        h('div', { class:'row' }, h('span', { class:'muted' }, x.city), h('span', { class:'price' }, h('b', {}, fmtNaira(x.price)), ' / night')),
        h('div', { class:'row' }, starsEl(st.avg), h('span', { class:'muted' }, st.n + (st.n === 1 ? ' review' : ' reviews'))),
        h('div', { class:'tags' }, x.tags.slice(0, 3).map((t) => h('span', { class:'tag' }, t)))));
  }));
  renderPagination(pageCount);
  $('#empty').hidden = list.length > 0;
  $('#count').textContent = list.length + (list.length === 1 ? ' hotel' : ' hotels') + (pageCount > 1 ? ' · Page ' + currentPage + ' of ' + pageCount : '');
  $('#stat').textContent = data.reviews.length + ' reviews';
}

// ---------- rendering: hotel dialog ----------
function renderDetail(id) {
  const x = data.hotels.find((k) => k.id === id), st = stats(id), dlg = $('#dlg');
  const list = h('div', { class:'reviews' });
  const opt = (v, t) => h('option', { value:v }, t);
  const sortSel = h('select', { 'aria-label':'Sort reviews', onchange:paint }, opt('new', 'Newest'), opt('high', 'Highest rated'), opt('low', 'Lowest rated'), opt('help', 'Most helpful'));

  function paint() {
    const by = { new:(a, b) => b.ts - a.ts, high:(a, b) => b.rating - a.rating, low:(a, b) => a.rating - b.rating, help:(a, b) => b.helpful - a.helpful };
    const rs = reviewsOf(id).sort(by[sortSel.value]);
    list.replaceChildren(...(rs.length ? rs.map(reviewEl) : [h('p', { class:'muted' }, 'No reviews yet. Be the first to write one.')]));
  }
  function reviewEl(r) {
    const voted = local.helped.includes(r.id);
    const helpBtn = h('button', { class:'ghost', 'aria-pressed':String(voted), onclick:async () => {
      const on = !local.helped.includes(r.id);
      flip(local.helped, r.id); r.helpful = Math.max(0, r.helpful + (on ? 1 : -1)); persist(); paint();
      try { await api('voteHelpful', { id:r.id, on }); }
      catch (e) { flip(local.helped, r.id); r.helpful = Math.max(0, r.helpful + (on ? -1 : 1)); persist(); paint(); toast(e.message); }
    } }, 'Helpful (' + r.helpful + ')');
    const del = local.mine.includes(r.id) ? h('button', { class:'ghost', onclick:async () => {
      try {
        await api('deleteReview', { id:r.id, key:local.key });
        data.reviews = data.reviews.filter((m) => m.id !== r.id);
        local.mine = local.mine.filter((m) => m !== r.id); persist();
        renderDetail(id); refresh(); toast('Review deleted');
      } catch (e) { toast(e.message); }
    } }, 'Delete') : null;
    return h('article', { class:'review' },
      h('div', { class:'who' }, h('span', { class:'av', style:'--av:' + hueOf(r.name) }, r.name[0].toUpperCase()), h('div', {}, h('strong', {}, r.name), h('div', { class:'muted' }, fmtDate(r.ts)))),
      starsEl(r.rating), h('p', {}, r.text), h('div', { class:'acts' }, helpBtn, del));
  }

  let rating = 0;
  const btns = [1, 2, 3, 4, 5].map((n) => h('button', { type:'button', 'aria-label':n + (n > 1 ? ' stars' : ' star'), onclick:() => { rating = n; paintPick(n); }, onmouseenter:() => paintPick(n) }, '★'));
  const paintPick = (n) => btns.forEach((b, i) => { b.classList.toggle('on', i < n); b.setAttribute('aria-pressed', String(i + 1 === rating)); });
  const pick = h('div', { class:'pick', onmouseleave:() => paintPick(rating) }, btns);
  const nameIn = h('input', { type:'text', id:'f-name', maxlength:'40', placeholder:'Your name', autocomplete:'name', value:local.name });
  const textIn = h('textarea', { id:'f-text', rows:'4', maxlength:'600', placeholder:'What was it like? Rooms, staff, noise, value…' });
  const err = h('p', { class:'err', role:'alert' });
  const submit = h('button', { class:'primary', type:'submit' }, 'Post review');
  const form = h('form', { class:'write', novalidate:true, onsubmit:async (e) => {
    e.preventDefault();
    const name = nameIn.value.trim(), text = textIn.value.trim(), msg = validateReview(name, rating, text);
    if (msg) { err.textContent = msg; return; }
    err.textContent = ''; submit.disabled = true; submit.textContent = 'Posting…';
    try {
      const r = await api('addReview', { hotel_id:id, name, rating, text, key:local.key });
      data.reviews.push(r); local.mine.push(r.id); local.name = name; persist();
      renderDetail(id); refresh(); toast('Thanks! Your review is posted.');
    } catch (ex) { err.textContent = ex.message; submit.disabled = false; submit.textContent = 'Post review'; }
  } },
    h('h3', {}, 'Write a review'),
    h('label', { for:'f-name' }, 'Name'), nameIn,
    h('label', {}, 'Your rating'), pick,
    h('label', { for:'f-text' }, 'Review'), textIn, err, submit);

  const bars = h('div', { class:'bars' }, [5, 4, 3, 2, 1].map((n) =>
    h('div', { class:'bar' }, h('span', {}, String(n)), h('span', { class:'track' }, h('span', { class:'fill', style:'--w:' + (st.n ? st.dist[n - 1] / st.n * 100 : 0) + '%' })), h('span', {}, String(st.dist[n - 1])))));

  dlg.replaceChildren(h('div', {},
    h('div', { class:'dhead' }, sceneEl(x), h('button', { class:'x', 'aria-label':'Close', onclick:() => dlg.close() }, '✕'),
    h('div', { class:'t' }, h('h2', {}, x.name), h('p', {}, x.city + ', ' + fmtNaira(x.price) + ' per night'))),
    h('div', { class:'cols' },
      h('div', {}, h('p', {}, x.blurb), h('div', { class:'tags' }, x.tags.map((t) => h('span', { class:'tag' }, t))),
        h('div', { class:'rhead' }, h('h3', {}, 'Guest reviews'), sortSel), list),
      h('aside', { class:'side' },
        h('div', { class:'panel' }, h('div', { class:'sum' },
          h('div', { class:'ring', style:'--p:' + (st.avg / 5 * 100) }, h('b', {}, st.n ? st.avg.toFixed(1) : '–')),
          h('div', {}, starsEl(st.avg), h('div', { class:'muted' }, st.n + (st.n === 1 ? ' review' : ' reviews')), bars))),
        h('div', { class:'panel' }, form)))));
  paint();
}

// ---------- routing: #hotel-id opens the dialog ----------
function route() {
  const dlg = $('#dlg'), id = location.hash.slice(1);
  if (data.hotels.some((k) => k.id === id)) { renderDetail(id); if (!dlg.open) dlg.showModal(); }
  else if (dlg.open) dlg.close();
}

// ---------- start ----------
async function start() {
  renderAuthNav();
  $('#demo').hidden = !DEMO;
  $('#foot').textContent = DEMO
    ? 'Demo mode: hotels and starting reviews are made-up samples, and reviews you add stay in this browser. Add your Apps Script URL in app.js to share reviews.'
    : 'Reviews are shared with everyone who visits this site.';
  $('#grid').textContent = 'Loading hotels…';
  try {
    const d = await api('load');
    d.hotels.forEach((x) => { x.price = Number(x.price); x.tags = Array.isArray(x.tags) ? x.tags : String(x.tags || '').split(',').map((t) => t.trim()).filter(Boolean); });
    d.hotels = d.hotels.filter((hotel) => !HIDDEN_HOTEL_IDS.has(String(hotel.id)));
    data = d;
  } catch (e) {
    $('#grid').replaceChildren(h('p', {}, 'Could not load hotels: ' + e.message), h('button', { class:'chip retry', onclick:start }, 'Try again'));
    return;
  }
  refresh(); route();
}

$('#q').addEventListener('input', (e) => { filters.q = e.target.value.trim(); currentPage = 1; renderGrid(); });
$('#sort').addEventListener('change', (e) => { filters.sort = e.target.value; currentPage = 1; renderGrid(); });
$('#savedBtn').addEventListener('click', (e) => { filters.saved = !filters.saved; currentPage = 1; e.currentTarget.setAttribute('aria-pressed', String(filters.saved)); renderGrid(); });
$('#dlg').addEventListener('click', (e) => { if (e.target === e.currentTarget) e.currentTarget.close(); });
$('#dlg').addEventListener('close', () => { if (location.hash) history.replaceState(null, '', location.pathname + location.search); });
addEventListener('hashchange', route);
start();
