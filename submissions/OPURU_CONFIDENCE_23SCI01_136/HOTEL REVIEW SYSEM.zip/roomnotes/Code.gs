const SHEET_ID = 'PASTE_SHEET_ID_HERE';
const SALT = 'change-me-to-a-long-random-string';

const HEAD = {
  hotels: ['id', 'name', 'city', 'price', 'tags', 'blurb', 'scene', 'hue'],
  reviews: ['id', 'hotel_id', 'name', 'rating', 'text', 'ts', 'helpful', 'owner_hash'],
  users: ['email', 'name', 'salt', 'password_hash', 'created_at'],
  sessions: ['token_hash', 'email', 'expires_at']
};

function setup() {
  const ss = book();
  Object.keys(HEAD).forEach(function (n) {
    const sh = ss.getSheetByName(n) || ss.insertSheet(n);
    sh.getRange(1, 1, 1, HEAD[n].length).setValues([HEAD[n]]);
  });
  const hs = ss.getSheetByName('hotels');
  if (hs.getLastRow() < 2) hs.getRange(2, 1, 8, 8).setValues([
    ['lagoon-house', 'Lagoon House', 'Lagos', 125000, 'Pool,Wi-Fi,Breakfast,Gym', 'Waterfront rooms with balconies over the lagoon, a rooftop pool and a quiet business lounge.', 'waves', 190],
    ['savanna-court', 'Savanna Court', 'Abuja', 95000, 'Wi-Fi,Parking,Restaurant', 'A calm, central stay with big desks, strong Wi-Fi and a garden restaurant.', 'skyline', 30],
    ['table-bay-inn', 'Table Bay Inn', 'Cape Town', 180000, 'Sea view,Bar,Breakfast,Spa', 'Harbour views, a small spa and a short walk to the waterfront.', 'mountain', 215],
    ['mara-ridge', 'Mara Ridge', 'Nairobi', 110000, 'Garden,Pool,Safari tours', 'Lodge-style rooms on the edge of the city with early safari pick-ups.', 'savanna', 140],
    ['coral-gate', 'Coral Gate', 'Zanzibar', 220000, 'Beach,Pool,Diving,Breakfast', 'Beachfront bungalows, a dive centre and sunset dinners on the sand.', 'palm', 8],
    ['osu-garden', 'Osu Garden', 'Accra', 100000, 'Wi-Fi,Restaurant,Bar', 'Friendly boutique hotel near the nightlife, with a leafy courtyard.', 'garden', 88],
    ['atlas-riad', 'Atlas Riad', 'Marrakech', 135000, 'Courtyard,Breakfast,Hammam', 'A tiled courtyard house inside the medina with a rooftop terrace.', 'arches', 340],
    ['hillside-lodge', 'Hillside Lodge', 'Kigali', 90000, 'Views,Wi-Fi,Gym,Breakfast', 'Modern rooms on a hill with a gym and a sunrise breakfast terrace.', 'hills', 265]
  ]);
  addMissingSampleHotels();
  const rs = ss.getSheetByName('reviews');
  if (rs.getLastRow() < 2) {
    const seed = [
      ['lagoon-house', 'Ada O.', 5, 'Woke up to the lagoon from the balcony. Staff remembered my name by day two.', '2026-09-14', 12],
      ['lagoon-house', 'Tunde B.', 4, 'Great pool and breakfast. The lift was slow at rush hour.', '2026-08-02', 5],
      ['savanna-court', 'Chidi E.', 4, 'Quiet, clean, and the desk was big enough for real work.', '2026-10-01', 7],
      ['savanna-court', 'Hauwa S.', 5, 'Best Wi-Fi I have had in a hotel. Dinner in the garden was lovely.', '2026-07-19', 9],
      ['table-bay-inn', 'Liam P.', 5, 'The harbour view is worth the price. Spa was small but excellent.', '2026-10-11', 15],
      ['table-bay-inn', 'Ravi D.', 2, 'Room was ready late and the bar was loud until midnight.', '2026-05-27', 6],
      ['mara-ridge', 'Wanjiru N.', 5, 'Left at 5am for the safari and breakfast was packed for us. Perfect.', '2026-08-15', 11],
      ['coral-gate', 'Amara F.', 5, 'Dived in the morning, dinner on the sand at night. Felt like a holiday film.', '2026-10-20', 18],
      ['coral-gate', 'Jonas H.', 3, 'Beautiful beach but pricey, and the Wi-Fi only works at reception.', '2026-09-09', 8],
      ['osu-garden', 'Kofi A.', 4, 'Fun location and kind staff. Walls are thin so bring earplugs.', '2026-10-05', 6],
      ['atlas-riad', 'Sofia R.', 5, 'Got lost finding it, then never wanted to leave the rooftop.', '2026-10-17', 14],
      ['atlas-riad', 'Omar L.', 4, 'Authentic and beautiful. Stairs are steep, so pack light.', '2026-09-22', 5],
      ['hillside-lodge', 'Grace U.', 5, 'Sunrise breakfast over the hills was the highlight of my trip.', '2026-10-08', 10],
      ['hillside-lodge', 'Eric M.', 3, 'Good gym and views, but the room felt small for the price.', '2026-07-30', 2]
    ].map(function (r, i) { return ['s' + i, r[0], r[1], r[2], r[3], Date.parse(r[4]), r[5], '']; });
    rs.getRange(2, 1, seed.length, 8).setValues(seed);
  }
}

// Adds the extra sample listings without changing existing hotels or custom rows.
function addMissingSampleHotels() {
  const hs = book().getSheetByName('hotels');
  const existing = hs.getDataRange().getValues().slice(1).map(function (row) { return String(row[0]); });
  const additions = [
    ['garden-city-suites', 'Garden City Suites', 'Ibadan', 85000, 'Garden,Wi-Fi,Breakfast', 'A relaxed city stay with leafy courtyards, comfortable rooms and easy access to local markets.', 'garden', 112],
    ['cedar-view-hotel', 'Cedar View Hotel', 'Jos', 78000, 'Mountain views,Restaurant,Parking', 'A cool-climate retreat with hillside views, hearty meals and a quiet terrace.', 'hills', 152],
    ['royal-palm-lodge', 'Royal Palm Lodge', 'Calabar', 105000, 'Pool,Garden,Airport shuttle', 'A tropical lodge with a garden pool and welcoming spaces for unwinding after a day out.', 'palm', 34],
    ['blue-creek-inn', 'Blue Creek Inn', 'Ilorin', 72000, 'Wi-Fi,Breakfast,Parking', 'A simple, comfortable base with bright rooms and a laid-back breakfast area.', 'waves', 198],
    ['acacia-house', 'Acacia House', 'Kampala', 118000, 'Restaurant,Garden,Wi-Fi', 'Boutique rooms, a peaceful garden and a restaurant serving regional favourites.', 'savanna', 78],
    ['harbour-light-hotel', 'Harbour Light Hotel', 'Lagos', 160000, 'Sea view,Bar,Pool', 'A contemporary waterfront stay with sunset views and a lively dining room.', 'waves', 208],
    ['sunstone-riad', 'Sunstone Riad', 'Fes', 145000, 'Courtyard,Hammam,Breakfast', 'A restored courtyard home with tiled details, quiet rooms and a rooftop breakfast spot.', 'arches', 348],
    ['misty-hills-retreat', 'Misty Hills Retreat', 'Entebbe', 132000, 'Lake view,Garden,Restaurant', 'A peaceful hillside hideaway with green views and a breezy outdoor dining area.', 'hills', 160],
    ['golden-dune-hotel', 'Golden Dune Hotel', 'Dakar', 175000, 'Pool,Restaurant,Wi-Fi', 'Warmly styled rooms, a sunny pool deck and easy access to the city.', 'savanna', 26],
    ['moonrise-bay-resort', 'Moonrise Bay Resort', 'Mombasa', 205000, 'Beach,Pool,Spa', 'A coastal escape with breezy rooms, a palm-lined pool and evenings by the shore.', 'palm', 186]
  ];
  additions.forEach(function (hotel) {
    if (existing.indexOf(hotel[0]) === -1) hs.appendRow(hotel);
  });
}

// Run once from the Apps Script editor to update the built-in sample hotel rates.
function updateSampleHotelPricesToNaira() {
  const prices = {
    'lagoon-house': 125000,
    'savanna-court': 95000,
    'table-bay-inn': 180000,
    'mara-ridge': 110000,
    'coral-gate': 220000,
    'osu-garden': 100000,
    'atlas-riad': 135000,
    'hillside-lodge': 90000,
    'garden-city-suites': 85000,
    'cedar-view-hotel': 78000,
    'royal-palm-lodge': 105000,
    'blue-creek-inn': 72000,
    'acacia-house': 118000,
    'harbour-light-hotel': 160000,
    'sunstone-riad': 145000,
    'misty-hills-retreat': 132000,
    'golden-dune-hotel': 175000,
    'moonrise-bay-resort': 205000
  };
  const sh = book().getSheetByName('hotels');
  if (!sh || sh.getLastRow() < 2) return;
  const values = sh.getDataRange().getValues();
  const idCol = HEAD.hotels.indexOf('id');
  const priceCol = HEAD.hotels.indexOf('price') + 1;
  values.slice(1).forEach(function (row, i) {
    const price = prices[String(row[idCol])];
    if (price !== undefined) sh.getRange(i + 2, priceCol).setValue(price);
  });
}

// ---------- entry point ----------
const ACTIONS = { load: load, addReview: addReview, deleteReview: deleteReview, voteHelpful: voteHelpful, register: register, login: login, logout: logout };

function doPost(e) {
  const lock = LockService.getScriptLock();
  let out;
  try {
    const req = JSON.parse(e.postData.contents);
    if (!ACTIONS.hasOwnProperty(req.action)) throw new Error('Unknown action');
    lock.waitLock(10000);
    out = { ok: true, data: ACTIONS[req.action](req) };
  } catch (err) {
    out = { ok: false, error: err.message };
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

// ---------- helpers ----------
function book() { return SHEET_ID.indexOf('PASTE') === 0 ? SpreadsheetApp.getActiveSpreadsheet() : SpreadsheetApp.openById(SHEET_ID); }

function rows(name) {
  const v = book().getSheetByName(name).getDataRange().getValues();
  const head = v.shift();
  return v.map(function (r) { const o = {}; head.forEach(function (k, i) { o[k] = r[i]; }); return o; });
}

// Formula injection guard: text starting with = + - @ gets an apostrophe prefix
function safe(v) { return typeof v === 'string' && /^[=+\-@]/.test(v) ? "'" + v : v; }

function hashKey(k) {
  const d = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, SALT + k, Utilities.Charset.UTF_8);
  return d.map(function (b) { return ('0' + (b & 0xff).toString(16)).slice(-2); }).join('');
}

function passwordHash(password, salt) {
  var value = salt + ':' + password;
  for (var i = 0; i < 10000; i++) {
    value = Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, value, Utilities.Charset.UTF_8));
  }
  return value;
}

function authSheet(name) {
  var ss = book(), sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.getRange(1, 1, 1, HEAD[name].length).setValues([HEAD[name]]);
  }
  return sh;
}

function newSession(email, name) {
  var token = Utilities.getUuid() + Utilities.getUuid().replace(/-/g, '');
  var expires = Date.now() + 30 * 24 * 60 * 60 * 1000;
  authSheet('sessions').appendRow([hashKey('session:' + token), email, expires]);
  return { token: token, email: email, name: name, expires: expires };
}

function text(v, label, min, max) {
  v = String(v == null ? '' : v).trim();
  if (v.length < min || v.length > max) throw new Error(label + ' must be ' + min + ' to ' + max + ' characters');
  return v;
}

// Finds a review row by id. Returns {sh, row (1-based), rec}
function findReview(id) {
  const sh = book().getSheetByName('reviews');
  const v = sh.getDataRange().getValues();
  for (let i = 1; i < v.length; i++) {
    if (String(v[i][0]) === String(id)) {
      const rec = {}; v[0].forEach(function (k, j) { rec[k] = v[i][j]; });
      return { sh: sh, row: i + 1, rec: rec };
    }
  }
  throw new Error('Review not found');
}

function publicReview(r) {
  return { id: r.id, hotel_id: r.hotel_id, name: r.name, rating: Number(r.rating), text: r.text, ts: Number(r.ts), helpful: Number(r.helpful) || 0 };
}

// ---------- actions ----------
function load() {
  return {
    hotels: rows('hotels').filter(function (hotel) { return String(hotel.id) !== 'copper-lane-hotel'; }),
    reviews: rows('reviews').map(publicReview)
  };
}

function register(req) {
  var email = text(req.email, 'Email', 5, 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Enter a valid email address.');
  var name = text(req.name, 'Name', 2, 60);
  var password = String(req.password == null ? '' : req.password);
  if (password.length < 10 || password.length > 128) throw new Error('Password must be 10 to 128 characters.');
  var users = authSheet('users'), values = users.getDataRange().getValues();
  if (values.slice(1).some(function (r) { return String(r[0]).toLowerCase() === email; })) throw new Error('An account with this email already exists.');
  var salt = Utilities.getUuid() + Utilities.getUuid();
  users.appendRow([email, safe(name), salt, passwordHash(password, salt), Date.now()]);
  return newSession(email, name);
}

function login(req) {
  var email = text(req.email, 'Email', 5, 254).toLowerCase();
  var password = String(req.password == null ? '' : req.password);
  if (!password || password.length > 128) throw new Error('Email or password is incorrect.');
  var values = authSheet('users').getDataRange().getValues(), user = null;
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][0]).toLowerCase() === email) { user = values[i]; break; }
  }
  if (!user || passwordHash(password, String(user[2])) !== String(user[3])) throw new Error('Email or password is incorrect.');
  return newSession(email, String(user[1]));
}

function logout(req) {
  var token = String(req.token || '');
  if (!token) return true;
  var sessions = authSheet('sessions'), values = sessions.getDataRange().getValues(), digest = hashKey('session:' + token);
  for (var i = values.length - 1; i >= 1; i--) {
    if (String(values[i][0]) === digest) { sessions.deleteRow(i + 1); break; }
  }
  return true;
}

function addReview(req) {
  const hotelId = String(req.hotel_id || '');
  if (!rows('hotels').some(function (h) { return String(h.id) === hotelId; })) throw new Error('Hotel not found');
  const name = text(req.name, 'Name', 2, 40);
  const body = text(req.text, 'Review', 10, 600);
  const rating = Number(req.rating);
  if (!(rating >= 1 && rating <= 5) || rating % 1 !== 0) throw new Error('Rating must be 1 to 5');
  const owner = hashKey(text(req.key, 'Key', 16, 120));
  if (rows('reviews').some(function (r) { return String(r.hotel_id) === hotelId && r.owner_hash === owner; }))
    throw new Error('You already reviewed this hotel. Delete your review to post a new one.');
  const rec = { id: Utilities.getUuid().slice(0, 8), hotel_id: hotelId, name: name, rating: rating, text: body, ts: Date.now(), helpful: 0, owner_hash: owner };
  book().getSheetByName('reviews').appendRow(HEAD.reviews.map(function (k) { return safe(rec[k]); }));
  return publicReview(rec);
}

// Only the browser that wrote a review (same secret key) can delete it
function deleteReview(req) {
  const f = findReview(req.id);
  if (!f.rec.owner_hash || f.rec.owner_hash !== hashKey(String(req.key || ''))) throw new Error('You can only delete your own review');
  f.sh.deleteRow(f.row);
  return true;
}

function voteHelpful(req) {
  const f = findReview(req.id);
  const col = HEAD.reviews.indexOf('helpful') + 1;
  const n = Math.max(0, (Number(f.rec.helpful) || 0) + (req.on ? 1 : -1));
  f.sh.getRange(f.row, col).setValue(n);
  return n;
}
