# PandaHomes

PandaHomes is a real estate listing website built for the semi project **Building Web Applications: Web Application Security, Testing, Deployment and Review**. Agents post properties, an admin approves them, and buyers search, save listings and send inquiries.

This is a front-end prototype. It is a single HTML file that runs in the browser and keeps its data in the browser's local storage. There is no server or database. See [Limitations](#limitations).

## What it does

**Visitors** can browse approved listings, search by text, filter by type (house, apartment, land, commercial), rent or sale, and maximum price, and open a property page.

**Buyers** can also save listings, send inquiries (up to 500 characters) and see their saved listings and inquiries on a dashboard.

**Agents** can add a listing (it waits for admin approval), edit its price, mark it sold or rented, delete it, and read inquiries on their listings.

**Admins** can approve or reject listings, suspend or restore users, and read an audit log of logins, denied actions and changes.

**Everyone with an account** has a profile page where they can change their name and password.

### Security features

| Feature | How it works |
|---|---|
| Password hashing | PBKDF2-SHA256, 100,000 rounds, a unique salt per user. Plain passwords are never stored. |
| Authentication | Login and logout. A wrong password and an unknown email give the same message. |
| Role-based access | Visitor, buyer, agent and admin have different permissions. |
| Access-control checks | Every action rechecks the role and ownership. Denied attempts go to the audit log. |
| Input validation | Email, password strength, price, Nigerian phone number, file type and size, text length. |
| XSS protection | Every user value is HTML-escaped before it is shown. |
| SQL injection protection | Search is a code filter, not a query built from typed text. The Security page shows an unsafe query next to a parameterised one. |
| Session management | Automatic logout after 10 minutes of inactivity. Three failed logins lock that email for 60 seconds. |
| Sensitive information | No passwords in the page, URLs or logs. |
| HTTPS and headers | Example server configuration is shown on the Security page. |

Passwords must have at least 8 characters, with an uppercase letter, a lowercase letter, a number and a symbol.

## How to run it

There is nothing to install and no server to start.

1. Put `pandahomes.html` in a folder on your computer.
2. Double-click it, or drag it into **Chrome** or **Firefox**.
3. Click **Log in** and use one of the demo accounts below.

You need an internet connection only to load the fonts. The site works without it, with plain fallback fonts.

### Demo accounts

| Role | Email | Password |
|---|---|---|
| Admin | `admin@estate.ng` | `Admin#2026` |
| Agent | `agent@estate.ng` | `Agent#2026` |
| Buyer | `buyer@estate.ng` | `Buyer#2026` |

You can also create your own buyer or agent account on the **Create account** page. Admin accounts cannot be created there.

### Try this flow

1. Log in as the **agent** and add a listing. It shows as pending.
2. Log out, log in as the **admin** and approve it. It now appears on the home page.
3. Log in as the **buyer**, open the listing, save it and send an inquiry.
4. Open the **Security** page and type `' OR 1=1 --` into the injection sandbox.

### Optional: add your own property photos

The property pictures are drawn scenes. To replace them with real or AI-generated photos:

1. Create a folder named `images` next to `pandahomes.html`.
2. Save landscape photos (about 1200 x 800) as `home1.jpg`, `home2.jpg` and so on. The number is the listing id; the six starting listings use 1 to 6, and new listings start at 20 (`home20.jpg`).
3. Reload the page. Any listing with a matching photo shows it. The others keep the drawn scene.

### Reset the data

All data is stored in your browser under the key `pandahomes_v1`. To reset it, clear the site's data in your browser settings, or delete that key in the browser's developer tools (Application, Local Storage).

## Project files

```
pandahomes/
├── pandahomes.html                          the website (HTML, CSS and JavaScript in one file)
├── README.md                                this file
├── PandaHomes_Testing_Deployment_Review.docx   testing, deployment, and review and evaluation
└── images/                                  optional photos (home1.jpg, home2.jpg, ...)
```

Testing, deployment, and review and evaluation are in the Word document, not on the website.

## Built with

- HTML, CSS and JavaScript with no frameworks or build step
- Web Crypto (PBKDF2) for password hashing
- Browser local storage for data
- Google Fonts (Bricolage Grotesque, Unbounded, JetBrains Mono)

## Limitations

- Data lives only in your browser, so it is not shared between users or devices.
- The security checks run in browser code, which a user can bypass. A live version must repeat them on a server with a real database.
- The photo field checks the file type and size but does not store the image.
- If the browser does not offer Web Crypto (some non-secure contexts), the site uses a simpler fallback hash so it still loads. A real server would always use a strong hash.
- HTTPS, security headers and backups are described but not demonstrated here.
