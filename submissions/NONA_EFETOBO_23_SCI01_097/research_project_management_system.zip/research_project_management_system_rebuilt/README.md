# Research Project Management System

Flask + SQLite student application. Includes registration/login, hashed passwords, user-owned project records, project search/filter, profile editing, admin user listing, security overview, CSRF tokens, parameterized SQL, role checks, browser security headers, responsive dark-blue design, Source Sans 3, glowing cyan buttons and scroll reveal animations.

## Run on macOS
```bash
python3 -m venv venv
source venv/bin/activate
python -m pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000. If port 5000 is busy: `PORT=5001 python app.py` and open http://127.0.0.1:5001.

Starter administrator: admin@example.com / Admin123! Change this before public deployment.

Before deployment, set a strong SECRET_KEY, use HTTPS, set COOKIE_SECURE=1, use a production WSGI server, configure backups/logging and perform a security review. This is a student demonstration app, not a production-hardened institutional service.
