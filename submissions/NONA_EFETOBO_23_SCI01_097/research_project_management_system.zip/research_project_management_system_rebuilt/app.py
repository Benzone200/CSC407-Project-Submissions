import os, sqlite3, secrets
from functools import wraps
from datetime import datetime
from flask import Flask, g, request, redirect, url_for, session, flash, abort, render_template_string
from werkzeug.security import generate_password_hash, check_password_hash

app=Flask(__name__)
app.config.update(SECRET_KEY=os.environ.get("SECRET_KEY","change-this-development-secret"),SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE="Lax",SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE","0")=="1",PERMANENT_SESSION_LIFETIME=7200)
DB=os.path.join(os.path.dirname(__file__),"research_projects.db")

def getdb():
    if "db" not in g:
        g.db=sqlite3.connect(DB); g.db.row_factory=sqlite3.Row
    return g.db
@app.teardown_appcontext
def close_db(e=None):
    c=g.pop("db",None)
    if c: c.close()
def init_db():
    c=sqlite3.connect(DB)
    c.executescript("""CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT,email TEXT UNIQUE,password_hash TEXT,role TEXT DEFAULT 'user',created_at TEXT);
    CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY,user_id INTEGER,title TEXT,research_area TEXT,description TEXT,status TEXT,due_date TEXT,created_at TEXT,FOREIGN KEY(user_id) REFERENCES users(id));""")
    if c.execute("SELECT COUNT(*) FROM users").fetchone()[0]==0:
        c.execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",("Administrator","admin@example.com",generate_password_hash("Admin123!"),"admin",datetime.now().isoformat()))
    c.commit(); c.close()
@app.before_request
def csrf():
    if "csrf" not in session: session["csrf"]=secrets.token_urlsafe(32)
    if request.method=="POST":
        t=request.form.get("csrf_token","")
        if not t or not secrets.compare_digest(t,session.get("csrf","")): abort(400)
@app.after_request
def headers(r):
    r.headers["X-Content-Type-Options"]="nosniff"; r.headers["X-Frame-Options"]="DENY"; r.headers["Referrer-Policy"]="strict-origin-when-cross-origin"
    r.headers["Content-Security-Policy"]="default-src 'self'; style-src 'self' https://fonts.googleapis.com 'unsafe-inline'; font-src https://fonts.gstatic.com; script-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'"
    return r
def current():
    return getdb().execute("SELECT id,name,email,role FROM users WHERE id=?",(session["uid"],)).fetchone() if session.get("uid") else None
def login_required(f):
    @wraps(f)
    def w(*a,**k):
        if not current(): return redirect(url_for("login"))
        return f(*a,**k)
    return w
def admin_required(f):
    @wraps(f)
    def w(*a,**k):
        u=current()
        if not u: return redirect(url_for("login"))
        if u["role"]!="admin": abort(403)
        return f(*a,**k)
    return w

BASE=r"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{{title}} · ResearchSpace</title><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@400;500;600;700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="/static/style.css"></head><body><header><a class="brand" href="/">✳ Research<span>Space</span></a><button class="menubtn" onclick="document.querySelector('nav').classList.toggle('open')">☰</button><nav><a href="/#features">Features</a><a href="/#workflow">How it works</a><a href="/security">Security</a></nav><aside>{% if user %}<a href="/dashboard">Dashboard</a><a href="/profile">Profile</a>{% if user.role=='admin' %}<a href="/admin/users">Admin</a>{% endif %}<form method="post" action="/logout"><input type="hidden" name="csrf_token" value="{{csrf}}"><button class="linkbtn">Log out</button></form>{% else %}<a href="/login">Log in</a><a class="btn small" href="/register">Register ↗</a>{% endif %}</aside></header>{% for cat,msg in get_flashed_messages(with_categories=true) %}<div class="flash {{cat}}">{{msg}}</div>{% endfor %}<main>{{body|safe}}</main><footer><b>✳ Research<span>Space</span></b><p>A shared workspace for research projects, people and progress.</p><small>© 2026 ResearchSpace</small></footer><script>const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('shown');io.unobserve(e.target)}}),{threshold:.12});document.querySelectorAll('.reveal').forEach(x=>io.observe(x));</script></body></html>"""
def page(title,body,**kw):
    return render_template_string(BASE,title=title,body=render_template_string(body,user=current(),csrf=session.get("csrf"),**kw),user=current(),csrf=session.get("csrf"))

@app.route("/")
def home():
    body=r"""<section class="hero wrap"><div class="reveal"><label class="eyebrow">✧ BUILT FOR ACADEMIC RESEARCH</label><h1>Bring your research<br>work into <em>focus.</em></h1><p class="lead">Plan projects, organise research activities and keep track of progress — all in one secure workspace for students and research teams.</p><div class="actions"><a class="btn glow" href="/register">Create your account →</a><a class="btn secondary" href="/login">Log in</a></div><p class="trust">● Organised project records　 ● Secure access　 ● Progress at a glance</p></div><div class="preview reveal delay"><small>PROJECT OVERVIEW</small><h2>Research workspace</h2><div class="metrics"><div><small>Projects</small><b>08</b></div><div><small>In progress</small><b class="cyan">05</b></div><div><small>Completed</small><b>03</b></div></div><label class="caption">RECENT RESEARCH ACTIVITY</label><div class="activity">▤　 <b>Literature review</b><span>In progress</span></div><div class="activity">◇　 <b>Research proposal</b><span>Planning</span></div><div class="activity">✓　 <b>Dataset preparation</b><span>Completed</span></div></div></section><section class="wrap section" id="features"><div class="sectiontitle reveal"><label class="eyebrow">ONE WORKSPACE, MORE CLARITY</label><h2>Everything your research<br>workflow needs.</h2><p>Replace scattered notes and disconnected records with a clearer way to manage academic work.</p></div><div class="grid">{% for a,b,c in [('▦','Project dashboard','See projects, status and activity from one organised dashboard.'),('⌕','Search and filter','Find projects by title, research area or progress status.'),('♙','User accounts','Each researcher has a personal account and private workspace.'),('◈','Secure access','Protect accounts and records with authentication and access controls.'),('↗','Progress tracking','Track planning, active work and completed projects.'),('⚙','Administration','Administrators can review accounts and manage roles.')] %}<article class="tile reveal"><i>{{a}}</i><h3>{{b}}</h3><p>{{c}}</p></article>{% endfor %}</div></section><section class="workflow" id="workflow"><div class="wrap workflowinner"><div><label class="eyebrow">A SIMPLE WORKFLOW</label><h2>From idea to<br><em>completed research.</em></h2></div><div class="steps"><p><b>01</b>　Create your account — set up your research workspace.</p><p><b>02</b>　Add your projects — enter title, area, due date and status.</p><p><b>03</b>　Track your progress — update and review your work.</p></div></div></section><section class="cta wrap reveal"><label class="eyebrow">MAKE YOUR NEXT STEP COUNT</label><h2>Give your research<br>a more organised home.</h2><a class="btn glow" href="/register">Get started →</a></section>"""
    return page("Research, organised",body)

@app.route("/register",methods=["GET","POST"])
def register():
    if request.method=="POST":
        name=request.form.get("name","").strip(); email=request.form.get("email","").strip().lower(); pw=request.form.get("password","")
        if len(name)<2 or "@" not in email or len(pw)<8: flash("Enter a valid name/email and password of at least 8 characters.","error")
        else:
            try:
                cur=getdb().execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",(name,email,generate_password_hash(pw),"user",datetime.now().isoformat())); getdb().commit()
                session.clear(); session["uid"]=cur.lastrowid; session["csrf"]=secrets.token_urlsafe(32); session.permanent=True
                return redirect("/dashboard")
            except sqlite3.IntegrityError: flash("That email is already registered.","error")
    return page("Register",r"""<section class="auth wrap"><div class="reveal"><label class="eyebrow">YOUR RESEARCH WORKSPACE</label><h1>Start with a clear workspace.</h1><p class="lead">Keep your research projects organised, accessible and protected.</p></div><div class="panel reveal"><label class="eyebrow">CREATE AN ACCOUNT</label><h2>Create your account</h2><form method="post" class="fields"><input type="hidden" name="csrf_token" value="{{csrf}}"><label>Full name<input name="name" required minlength="2"></label><label>Email address<input type="email" name="email" required></label><label>Password<input type="password" name="password" minlength="8" required></label><button class="btn glow">Create account →</button></form><p>Already registered? <a href="/login">Log in</a></p></div></section>""")

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        u=getdb().execute("SELECT * FROM users WHERE email=?",(request.form.get("email","").strip().lower(),)).fetchone()
        if u and check_password_hash(u["password_hash"],request.form.get("password","")):
            session.clear(); session["uid"]=u["id"]; session["csrf"]=secrets.token_urlsafe(32); session.permanent=True; return redirect("/dashboard")
        flash("Email or password is incorrect.","error")
    return page("Log in",r"""<section class="auth wrap"><div><label class="eyebrow">YOUR RESEARCH WORKSPACE</label><h1>Welcome back.</h1><p class="lead">Your research workspace is ready when you are.</p></div><div class="panel"><label class="eyebrow">ACCOUNT ACCESS</label><h2>Log in to ResearchSpace</h2><form method="post" class="fields"><input type="hidden" name="csrf_token" value="{{csrf}}"><label>Email<input type="email" name="email" required></label><label>Password<input type="password" name="password" required></label><button class="btn glow">Log in →</button></form><p>New here? <a href="/register">Create an account</a></p><small>Starter admin: admin@example.com / Admin123! (change before deployment)</small></div></section>""")

@app.post("/logout")
@login_required
def logout(): session.clear(); return redirect("/")

@app.route("/dashboard")
@login_required
def dashboard():
    q=request.args.get("q","").strip(); st=request.args.get("status","")
    sql="SELECT * FROM projects WHERE user_id=?"; args=[session["uid"]]
    if q: sql+=" AND (title LIKE ? OR research_area LIKE ?)"; args += [f"%{q}%",f"%{q}%"]
    if st in ["Planning","In progress","Completed","On hold"]: sql+=" AND status=?"; args.append(st)
    projects=getdb().execute(sql+" ORDER BY id DESC",args).fetchall()
    counts=getdb().execute("SELECT COUNT(*) total,SUM(status='In progress') active,SUM(status='Completed') completed FROM projects WHERE user_id=?",(session["uid"],)).fetchone()
    body=r"""<section class="wrap dash"><div class="dashhead reveal"><div><label class="eyebrow">YOUR WORKSPACE</label><h1>Good to see you, <em>{{user.name.split()[0]}}.</em></h1><p>Here's an overview of your research activity.</p></div><a class="btn glow" href="/projects/new">＋ New project</a></div><div class="metrics stats"><div><small>Total projects</small><b>{{counts.total or 0}}</b></div><div><small>In progress</small><b class="cyan">{{counts.active or 0}}</b></div><div><small>Completed</small><b>{{counts.completed or 0}}</b></div></div><h2>Your research projects</h2><form class="filters"><input name="q" value="{{q}}" placeholder="Search by title or research area"><select name="status"><option value="">All statuses</option>{% for x in ['Planning','In progress','Completed','On hold'] %}<option {% if st==x %}selected{% endif %}>{{x}}</option>{% endfor %}</select><button class="btn secondary">Search</button></form>{% if projects %}<div class="grid">{% for p in projects %}<article class="tile reveal"><span class="tag">{{p.status}}</span><h3>{{p.title}}</h3><label class="cyan">{{p.research_area}}</label><p>{{p.description}}</p><small>Due: {{p.due_date or 'Not set'}}</small><p><a href="/projects/{{p.id}}/edit">Edit project ↗</a></p><form method="post" action="/projects/{{p.id}}/delete" onsubmit="return confirm('Delete this project?')"><input type="hidden" name="csrf_token" value="{{csrf}}"><button class="delete">Delete project</button></form></article>{% endfor %}</div>{% else %}<div class="panel"><h2>No projects found</h2><p>Add your first project or adjust your search.</p></div>{% endif %}</section>"""
    return page("Dashboard",body,projects=projects,counts=counts,q=q,st=st)

@app.route("/projects/new",methods=["GET","POST"])
@app.route("/projects/<int:pid>/edit",methods=["GET","POST"])
@login_required
def project_form(pid=None):
    p=getdb().execute("SELECT * FROM projects WHERE id=? AND user_id=?",(pid,session["uid"])).fetchone() if pid else None
    if pid and not p: abort(404)
    if request.method=="POST":
        title=request.form.get("title","").strip(); area=request.form.get("research_area","").strip(); status=request.form.get("status","Planning")
        if not title or not area or status not in ["Planning","In progress","Completed","On hold"]: flash("Complete the required fields.","error")
        elif p:
            getdb().execute("UPDATE projects SET title=?,research_area=?,description=?,status=?,due_date=? WHERE id=? AND user_id=?",(title,area,request.form.get("description",""),status,request.form.get("due_date",""),pid,session["uid"])); getdb().commit(); return redirect("/dashboard")
        else:
            getdb().execute("INSERT INTO projects(user_id,title,research_area,description,status,due_date,created_at) VALUES(?,?,?,?,?,?,?)",(session["uid"],title,area,request.form.get("description",""),status,request.form.get("due_date",""),datetime.now().isoformat())); getdb().commit(); return redirect("/dashboard")
    body=r"""<section class="wrap formpage"><div class="panel"><a href="/dashboard">← Back to dashboard</a><label class="eyebrow">RESEARCH RECORD</label><h1>{{'Edit project' if p else 'Add a research project'}}</h1><form method="post" class="fields"><input type="hidden" name="csrf_token" value="{{csrf}}"><label>Project title<input name="title" required value="{{p.title if p else ''}}"></label><label>Research area<input name="research_area" required value="{{p.research_area if p else ''}}"></label><label>Description<textarea name="description" rows="4">{{p.description if p else ''}}</textarea></label><div class="twocol"><label>Status<select name="status">{% for x in ['Planning','In progress','Completed','On hold'] %}<option {% if p and p.status==x %}selected{% elif not p and x=='Planning' %}selected{% endif %}>{{x}}</option>{% endfor %}</select></label><label>Due date<input type="date" name="due_date" value="{{p.due_date if p else ''}}"></label></div><button class="btn glow">Save project →</button></form></div></section>"""
    return page("Project",body,p=p)

@app.post("/projects/<int:pid>/delete")
@login_required
def delete_project(pid):
    getdb().execute("DELETE FROM projects WHERE id=? AND user_id=?",(pid,session["uid"])); getdb().commit(); return redirect("/dashboard")

@app.route("/profile",methods=["GET","POST"])
@login_required
def profile():
    u=getdb().execute("SELECT * FROM users WHERE id=?",(session["uid"],)).fetchone()
    if request.method=="POST":
        name=request.form.get("name","").strip()
        if len(name)>1: getdb().execute("UPDATE users SET name=? WHERE id=?",(name,session["uid"])); getdb().commit(); return redirect("/profile")
        flash("Enter a valid name.","error")
    return page("Profile",r"""<section class="wrap formpage"><div class="panel"><label class="eyebrow">ACCOUNT SETTINGS</label><h1>Your profile</h1><p>{{u.email}} · {{u.role}}</p><form method="post" class="fields"><input type="hidden" name="csrf_token" value="{{csrf}}"><label>Full name<input name="name" value="{{u.name}}" required></label><button class="btn glow">Save profile</button></form></div></section>""",u=u)

@app.route("/security")
def security():
    return page("Security",r"""<section class="wrap section"><div class="sectiontitle"><label class="eyebrow">SECURITY BY DESIGN</label><h1>Research information<br><em>deserves protection.</em></h1><p>Foundational security controls help protect accounts and research records.</p></div><div class="grid">{% for h,t,d in [('⌑','Password hashing','Passwords are stored as secure hashes, not plain text.'),('♙','Authentication','Users must log in to access private project records.'),('◈','Role-based access','Administrator pages are restricted to administrator accounts.'),('⌘','SQL injection protection','Database queries use parameterized statements.'),('⛨','CSRF protection','State-changing forms use session-bound CSRF tokens.'),('▣','Security headers','Responses include browser security headers.')] %}<article class="tile"><i>{{h}}</i><h3>{{t}}</h3><p>{{d}}</p></article>{% endfor %}</div><p class="notice">Before public deployment configure HTTPS, a strong SECRET_KEY, secure cookies, production WSGI server, backups and monitoring.</p></section>""")

@app.route("/admin/users")
@admin_required
def admin_users():
    users=getdb().execute("SELECT * FROM users ORDER BY id").fetchall()
    return page("Administration",r"""<section class="wrap dash"><label class="eyebrow">ADMINISTRATION</label><h1>User <em>management.</em></h1><div class="panel tablebox"><table><tr><th>Name</th><th>Email</th><th>Role</th></tr>{% for u in users %}<tr><td>{{u.name}}</td><td>{{u.email}}</td><td>{{u.role}}</td></tr>{% endfor %}</table></div></section>""",users=users)

@app.errorhandler(403)
def forbidden(e): return page("Forbidden","<section class='wrap formpage'><h1>403</h1><p>You do not have permission to view this page.</p></section>"),403
@app.errorhandler(404)
def missing(e): return page("Not found","<section class='wrap formpage'><h1>404</h1><p>The requested page or project was not found.</p></section>"),404

if __name__=="__main__":
    init_db()
    app.run(host="127.0.0.1",port=int(os.environ.get("PORT","5000")),debug=False)
