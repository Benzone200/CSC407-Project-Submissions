# ExamSchedule — CSC 407

Academic examination scheduling system built with Next.js 16, React 19, TypeScript, Tailwind CSS, Supabase Auth and Supabase PostgreSQL. It provides role-specific administrator, student and invigilator workspaces with database-enforced scheduling rules, notifications and audit history.

## Authentication and authorization

Supabase Auth is the only active authentication provider. Email/password sign-in and sign-up are implemented with validated Server Actions. Sessions are stored in secure, HTTP-only cookies and refreshed by `src/proxy.ts` before protected server rendering.

Application roles are stored only in `public.profiles.role`:

- `admin`
- `student`
- `invigilator`

New accounts receive the `student` role from a database trigger. Sign-up metadata is used only for display names and cannot choose a role or account status. Protected layouts call `requireRole()`, and PostgreSQL RLS independently resolves the profile with `auth.uid()`.

`public.profiles.account_status` is either `active` or `restricted`. A restricted profile receives no role-based database access even when it calls Supabase directly.

### School account onboarding

All users authenticate through the same sign-up and sign-in pages. Authentication proves identity; `public.profiles.role` determines the workspace and database permissions:

- new self-service registrations default to `student`;
- an administrator completes the student's academic record and course enrolments;
- verified staff accounts are promoted to `invigilator`, then assigned a staff ID and department;
- additional administrators are promoted only through a trusted administrative operation.

The sign-up form never accepts an administrator or invigilator role. This prevents users from granting themselves privileged access. `/dashboard` reads the database-authoritative role and routes the user to `/student`, `/invigilator`, or `/admin`.

### Initial administrator

Create a normal Supabase Auth account, then promote its exact linked profile from the trusted Supabase SQL Editor:

```sql
update public.profiles
set role = 'admin', updated_at = now()
where auth_user_id = 'REPLACE_WITH_VERIFIED_SUPABASE_AUTH_UUID';
```

Confirm exactly one row changed. Never expose role promotion through browser input.

### Migrating existing Clerk-era profiles

Migration `20261116000100_migrate_to_supabase_auth.sql` preserves existing profile IDs and the student, invigilator, notification and audit relationships that reference them. Legacy `clerk_user_id` values remain only as migration evidence.

An existing profile is never linked automatically by matching email. First create the replacement Supabase Auth account and complete its email confirmation. Then a trusted operator must link the exact application profile UUID to the exact confirmed Auth user UUID from the Supabase SQL Editor:

```sql
select private.link_existing_profile_to_auth_user(
  'REPLACE_WITH_VERIFIED_PROFILE_UUID'::uuid,
  'REPLACE_WITH_CONFIRMED_AUTH_USER_UUID'::uuid
);
```

The function rejects missing or already-linked records, unconfirmed Auth emails and mismatched emails. Creating an Auth account with an old profile's email alone grants no application role; until the trusted exact-ID link is completed, that account has no application profile access.

## Environment

Copy `.env.example` to `.env.local` and provide:

```dotenv
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=your-publishable-key
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

Do not put service-role or secret keys in browser-visible variables. The application does not require a service-role key for ordinary authentication or data operations.

In the Supabase dashboard, enable email/password authentication and configure the site URL and redirect URL matching `NEXT_PUBLIC_SITE_URL` and `/auth/confirm`. If email confirmation is enabled, confirmation links return through that route.

## Database setup

Apply every migration in `supabase/migrations/` in timestamp order. The latest authentication migration is:

```text
20261116000100_migrate_to_supabase_auth.sql
```

It:

- adds `profiles.auth_user_id` referencing `auth.users`;
- adds database-managed account restriction status;
- replaces identity helpers and own-profile RLS with `auth.uid()`;
- creates default-student profiles for new Auth users;
- provides trusted exact-ID linking for confirmed legacy users;
- retains `clerk_user_id` only for controlled migration evidence.

The migration is validated by the disposable PostgreSQL integration harness. Every school deployment must apply all migrations to its own Supabase project before the application is opened to users.

## Run locally

```bash
pnpm install
cp .env.example .env.local
# Fill the Supabase values in .env.local
pnpm dev
```

Open `http://localhost:3000`.

## Verification

```bash
pnpm lint
pnpm exec tsc --noEmit
pnpm test
pnpm test:db
pnpm build
pnpm audit --prod
pnpm test:e2e
```

`pnpm verify` runs lint, TypeScript, automated tests and the production build. `pnpm test:db` creates a disposable PostgreSQL cluster, applies all migrations and tests RLS, lifecycle, conflict, role-escalation, restricted-account and provisioning behavior.

## Scheduling behavior

Administrators manage departments, courses, students, enrolments, venues, invigilators, examination sessions and schedules. Exams follow `draft → scheduled → published`, with supported unpublishing and cancellation. PostgreSQL triggers enforce:

- session date and semester consistency;
- venue capacity and active status;
- venue, invigilator and enrolled-student overlaps;
- valid lifecycle transitions and publication timestamps;
- role-compatible student/invigilator records;
- trusted append-only activity history.

Students see published exams only for matching enrolments. Invigilators see only assigned scheduled or published exams. Notifications are recipient-owned and RLS-protected.

## Keepalive

The optional keepalive workflow uses only the project URL and publishable key to call the narrow `keepalive_ping` RPC. It does not use an authentication secret or service-role key. Run locally with:

```bash
pnpm db:keepalive
```

## Deployment notes and current limitations

- Each target Supabase project requires project-owner configuration of migrations, email/password authentication, site URLs and redirect URLs.
- Existing Clerk users must create and confirm Supabase Auth credentials, then be linked through the trusted exact-ID procedure above.
- Authenticated Playwright role workflows require dedicated Supabase Auth test accounts.
- Deployment, automated timetable optimization and bulk academic-data import remain outside the project scope.

See `docs/completion/final-project-report.md` and `docs/completion/demo-guide.md` for submission and demonstration guidance.
