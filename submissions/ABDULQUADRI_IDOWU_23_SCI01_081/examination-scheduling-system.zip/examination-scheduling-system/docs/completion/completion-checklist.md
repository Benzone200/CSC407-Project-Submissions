# Completion Checklist

Status values: `COMPLETE`, `PARTIALLY COMPLETE`, `BLOCKED`, `NOT IMPLEMENTED`.

## Discovery and preservation

- [x] COMPLETE — Repository, routes, components, actions, queries, validation, migrations, tests and documentation inspected.
- [x] COMPLETE — Git status and existing keepalive, `.nia-runs/` and `Library/` work identified and preserved.
- [x] COMPLETE — Existing Next.js/Supabase architecture retained; Clerk was replaced with Supabase Auth on 2026-11-17.
- [ ] PARTIALLY COMPLETE — Linked migration history inspected on 2026-11-14; `20261111000100`, `20261113000100`, and `20261116000100` remain unconfirmed remotely.

## Dependencies

- [x] COMPLETE — Next.js and matching ESLint config upgraded to 16.4.6.
- [x] COMPLETE — Zod upgraded to 4.6.7.
- [x] COMPLETE — pnpm lockfile regenerated and production dependency audit reports zero advisories.

## Database and permissions

- [x] COMPLETE — Direct authenticated activity-log insertion revoked; sensitive history is trigger-generated.
- [x] COMPLETE — Schedule/session lifecycle, draft-only creation and database-owned publication timestamps enforced.
- [x] COMPLETE — Course, enrolment and examination-session semester consistency enforced.
- [x] COMPLETE — Linked student/invigilator profile-role consistency enforced in both directions.
- [x] COMPLETE — Venue capacity, venue availability and resource overlaps enforced.
- [x] COMPLETE — Duplicate enrolment and invalid relationships prevented.
- [x] COMPLETE — Rejected schedule transitions can recompute and persist factual conflict records from saved data.
- [x] COMPLETE — Publish/unpublish/cancel notifications and ownership-safe mark-as-read implemented.
- [x] COMPLETE — Executable PostgreSQL tests exercise triggers and direct RLS/API-style bypass attempts.

## Admin workspace

- [x] COMPLETE — Database-backed dashboard, sessions, upcoming exams, recent activity and statistics.
- [x] COMPLETE — Department create/view/edit/safe delete.
- [x] COMPLETE — Course create/view/edit/safe delete with department/semester validation.
- [x] COMPLETE — Student create/view/edit/safe delete, search/filter, enrol and unenrol.
- [x] COMPLETE — Venue create/view/edit/capacity/status/safe delete.
- [x] COMPLETE — Invigilator create/view/edit/safe delete and real assignment display.
- [x] COMPLETE — Session create/view/edit/delete and monotonic activate/complete/archive lifecycle.
- [x] COMPLETE — Draft/edit/schedule/publish/unpublish/cancel examination workflow.
- [x] COMPLETE — Confirmation controls and database transition enforcement.
- [x] COMPLETE — Conflict search/filter, explanations and examination links.
- [x] COMPLETE — Trusted read-only activity-log UI.
- [x] COMPLETE — User profile search and trusted-role inspection.
- [ ] NOT IMPLEMENTED — Browser role promotion/invitation UI is intentionally excluded; role promotion remains a trusted database operation.

## Student workspace

- [x] COMPLETE — Dashboard, eligible published exams, chronological timetable and empty states.
- [x] COMPLETE — Server-side course/date search with bounded pagination.
- [x] COMPLETE — Owned notifications, event generation and mark-as-read.
- [x] COMPLETE — Supabase Auth identity plus linked academic profile details and graceful missing-record state.

## Invigilator workspace

- [x] COMPLETE — Dashboard, paginated assigned exams, detail pages and timetable.
- [x] COMPLETE — Staff/department profile details and owned notifications.
- [x] COMPLETE — Assigned-only visibility verified by executable RLS integration test.

## UI, navigation and accessibility

- [x] COMPLETE — Every visible navigation destination has a functional route.
- [x] COMPLETE — Confirmation UI for lifecycle and destructive actions.
- [x] COMPLETE — Skip-to-content link, loading/error/empty states and mobile-menu focus restoration.
- [x] COMPLETE — Desktop and Pixel 7 public/protected-route Playwright smoke tests pass.
- [ ] PARTIALLY COMPLETE — Semantic labels and keyboard focus mechanics were reviewed; a formal screen-reader and measured contrast audit was not executed.

## Testing and automation

- [x] COMPLETE — ESLint, TypeScript, automated tests and production build pass.
- [x] COMPLETE — Real PostgreSQL migration/trigger/RLS integration suite passes.
- [x] COMPLETE — Direct activity-log, schedule, catalogue, conflict-RPC, role, notification and visibility bypass attempts are tested.
- [x] COMPLETE — A two-connection PostgreSQL race test verifies course/enrolment semester consistency under concurrent writes.
- [x] COMPLETE — 16/16 public and unauthenticated desktop/mobile Playwright checks pass using system Chrome.
- [x] COMPLETE — CI workflow gates lint, typecheck, tests, PostgreSQL integration, build, audit and browser smoke when secrets are configured.
- [ ] BLOCKED — Authenticated admin/student/invigilator Playwright workflows require dedicated Supabase Auth test-account credentials that were not provided.
- [ ] PARTIALLY COMPLETE — The 80% target is enforced for exercised utility modules only; whole-application statement/branch coverage was not measured.

## Documentation and submission

- [x] COMPLETE — README and public review/security/testing pages corrected.
- [x] COMPLETE — Implementation plan and this evidence-based checklist prepared.
- [x] COMPLETE — Final academic project report prepared.
- [x] COMPLETE — Administrator/student/invigilator demonstration guide prepared.
- [ ] PARTIALLY COMPLETE — Source is submission-ready, but remote migrations and authenticated credential-backed rehearsal remain operator steps.
