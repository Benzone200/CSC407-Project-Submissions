# Demonstration Guide

## Before the demonstration

1. Use a non-production Supabase project with email/password Auth enabled.
2. Confirm environment variables from `.env.example` are present in `.env.local`.
3. Inspect migration state:

   ```bash
   pnpm exec supabase migration list --linked
   ```

4. Review and apply pending migrations through the approved Supabase workflow. Do not demonstrate authentication or lifecycle claims against a database missing `20261116000100`.
5. Prepare three approved Supabase Auth accounts: administrator, student and invigilator. Do not put credentials in the repository or this guide.
6. Let each new account sign up so its student profile exists. Promote the approved admin and invigilator profiles through a trusted database session:

   ```sql
   update public.profiles
   set role = 'admin', updated_at = now()
   where auth_user_id = 'VERIFIED_ADMIN_AUTH_UUID';

   update public.profiles
   set role = 'invigilator', updated_at = now()
   where auth_user_id = 'VERIFIED_INVIGILATOR_AUTH_UUID';
   ```

7. Run `pnpm dev` and open `http://localhost:3000`.

## Administrator sequence

1. Sign in as the administrator and show the live database-backed `/admin` dashboard.
2. Open **Departments** and create/select a department.
3. Open **Courses** and create/select a course in the correct semester.
4. Open **Venues** and create/select an active venue with sufficient capacity.
5. Open **Invigilators** and assign the approved invigilator profile to a staff record; point out its real assignment list.
6. Open **Students**, assign the student profile to an academic record, use search/filter, and enrol the student in the course for the intended session/semester.
7. Open **Examination Sessions**, create a draft, edit it if needed, then activate it.
8. Open **Scheduling**, create a draft exam inside the session date range.
9. Select **Schedule and validate** and confirm the action. Explain that the database checks capacity, venue, invigilator and shared-student conflicts.
10. Select **Publish to students** and confirm.
11. Show the exam in **Timetable**, the updated dashboard and trusted **Activity Logs**.
12. Optionally demonstrate a rejected overlap using a second draft, then show its explanation under **Conflicts**. Do not modify real records merely for the demonstration.
13. Demonstrate **Unpublish** or **Cancel** only on disposable demo data; explain that cancellation is irreversible.

## Student sequence

1. Sign out and sign in as the enrolled student.
2. Show `/student` counts and upcoming examination card.
3. Open **My Exams** and **My Timetable**; confirm the published course, date, time and venue.
4. Open **Search Exams**, search by course code/title and filter by date.
5. Open **Notifications**, show the publication notification and mark it read.
6. Open **Profile** and show Supabase Auth identity plus matriculation number, level and department.
7. Explain that unpublished/cancelled exams and courses without a matching enrolment are excluded by RLS.

## Invigilator sequence

1. Sign out and sign in as the assigned invigilator.
2. Show `/invigilator` and the accurate assignment count.
3. Open **Assigned Exams**, then open the examination detail page.
4. Show **Timetable** with course, date, time and venue.
5. Show **Notifications** and mark the publication notification read.
6. Show **Profile** with staff ID and department.
7. Explain that an unassigned examination cannot be opened because the query is constrained by RLS.

## Security and quality evidence

Show, but do not rerun during a time-limited presentation unless requested:

```bash
pnpm test          # 55 passing at completion
pnpm test:db       # disposable PostgreSQL trigger/RLS suite
pnpm verify        # lint, TypeScript, tests and production build
pnpm audit --prod  # zero production advisories at completion
```

The public `/security`, `/testing` and `/review` routes summarize the implementation without claiming deployment.

## Honest fallback states

- If pending migrations have not been applied, demonstrate the local source/tests only and state that live database protections are not active remotely.
- If a role account is unavailable, do not reuse another role or invent credentials; show the route and executable RLS evidence instead.
- If there is no schedule data, show the honest empty states and create only disposable academic demo records.
- Deployment is outside this task and must not be claimed.
