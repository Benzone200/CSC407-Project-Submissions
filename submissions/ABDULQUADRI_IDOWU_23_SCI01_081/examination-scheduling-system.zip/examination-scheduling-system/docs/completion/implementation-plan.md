# Examination Scheduling System Completion Plan

## Purpose and constraints

Complete the existing Next.js and Supabase application for an academic demonstration without discarding its architecture or existing work. Authentication was subsequently migrated from Clerk to Supabase Auth through an additive identity/RLS migration. Changes preserve RLS, avoid destructive data operations, and do not deploy or mutate remote services as part of this task.

## Baseline discovery

### Working functionality

- Supabase Auth sign-in/sign-up, secure cookie session resolution, database-owned profile provisioning, and role-specific layouts.
- Supabase schema for profiles, departments, students, courses, enrolments, venues, invigilators, examination sessions, schedules, conflicts, notifications, and activity logs.
- Admin catalogue creation, limited course/venue edits, session creation/activation, schedule draft/edit/schedule/publish/unpublish/cancel workflows, timetable, dashboards, and activity views.
- Student published-exam dashboard, list, timetable, search, notifications display, and account profile.
- Invigilator assigned-exam dashboard, list, timetable, and profile.
- RLS policies, conflict/capacity/date triggers, append-only activity logs, validation schemas, build checks, and source-contract tests.
- Local keepalive script, RPC migration, tests, and GitHub Actions workflow are present as uncommitted work.

### Incomplete or broken functionality

- Vulnerable Next.js and Zod versions block release.
- Admin CRUD is incomplete: department/student/invigilator/session edits, safe deletion, and enrolment removal are missing.
- Database permits forged activity-log inserts and does not fully enforce schedule lifecycle, profile-role consistency, or semester relationships.
- Conflict attempts are rejected but not stored, leaving the conflict page without actionable records.
- Notification creation and mark-as-read are missing.
- Student search filters after a fixed fetch limit; large result sets are not paginated.
- Student profile omits linked academic data; admin user management shows only the current account.
- Important schedule actions lack confirmation.
- Mobile focus restoration, skip navigation, measured contrast checks, and manual accessibility verification are incomplete.
- Public review/security/testing pages describe an obsolete project state.
- Existing tests do not execute migrations or authenticated RLS behavior; there is no application CI or browser E2E suite.
- Keepalive migration is not applied remotely and the workflow is not committed/configured.

## Implementation stages

### Stage 1: Dependency and baseline remediation

1. Upgrade Next.js and matching ESLint config to a patched compatible 16.x release.
2. Upgrade Zod to a patched compatible 4.x release.
3. Regenerate the pnpm lockfile and rerun audit, lint, typecheck, tests, and build.
4. Preserve all existing unrelated untracked files.

Acceptance criteria:

- No known critical or high production dependency advisory remains where a compatible patch exists.
- Existing checks continue to pass.

### Stage 2: Database integrity and permissions

Create an additive migration that:

- Revokes direct authenticated inserts into activity logs while retaining trigger-generated entries.
- Enforces valid examination status transitions and published timestamp invariants.
- Enforces course, enrolment, and examination-session semester consistency.
- Enforces student/invigilator profile-role consistency.
- Adds safe admin update/delete policies and column grants required by completed CRUD.
- Stores rejected conflict attempts only where PostgreSQL transaction semantics permit reliable persistence; otherwise expose deterministic conflict explanations without claiming persistence.
- Adds notification creation and ownership-safe mark-as-read support.
- Adds indexes needed for search and pagination.

Acceptance criteria:

- Direct API writes cannot bypass critical invariants.
- Existing records are preserved; migrations contain no destructive bulk data cleanup.
- Migration order and remote-application status are documented.

### Stage 3: Admin workspace completion

- Complete edit and safe delete flows for departments, courses, students, enrolments, venues, invigilators, and sessions.
- Add useful search/filtering and relationship-aware empty/error states.
- Keep dashboard values database-driven.
- Add lifecycle confirmation controls and database-backed transition enforcement.
- Improve conflict explanations, filters, and linked resource details.
- Keep audit history trusted and read-only from ordinary clients.

Acceptance criteria:

- Every visible admin action performs a real validated operation.
- Unsafe deletion is rejected with a clear message.
- Scheduling conflicts never corrupt persisted schedules.

### Stage 4: Student and invigilator completion

- Move exam filtering/search into server-side database queries with pagination.
- Display linked student academic information.
- Create notifications for relevant publication/cancellation events and implement mark-as-read.
- Complete invigilator details and verify assigned-only visibility.
- Add complete loading, empty, and error behavior.

Acceptance criteria:

- Students see only published exams for their enrolments and their own notifications.
- Invigilators see only assigned scheduled/published exams.
- Large datasets do not silently disappear behind fixed fetch limits.

### Stage 5: Navigation, UI, and accessibility

- Remove stale/misleading controls and content.
- Add confirmation dialogs/forms for publish, unpublish, cancel, and destructive catalogue actions.
- Add skip navigation and restore mobile-menu focus.
- Normalize headings, feedback, buttons, tables, mobile layouts, and status messaging.
- Perform keyboard, responsive, and contrast checks.

Acceptance criteria:

- Every navigation destination and visible control is functional or honestly informational.
- Core workflows work at mobile and desktop widths and are keyboard operable.

### Stage 6: Testing and verification

- Extend unit tests for new validation, filtering, transitions, and permission helpers.
- Add executable database integration tests using local Supabase/PostgreSQL when available.
- Test direct database/API bypass attempts.
- Add minimal Playwright configuration and principal role workflows where safe test credentials are available.
- Add a CI workflow for lint, typecheck, tests, build, audit, and migration checks.

Acceptance criteria:

- All feasible checks run and their actual results are recorded.
- External-auth limitations are documented instead of simulated.

### Stage 7: Documentation and academic submission

- Correct README and public project/security/testing pages.
- Document architecture, schema, roles, scheduling rules, setup, test results, limitations, and demo data requirements.
- Create `final-project-report.md` and `demo-guide.md`.

Acceptance criteria:

- Documentation matches the implemented application and does not invent deployment, screenshots, or test results.

## Remote and external boundaries

- The linked Supabase project was active during discovery, but the keepalive migration was not applied remotely.
- New migrations will be validated locally where possible and left unapplied remotely unless separately authorized.
- GitHub workflow secrets, deployment, commits, and pushes remain operator steps.
- Dedicated Supabase Auth test accounts are required for fully automated authenticated E2E flows; credentials will not be invented.

## Final verification commands

```bash
pnpm install
pnpm lint
pnpm exec tsc --noEmit
pnpm test
pnpm build
pnpm audit
pnpm exec supabase migration list --linked
```

Additional database and Playwright commands will be documented when their harnesses are added.
