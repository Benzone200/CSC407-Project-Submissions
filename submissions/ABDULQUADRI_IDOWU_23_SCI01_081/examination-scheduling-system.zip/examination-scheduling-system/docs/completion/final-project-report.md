# Final Project Report

## 1. Project overview

ExamSchedule is a role-based university examination scheduling system for administrators, students and invigilators. The completed source supports academic catalogue management, examination-session planning, conflict-aware scheduling, publication, role-specific timetables, notifications and audit history.

**Overall verdict: PARTIALLY COMPLETE for live submission, COMPLETE at the local source/verification level.** The application code, local migrations and feasible automated checks are complete. Remote application of the latest migrations is unconfirmed, and authenticated browser workflows remain blocked on dedicated Supabase Auth test-account credentials.

## 2. Problem statement

Manual examination planning is vulnerable to room-capacity errors, venue clashes, double-booked invigilators and overlapping exams for students enrolled in multiple courses. Students and staff also need a controlled way to receive only the schedules relevant to them.

## 3. Project objectives

- Maintain departments, courses, students, enrolments, venues, invigilators and exam sessions.
- Create and manage examinations through a controlled lifecycle.
- reject capacity, venue, student and invigilator conflicts.
- Publish only validated examinations to eligible students.
- Restrict users to their own role and records.
- Preserve trusted administrative history and notify affected users.
- Provide a clean, demonstrable academic-project interface.

## 4. Technology stack

- Next.js 16.4.6 App Router and React 19.2.8
- TypeScript 5 and Tailwind CSS 4
- Supabase Auth for email/password authentication and sessions
- Supabase PostgreSQL and Row Level Security
- Zod 4.6.7 for server-boundary validation
- pnpm 11.10.0
- Node test runner and Playwright 1.65.0

## 5. System architecture

The browser renders Next.js server/client components. Supabase Auth verifies the session through secure cookies refreshed by the Next.js proxy. Server layouts and actions resolve a trusted profile from `auth.uid()` and authorize its database-backed role. RLS limits visible rows, while PostgreSQL constraints and triggers enforce critical scheduling rules even when a caller bypasses the UI. Server actions validate FormData with Zod, mutate through RLS, revalidate affected routes and redirect with user-facing results.

## 6. Main application components

- Public landing, security, testing and project-review pages.
- Shared protected shell with responsive navigation, skip link, loading/error states and Supabase sign-out controls.
- Admin dashboard, catalogue CRUD, user inspection, session lifecycle, scheduling, timetable, conflicts and activity logs.
- Student dashboard, exams, timetable, search, notifications and academic profile.
- Invigilator dashboard, assigned exams, detail view, timetable, notifications and staff profile.
- Server-side auth, catalogue, scheduling, validation, pagination and Supabase modules.

## 7. Database structure and relationships

`profiles` maps Supabase Auth UUIDs to application roles and account status. `students` and `invigilators` each reference a role-compatible profile and department. `courses` belong to departments and semesters. `course_enrollments` link students and courses for an academic session/semester with a uniqueness constraint. `exam_sessions` define the term and date window. `exam_schedules` link a session, course, venue and invigilator and expose a generated half-open time range. `schedule_conflicts`, `notifications` and `activity_logs` store derived operational records.

Foreign keys use restrictive deletion for academic relationships. Additive triggers enforce role consistency, academic-period consistency, venue availability/capacity, schedule/session lifecycle and overlaps.

## 8. User roles and permissions

- **Admin:** database-backed admin role; CRUD for academic records and examination operations.
- **Student:** only the student's profile, enrolments, notifications and published enrolled-course exams.
- **Invigilator:** only the invigilator's profile, notifications and assigned scheduled/published exams.

New profiles default to `student`. Browser input and Supabase user metadata cannot grant roles. Initial admin and invigilator promotion remain trusted database operations. Database-managed restricted accounts are redirected to `/restricted` and receive no role-based RLS access.

## 9. Examination scheduling process

1. Create academic catalogue and role-linked records.
2. Create a draft examination session and activate it.
3. Create an examination draft with course, venue, invigilator, date and time.
4. Move `draft → scheduled`; database triggers validate all conflicts.
5. Move `scheduled → published`; the database owns `published_at` and generates notifications.
6. Optionally unpublish to `scheduled` or cancel. Cancelled exams are immutable.

Only draft exam details can be edited. Sessions follow `draft → active → completed → archived`, and new sessions must start as drafts.

## 10. Conflict detection approach

PostgreSQL takes an advisory transaction lock for serialized validation. Scheduled/published exams reserve half-open `[start,end)` ranges, so adjacent exams are permitted. The trigger rejects:

- dates outside the selected active session;
- inactive venues;
- enrolment above venue capacity;
- overlapping use of a venue;
- overlapping assignment of an invigilator;
- overlap for any student enrolled in both courses.

After a rejected scheduling transition, an admin-only RPC recomputes factual conflict rows from the saved draft in a separate transaction. The frontend displays concise explanations and filters without exposing student identities.

## 11. Security measures

- Supabase Auth plus server-side role checks on layouts and every mutation.
- Supabase RLS for direct API protection.
- Zod validation for user-controlled identifiers, dates, terms, capacities and filters.
- Parameterized Supabase query builder; no browser-built SQL.
- Trigger-owned audit and notification creation.
- No authenticated insert privilege on activity logs.
- Server-only Supabase secret used only for idempotent missing-profile provisioning.
- Security response headers for framing, MIME sniffing, referrer and device permissions.
- Generic authentication errors and restricted-account handling.
- No secrets committed by this work.

## 12. Testing performed

Final verification executed on 2026-11-16:

- `pnpm test`: **55 passed, 0 failed**.
- Node test coverage for the imported/testable utility modules: **94.95% lines, 84.54% branches, 96.15% functions**. This is not presented as whole-application coverage.
- `pnpm test:db`: **passed**; all five migrations applied to disposable PostgreSQL 17 and trigger/RLS assertions passed.
- Database behavior exercised: migration order, audit anti-forgery, direct schedule/catalogue/role/RPC bypass attempts, draft-only creation, lifecycle, database-owned timestamps, venue capacity/status, venue/invigilator/student overlaps, profile roles, student visibility, notification ownership, invigilator assignment isolation and a two-connection course/enrolment race.
- `PLAYWRIGHT_USE_SYSTEM_CHROME=1 pnpm test:e2e -- --reporter=line`: **16 passed, 0 failed** across desktop and Pixel 7 projects.
- `pnpm lint`: passed.
- `pnpm exec tsc --noEmit`: passed.
- `pnpm build`: passed; 32 application routes were generated.
- `pnpm audit --prod` and `pnpm audit`: zero known advisories.

Authenticated Playwright role workflows were not executed because dedicated Supabase Auth test-account credentials were not provided. No test was run against production/student data.

## 13. Screens and routes implemented

- Public: `/`, `/sign-in`, `/sign-up`, `/security`, `/testing`, `/review`, `/restricted`.
- Admin: `/admin`, `/admin/departments`, `/admin/courses`, `/admin/students`, `/admin/venues`, `/admin/invigilators`, `/admin/sessions`, `/admin/scheduling`, `/admin/conflicts`, `/admin/timetable`, `/admin/users`, `/admin/activity-logs`.
- Student: `/student`, `/student/exams`, `/student/timetable`, `/student/search`, `/student/notifications`, `/student/profile`.
- Invigilator: `/invigilator`, `/invigilator/exams`, `/invigilator/exams/[id]`, `/invigilator/timetable`, `/invigilator/notifications`, `/invigilator/profile`.

## 14. Known limitations

- **PARTIALLY COMPLETE:** migrations through `20261116000100` are locally validated but remote application is unconfirmed.
- **BLOCKED:** authenticated Supabase Auth E2E needs safe development test accounts.
- **PARTIALLY COMPLETE:** no formal screen-reader/measured-contrast audit or whole-app 80% coverage report was produced.
- **NOT IMPLEMENTED by design:** browser role promotion, bulk import, automated timetable optimization and deployment.
- GitHub workflows are present locally but do not run until changes are committed/pushed and repository secrets are configured.

## 15. Setup and demonstration instructions

```bash
pnpm install
cp .env.example .env.local
# Fill Supabase development values in .env.local.
pnpm dev
```

Open `http://localhost:3000`. Before a live role-based demonstration, review/apply pending migrations to the intended non-production Supabase project and prepare one approved account per role. Use `docs/completion/demo-guide.md` for the sequence.

Verification commands:

```bash
pnpm lint
pnpm exec tsc --noEmit
pnpm test
pnpm test:db
pnpm build
pnpm audit --prod
pnpm test:e2e:install
pnpm test:e2e
```
