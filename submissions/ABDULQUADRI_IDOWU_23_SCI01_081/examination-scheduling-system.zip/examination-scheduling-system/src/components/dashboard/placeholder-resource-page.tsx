import type { LucideIcon } from "lucide-react";
import { EmptyState } from "./empty-state";
import { PageHeading } from "./page-heading";

export function PlaceholderResourcePage({ title, description, icon: Icon, actionLabel }: { title: string; description: string; icon: LucideIcon; actionLabel?: string }) {
  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Workspace" title={title} description={description} action={actionLabel ? <button disabled title="Available in a later phase" className="inline-flex h-10 items-center rounded-lg bg-violet-800 px-4 text-xs font-semibold text-white opacity-80">{actionLabel}</button> : undefined} />
    <section className="rounded-xl border border-slate-200/90 bg-white shadow-sm"><div className="border-b border-slate-100 px-5 py-4"><p className="text-sm font-semibold text-slate-900">{title} workspace</p><p className="mt-1 text-xs text-slate-500">This area is ready for the next implementation phase.</p></div><EmptyState icon={Icon} title={`No ${title.toLowerCase()} to display`} description="No database records are connected to this screen yet. This placeholder will show live information when the feature is implemented." /></section>
  </div>;
}
