import { CalendarDays, MapPin } from "lucide-react";
import type { getStudentExams } from "@/src/lib/scheduling/queries";
import Link from "next/link";

type StudentExam = Awaited<ReturnType<typeof getStudentExams>>[number];

export function StudentExamList({ exams, detailHref }: { exams: StudentExam[]; detailHref?: (id: string) => string }) {
  if (!exams.length) return <div className="rounded-xl border border-slate-200 bg-white px-5 py-12 text-center"><CalendarDays className="mx-auto size-8 text-violet-500" /><h2 className="mt-3 text-sm font-semibold text-slate-900">No published examinations found</h2><p className="mx-auto mt-1 max-w-md text-sm leading-6 text-slate-500">Published exams for your enrolled courses will appear here when they are available.</p></div>;

  return <ul className="divide-y divide-slate-100 overflow-hidden rounded-xl border border-slate-200 bg-white">
    {exams.map((exam) => <li key={exam.id} className="grid gap-2 px-5 py-4 sm:grid-cols-[minmax(0,1fr)_190px] sm:items-center">
      <div><p className="text-sm font-semibold text-slate-900">{exam.course.code} · {exam.course.title}</p><p className="mt-1 text-xs text-slate-500">{exam.session.name} · {exam.session.academic_session} · Semester {exam.session.semester}</p><p className="mt-2 inline-flex items-center gap-1.5 text-xs text-slate-600"><MapPin className="size-3.5" />{exam.venue.name} · {exam.venue.location}</p></div>
      <div className="text-sm text-slate-700 sm:text-right"><p className="font-medium">{exam.exam_date}</p><p className="mt-1 text-xs text-slate-500">{exam.start_time.slice(0, 5)}–{exam.end_time.slice(0, 5)}</p>{detailHref ? <Link href={detailHref(exam.id)} className="mt-2 inline-block text-xs font-semibold text-violet-800 hover:text-violet-950">View details</Link> : null}</div>
    </li>)}
  </ul>;
}
