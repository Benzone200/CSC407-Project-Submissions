import type { LucideIcon } from "lucide-react";

export function StatCard({ label, value = "—", detail, icon: Icon }: { label: string; value?: string; detail: string; icon: LucideIcon }) {
  return <article className="rounded-xl border border-slate-200/90 bg-white p-4 shadow-[0_1px_2px_rgba(25,15,40,.03)] sm:p-5">
    <div className="flex items-start justify-between gap-3"><p className="text-xs font-medium text-slate-500">{label}</p><span className="grid size-8 shrink-0 place-items-center rounded-lg bg-violet-50 text-violet-700"><Icon className="size-4" strokeWidth={1.8} /></span></div>
    <p className="mt-3 text-2xl font-semibold tracking-tight text-slate-900">{value}</p>
    <p className="mt-1 text-[11px] text-slate-500">{detail}</p>
  </article>;
}
