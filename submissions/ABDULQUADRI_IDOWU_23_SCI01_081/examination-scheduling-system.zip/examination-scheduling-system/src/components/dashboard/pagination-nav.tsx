import Link from "next/link";

export function PaginationNav({ page, totalPages, href }: { page: number; totalPages: number; href: (page: number) => string }) {
  if (totalPages <= 1) return null;
  return <nav aria-label="Pagination" className="mt-5 flex items-center justify-between gap-3">
    {page > 1 ? <Link href={href(page - 1)} className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50">Previous</Link> : <span />}
    <span className="text-xs text-slate-500">Page {page} of {totalPages}</span>
    {page < totalPages ? <Link href={href(page + 1)} className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50">Next</Link> : <span />}
  </nav>;
}
