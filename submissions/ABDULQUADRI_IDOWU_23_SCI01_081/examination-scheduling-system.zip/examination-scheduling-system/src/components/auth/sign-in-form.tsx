"use client";

import { useActionState } from "react";
import { signInAction, type AuthActionState } from "@/src/app/auth/actions";

const initialState: AuthActionState = {};

export function SignInForm() {
  const [state, action, pending] = useActionState(signInAction, initialState);
  return (
    <form action={action} className="mt-6 grid gap-4" noValidate>
      <label className="grid gap-1.5 text-sm font-medium text-slate-700">
        Email address
        <input name="email" type="email" autoComplete="email" required maxLength={254} className="h-11 rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-violet-700 focus:ring-2 focus:ring-violet-100" />
        {state.errors?.email?.map((error) => <span key={error} className="text-xs text-red-700">{error}</span>)}
      </label>
      <label className="grid gap-1.5 text-sm font-medium text-slate-700">
        Password
        <input name="password" type="password" autoComplete="current-password" required minLength={8} maxLength={128} className="h-11 rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-violet-700 focus:ring-2 focus:ring-violet-100" />
        {state.errors?.password?.map((error) => <span key={error} className="text-xs text-red-700">{error}</span>)}
      </label>
      {state.message ? <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-xs leading-5 text-red-800">{state.message}</p> : null}
      <button disabled={pending} className="mt-1 h-11 rounded-lg bg-violet-800 px-4 text-sm font-semibold text-white hover:bg-violet-900 disabled:cursor-not-allowed disabled:opacity-60">
        {pending ? "Signing in…" : "Sign in"}
      </button>
    </form>
  );
}
