"use client";

import { useActionState } from "react";
import { signUpAction, type AuthActionState } from "@/src/app/auth/actions";

const initialState: AuthActionState = {};

export function SignUpForm() {
  const [state, action, pending] = useActionState(signUpAction, initialState);
  return (
    <form action={action} className="mt-6 grid gap-4" noValidate>
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="grid gap-1.5 text-sm font-medium text-slate-700">First name<input name="firstName" autoComplete="given-name" required maxLength={100} className="h-11 rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-violet-700 focus:ring-2 focus:ring-violet-100" />{state.errors?.firstName?.map((error) => <span key={error} className="text-xs text-red-700">{error}</span>)}</label>
        <label className="grid gap-1.5 text-sm font-medium text-slate-700">Last name<input name="lastName" autoComplete="family-name" required maxLength={100} className="h-11 rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-violet-700 focus:ring-2 focus:ring-violet-100" />{state.errors?.lastName?.map((error) => <span key={error} className="text-xs text-red-700">{error}</span>)}</label>
      </div>
      <label className="grid gap-1.5 text-sm font-medium text-slate-700">Email address<input name="email" type="email" autoComplete="email" required maxLength={254} className="h-11 rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-violet-700 focus:ring-2 focus:ring-violet-100" />{state.errors?.email?.map((error) => <span key={error} className="text-xs text-red-700">{error}</span>)}</label>
      <label className="grid gap-1.5 text-sm font-medium text-slate-700">Password<input name="password" type="password" autoComplete="new-password" required minLength={8} maxLength={128} className="h-11 rounded-lg border border-slate-300 px-3 text-sm outline-none focus:border-violet-700 focus:ring-2 focus:ring-violet-100" />{state.errors?.password?.map((error) => <span key={error} className="text-xs text-red-700">{error}</span>)}</label>
      {state.message ? <p role={state.success ? "status" : "alert"} className={`rounded-lg px-3 py-2 text-xs leading-5 ${state.success ? "bg-emerald-50 text-emerald-800" : "bg-red-50 text-red-800"}`}>{state.message}</p> : null}
      <button disabled={pending || state.success} className="mt-1 h-11 rounded-lg bg-violet-800 px-4 text-sm font-semibold text-white hover:bg-violet-900 disabled:cursor-not-allowed disabled:opacity-60">{pending ? "Creating account…" : "Create account"}</button>
    </form>
  );
}
