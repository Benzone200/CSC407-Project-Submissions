import Link from "next/link";
import { LogOut } from "lucide-react";
import { getCurrentProfile } from "@/src/lib/auth/current-user";
import { signOutAction } from "@/src/app/auth/actions";
import { homeForRole } from "@/src/lib/auth/authorization-policy";
import { unstable_rethrow } from "next/navigation";

export async function SiteHeader() {
  let current: Awaited<ReturnType<typeof getCurrentProfile>> = null;
  try {
    current = await getCurrentProfile();
  } catch (error) {
    unstable_rethrow(error);
    current = null;
  }
  const displayName = current
    ? [current.profile.first_name, current.profile.last_name].filter(Boolean).join(" ") || current.profile.email
    : null;

  return <header className="border-b border-slate-200 bg-white/90 backdrop-blur">
    <nav aria-label="Main navigation" className="mx-auto flex h-16 w-full max-w-7xl items-center justify-between px-5 sm:px-8">
      <Link href="/" className="flex items-center gap-3"><span className="grid size-9 place-items-center rounded-xl bg-violet-800 text-sm font-bold text-white">E</span><span className="leading-tight"><span className="block text-sm font-semibold tracking-tight text-slate-950">ExamSchedule</span><span className="block text-xs text-slate-500">CSC 407</span></span></Link>
      <div className="flex items-center gap-3">
        {current ? <>
          <Link href={homeForRole(current.profile.role)} className="hidden rounded-lg px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 hover:text-slate-950 sm:inline-flex">Workspace</Link>
          <span className="hidden max-w-48 truncate text-sm text-slate-600 md:inline">{displayName}</span>
          <form action={signOutAction}><button aria-label="Sign out" title="Sign out" className="grid size-9 place-items-center rounded-full bg-violet-100 text-violet-800 hover:bg-violet-200"><LogOut className="size-4" /></button></form>
        </> : <>
          <Link href="/sign-in" className="rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100">Sign in</Link>
          <Link href="/sign-up" className="rounded-lg bg-violet-800 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-violet-900">Create account</Link>
        </>}
      </div>
    </nav>
  </header>;
}
