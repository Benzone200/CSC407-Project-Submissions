"use client";

import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { X } from "lucide-react";
import type { ApplicationRole } from "@/src/lib/auth/authorization-policy";
import { adminNavigation, invigilatorNavigation, studentNavigation, systemNavigation, type NavigationItem } from "./navigation";

type AppSidebarProps = { area: ApplicationRole; mobileOpen: boolean; onClose: () => void };

function NavigationGroup({ title, items, onNavigate }: { title: string; items: NavigationItem[]; onNavigate: () => void }) {
  const pathname = usePathname();
  return (
    <div className="mb-7">
      <p className="mb-2 px-3 text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-400">{title}</p>
      <nav aria-label={title} className="space-y-1">
        {items.map(({ label, href, icon: Icon }) => {
          const isAreaHome = ["/student", "/admin", "/invigilator"].includes(href);
          const active = pathname === href || (!isAreaHome && pathname.startsWith(`${href}/`));
          return (
            <Link key={href} href={href} onClick={onNavigate} aria-current={active ? "page" : undefined}
              className={`group flex min-h-10 items-center gap-3 rounded-lg px-3 text-[13px] font-medium transition-colors ${active ? "bg-violet-50 text-violet-800" : "text-slate-600 hover:bg-slate-50 hover:text-slate-950"}`}>
              <Icon aria-hidden="true" className={`size-[17px] shrink-0 ${active ? "text-violet-700" : "text-slate-400 group-hover:text-slate-600"}`} strokeWidth={1.8} />
              <span className="truncate">{label}</span>
              {active && <span className="ml-auto h-5 w-0.5 rounded-full bg-violet-600" />}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

export function AppSidebar({ area, mobileOpen, onClose }: AppSidebarProps) {
  const mobileDialogRef = useRef<HTMLElement>(null);
  const items = area === "admin" ? adminNavigation : area === "invigilator" ? invigilatorNavigation : studentNavigation;
  useEffect(() => {
    if (!mobileOpen) return;
    const dialog = mobileDialogRef.current;
    const focusable = dialog?.querySelectorAll<HTMLElement>('a[href], button:not([disabled])') ?? [];
    focusable[0]?.focus();
    const handleDialogKeys = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onClose();
      } else if (event.key === "Tab" && focusable.length > 0) {
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", handleDialogKeys);
    return () => document.removeEventListener("keydown", handleDialogKeys);
  }, [mobileOpen, onClose]);
  return (
    <>
      <aside id="application-navigation" aria-label={`${area} application navigation`} className="hidden w-[270px] shrink-0 flex-col border-r border-slate-200/80 bg-white px-4 pb-4 pt-5 md:flex">
        <SidebarContent area={area} items={items} onClose={onClose} />
      </aside>
      {mobileOpen && <>
      <button aria-label="Close navigation menu" tabIndex={-1} className="fixed inset-0 z-40 bg-slate-950/35 md:hidden" onClick={onClose} />
      <aside ref={mobileDialogRef} id="application-navigation-mobile" role="dialog" aria-modal="true" aria-label={`${area} application navigation`} className="fixed inset-y-0 left-0 z-50 flex w-[min(270px,calc(100vw-2rem))] flex-col border-r border-slate-200/80 bg-white px-4 pb-4 pt-5 shadow-xl md:hidden">
        <SidebarContent area={area} items={items} onClose={onClose} />
      </aside>
      </>}
    </>
  );
}

function SidebarContent({ area, items, onClose }: { area: ApplicationRole; items: NavigationItem[]; onClose: () => void }) {
  return <>
        <div className="mb-8 flex items-center justify-between px-2">
          <Link href={area === "admin" ? "/admin" : area === "invigilator" ? "/invigilator" : "/student"} onClick={onClose} className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-xl bg-violet-800 text-white"><span className="text-sm font-bold">E</span></span>
            <span><span className="block text-[15px] font-semibold tracking-tight text-slate-950">ExamSchedule</span><span className="block text-[11px] text-slate-500">CSC 407 workspace</span></span>
          </Link>
          <button onClick={onClose} aria-label="Close menu" className="rounded-md p-2 text-slate-500 hover:bg-slate-100 md:hidden"><X className="size-4" /></button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto">
          <NavigationGroup title={area === "admin" ? "Administration" : area === "invigilator" ? "Invigilator workspace" : "Student workspace"} items={items} onNavigate={onClose} />
          <NavigationGroup title="Project" items={systemNavigation} onNavigate={onClose} />
        </div>
        <div className="rounded-xl border border-violet-100 bg-violet-50/70 p-3.5">
          <p className="text-xs font-semibold text-violet-950">Examination planning</p>
          <p className="mt-1 text-[11px] leading-5 text-violet-900/70">A shared workspace for a more coordinated exam period.</p>
        </div>
  </>;
}
