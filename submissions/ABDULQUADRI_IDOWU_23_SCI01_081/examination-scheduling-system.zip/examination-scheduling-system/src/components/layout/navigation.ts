import {
  Activity, Bell, BookOpen, CalendarDays, ClipboardCheck, GraduationCap,
  LayoutDashboard, Search, ShieldCheck, SlidersHorizontal, Users, UserRound,
  UserRoundCog, Building2, DoorOpen, AlertTriangle, FlaskConical, FileSearch,
  type LucideIcon,
} from "lucide-react";

export type NavigationItem = { label: string; href: string; icon: LucideIcon };

export const studentNavigation: NavigationItem[] = [
  { label: "Student Dashboard", href: "/student", icon: LayoutDashboard },
  { label: "My Timetable", href: "/student/timetable", icon: CalendarDays },
  { label: "My Exams", href: "/student/exams", icon: ClipboardCheck },
  { label: "Search Exams", href: "/student/search", icon: Search },
  { label: "Notifications", href: "/student/notifications", icon: Bell },
  { label: "Profile", href: "/student/profile", icon: UserRound },
];

export const invigilatorNavigation: NavigationItem[] = [
  { label: "Invigilator Dashboard", href: "/invigilator", icon: LayoutDashboard },
  { label: "Assigned Exams", href: "/invigilator/exams", icon: ClipboardCheck },
  { label: "Timetable", href: "/invigilator/timetable", icon: CalendarDays },
  { label: "Notifications", href: "/invigilator/notifications", icon: Bell },
  { label: "Profile", href: "/invigilator/profile", icon: UserRound },
];

export const adminNavigation: NavigationItem[] = [
  { label: "Admin Dashboard", href: "/admin", icon: LayoutDashboard },
  { label: "Examination Sessions", href: "/admin/sessions", icon: CalendarDays },
  { label: "Courses", href: "/admin/courses", icon: BookOpen },
  { label: "Students", href: "/admin/students", icon: GraduationCap },
  { label: "Departments", href: "/admin/departments", icon: Building2 },
  { label: "Venues", href: "/admin/venues", icon: DoorOpen },
  { label: "Invigilators", href: "/admin/invigilators", icon: UserRoundCog },
  { label: "Scheduling", href: "/admin/scheduling", icon: SlidersHorizontal },
  { label: "Conflicts", href: "/admin/conflicts", icon: AlertTriangle },
  { label: "Timetable", href: "/admin/timetable", icon: ClipboardCheck },
  { label: "Users", href: "/admin/users", icon: Users },
  { label: "Activity Logs", href: "/admin/activity-logs", icon: Activity },
];

export const systemNavigation: NavigationItem[] = [
  { label: "Security", href: "/security", icon: ShieldCheck },
  { label: "Testing", href: "/testing", icon: FlaskConical },
  { label: "Project review", href: "/review", icon: FileSearch },
];
