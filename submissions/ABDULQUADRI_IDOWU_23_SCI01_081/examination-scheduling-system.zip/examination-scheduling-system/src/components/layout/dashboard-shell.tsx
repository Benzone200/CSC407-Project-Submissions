"use client";

import { useCallback, useRef, useState, type ReactNode } from "react";
import { AppHeader } from "./app-header";
import { AppSidebar } from "./app-sidebar";
import type { ApplicationRole } from "@/src/lib/auth/authorization-policy";

export function DashboardShell({ area, displayName, children }: { area: ApplicationRole; displayName: string; children: ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const menuButtonRef = useRef<HTMLButtonElement>(null);
  const closeMobileNav = useCallback(() => {
    setMobileOpen(false);
    requestAnimationFrame(() => menuButtonRef.current?.focus());
  }, []);
  return (
    <div className="flex min-h-screen bg-[#faf9fc]">
      <a href="#main-content" className="fixed left-4 top-4 z-[60] -translate-y-24 rounded-lg bg-violet-900 px-4 py-2 text-sm font-semibold text-white shadow-lg transition-transform focus:translate-y-0">
        Skip to main content
      </a>
      <AppSidebar area={area} mobileOpen={mobileOpen} onClose={closeMobileNav} />
      <div className="flex min-w-0 flex-1 flex-col">
        <AppHeader area={area} displayName={displayName} menuButtonRef={menuButtonRef} onMenuClick={() => mobileOpen ? closeMobileNav() : setMobileOpen(true)} mobileNavOpen={mobileOpen} />
        <main id="main-content" tabIndex={-1} className="min-w-0 flex-1 outline-none">{children}</main>
        <footer className="border-t border-slate-200/80 px-6 py-4 text-center text-[11px] text-slate-500">ExamSchedule · CSC 407 Examination Scheduling System</footer>
      </div>
    </div>
  );
}
