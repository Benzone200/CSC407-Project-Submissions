"use client";

import { Bell, LogOut, Menu } from "lucide-react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import type { RefObject } from "react";
import { adminNavigation, studentNavigation, systemNavigation } from "./navigation";
import type { ApplicationRole } from "@/src/lib/auth/authorization-policy";
import { invigilatorNavigation } from "./navigation";
import { signOutAction } from "@/src/app/auth/actions";

export function AppHeader({ area, displayName, menuButtonRef, onMenuClick, mobileNavOpen }: { area: ApplicationRole; displayName: string; menuButtonRef: RefObject<HTMLButtonElement | null>; onMenuClick: () => void; mobileNavOpen: boolean }) {
  const pathname = usePathname();
  const allItems = [...studentNavigation, ...adminNavigation, ...invigilatorNavigation, ...systemNavigation];
  const current = allItems.find((item) => item.href === pathname);
  return (
    <header className="sticky top-0 z-30 flex h-[68px] items-center justify-between border-b border-slate-200/80 bg-white/95 px-4 backdrop-blur sm:px-7">
      <div className="flex min-w-0 items-center gap-3">
        <button ref={menuButtonRef} onClick={onMenuClick} aria-label={mobileNavOpen ? "Close navigation menu" : "Open navigation menu"} aria-controls="application-navigation-mobile" aria-expanded={mobileNavOpen} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 md:hidden"><Menu aria-hidden="true" className="size-5" /></button>
        <div className="min-w-0"><p className="truncate text-sm font-semibold text-slate-950">{current?.label ?? (area === "admin" ? "Administration" : area === "invigilator" ? "Invigilator workspace" : "Student workspace")}</p><p className="hidden text-xs text-slate-500 sm:block">{area === "admin" ? "Examination operations" : "Your examination workspace"}</p></div>
      </div>
      <div className="flex items-center gap-3 sm:gap-4">
        <Link href={area === "admin" ? "/admin/conflicts" : area === "invigilator" ? "/invigilator/exams" : "/student/notifications"} aria-label={area === "admin" ? "View conflicts" : area === "invigilator" ? "View assigned exams" : "View notifications"} title={area === "admin" ? "Conflicts" : area === "invigilator" ? "Assigned exams" : "Notifications"} className="relative rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 hover:text-violet-800"><Bell className="size-[18px]" strokeWidth={1.8} /></Link>
        <span className="hidden max-w-48 truncate text-right text-xs font-medium text-slate-700 sm:block">{displayName}</span>
        <form action={signOutAction}><button aria-label="Sign out" title="Sign out" className="grid size-9 place-items-center rounded-full bg-violet-100 text-violet-800 hover:bg-violet-200"><LogOut className="size-4" /></button></form>
      </div>
    </header>
  );
}
