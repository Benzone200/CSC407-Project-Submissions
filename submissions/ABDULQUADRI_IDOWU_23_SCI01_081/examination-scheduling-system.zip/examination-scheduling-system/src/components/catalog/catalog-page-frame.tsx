import type { ReactNode } from "react";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { createCatalogRecord } from "@/src/app/admin/catalog-actions";

const resultMessages: Record<string, string> = {
  saved: "Record added.",
  updated: "Changes saved.",
  invalid: "Check the required fields and use valid values.",
  duplicate: "A record with one of these unique values already exists.",
  capacity: "The new capacity is below the enrollment count for a scheduled examination.",
  profile: "Choose an unassigned profile with the matching application role.",
  unavailable: "The record could not be saved. Check that its references are valid, then try again.",
  enrolled: "Enrollment added.",
  deleted: "Record deleted.",
  unenrolled: "Enrollment removed.",
  referenced: "This record is still in use and cannot be deleted.",
  period: "The academic period does not match the selected course.",
};

export function CatalogPageFrame({
  title,
  description,
  result,
  form,
  records,
}: {
  title: string;
  description: string;
  result?: string;
  form: ReactNode;
  records: ReactNode;
}) {
  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Administration" title={title} description={description} />
    {result && resultMessages[result] ? <p role="status" className="mb-5 rounded-lg border border-violet-200 bg-violet-50 px-4 py-3 text-sm text-violet-900">{resultMessages[result]}</p> : null}
    <div className="grid gap-6 xl:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)]">
      {form}
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-100 px-5 py-4"><h2 className="font-semibold text-slate-900">Current records</h2><p className="mt-1 text-xs text-slate-500">Live data from the secured application database.</p></div>
        {records}
      </section>
    </div>
  </div>;
}

export function CatalogForm({ entity, title, hint, children }: { entity: string; title: string; hint: string; children: ReactNode }) {
  return <form action={createCatalogRecord} className="h-fit rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
    <h2 className="font-semibold text-slate-900">{title}</h2>
    <p className="mb-5 mt-1 text-xs leading-5 text-slate-500">{hint}</p>
    <input type="hidden" name="entity" value={entity} />
    {children}
  </form>;
}

export function RecordList({ records, emptyText }: { records: { id: string; label: string; detail?: string }[]; emptyText: string }) {
  return records.length ? <ul className="divide-y divide-slate-100">{records.map((record) => <li key={record.id} className="px-5 py-4"><p className="text-sm font-medium text-slate-900">{record.label}</p>{record.detail ? <p className="mt-1 text-xs text-slate-500">{record.detail}</p> : null}</li>)}</ul> : <p className="px-5 py-10 text-center text-sm text-slate-500">{emptyText}</p>;
}

export const catalogField = "h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-700 outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100";

export function CatalogField({ label, name, ...props }: { label: string; name: string; type?: string; min?: number; max?: number; maxLength?: number; pattern?: string; placeholder?: string; required?: boolean; defaultValue?: string; children?: ReactNode }) {
  return <label className="block"><span className="mb-1.5 block text-xs font-medium text-slate-700">{label}</span><input name={name} {...props} className={catalogField} /></label>;
}

export function CatalogSelect({ label, name, options, placeholder }: { label: string; name: string; options: { id: string; label: string }[]; placeholder: string }) {
  return <label className="block"><span className="mb-1.5 block text-xs font-medium text-slate-700">{label}</span><select name={name} required defaultValue="" className={catalogField}><option value="" disabled>{placeholder}</option>{options.map((option) => <option key={option.id} value={option.id}>{option.label}</option>)}</select></label>;
}

export function CatalogSubmit({ children = "Add record", disabled = false }: { children?: string; disabled?: boolean }) {
  return <button disabled={disabled} className="mt-5 h-10 rounded-lg bg-violet-800 px-4 text-sm font-semibold text-white hover:bg-violet-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-700 disabled:cursor-not-allowed disabled:opacity-50">{children}</button>;
}
