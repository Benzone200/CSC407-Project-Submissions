"use client";

import type { ButtonHTMLAttributes, MouseEvent } from "react";
import { useFormStatus } from "react-dom";

type ConfirmSubmitButtonProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, "type"> & {
  confirmation: string;
  pendingLabel?: string;
};

export function ConfirmSubmitButton({ children, confirmation, disabled, onClick, pendingLabel = "Working…", ...props }: ConfirmSubmitButtonProps) {
  const { pending } = useFormStatus();

  function handleClick(event: MouseEvent<HTMLButtonElement>) {
    onClick?.(event);
    if (!event.defaultPrevented && !window.confirm(confirmation)) event.preventDefault();
  }

  return <button {...props} type="submit" disabled={disabled || pending} aria-disabled={disabled || pending} onClick={handleClick}>
    {pending ? pendingLabel : children}
  </button>;
}
