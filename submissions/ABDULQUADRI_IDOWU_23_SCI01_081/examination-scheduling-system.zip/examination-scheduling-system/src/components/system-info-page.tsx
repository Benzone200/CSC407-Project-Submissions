import type { ReactNode } from "react";
import { SiteHeader } from "./site-header";

export function SystemInfoPage({ eyebrow, title, description, children }: { eyebrow: string; title: string; description: string; children: ReactNode }) {
  return <div className="min-h-screen bg-[#faf9fc]"><SiteHeader /><main className="mx-auto w-full max-w-6xl px-5 py-10 sm:px-8 sm:py-14"><div className="max-w-3xl"><p className="text-xs font-semibold uppercase tracking-[.15em] text-violet-700">{eyebrow}</p><h1 className="mt-3 text-3xl font-semibold tracking-tight text-slate-950 sm:text-4xl">{title}</h1><p className="mt-3 text-sm leading-6 text-slate-600 sm:text-base">{description}</p></div><div className="mt-8">{children}</div></main><footer className="border-t border-slate-200 bg-white px-5 py-5 text-center text-xs text-slate-500">ExamSchedule · CSC 407 Examination Scheduling System</footer></div>;
}
