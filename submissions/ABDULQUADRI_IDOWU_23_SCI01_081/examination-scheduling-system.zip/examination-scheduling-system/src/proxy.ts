import { createClient } from "@supabase/supabase-js";
import { NextResponse, type NextRequest } from "next/server";
import { getSupabasePublicEnv } from "@/src/lib/supabase/env";
import { authCookieOptions, createAuthCookieMutations, readAuthCookie } from "@/src/lib/supabase/auth-cookies";

export default async function proxy(request: NextRequest) {
  const { url, publishableKey } = getSupabasePublicEnv();
  const pendingCookies = new Map<string, string | null>();
  const supabase = createClient(url, publishableKey, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: true,
      flowType: "pkce",
      storage: {
        getItem(key) {
          return readAuthCookie(key, (name) => request.cookies.get(name)?.value);
        },
        setItem(key, value) {
          const mutations = createAuthCookieMutations(
            key,
            value,
            (name) => request.cookies.get(name)?.value,
          );
          for (const mutation of mutations) {
            if (mutation.value === null) request.cookies.delete(mutation.name);
            else request.cookies.set(mutation.name, mutation.value);
            pendingCookies.set(mutation.name, mutation.value);
          }
        },
        removeItem(key) {
          const mutations = createAuthCookieMutations(
            key,
            null,
            (name) => request.cookies.get(name)?.value,
          );
          for (const mutation of mutations) {
            request.cookies.delete(mutation.name);
            pendingCookies.set(mutation.name, null);
          }
        },
      },
    },
  });

  await supabase.auth.getClaims();
  const response = NextResponse.next({ request });
  for (const [name, value] of pendingCookies) {
    if (value === null) response.cookies.delete(name);
    else response.cookies.set(name, value, authCookieOptions);
  }
  if (pendingCookies.size > 0) {
    response.headers.set("Cache-Control", "private, no-store");
    response.headers.set("Pragma", "no-cache");
    response.headers.set("Expires", "0");
  }
  return response;
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)",
  ],
};
