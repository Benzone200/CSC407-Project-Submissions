import "server-only";

import { requireRole } from "@/src/lib/auth/current-user";
import { createServerSupabaseClient } from "@/src/lib/supabase/server";

export async function getAdminCatalogWorkspace() {
  await requireRole("admin");
  const supabase = await createServerSupabaseClient();
  const [departments, courses, venues, students, invigilators, studentProfiles, invigilatorProfiles, enrollments] = await Promise.all([
    supabase.from("departments").select("id,name,code").order("name"),
    supabase.from("courses").select("id,department_id,code,title,level,credit_units,semester").order("code"),
    supabase.from("venues").select("id,name,location,capacity,status").order("name"),
    supabase.from("students").select("id,profile_id,matric_number,department_id,level").order("matric_number"),
    supabase.from("invigilators").select("id,profile_id,staff_id,department_id").order("staff_id"),
    supabase.from("profiles").select("id,email,first_name,last_name").eq("role", "student").order("email"),
    supabase.from("profiles").select("id,email,first_name,last_name").eq("role", "invigilator").order("email"),
    supabase.from("course_enrollments").select("id,student_id,course_id,academic_session,semester").order("created_at", { ascending: false }),
  ]);
  if (departments.error || !departments.data || courses.error || !courses.data || venues.error || !venues.data
    || students.error || !students.data || invigilators.error || !invigilators.data
    || studentProfiles.error || !studentProfiles.data || invigilatorProfiles.error || !invigilatorProfiles.data
    || enrollments.error || !enrollments.data) {
    throw new Error("Catalogue data is temporarily unavailable.");
  }
  const assignedStudentIds = new Set(students.data.map((item) => item.profile_id));
  const assignedInvigilatorIds = new Set(invigilators.data.map((item) => item.profile_id));
  return {
    departments: departments.data,
    courses: courses.data,
    venues: venues.data,
    students: students.data,
    invigilators: invigilators.data,
    studentProfiles: studentProfiles.data.filter((profile) => !assignedStudentIds.has(profile.id)),
    invigilatorProfiles: invigilatorProfiles.data.filter((profile) => !assignedInvigilatorIds.has(profile.id)),
    allStudentProfiles: studentProfiles.data,
    allInvigilatorProfiles: invigilatorProfiles.data,
    enrollments: enrollments.data,
  };
}

export async function getAdminProfiles() {
  await requireRole("admin");
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase
    .from("profiles")
    .select("id,auth_user_id,email,first_name,last_name,role,account_status,created_at,updated_at")
    .order("created_at", { ascending: false })
    .limit(500);
  if (error) throw new Error("User profiles are temporarily unavailable.");
  return data;
}
