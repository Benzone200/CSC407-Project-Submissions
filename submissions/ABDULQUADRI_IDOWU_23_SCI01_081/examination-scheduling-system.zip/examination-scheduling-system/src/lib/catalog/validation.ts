import { z } from "zod";

const id = z.string().uuid();
const code = z.string().trim().toUpperCase().regex(/^[A-Z0-9][A-Z0-9_-]{1,19}$/);
const level = z.coerce.number().int().refine((value) => [100, 200, 300, 400, 500, 600].includes(value));
const semester = z.coerce.number().int().refine((value) => value === 1 || value === 2);

export const catalogInputSchema = z.discriminatedUnion("entity", [
  z.object({ entity: z.literal("department"), name: z.string().trim().min(1).max(160), code: code.max(16) }),
  z.object({ entity: z.literal("course"), department_id: id, code, title: z.string().trim().min(1).max(200), level, credit_units: z.coerce.number().int().min(1).max(30), semester }),
  z.object({ entity: z.literal("venue"), name: z.string().trim().min(1).max(160), location: z.string().trim().min(1).max(240), capacity: z.coerce.number().int().positive(), status: z.enum(["active", "inactive", "maintenance"]) }),
  z.object({ entity: z.literal("student"), profile_id: id, matric_number: z.string().trim().min(1).max(40), department_id: id, level }),
  z.object({ entity: z.literal("invigilator"), profile_id: id, staff_id: z.string().trim().min(1).max(40), department_id: id }),
  z.object({ entity: z.literal("enrollment"), student_id: id, course_id: id, academic_session: z.string().regex(/^\d{4}\/\d{4}$/), semester }),
]);

export const catalogEditInputSchema = z.discriminatedUnion("entity", [
  z.object({
    entity: z.literal("department"),
    id,
    name: z.string().trim().min(1).max(160),
    code: code.max(16),
  }),
  z.object({
    entity: z.literal("course"),
    id,
    department_id: id,
    code,
    title: z.string().trim().min(1).max(200),
    level,
    credit_units: z.coerce.number().int().min(1).max(30),
    semester,
  }),
  z.object({
    entity: z.literal("venue"),
    id,
    name: z.string().trim().min(1).max(160),
    location: z.string().trim().min(1).max(240),
    capacity: z.coerce.number().int().positive(),
    status: z.enum(["active", "inactive", "maintenance"]),
  }),
  z.object({
    entity: z.literal("student"),
    id,
    matric_number: z.string().trim().min(1).max(40),
    department_id: id,
    level,
  }),
  z.object({
    entity: z.literal("invigilator"),
    id,
    staff_id: z.string().trim().min(1).max(40),
    department_id: id,
  }),
]);

export const catalogDeleteInputSchema = z.object({
  entity: z.enum(["department", "course", "venue", "student", "invigilator", "enrollment"]),
  id,
});

export type CatalogInput = z.infer<typeof catalogInputSchema>;
export type CatalogEditInput = z.infer<typeof catalogEditInputSchema>;
export type CatalogDeleteInput = z.infer<typeof catalogDeleteInputSchema>;
