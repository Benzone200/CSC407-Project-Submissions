import "server-only";

import { cache } from "react";
import { redirect, unstable_rethrow } from "next/navigation";
import { z } from "zod";
import { createServerSupabaseClient } from "@/src/lib/supabase/server";
import {
  applicationRoles,
  assertAccountActive,
  assertRoleAccess,
  ForbiddenAuthorizationError,
  homeForRole,
  RestrictedAccountError,
  type ApplicationRole,
} from "./authorization-policy";

const applicationRoleSchema = z.enum(applicationRoles);
const accountStatusSchema = z.enum(["active", "restricted"]);

export type CurrentApplicationUser = {
  authUserId: string;
  accountStatus: "active" | "restricted";
  profile: {
    id: string;
    auth_user_id: string;
    email: string;
    first_name: string;
    last_name: string;
    role: ApplicationRole;
    account_status: "active" | "restricted";
    created_at: string;
    updated_at: string;
  };
};

export class CurrentProfileUnavailableError extends Error {
  constructor() {
    super("Your application profile is temporarily unavailable. Please try again later.");
    this.name = "CurrentProfileUnavailableError";
  }
}

/** Resolve a verified Supabase Auth subject to its database-authoritative profile. */
export const getCurrentProfile = cache(async (): Promise<CurrentApplicationUser | null> => {
  try {
    const supabase = await createServerSupabaseClient();
    const { data: claimsData, error: claimsError } = await supabase.auth.getClaims();
    const authUserId = claimsData?.claims?.sub;
    if (claimsError || typeof authUserId !== "string") return null;

    const ownProfile = await supabase
      .from("profiles")
      .select("id, auth_user_id, email, first_name, last_name, role, account_status, created_at, updated_at")
      .eq("auth_user_id", authUserId)
      .maybeSingle();

    if (ownProfile.error || !ownProfile.data) throw new CurrentProfileUnavailableError();
    const role = applicationRoleSchema.safeParse(ownProfile.data.role);
    const status = accountStatusSchema.safeParse(ownProfile.data.account_status);
    if (!role.success || !status.success || ownProfile.data.auth_user_id !== authUserId) {
      throw new CurrentProfileUnavailableError();
    }

    return {
      authUserId,
      accountStatus: status.data,
      profile: { ...ownProfile.data, auth_user_id: authUserId, role: role.data, account_status: status.data },
    };
  } catch (error) {
    unstable_rethrow(error);
    if (error instanceof CurrentProfileUnavailableError) throw error;
    throw new CurrentProfileUnavailableError();
  }
});

export async function requireAuthenticatedUser(): Promise<CurrentApplicationUser> {
  const current = await getCurrentProfile();
  if (!current) redirect("/sign-in");
  try {
    assertAccountActive(current.accountStatus);
  } catch (error) {
    if (error instanceof RestrictedAccountError) redirect("/restricted");
    throw error;
  }
  return current;
}

export async function requireRole(role: ApplicationRole): Promise<CurrentApplicationUser> {
  return requireAnyRole([role]);
}

export async function requireAnyRole(roles: readonly ApplicationRole[]): Promise<CurrentApplicationUser> {
  const current = await requireAuthenticatedUser();
  try {
    assertRoleAccess(current.profile.role, roles);
  } catch (error) {
    if (error instanceof ForbiddenAuthorizationError) redirect(homeForRole(current.profile.role));
    throw error;
  }
  return current;
}
