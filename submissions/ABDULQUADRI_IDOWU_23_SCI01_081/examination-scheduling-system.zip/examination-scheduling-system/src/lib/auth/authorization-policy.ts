export const applicationRoles = ["admin", "student", "invigilator"] as const;

export type ApplicationRole = (typeof applicationRoles)[number];

export class UnauthenticatedAuthorizationError extends Error {
  constructor() {
    super("Authentication is required.");
    this.name = "UnauthenticatedAuthorizationError";
  }
}

export class ForbiddenAuthorizationError extends Error {
  constructor() {
    super("This account does not have access to this area.");
    this.name = "ForbiddenAuthorizationError";
  }
}

export class RestrictedAccountError extends Error {
  constructor() {
    super("This account is restricted and cannot access the application.");
    this.name = "RestrictedAccountError";
  }
}

export function assertAccountActive(
  status: "active" | "restricted",
): asserts status is "active" {
  if (status !== "active") throw new RestrictedAccountError();
}

export function assertRoleAccess(
  role: ApplicationRole | null,
  allowedRoles: readonly ApplicationRole[],
): asserts role is ApplicationRole {
  if (!role) throw new UnauthenticatedAuthorizationError();
  if (!allowedRoles.includes(role)) throw new ForbiddenAuthorizationError();
}

export function homeForRole(role: ApplicationRole): string {
  switch (role) {
    case "admin":
      return "/admin";
    case "student":
      return "/student";
    case "invigilator":
      return "/invigilator";
  }
}
