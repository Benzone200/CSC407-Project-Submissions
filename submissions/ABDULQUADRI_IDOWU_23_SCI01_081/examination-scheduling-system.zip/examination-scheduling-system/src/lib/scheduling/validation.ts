import { z } from "zod";

const dateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine((value) => {
  const parsed = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(parsed.valueOf()) && parsed.toISOString().slice(0, 10) === value;
}, "Enter a valid date.");

const timeSchema = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Enter a valid 24-hour time.");
const uuidSchema = z.string().uuid();

export const examSessionInputSchema = z.object({
  name: z.string().trim().min(1).max(160),
  academic_session: z.string().regex(/^\d{4}\/\d{4}$/),
  semester: z.coerce.number().int().refine((value) => value === 1 || value === 2),
  start_date: dateSchema,
  end_date: dateSchema,
}).refine((value) => value.end_date >= value.start_date, {
  path: ["end_date"],
  message: "The end date must be on or after the start date.",
});

export const examSessionEditSchema = examSessionInputSchema.and(z.object({ id: uuidSchema }));

export const examScheduleInputSchema = z.object({
  id: z.union([z.literal(""), uuidSchema]).optional(),
  exam_session_id: uuidSchema,
  course_id: uuidSchema,
  venue_id: uuidSchema,
  invigilator_id: uuidSchema,
  exam_date: dateSchema,
  start_time: timeSchema,
  end_time: timeSchema,
}).refine((value) => value.end_time > value.start_time, {
  path: ["end_time"],
  message: "The end time must be after the start time.",
});

export const studentExamFilterSchema = z.object({
  query: z.string().trim().max(100).optional(),
  date: dateSchema.optional(),
});

export function overlapsHalfOpen(
  first: { start: number; end: number },
  second: { start: number; end: number },
): boolean {
  return first.start < second.end && second.start < first.end;
}

export function isWithinPeriod(date: string, startDate: string, endDate: string): boolean {
  return date >= startDate && date <= endDate;
}

export function toMinutes(time: string): number {
  const [hours, minutes] = time.split(":").map(Number);
  return (hours ?? 0) * 60 + (minutes ?? 0);
}
