import { z } from "zod";

export const examStatuses = ["draft", "scheduled", "published", "cancelled"] as const;

const dateSchema = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine((value) => {
  const date = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(date.valueOf()) && date.toISOString().slice(0, 10) === value;
});

export const adminExamFilterSchema = z.object({
  query: z.string().trim().max(100).optional(),
  status: z.enum(examStatuses).optional(),
  date: dateSchema.optional(),
  sessionId: z.string().uuid().optional(),
});

export type AdminExamFilters = {
  query?: string;
  status?: (typeof examStatuses)[number];
  date?: string;
  sessionId?: string;
};

export type FilterableAdminExam = {
  id: string;
  exam_session_id: string;
  course_id: string;
  venue_id: string;
  invigilator_id: string;
  exam_date: string;
  start_time: string;
  end_time: string;
  status: string;
  courseCode: string;
  courseTitle: string;
  examDate: string;
  examSessionId: string;
  sessionName: string;
};

export function filterAdminExams<T extends FilterableAdminExam>(
  exams: readonly T[],
  filters: AdminExamFilters,
): T[] {
  const query = filters.query?.trim().toLocaleLowerCase();

  return exams.filter((exam) => {
    if (filters.status && exam.status !== filters.status) return false;
    if (filters.date && exam.examDate !== filters.date) return false;
    if (filters.sessionId && exam.examSessionId !== filters.sessionId) return false;
    if (!query) return true;

    return `${exam.courseCode} ${exam.courseTitle} ${exam.sessionName}`
      .toLocaleLowerCase()
      .includes(query);
  });
}
