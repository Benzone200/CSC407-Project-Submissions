const defaultPageSize = 25;
const maximumPageSize = 50;

export type PaginationInput = {
  page?: number;
  pageSize?: number;
};

export type Pagination = {
  page: number;
  pageSize: number;
  from: number;
  to: number;
};

export function normalizePagination(input: PaginationInput = {}): Pagination {
  const page = Number.isSafeInteger(input.page) && (input.page ?? 0) > 0
    ? input.page as number
    : 1;
  const requestedSize = Number.isSafeInteger(input.pageSize) && (input.pageSize ?? 0) > 0
    ? input.pageSize as number
    : defaultPageSize;
  const pageSize = Math.min(requestedSize, maximumPageSize);
  const from = (page - 1) * pageSize;

  return { page, pageSize, from, to: from + pageSize - 1 };
}

export function totalPages(total: number, pageSize: number): number {
  return Math.max(1, Math.ceil(total / pageSize));
}

export function parsePage(value: string | undefined): number {
  if (!value || !/^\d+$/.test(value)) return 1;
  const page = Number(value);
  return Number.isSafeInteger(page) && page > 0 ? page : 1;
}
