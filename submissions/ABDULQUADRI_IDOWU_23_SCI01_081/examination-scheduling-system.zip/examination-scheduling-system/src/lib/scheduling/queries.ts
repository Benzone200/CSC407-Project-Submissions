import "server-only";

import { requireRole } from "@/src/lib/auth/current-user";
import { createServerSupabaseClient } from "@/src/lib/supabase/server";
import type { Database } from "@/src/lib/supabase/database.types";
import { normalizePagination, totalPages, type PaginationInput } from "./pagination";

type ScheduleListRow = Pick<
  Database["public"]["Tables"]["exam_schedules"]["Row"],
  "id" | "exam_session_id" | "course_id" | "venue_id" | "exam_date" | "start_time" | "end_time" | "status"
>;

async function enrichExamSchedules(
  supabase: Awaited<ReturnType<typeof createServerSupabaseClient>>,
  schedules: ScheduleListRow[],
) {
  if (!schedules.length) return [];

  const courseIds = [...new Set(schedules.map((row) => row.course_id))];
  const venueIds = [...new Set(schedules.map((row) => row.venue_id))];
  const sessionIds = [...new Set(schedules.map((row) => row.exam_session_id))];
  const [coursesResult, venuesResult, sessionsResult] = await Promise.all([
    supabase.from("courses").select("id,code,title").in("id", courseIds),
    supabase.from("venues").select("id,name,location").in("id", venueIds),
    supabase.from("exam_sessions").select("id,name,academic_session,semester").in("id", sessionIds),
  ]);
  if (coursesResult.error || venuesResult.error || sessionsResult.error) {
    throw new Error("Examination details are temporarily unavailable.");
  }

  const coursesById = new Map(coursesResult.data.map((course) => [course.id, course]));
  const venuesById = new Map(venuesResult.data.map((venue) => [venue.id, venue]));
  const sessionsById = new Map(sessionsResult.data.map((session) => [session.id, session]));
  return schedules.flatMap((schedule) => {
    const course = coursesById.get(schedule.course_id);
    const venue = venuesById.get(schedule.venue_id);
    const session = sessionsById.get(schedule.exam_session_id);
    return course && venue && session ? [{ ...schedule, course, venue, session }] : [];
  });
}

export function campusDateKey(date = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Africa/Lagos",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const part = (type: Intl.DateTimeFormatPartTypes) => parts.find((value) => value.type === type)?.value ?? "";
  return `${part("year")}-${part("month")}-${part("day")}`;
}

export async function getAdminScheduleWorkspace() {
  await requireRole("admin");
  const supabase = await createServerSupabaseClient();
  const [sessions, schedules, courses, venues, invigilators] = await Promise.all([
    supabase.from("exam_sessions").select("id,name,academic_session,semester,start_date,end_date,status").order("start_date", { ascending: false }),
    supabase.from("exam_schedules").select("id,exam_session_id,course_id,venue_id,invigilator_id,exam_date,start_time,end_time,status,published_at").order("exam_date", { ascending: true }),
    supabase.from("courses").select("id,department_id,code,title,semester,level").order("code"),
    supabase.from("venues").select("id,name,location,capacity,status").eq("status", "active").order("name"),
    supabase.from("invigilators").select("id,staff_id,profile_id").order("staff_id"),
  ]);

  if (sessions.error || schedules.error || courses.error || venues.error || invigilators.error) {
    throw new Error("Scheduling data is temporarily unavailable.");
  }

  return {
    sessions: sessions.data,
    schedules: schedules.data,
    courses: courses.data,
    venues: venues.data,
    invigilators: invigilators.data,
  };
}

export async function getInvigilatorExamPage(input: PaginationInput = {}) {
  await requireRole("invigilator");
  const supabase = await createServerSupabaseClient();
  const pagination = normalizePagination(input);
  const { data: schedules, error, count } = await supabase
    .from("exam_schedules")
    .select("id,exam_session_id,course_id,venue_id,exam_date,start_time,end_time,status", { count: "exact" })
    .in("status", ["scheduled", "published"])
    .order("exam_date", { ascending: true })
    .order("start_time", { ascending: true })
    .range(pagination.from, pagination.to);
  if (error) throw new Error("Assigned examination data is temporarily unavailable.");
  const total = count ?? 0;
  return {
    items: await enrichExamSchedules(supabase, schedules),
    page: pagination.page,
    pageSize: pagination.pageSize,
    total,
    totalPages: totalPages(total, pagination.pageSize),
  };
}

export async function getInvigilatorExams() {
  return (await getInvigilatorExamPage({ pageSize: 50 })).items;
}

export async function getInvigilatorExamById(id: string) {
  await requireRole("invigilator");
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase
    .from("exam_schedules")
    .select("id,exam_session_id,course_id,venue_id,exam_date,start_time,end_time,status")
    .eq("id", id)
    .in("status", ["scheduled", "published"])
    .maybeSingle();
  if (error) throw new Error("Assigned examination data is temporarily unavailable.");
  if (!data) return null;
  return (await enrichExamSchedules(supabase, [data]))[0] ?? null;
}

export async function getInvigilatorProfileDetails() {
  const current = await requireRole("invigilator");
  const supabase = await createServerSupabaseClient();
  const { data: record, error } = await supabase
    .from("invigilators")
    .select("id,staff_id,department_id")
    .eq("profile_id", current.profile.id)
    .maybeSingle();
  if (error) throw new Error("Invigilator profile data is temporarily unavailable.");
  if (!record) return null;
  const { data: department, error: departmentError } = await supabase
    .from("departments")
    .select("id,name,code")
    .eq("id", record.department_id)
    .maybeSingle();
  if (departmentError) throw new Error("Invigilator profile data is temporarily unavailable.");
  return { ...record, department };
}

export async function getAdminConflicts() {
  await requireRole("admin");
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase
    .from("schedule_conflicts")
    .select("id,exam_schedule_id,conflict_type,severity,description,resolved,resolved_at,created_at")
    .order("created_at", { ascending: false })
    .limit(200);
  if (error || !data) throw new Error("Conflict records are temporarily unavailable.");
  return data;
}

export async function getAdminActivityLogs() {
  await requireRole("admin");
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase
    .from("activity_logs")
    .select("id,profile_id,action,entity_type,entity_id,metadata,created_at")
    .order("created_at", { ascending: false })
    .limit(200);
  if (error || !data) throw new Error("Activity history is temporarily unavailable.");
  const profileIds = [...new Set(data.flatMap((entry) => entry.profile_id ? [entry.profile_id] : []))];
  const { data: profiles, error: profilesError } = profileIds.length
    ? await supabase.from("profiles").select("id,first_name,last_name,email").in("id", profileIds)
    : { data: [], error: null };
  if (profilesError || !profiles) throw new Error("Activity history is temporarily unavailable.");
  const profilesById = new Map(profiles.map((profile) => [profile.id, profile]));
  return data.map((entry) => ({
    ...entry,
    actor: entry.profile_id ? profilesById.get(entry.profile_id) ?? null : null,
  }));
}

export async function getStudentNotifications() {
  await requireRole("student");
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase
    .from("notifications")
    .select("id,type,title,message,read_at,created_at")
    .order("created_at", { ascending: false })
    .limit(100);
  if (error || !data) throw new Error("Notification data is temporarily unavailable.");
  return data;
}

export async function getInvigilatorNotifications() {
  await requireRole("invigilator");
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase
    .from("notifications")
    .select("id,type,title,message,read_at,created_at")
    .order("created_at", { ascending: false })
    .limit(100);
  if (error) throw new Error("Notification data is temporarily unavailable.");
  return data;
}

export async function getAdminSessions() {
  await requireRole("admin");
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase
    .from("exam_sessions")
    .select("id,name,academic_session,semester,start_date,end_date,status")
    .order("start_date", { ascending: false });
  if (error) throw new Error("Examination session data is temporarily unavailable.");
  return data;
}

export type StudentExamFilters = PaginationInput & {
  query?: string;
  date?: string;
  dateFrom?: string;
  dateBefore?: string;
};

export async function getStudentExamPage(filters: StudentExamFilters = {}) {
  await requireRole("student");
  const supabase = await createServerSupabaseClient();
  const pagination = normalizePagination(filters);
  const normalizedQuery = filters.query?.trim();
  let matchingCourseIds: string[] | null = null;

  if (normalizedQuery) {
    const pattern = `%${normalizedQuery}%`;
    const [codes, titles] = await Promise.all([
      supabase.from("courses").select("id").ilike("code", pattern),
      supabase.from("courses").select("id").ilike("title", pattern),
    ]);
    if (codes.error || titles.error) {
      throw new Error("Published examination search is temporarily unavailable.");
    }
    matchingCourseIds = [...new Set([...codes.data, ...titles.data].map((course) => course.id))];
    if (!matchingCourseIds.length) {
      return { items: [], page: pagination.page, pageSize: pagination.pageSize, total: 0, totalPages: 1 };
    }
  }

  let scheduleQuery = supabase
    .from("exam_schedules")
    .select("id,exam_session_id,course_id,venue_id,exam_date,start_time,end_time,status", { count: "exact" })
    .eq("status", "published")
    .order("exam_date", { ascending: true })
    .order("start_time", { ascending: true })
    .range(pagination.from, pagination.to);

  if (filters.date) scheduleQuery = scheduleQuery.eq("exam_date", filters.date);
  if (filters.dateFrom) scheduleQuery = scheduleQuery.gte("exam_date", filters.dateFrom);
  if (filters.dateBefore) scheduleQuery = scheduleQuery.lt("exam_date", filters.dateBefore);
  if (matchingCourseIds) scheduleQuery = scheduleQuery.in("course_id", matchingCourseIds);

  const { data: schedules, error: scheduleError, count } = await scheduleQuery;
  if (scheduleError) throw new Error("Published examination data is temporarily unavailable.");
  const total = count ?? 0;
  return {
    items: await enrichExamSchedules(supabase, schedules),
    page: pagination.page,
    pageSize: pagination.pageSize,
    total,
    totalPages: totalPages(total, pagination.pageSize),
  };
}

export async function getStudentExams(filters: StudentExamFilters = {}) {
  return (await getStudentExamPage({ ...filters, pageSize: filters.pageSize ?? 50 })).items;
}

export async function getStudentDashboardData(today = campusDateKey()) {
  const upcoming = await getStudentExamPage({ dateFrom: today, pageSize: 5 });
  const completed = await getStudentExamPage({ dateBefore: today, pageSize: 1 });
  return {
    upcoming: upcoming.items,
    total: upcoming.total + completed.total,
    upcomingCount: upcoming.total,
    completedCount: completed.total,
  };
}

export async function getStudentProfileDetails() {
  const current = await requireRole("student");
  const supabase = await createServerSupabaseClient();
  const { data: record, error } = await supabase
    .from("students")
    .select("id,matric_number,department_id,level")
    .eq("profile_id", current.profile.id)
    .maybeSingle();
  if (error) throw new Error("Student profile data is temporarily unavailable.");
  if (!record) return null;
  const { data: department, error: departmentError } = await supabase
    .from("departments")
    .select("id,name,code")
    .eq("id", record.department_id)
    .maybeSingle();
  if (departmentError) throw new Error("Student profile data is temporarily unavailable.");
  return { ...record, department };
}
