// Generated from the applied Supabase migration schema. Regenerate with pnpm db:types after applying migrations locally.
export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export type Database = {
  public: {
    Tables: {
      "activity_logs": {
        Row: {
        "id": string
        "profile_id": string | null
        "action": string
        "entity_type": string
        "entity_id": string | null
        "metadata": Json
        "created_at": string
        }
        Insert: {
        "id"?: string
        "profile_id"?: string | null
        "action": string
        "entity_type": string
        "entity_id"?: string | null
        "metadata"?: Json
        "created_at"?: string
        }
        Update: {
        "id"?: string
        "profile_id"?: string | null
        "action"?: string
        "entity_type"?: string
        "entity_id"?: string | null
        "metadata"?: Json
        "created_at"?: string
        }
        Relationships: [
        { foreignKeyName: "activity_logs_profile_id_fkey"; columns: ["profile_id"]; isOneToOne: false; referencedRelation: "profiles"; referencedColumns: ["id"] }
        ]
      }
      "course_enrollments": {
        Row: {
        "id": string
        "student_id": string
        "course_id": string
        "academic_session": string
        "semester": number
        "created_at": string
        }
        Insert: {
        "id"?: string
        "student_id": string
        "course_id": string
        "academic_session": string
        "semester": number
        "created_at"?: string
        }
        Update: {
        "id"?: string
        "student_id"?: string
        "course_id"?: string
        "academic_session"?: string
        "semester"?: number
        "created_at"?: string
        }
        Relationships: [
        { foreignKeyName: "course_enrollments_course_id_fkey"; columns: ["course_id"]; isOneToOne: false; referencedRelation: "courses"; referencedColumns: ["id"] },
        { foreignKeyName: "course_enrollments_student_id_fkey"; columns: ["student_id"]; isOneToOne: false; referencedRelation: "students"; referencedColumns: ["id"] },
        ]
      }
      "courses": {
        Row: {
        "id": string
        "department_id": string
        "code": string
        "title": string
        "level": number
        "credit_units": number
        "semester": number
        "created_at": string
        "updated_at": string
        }
        Insert: {
        "id"?: string
        "department_id": string
        "code": string
        "title": string
        "level": number
        "credit_units": number
        "semester": number
        "created_at"?: string
        "updated_at"?: string
        }
        Update: {
        "id"?: string
        "department_id"?: string
        "code"?: string
        "title"?: string
        "level"?: number
        "credit_units"?: number
        "semester"?: number
        "created_at"?: string
        "updated_at"?: string
        }
        Relationships: [
        { foreignKeyName: "courses_department_id_fkey"; columns: ["department_id"]; isOneToOne: false; referencedRelation: "departments"; referencedColumns: ["id"] }
        ]
      }
      "departments": {
        Row: {
        "id": string
        "name": string
        "code": string
        "created_at": string
        "updated_at": string
        }
        Insert: {
        "id"?: string
        "name": string
        "code": string
        "created_at"?: string
        "updated_at"?: string
        }
        Update: {
        "id"?: string
        "name"?: string
        "code"?: string
        "created_at"?: string
        "updated_at"?: string
        }
        Relationships: [

        ]
      }
      "exam_schedules": {
        Row: {
        "id": string
        "exam_session_id": string
        "course_id": string
        "venue_id": string
        "invigilator_id": string
        "exam_date": string
        "start_time": string
        "end_time": string
        "scheduled_period": string
        "status": string
        "published_at": string | null
        "created_at": string
        "updated_at": string
        }
        Insert: {
        "id"?: string
        "exam_session_id": string
        "course_id": string
        "venue_id": string
        "invigilator_id": string
        "exam_date": string
        "start_time": string
        "end_time": string
        "scheduled_period"?: never
        "status"?: string
        "published_at"?: string | null
        "created_at"?: string
        "updated_at"?: string
        }
        Update: {
        "id"?: string
        "exam_session_id"?: string
        "course_id"?: string
        "venue_id"?: string
        "invigilator_id"?: string
        "exam_date"?: string
        "start_time"?: string
        "end_time"?: string
        "scheduled_period"?: never
        "status"?: string
        "published_at"?: string | null
        "created_at"?: string
        "updated_at"?: string
        }
        Relationships: [
        { foreignKeyName: "exam_schedules_course_id_fkey"; columns: ["course_id"]; isOneToOne: false; referencedRelation: "courses"; referencedColumns: ["id"] },
        { foreignKeyName: "exam_schedules_exam_session_id_fkey"; columns: ["exam_session_id"]; isOneToOne: false; referencedRelation: "exam_sessions"; referencedColumns: ["id"] },
        { foreignKeyName: "exam_schedules_invigilator_id_fkey"; columns: ["invigilator_id"]; isOneToOne: false; referencedRelation: "invigilators"; referencedColumns: ["id"] },
        { foreignKeyName: "exam_schedules_venue_id_fkey"; columns: ["venue_id"]; isOneToOne: false; referencedRelation: "venues"; referencedColumns: ["id"] },
        ]
      }
      "exam_sessions": {
        Row: {
        "id": string
        "name": string
        "academic_session": string
        "semester": number
        "start_date": string
        "end_date": string
        "status": string
        "created_at": string
        "updated_at": string
        }
        Insert: {
        "id"?: string
        "name": string
        "academic_session": string
        "semester": number
        "start_date": string
        "end_date": string
        "status"?: string
        "created_at"?: string
        "updated_at"?: string
        }
        Update: {
        "id"?: string
        "name"?: string
        "academic_session"?: string
        "semester"?: number
        "start_date"?: string
        "end_date"?: string
        "status"?: string
        "created_at"?: string
        "updated_at"?: string
        }
        Relationships: [

        ]
      }
      "invigilators": {
        Row: {
        "id": string
        "profile_id": string
        "staff_id": string
        "department_id": string
        "created_at": string
        "updated_at": string
        }
        Insert: {
        "id"?: string
        "profile_id": string
        "staff_id": string
        "department_id": string
        "created_at"?: string
        "updated_at"?: string
        }
        Update: {
        "id"?: string
        "profile_id"?: string
        "staff_id"?: string
        "department_id"?: string
        "created_at"?: string
        "updated_at"?: string
        }
        Relationships: [
        { foreignKeyName: "invigilators_department_id_fkey"; columns: ["department_id"]; isOneToOne: false; referencedRelation: "departments"; referencedColumns: ["id"] },
        { foreignKeyName: "invigilators_profile_id_fkey"; columns: ["profile_id"]; isOneToOne: true; referencedRelation: "profiles"; referencedColumns: ["id"] },
        ]
      }
      "notifications": {
        Row: {
        "id": string
        "profile_id": string
        "type": string
        "title": string
        "message": string
        "read_at": string | null
        "created_at": string
        }
        Insert: {
        "id"?: string
        "profile_id": string
        "type": string
        "title": string
        "message": string
        "read_at"?: string | null
        "created_at"?: string
        }
        Update: {
        "id"?: string
        "profile_id"?: string
        "type"?: string
        "title"?: string
        "message"?: string
        "read_at"?: string | null
        "created_at"?: string
        }
        Relationships: [
        { foreignKeyName: "notifications_profile_id_fkey"; columns: ["profile_id"]; isOneToOne: false; referencedRelation: "profiles"; referencedColumns: ["id"] }
        ]
      }
      "profiles": {
        Row: {
        "account_status": string
        "auth_user_id": string | null
        "id": string
        "clerk_user_id": string | null
        "email": string
        "first_name": string
        "last_name": string
        "role": "admin" | "student" | "invigilator"
        "created_at": string
        "updated_at": string
        }
        Insert: {
        "account_status"?: string
        "auth_user_id"?: string | null
        "id"?: string
        "clerk_user_id"?: string | null
        "email": string
        "first_name"?: string
        "last_name"?: string
        "role": "admin" | "student" | "invigilator"
        "created_at"?: string
        "updated_at"?: string
        }
        Update: {
        "account_status"?: string
        "auth_user_id"?: string | null
        "id"?: string
        "clerk_user_id"?: string | null
        "email"?: string
        "first_name"?: string
        "last_name"?: string
        "role"?: "admin" | "student" | "invigilator"
        "created_at"?: string
        "updated_at"?: string
        }
        Relationships: [

        ]
      }
      "schedule_conflicts": {
        Row: {
        "id": string
        "exam_schedule_id": string
        "conflict_type": string
        "severity": string
        "description": string
        "resolved": boolean
        "resolved_at": string | null
        "created_at": string
        }
        Insert: {
        "id"?: string
        "exam_schedule_id": string
        "conflict_type": string
        "severity"?: string
        "description": string
        "resolved"?: boolean
        "resolved_at"?: string | null
        "created_at"?: string
        }
        Update: {
        "id"?: string
        "exam_schedule_id"?: string
        "conflict_type"?: string
        "severity"?: string
        "description"?: string
        "resolved"?: boolean
        "resolved_at"?: string | null
        "created_at"?: string
        }
        Relationships: [
        { foreignKeyName: "schedule_conflicts_exam_schedule_id_fkey"; columns: ["exam_schedule_id"]; isOneToOne: false; referencedRelation: "exam_schedules"; referencedColumns: ["id"] }
        ]
      }
      "students": {
        Row: {
        "id": string
        "profile_id": string
        "matric_number": string
        "department_id": string
        "level": number
        "created_at": string
        "updated_at": string
        }
        Insert: {
        "id"?: string
        "profile_id": string
        "matric_number": string
        "department_id": string
        "level": number
        "created_at"?: string
        "updated_at"?: string
        }
        Update: {
        "id"?: string
        "profile_id"?: string
        "matric_number"?: string
        "department_id"?: string
        "level"?: number
        "created_at"?: string
        "updated_at"?: string
        }
        Relationships: [
        { foreignKeyName: "students_department_id_fkey"; columns: ["department_id"]; isOneToOne: false; referencedRelation: "departments"; referencedColumns: ["id"] },
        { foreignKeyName: "students_profile_id_fkey"; columns: ["profile_id"]; isOneToOne: true; referencedRelation: "profiles"; referencedColumns: ["id"] },
        ]
      }
      "venues": {
        Row: {
        "id": string
        "name": string
        "location": string
        "capacity": number
        "status": string
        "created_at": string
        "updated_at": string
        }
        Insert: {
        "id"?: string
        "name": string
        "location": string
        "capacity": number
        "status"?: string
        "created_at"?: string
        "updated_at"?: string
        }
        Update: {
        "id"?: string
        "name"?: string
        "location"?: string
        "capacity"?: number
        "status"?: string
        "created_at"?: string
        "updated_at"?: string
        }
        Relationships: [

        ]
      }
    }
    Views: { [_ in never]: never }
    Functions: {
      keep_project_active: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      refresh_schedule_conflicts: {
        Args: { p_schedule_id: string }
        Returns: number
      }
    }
    Enums: { [_ in never]: never }
    CompositeTypes: { [_ in never]: never }
  }
}
