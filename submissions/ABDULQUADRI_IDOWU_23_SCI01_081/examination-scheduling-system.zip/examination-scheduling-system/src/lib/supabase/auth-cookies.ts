export const authCookieOptions = {
  httpOnly: true,
  sameSite: "lax",
  secure: process.env.NODE_ENV === "production",
  path: "/",
} as const;

const AUTH_COOKIE_CHUNK_SIZE = 3_000;
const MAX_AUTH_COOKIE_CHUNKS = 32;

export type AuthCookieMutation = Readonly<{
  name: string;
  value: string | null;
}>;

export function encodeAuthCookie(value: string): string {
  return Buffer.from(value, "utf8").toString("base64url");
}

export function decodeAuthCookie(value: string): string | null {
  try {
    return Buffer.from(value, "base64url").toString("utf8");
  } catch {
    return null;
  }
}

export function authCookieName(storageKey: string): string {
  return `exam-schedule-${storageKey}`;
}

function authCookieChunkCountName(storageKey: string): string {
  return `${authCookieName(storageKey)}.chunks`;
}

function authCookieChunkName(storageKey: string, index: number): string {
  return `${authCookieName(storageKey)}.${index}`;
}

function parseChunkCount(value: string | undefined): number | null {
  if (!value || !/^\d+$/.test(value)) return null;
  const count = Number(value);
  return Number.isSafeInteger(count) && count >= 1 && count <= MAX_AUTH_COOKIE_CHUNKS
    ? count
    : null;
}

export function readAuthCookie(
  storageKey: string,
  getCookie: (name: string) => string | undefined,
): string | null {
  const count = parseChunkCount(getCookie(authCookieChunkCountName(storageKey)));
  if (count !== null) {
    const chunks = Array.from({ length: count }, (_, index) =>
      getCookie(authCookieChunkName(storageKey, index)),
    );
    if (chunks.some((chunk) => chunk === undefined)) return null;
    return decodeAuthCookie(chunks.join(""));
  }

  const legacyValue = getCookie(authCookieName(storageKey));
  return legacyValue ? decodeAuthCookie(legacyValue) : null;
}

export function createAuthCookieMutations(
  storageKey: string,
  value: string | null,
  getCookie: (name: string) => string | undefined,
): readonly AuthCookieMutation[] {
  const countName = authCookieChunkCountName(storageKey);
  const previousCountValue = getCookie(countName);
  const previousCount = parseChunkCount(previousCountValue);
  const cleanupCount = previousCount ?? (previousCountValue ? MAX_AUTH_COOKIE_CHUNKS : 0);
  const mutations = new Map<string, string | null>([
    [authCookieName(storageKey), null],
    [countName, null],
  ]);

  for (let index = 0; index < cleanupCount; index += 1) {
    mutations.set(authCookieChunkName(storageKey, index), null);
  }

  if (value !== null) {
    const encoded = encodeAuthCookie(value);
    const chunks = encoded.match(new RegExp(`.{1,${AUTH_COOKIE_CHUNK_SIZE}}`, "g")) ?? [""];
    if (chunks.length > MAX_AUTH_COOKIE_CHUNKS) {
      throw new RangeError("The authentication session is too large to store safely in cookies.");
    }
    mutations.set(countName, String(chunks.length));
    chunks.forEach((chunk, index) => {
      mutations.set(authCookieChunkName(storageKey, index), chunk);
    });
  }

  return Array.from(mutations, ([name, mutationValue]) => ({ name, value: mutationValue }));
}
