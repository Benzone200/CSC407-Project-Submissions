import "server-only";

import { createClient } from "@supabase/supabase-js";
import { cookies } from "next/headers";
import type { Database } from "./database.types";
import { getSupabasePublicEnv } from "./env";
import { authCookieOptions, createAuthCookieMutations, readAuthCookie } from "./auth-cookies";

/** Create a request-scoped Supabase client backed by secure session cookies. */
export async function createServerSupabaseClient() {
  const { url, publishableKey } = getSupabasePublicEnv();
  const cookieStore = await cookies();

  return createClient<Database>(url, publishableKey, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: true,
      flowType: "pkce",
      storage: {
        getItem(key) {
          return readAuthCookie(key, (name) => cookieStore.get(name)?.value);
        },
        setItem(key, value) {
          const mutations = createAuthCookieMutations(
            key,
            value,
            (name) => cookieStore.get(name)?.value,
          );
          try {
            for (const mutation of mutations) {
              if (mutation.value === null) cookieStore.delete(mutation.name);
              else cookieStore.set(mutation.name, mutation.value, authCookieOptions);
            }
          } catch {
            // Server Components cannot write cookies. The proxy refreshes them.
          }
        },
        removeItem(key) {
          const mutations = createAuthCookieMutations(
            key,
            null,
            (name) => cookieStore.get(name)?.value,
          );
          try {
            for (const mutation of mutations) cookieStore.delete(mutation.name);
          } catch {
            // Server Components cannot write cookies. The proxy refreshes them.
          }
        },
      },
    },
  });
}
