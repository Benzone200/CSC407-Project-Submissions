"use client";

import { createClient } from "@supabase/supabase-js";
import type { Database } from "./database.types";
import { getSupabasePublicEnv } from "./env";

/** Create an anonymous browser client. Authenticated work stays on the cookie-backed server client. */
export function createBrowserSupabaseClient() {
  const { url, publishableKey } = getSupabasePublicEnv();

  return createClient<Database>(url, publishableKey, {
    auth: {
      autoRefreshToken: false,
      detectSessionInUrl: false,
      persistSession: false,
      flowType: "pkce",
    },
  });
}
