import { redirect } from "next/navigation";
import { requireAuthenticatedUser } from "@/src/lib/auth/current-user";
import { homeForRole } from "@/src/lib/auth/authorization-policy";

export default async function LegacyDashboardPage() {
  const user = await requireAuthenticatedUser();
  redirect(homeForRole(user.profile.role));
}
