"use client";

import { useEffect, useRef } from "react";

export default function ApplicationError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  const headingRef = useRef<HTMLHeadingElement>(null);
  useEffect(() => headingRef.current?.focus(), []);
  return <main className="grid min-h-[60vh] place-items-center px-5 py-16"><div role="alert" aria-live="assertive" className="max-w-md text-center"><p className="text-xs font-semibold uppercase tracking-[.15em] text-violet-700">Something went wrong</p><h1 ref={headingRef} tabIndex={-1} className="mt-3 text-2xl font-semibold text-slate-950 outline-none">We couldn’t load this page</h1><p className="mt-2 text-sm leading-6 text-slate-600">Your request could not be completed. Please try again in a moment. If the problem continues, return to your workspace and retry the action.</p><button type="button" onClick={reset} className="mt-5 rounded-lg bg-violet-800 px-4 py-2.5 text-xs font-semibold text-white hover:bg-violet-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-700">Try again</button></div></main>;
}
