import { TriangleAlert } from "lucide-react";
import { EmptyState } from "@/src/components/dashboard/empty-state";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { getAdminConflicts, getAdminScheduleWorkspace } from "@/src/lib/scheduling/queries";
import Link from "next/link";

export default async function ConflictsPage({ searchParams }: { searchParams: Promise<{ query?: string; type?: string; state?: string }> }) {
  const [params, conflicts, workspace] = await Promise.all([searchParams, getAdminConflicts(), getAdminScheduleWorkspace()]);
  const query = params.query?.trim().toLowerCase().slice(0, 100) ?? "";
  const type = ["venue", "invigilator", "student", "capacity", "examination_period"].includes(params.type ?? "") ? params.type : "";
  const state = params.state === "open" || params.state === "resolved" ? params.state : "";
  const schedules = new Map(workspace.schedules.map((item) => [item.id, item]));
  const courses = new Map(workspace.courses.map((item) => [item.id, item]));
  const filtered = conflicts.filter((item) => {
    const schedule = schedules.get(item.exam_schedule_id);
    const course = schedule ? courses.get(schedule.course_id) : null;
    const haystack = `${item.description} ${item.conflict_type} ${course?.code ?? ""} ${course?.title ?? ""}`.toLowerCase();
    return (!query || haystack.includes(query)) && (!type || item.conflict_type === type) && (!state || (state === "resolved") === item.resolved);
  });
  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Administration" title="Scheduling conflicts" description="Review conflict records associated with examination schedules." />
    <form method="get" className="mb-5 grid gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:grid-cols-3" aria-label="Filter conflicts"><label><span className="mb-1 block text-xs font-medium text-slate-700">Search</span><input name="query" type="search" maxLength={100} defaultValue={query} placeholder="Course or explanation" className="h-10 w-full rounded-lg border border-slate-200 px-3 text-sm" /></label><label><span className="mb-1 block text-xs font-medium text-slate-700">Conflict type</span><select name="type" defaultValue={type ?? ""} className="h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm"><option value="">All types</option><option value="venue">Venue</option><option value="invigilator">Invigilator</option><option value="student">Student</option><option value="capacity">Capacity</option><option value="examination_period">Examination period</option></select></label><label><span className="mb-1 block text-xs font-medium text-slate-700">State</span><select name="state" defaultValue={state ?? ""} className="h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm"><option value="">All states</option><option value="open">Open</option><option value="resolved">Resolved</option></select></label><div className="flex gap-2 sm:col-span-3"><button className="rounded-lg bg-violet-800 px-4 py-2 text-xs font-semibold text-white">Apply filters</button><Link href="/admin/conflicts" className="rounded-lg px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-50">Clear</Link></div></form>
    <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 px-5 py-4"><h2 className="font-semibold text-slate-900">Recorded conflicts</h2><p className="mt-1 text-xs text-slate-500">The database rejects invalid schedule changes before saving them.</p></div>
      {filtered.length ? <ul className="divide-y divide-slate-100">{filtered.map((conflict) => { const schedule = schedules.get(conflict.exam_schedule_id); const course = schedule ? courses.get(schedule.course_id) : null; return <li key={conflict.id} className="px-5 py-4"><div className="flex flex-wrap items-center gap-2"><span className="text-sm font-semibold capitalize text-slate-900">{conflict.conflict_type.replaceAll("_", " ")}</span><span className="rounded-full bg-amber-50 px-2.5 py-1 text-xs capitalize text-amber-800">{conflict.severity}</span><span className="text-xs text-slate-500">{conflict.resolved ? "Resolved" : "Open"}</span></div><p className="mt-2 text-sm font-medium text-slate-800">{course ? `${course.code} · ${course.title}` : "Examination record unavailable"}{schedule ? ` · ${schedule.exam_date} ${schedule.start_time.slice(0, 5)}–${schedule.end_time.slice(0, 5)}` : ""}</p><p className="mt-1 text-sm text-slate-700">{conflict.description}</p><div className="mt-2 flex flex-wrap items-center justify-between gap-2"><p className="text-xs text-slate-500">{new Date(conflict.created_at).toLocaleString()}</p>{schedule ? <Link href={`/admin/scheduling?edit=${schedule.id}`} className="text-xs font-semibold text-violet-800 hover:text-violet-950">Open examination</Link> : null}</div></li>; })}</ul> : <EmptyState icon={TriangleAlert} title="No conflict records match" description="Rejected scheduling attempts produce actual conflict records here. Change the filters or validate another draft." />}
    </section>
  </div>;
}
