import { deleteCatalogRecord, updateCatalogRecord } from "../catalog-actions";
import { ConfirmSubmitButton } from "@/src/components/forms/confirm-submit-button";

const fieldClass = "h-9 w-full rounded-lg border border-slate-200 bg-white px-2.5 text-xs text-slate-700 outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100";
const saveClass = "h-9 w-fit rounded-lg border border-violet-200 bg-white px-3 text-xs font-semibold text-violet-800 hover:bg-violet-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-700";
const deleteClass = "h-9 w-fit rounded-lg px-3 text-xs font-semibold text-rose-700 hover:bg-rose-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-600";

type Option = { id: string; label: string };

function DeleteRecordForm({ entity, id, label }: { entity: string; id: string; label: string }) {
  return <form action={deleteCatalogRecord}>
    <input type="hidden" name="entity" value={entity} />
    <input type="hidden" name="id" value={id} />
    <ConfirmSubmitButton className={deleteClass} confirmation={`Delete ${label}? This succeeds only when no protected records depend on it.`} pendingLabel="Deleting…">Delete</ConfirmSubmitButton>
  </form>;
}

function Field({ label, name, defaultValue, ...props }: { label: string; name: string; defaultValue: string; type?: string; min?: number; max?: number; maxLength?: number; required?: boolean }) {
  return <label className="block"><span className="mb-1 block text-[11px] font-medium text-slate-700">{label}</span><input name={name} defaultValue={defaultValue} {...props} className={fieldClass} /></label>;
}

function Select({ label, name, defaultValue, options }: { label: string; name: string; defaultValue: string; options: Option[] }) {
  return <label className="block"><span className="mb-1 block text-[11px] font-medium text-slate-700">{label}</span><select name={name} defaultValue={defaultValue} required className={fieldClass}>{options.map((option) => <option key={option.id} value={option.id}>{option.label}</option>)}</select></label>;
}

export function DepartmentRecordForm({ department }: { department: { id: string; name: string; code: string } }) {
  return <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50/70 p-3">
    <form action={updateCatalogRecord} className="grid gap-3 sm:grid-cols-2">
      <input type="hidden" name="entity" value="department" /><input type="hidden" name="id" value={department.id} />
      <Field label="Department name" name="name" required maxLength={160} defaultValue={department.name} />
      <Field label="Code" name="code" required maxLength={16} defaultValue={department.code} />
      <button className={`${saveClass} sm:col-span-2`}>Save department</button>
    </form>
    <div className="mt-2"><DeleteRecordForm entity="department" id={department.id} label={department.name} /></div>
  </div>;
}

export function CourseRecordForm({ course, departments }: { course: { id: string; department_id: string; code: string; title: string; level: number; credit_units: number; semester: number }; departments: Option[] }) {
  return <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50/70 p-3">
    <form action={updateCatalogRecord} className="grid gap-3 sm:grid-cols-2">
      <input type="hidden" name="entity" value="course" /><input type="hidden" name="id" value={course.id} />
      <Select label="Department" name="department_id" defaultValue={course.department_id} options={departments} />
      <Field label="Course code" name="code" required maxLength={20} defaultValue={course.code} />
      <label className="block sm:col-span-2"><span className="mb-1 block text-[11px] font-medium text-slate-700">Title</span><input name="title" required maxLength={200} defaultValue={course.title} className={fieldClass} /></label>
      <Select label="Level" name="level" defaultValue={String(course.level)} options={[100, 200, 300, 400, 500, 600].map((value) => ({ id: String(value), label: String(value) }))} />
      <Field label="Credit units" name="credit_units" type="number" min={1} max={30} required defaultValue={String(course.credit_units)} />
      <Select label="Semester" name="semester" defaultValue={String(course.semester)} options={[{ id: "1", label: "First semester" }, { id: "2", label: "Second semester" }]} />
      <button className={saveClass}>Save course</button>
    </form>
    <div className="mt-2"><DeleteRecordForm entity="course" id={course.id} label={`${course.code} ${course.title}`} /></div>
  </div>;
}

export function VenueRecordForm({ venue }: { venue: { id: string; name: string; location: string; capacity: number; status: string } }) {
  return <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50/70 p-3">
    <form action={updateCatalogRecord} className="grid gap-3 sm:grid-cols-2">
      <input type="hidden" name="entity" value="venue" /><input type="hidden" name="id" value={venue.id} />
      <Field label="Venue name" name="name" required maxLength={160} defaultValue={venue.name} />
      <Field label="Location" name="location" required maxLength={240} defaultValue={venue.location} />
      <Field label="Capacity" name="capacity" type="number" min={1} required defaultValue={String(venue.capacity)} />
      <Select label="Status" name="status" defaultValue={venue.status} options={[{ id: "active", label: "Active" }, { id: "inactive", label: "Inactive" }, { id: "maintenance", label: "Maintenance" }]} />
      <button className={`${saveClass} sm:col-span-2`}>Save venue</button>
    </form>
    <div className="mt-2"><DeleteRecordForm entity="venue" id={venue.id} label={venue.name} /></div>
  </div>;
}

export function StudentRecordForm({ student, departments }: { student: { id: string; matric_number: string; department_id: string; level: number }; departments: Option[] }) {
  return <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50/70 p-3">
    <form action={updateCatalogRecord} className="grid gap-3 sm:grid-cols-2">
      <input type="hidden" name="entity" value="student" /><input type="hidden" name="id" value={student.id} />
      <Field label="Matriculation number" name="matric_number" required maxLength={40} defaultValue={student.matric_number} />
      <Select label="Department" name="department_id" defaultValue={student.department_id} options={departments} />
      <Select label="Level" name="level" defaultValue={String(student.level)} options={[100, 200, 300, 400, 500, 600].map((value) => ({ id: String(value), label: String(value) }))} />
      <button className={saveClass}>Save student</button>
    </form>
    <div className="mt-2"><DeleteRecordForm entity="student" id={student.id} label={student.matric_number} /></div>
  </div>;
}

export function InvigilatorRecordForm({ invigilator, departments }: { invigilator: { id: string; staff_id: string; department_id: string }; departments: Option[] }) {
  return <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50/70 p-3">
    <form action={updateCatalogRecord} className="grid gap-3 sm:grid-cols-2">
      <input type="hidden" name="entity" value="invigilator" /><input type="hidden" name="id" value={invigilator.id} />
      <Field label="Staff ID" name="staff_id" required maxLength={40} defaultValue={invigilator.staff_id} />
      <Select label="Department" name="department_id" defaultValue={invigilator.department_id} options={departments} />
      <button className={`${saveClass} sm:col-span-2`}>Save invigilator</button>
    </form>
    <div className="mt-2"><DeleteRecordForm entity="invigilator" id={invigilator.id} label={invigilator.staff_id} /></div>
  </div>;
}

export function EnrollmentDeleteForm({ id, label }: { id: string; label: string }) {
  return <DeleteRecordForm entity="enrollment" id={id} label={label} />;
}
