import {
  CatalogField,
  CatalogForm,
  CatalogPageFrame,
  CatalogSelect,
  CatalogSubmit,
  catalogField,
} from "@/src/components/catalog/catalog-page-frame";
import Link from "next/link";
import { getAdminCatalogWorkspace } from "@/src/lib/catalog/queries";
import { EnrollmentDeleteForm, StudentRecordForm } from "../_components/catalog-record-forms";

export default async function StudentsPage({
  searchParams,
}: {
  searchParams: Promise<{ result?: string; query?: string; department?: string; level?: string }>;
}) {
  const [{ result, query: rawQuery, department: rawDepartment, level: rawLevel }, data] = await Promise.all([searchParams, getAdminCatalogWorkspace()]);
  const departments = new Map(data.departments.map((item) => [item.id, item.name]));
  const studentsById = new Map(data.students.map((item) => [item.id, item]));
  const coursesById = new Map(data.courses.map((item) => [item.id, item]));
  const profilesById = new Map(data.allStudentProfiles.map((item) => [item.id, item]));
  const departmentOptions = data.departments.map((item) => ({ id: item.id, label: item.name }));
  const profileOptions = data.studentProfiles.map((profile) => ({
    id: profile.id,
    label: [profile.first_name, profile.last_name].filter(Boolean).join(" ") || profile.email,
  }));
  const query = rawQuery?.trim().toLowerCase().slice(0, 100) ?? "";
  const department = departments.has(rawDepartment ?? "") ? rawDepartment ?? "" : "";
  const level = ["100", "200", "300", "400", "500", "600"].includes(rawLevel ?? "") ? Number(rawLevel) : null;
  const filteredStudents = data.students.filter((student) => {
    const profile = profilesById.get(student.profile_id);
    const haystack = `${student.matric_number} ${profile?.first_name ?? ""} ${profile?.last_name ?? ""} ${profile?.email ?? ""}`.toLowerCase();
    return (!query || haystack.includes(query))
      && (!department || student.department_id === department)
      && (!level || student.level === level);
  });
  const filteredStudentIds = new Set(filteredStudents.map((student) => student.id));
  const filteredEnrollments = data.enrollments.filter((enrollment) => filteredStudentIds.has(enrollment.student_id));

  const studentForm = (
    <CatalogForm
      entity="student"
      title="Assign a student record"
      hint="New Supabase Auth accounts default to student. The account role cannot be changed here."
    >
      {profileOptions.length && data.departments.length ? (
        <div className="grid gap-4">
          <CatalogSelect label="Student account" name="profile_id" placeholder="Choose an unassigned student account" options={profileOptions} />
          <CatalogField label="Matriculation number" name="matric_number" maxLength={40} required placeholder="CSC/2026/001" />
          <CatalogSelect label="Department" name="department_id" placeholder="Select department" options={data.departments.map((item) => ({ id: item.id, label: item.name }))} />
          <label className="block">
            <span className="mb-1.5 block text-xs font-medium text-slate-700">Level</span>
            <select name="level" required defaultValue="100" className={catalogField}>
              {[100, 200, 300, 400, 500, 600].map((value) => <option key={value} value={value}>{value}</option>)}
            </select>
          </label>
        </div>
      ) : <p className="text-sm text-slate-600">An unassigned student-role profile and a department are required before a student record can be added.</p>}
      <CatalogSubmit disabled={!profileOptions.length || !data.departments.length}>Assign student</CatalogSubmit>
    </CatalogForm>
  );

  const enrollmentForm = (
    <CatalogForm
      entity="enrollment"
      title="Enroll in a course"
      hint="Duplicate student/course/session/semester enrollments are rejected."
    >
      {data.students.length && data.courses.length ? (
        <div className="grid gap-4">
          <CatalogSelect
            label="Student"
            name="student_id"
            placeholder="Select student"
            options={data.students.map((item) => ({
              id: item.id,
              label: `${item.matric_number} · ${profilesById.get(item.profile_id)?.email ?? "Student account"}`,
            }))}
          />
          <CatalogSelect
            label="Course"
            name="course_id"
            placeholder="Select course"
            options={data.courses.map((item) => ({ id: item.id, label: `${item.code} · ${item.title}` }))}
          />
          <CatalogField label="Academic session" name="academic_session" maxLength={9} required pattern="\d{4}/\d{4}" placeholder="2026/2027" />
          <label className="block">
            <span className="mb-1.5 block text-xs font-medium text-slate-700">Semester</span>
            <select name="semester" required defaultValue="1" className={catalogField}>
              <option value="1">First semester</option>
              <option value="2">Second semester</option>
            </select>
          </label>
        </div>
      ) : <p className="text-sm text-slate-600">Create at least one student record and course before adding enrollment.</p>}
      <CatalogSubmit disabled={!data.students.length || !data.courses.length}>Add enrollment</CatalogSubmit>
    </CatalogForm>
  );

  const records = (
    <div>
      <form method="get" className="grid gap-3 border-b border-slate-100 bg-slate-50/60 p-4 sm:grid-cols-2" aria-label="Filter student records">
        <label className="sm:col-span-2"><span className="mb-1 block text-[11px] font-medium text-slate-700">Search students</span><input name="query" type="search" maxLength={100} defaultValue={query} placeholder="Matriculation number, name, or email" className={catalogField} /></label>
        <label><span className="mb-1 block text-[11px] font-medium text-slate-700">Department</span><select name="department" defaultValue={department} className={catalogField}><option value="">All departments</option>{data.departments.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
        <label><span className="mb-1 block text-[11px] font-medium text-slate-700">Level</span><select name="level" defaultValue={level ? String(level) : ""} className={catalogField}><option value="">All levels</option>{[100, 200, 300, 400, 500, 600].map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
        <div className="flex gap-2 sm:col-span-2"><button className="h-9 rounded-lg bg-violet-800 px-3 text-xs font-semibold text-white">Apply filters</button><Link href="/admin/students" className="inline-flex h-9 items-center rounded-lg px-3 text-xs font-semibold text-slate-600 hover:bg-white">Clear</Link></div>
      </form>
      <div className="border-b border-slate-100 px-5 py-3"><h3 className="text-sm font-semibold text-slate-800">Student records</h3><p className="mt-1 text-xs text-slate-500">Showing {filteredStudents.length} of {data.students.length} records.</p></div>
      {filteredStudents.length ? <ul className="divide-y divide-slate-100">{filteredStudents.map((item) => <li key={item.id} className="px-5 py-4"><p className="text-sm font-medium text-slate-900">{item.matric_number}</p><p className="mt-1 text-xs text-slate-500">{departments.get(item.department_id) ?? "Department"} · Level {item.level} · {profilesById.get(item.profile_id)?.email ?? "Student account"}</p><StudentRecordForm student={item} departments={departmentOptions} /></li>)}</ul> : <p className="px-5 py-10 text-center text-sm text-slate-500">No student records match these filters.</p>}
      <div className="border-y border-slate-100 px-5 py-3"><h3 className="text-sm font-semibold text-slate-800">Course enrollments</h3></div>
      {filteredEnrollments.length ? <ul className="divide-y divide-slate-100">{filteredEnrollments.map((item) => { const label = `${studentsById.get(item.student_id)?.matric_number ?? "Student"} · ${coursesById.get(item.course_id)?.code ?? "Course"}`; return <li key={item.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-4"><div><p className="text-sm font-medium text-slate-900">{label}</p><p className="mt-1 text-xs text-slate-500">{item.academic_session} · Semester {item.semester}</p></div><EnrollmentDeleteForm id={item.id} label={label} /></li>; })}</ul> : <p className="px-5 py-10 text-center text-sm text-slate-500">No enrollments match the selected students.</p>}
    </div>
  );

  return (
    <CatalogPageFrame
      title="Students and enrollments"
      description="Assign student records to existing Supabase Auth student accounts and enroll them in courses for an academic term."
      result={result}
      form={<div className="grid gap-5">{studentForm}{enrollmentForm}</div>}
      records={records}
    />
  );
}
