import Link from "next/link";
import { CalendarClock, CircleAlert } from "lucide-react";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { EmptyState } from "@/src/components/dashboard/empty-state";
import { ConfirmSubmitButton } from "@/src/components/forms/confirm-submit-button";
import { adminExamFilterSchema, filterAdminExams } from "@/src/lib/scheduling/admin-filters";
import { getAdminScheduleWorkspace } from "@/src/lib/scheduling/queries";
import { cancelExamSchedule, publishExamSchedule, saveExamSchedule, scheduleExam, unpublishExamSchedule } from "../actions";

const resultMessages: Record<string, string> = {
  saved: "Schedule saved as a draft.",
  updated: "The examination changes were saved and validated.",
  scheduled: "The exam is scheduled and resource conflicts have been checked.",
  published: "The exam has been published to eligible students.",
  unpublished: "The exam is no longer visible to students and remains scheduled.",
  cancelled: "The exam was cancelled.",
  invalid: "Check all required fields and ensure the end time is after the start time.",
  period: "The exam date must be within its session. Publishing also requires an active session.",
  "venue-conflict": "That venue already has an overlapping scheduled or published exam.",
  "invigilator-conflict": "That invigilator already has an overlapping exam.",
  "student-conflict": "At least one student enrolled in both courses has an overlapping exam.",
  capacity: "The enrolled student count is greater than the selected venue capacity.",
  "venue-inactive": "Choose an active examination venue.",
  lifecycle: "That lifecycle change is not permitted from the examination's current state.",
  semester: "The course semester must match the examination session semester.",
  unavailable: "The schedule could not be updated. Refresh and try again.",
};

const inputClass = "h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-700 outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100";

export default async function SchedulingPage({ searchParams }: { searchParams: Promise<{ result?: string; edit?: string; query?: string; status?: string; date?: string; sessionId?: string }> }) {
  const [{ result, edit, query, status, date, sessionId }, workspace] = await Promise.all([searchParams, getAdminScheduleWorkspace()]);
  const parsedFilters = adminExamFilterSchema.safeParse({ query, status: status || undefined, date: date || undefined, sessionId: sessionId || undefined });
  const filters = parsedFilters.success ? parsedFilters.data : {};
  const sessions = workspace.sessions;
  const hasReferences = sessions.length > 0 && workspace.courses.length > 0 && workspace.venues.length > 0 && workspace.invigilators.length > 0;
  const coursesById = new Map(workspace.courses.map((course) => [course.id, `${course.code} · ${course.title}`]));
  const coursesDataById = new Map(workspace.courses.map((course) => [course.id, course]));
  const venuesById = new Map(workspace.venues.map((venue) => [venue.id, `${venue.name} · ${venue.location} (${venue.capacity} seats)`]));
  const invigilatorsById = new Map(workspace.invigilators.map((item) => [item.id, item.staff_id]));
  const sessionsById = new Map(sessions.map((session) => [session.id, session]));
  const filteredSchedules = filterAdminExams(workspace.schedules.map((schedule) => {
    const course = coursesDataById.get(schedule.course_id);
    const session = sessionsById.get(schedule.exam_session_id);
    return {
      ...schedule,
      courseCode: course?.code ?? "",
      courseTitle: course?.title ?? "",
      examDate: schedule.exam_date,
      examSessionId: schedule.exam_session_id,
      sessionName: session?.name ?? "",
    };
  }), filters);
  const currentEdit = workspace.schedules.find((schedule) => schedule.id === edit && schedule.status === "draft");

  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Administration" title="Scheduling workspace" description="Create a draft, check resource conflicts, then schedule and publish validated examinations." action={<Link href="/admin/scheduling" className="inline-flex h-10 items-center rounded-lg border border-slate-200 bg-white px-4 text-sm font-semibold text-slate-700 hover:bg-slate-50">New draft</Link>} />
    {result && resultMessages[result] ? <p role="status" className="mb-5 rounded-lg border border-violet-200 bg-violet-50 px-4 py-3 text-sm text-violet-900">{resultMessages[result]}</p> : null}

    <form method="get" action="/admin/scheduling" className="mb-6 grid gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:grid-cols-2 xl:grid-cols-5" aria-label="Filter examinations">
      <label className="xl:col-span-2"><span className="mb-1.5 block text-xs font-medium text-slate-700">Search exams</span><input name="query" type="search" maxLength={100} defaultValue={filters.query ?? ""} placeholder="Course code, title, or session" className={inputClass} /></label>
      <label><span className="mb-1.5 block text-xs font-medium text-slate-700">Status</span><select name="status" defaultValue={filters.status ?? ""} className={inputClass}><option value="">All statuses</option><option value="draft">Draft</option><option value="scheduled">Scheduled</option><option value="published">Published</option><option value="cancelled">Cancelled</option></select></label>
      <label><span className="mb-1.5 block text-xs font-medium text-slate-700">Date</span><input name="date" type="date" defaultValue={filters.date ?? ""} className={inputClass} /></label>
      <label><span className="mb-1.5 block text-xs font-medium text-slate-700">Session</span><select name="sessionId" defaultValue={filters.sessionId ?? ""} className={inputClass}><option value="">All sessions</option>{sessions.map((session) => <option key={session.id} value={session.id}>{session.name} · {session.academic_session}</option>)}</select></label>
      <div className="flex items-end gap-3 sm:col-span-2 xl:col-span-5"><button className="h-10 rounded-lg bg-violet-800 px-4 text-sm font-semibold text-white hover:bg-violet-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-700">Apply filters</button><Link href="/admin/scheduling" className="inline-flex h-10 items-center rounded-lg px-3 text-sm font-medium text-slate-600 hover:bg-slate-50">Clear filters</Link></div>
    </form>

    <section className="grid gap-6 xl:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)]">
      <form action={saveExamSchedule} className="h-fit rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
        <div className="mb-5 flex items-start gap-3"><span className="rounded-lg bg-violet-50 p-2 text-violet-800"><CalendarClock className="size-5" /></span><div><h2 className="font-semibold text-slate-900">{currentEdit ? "Edit exam" : "Create exam draft"}</h2><p className="mt-1 text-xs leading-5 text-slate-500">Conflict checks run whenever an exam is scheduled, published, or edited.</p></div></div>
        {!hasReferences ? <div className="mb-4 flex gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs leading-5 text-amber-900"><CircleAlert className="mt-0.5 size-4 shrink-0" /><p>Scheduling needs existing courses, active venues, assigned invigilators, and at least one examination session. Add those trusted catalogue records before creating an exam.</p></div> : null}
        <input type="hidden" name="id" value={currentEdit?.id ?? ""} />
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="sm:col-span-2"><span className="mb-1.5 block text-xs font-medium text-slate-700">Examination session</span><select name="exam_session_id" required defaultValue={currentEdit?.exam_session_id ?? ""} className={inputClass}><option value="" disabled>Select a session</option>{sessions.map((session) => <option key={session.id} value={session.id}>{session.name} · {session.academic_session} · {session.status}</option>)}</select></label>
          <label className="sm:col-span-2"><span className="mb-1.5 block text-xs font-medium text-slate-700">Course</span><select name="course_id" required defaultValue={currentEdit?.course_id ?? ""} className={inputClass}><option value="" disabled>Select a course</option>{workspace.courses.map((course) => <option key={course.id} value={course.id}>{course.code} · {course.title}</option>)}</select></label>
          <label className="sm:col-span-2"><span className="mb-1.5 block text-xs font-medium text-slate-700">Venue</span><select name="venue_id" required defaultValue={currentEdit?.venue_id ?? ""} className={inputClass}><option value="" disabled>Select an active venue</option>{workspace.venues.map((venue) => <option key={venue.id} value={venue.id}>{venue.name} · {venue.location} ({venue.capacity} seats)</option>)}</select></label>
          <label className="sm:col-span-2"><span className="mb-1.5 block text-xs font-medium text-slate-700">Invigilator</span><select name="invigilator_id" required defaultValue={currentEdit?.invigilator_id ?? ""} className={inputClass}><option value="" disabled>Select an invigilator</option>{workspace.invigilators.map((person) => <option key={person.id} value={person.id}>Staff ID {person.staff_id}</option>)}</select></label>
          <label><span className="mb-1.5 block text-xs font-medium text-slate-700">Exam date</span><input name="exam_date" type="date" required defaultValue={currentEdit?.exam_date ?? ""} className={inputClass} /></label>
          <span aria-hidden="true" className="hidden sm:block" />
          <label><span className="mb-1.5 block text-xs font-medium text-slate-700">Starts</span><input name="start_time" type="time" required defaultValue={currentEdit?.start_time.slice(0, 5) ?? ""} className={inputClass} /></label>
          <label><span className="mb-1.5 block text-xs font-medium text-slate-700">Ends</span><input name="end_time" type="time" required defaultValue={currentEdit?.end_time.slice(0, 5) ?? ""} className={inputClass} /></label>
        </div>
        <button disabled={!hasReferences} className="mt-5 h-10 rounded-lg bg-violet-800 px-4 text-sm font-semibold text-white hover:bg-violet-900 disabled:cursor-not-allowed disabled:opacity-50">{currentEdit ? "Save examination changes" : "Save as draft"}</button>
      </form>

      <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-100 px-5 py-4"><h2 className="font-semibold text-slate-900">Exam schedule</h2><p className="mt-1 text-xs text-slate-500">Showing {filteredSchedules.length} of {workspace.schedules.length} records, including unpublished exams. Times use the institution&apos;s local campus timezone.</p></div>
        {filteredSchedules.length ? <ul className="divide-y divide-slate-100">{filteredSchedules.map((schedule) => {
          const session = sessionsById.get(schedule.exam_session_id);
          const published = schedule.status === "published";
          return <li key={schedule.id} className="px-5 py-4">
            <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="font-semibold text-slate-900">{coursesById.get(schedule.course_id) ?? "Course unavailable"}</p><p className="mt-1 text-xs text-slate-500">{session?.name ?? "Session unavailable"} · {schedule.exam_date} · {schedule.start_time.slice(0, 5)}–{schedule.end_time.slice(0, 5)}</p><p className="mt-1 text-xs text-slate-500">{venuesById.get(schedule.venue_id) ?? "Venue unavailable"} · Staff ID {invigilatorsById.get(schedule.invigilator_id) ?? "unavailable"}</p></div><span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium capitalize text-slate-700">{schedule.status}</span></div>
            <div className="mt-3 flex flex-wrap gap-2">
              {schedule.status === "draft" ? <Link href={`/admin/scheduling?edit=${schedule.id}`} className="inline-flex h-8 items-center rounded-md border border-slate-200 px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50">Edit</Link> : null}
              {schedule.status === "draft" ? <form action={scheduleExam}><input type="hidden" name="id" value={schedule.id} /><ConfirmSubmitButton confirmation="Schedule this examination and run all conflict checks?" pendingLabel="Checking…" className="h-8 rounded-md border border-violet-200 px-2.5 text-xs font-semibold text-violet-800 hover:bg-violet-50">Schedule and validate</ConfirmSubmitButton></form> : null}
              {schedule.status === "scheduled" ? <form action={publishExamSchedule}><input type="hidden" name="id" value={schedule.id} /><ConfirmSubmitButton confirmation="Publish this examination to enrolled students?" pendingLabel="Publishing…" className="h-8 rounded-md bg-violet-800 px-2.5 text-xs font-semibold text-white hover:bg-violet-900">Publish to students</ConfirmSubmitButton></form> : null}
              {published ? <form action={unpublishExamSchedule}><input type="hidden" name="id" value={schedule.id} /><ConfirmSubmitButton confirmation="Unpublish this examination? Students will no longer see it." pendingLabel="Unpublishing…" className="h-8 rounded-md border border-slate-200 px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50">Unpublish</ConfirmSubmitButton></form> : null}
              {schedule.status !== "cancelled" ? <form action={cancelExamSchedule}><input type="hidden" name="id" value={schedule.id} /><ConfirmSubmitButton confirmation="Cancel this examination? A cancelled examination cannot be restored." pendingLabel="Cancelling…" className="h-8 rounded-md px-2.5 text-xs font-medium text-rose-700 hover:bg-rose-50">Cancel</ConfirmSubmitButton></form> : null}
            </div>
          </li>;
        })}</ul> : <EmptyState icon={CalendarClock} title={workspace.schedules.length ? "No exams match these filters" : "No exams scheduled"} description={workspace.schedules.length ? "Change or clear the filters to see other examination records." : "Create an exam draft to begin building the timetable."} />}
      </section>
    </section>
  </div>;
}
