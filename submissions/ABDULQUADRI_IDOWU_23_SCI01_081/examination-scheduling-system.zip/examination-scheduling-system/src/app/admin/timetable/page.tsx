import { CalendarDays } from "lucide-react";
import { EmptyState } from "@/src/components/dashboard/empty-state";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { getAdminScheduleWorkspace } from "@/src/lib/scheduling/queries";

export default async function AdminTimetablePage() {
  const data = await getAdminScheduleWorkspace();
  const courses = new Map(data.courses.map((item) => [item.id, item]));
  const venues = new Map(data.venues.map((item) => [item.id, item]));
  const sessions = new Map(data.sessions.map((item) => [item.id, item]));
  const schedules = data.schedules.filter((item) => item.status === "scheduled" || item.status === "published");
  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Administration" title="Timetable" description="Review scheduled and published examinations from the live timetable." />
    <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 px-5 py-4"><h2 className="font-semibold text-slate-900">Scheduled examinations</h2><p className="mt-1 text-xs text-slate-500">Draft and cancelled entries are excluded.</p></div>
      {schedules.length ? <div className="overflow-x-auto"><table className="min-w-[720px] w-full text-left text-sm"><thead className="bg-slate-50 text-xs text-slate-500"><tr><th scope="col" className="px-5 py-3 font-medium">Course</th><th scope="col" className="px-5 py-3 font-medium">Session</th><th scope="col" className="px-5 py-3 font-medium">Date and time</th><th scope="col" className="px-5 py-3 font-medium">Venue</th><th scope="col" className="px-5 py-3 font-medium">Status</th></tr></thead><tbody className="divide-y divide-slate-100">{schedules.map((item) => <tr key={item.id}><td className="px-5 py-4 font-medium text-slate-900">{courses.get(item.course_id)?.code ?? "Course"} · {courses.get(item.course_id)?.title ?? "Unavailable"}</td><td className="px-5 py-4 text-slate-600">{sessions.get(item.exam_session_id)?.name ?? "Session"}</td><td className="whitespace-nowrap px-5 py-4 text-slate-600">{item.exam_date} · {item.start_time.slice(0, 5)}–{item.end_time.slice(0, 5)}</td><td className="px-5 py-4 text-slate-600">{venues.get(item.venue_id)?.name ?? "Venue unavailable"}</td><td className="px-5 py-4"><span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs capitalize text-slate-700">{item.status}</span></td></tr>)}</tbody></table></div> : <EmptyState icon={CalendarDays} title="No scheduled examinations" description="Move a validated draft to scheduled status to include it in this timetable." />}
    </section>
  </div>;
}
