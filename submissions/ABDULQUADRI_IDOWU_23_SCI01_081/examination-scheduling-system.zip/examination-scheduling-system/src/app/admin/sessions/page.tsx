import { CalendarRange } from "lucide-react";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { ConfirmSubmitButton } from "@/src/components/forms/confirm-submit-button";
import { getAdminSessions } from "@/src/lib/scheduling/queries";
import { activateExamSession, changeExamSessionStatus, createExamSession, deleteExamSession, updateExamSession } from "../actions";

const resultMessages: Record<string, string> = {
  created: "Examination session created as a draft.",
  activated: "Examination session is active.",
  active: "Examination session is active.",
  completed: "Examination session was marked completed.",
  archived: "Examination session was archived.",
  updated: "Examination session details were updated.",
  deleted: "Draft examination session deleted.",
  referenced: "This session is used by an examination and cannot be deleted.",
  duplicate: "A session with this name and academic period already exists.",
  lifecycle: "That session lifecycle change is not permitted.",
  invalid: "Check the session details and date range, then try again.",
  unavailable: "The session could not be updated. Check for another active session in this term.",
};

function SessionStatus({ status }: { status: string }) {
  const color = status === "active" ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-600";
  return <span className={`rounded-full px-2.5 py-1 text-xs font-medium capitalize ${color}`}>{status}</span>;
}

export default async function SessionsPage({ searchParams }: { searchParams: Promise<{ result?: string }> }) {
  const [{ result }, sessions] = await Promise.all([searchParams, getAdminSessions()]);
  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Administration" title="Examination sessions" description="Set the academic term and date window used to validate exam schedules." />
    {result && resultMessages[result] ? <p role="status" className="mb-5 rounded-lg border border-violet-200 bg-violet-50 px-4 py-3 text-sm text-violet-900">{resultMessages[result]}</p> : null}

    <section className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]">
      <form action={createExamSession} className="h-fit rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
        <div className="mb-5 flex items-center gap-3"><span className="rounded-lg bg-violet-50 p-2 text-violet-800"><CalendarRange className="size-5" /></span><div><h2 className="font-semibold text-slate-900">Create a session</h2><p className="text-xs text-slate-500">New sessions start in draft.</p></div></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="sm:col-span-2"><span className="mb-1.5 block text-xs font-medium text-slate-700">Session name</span><input name="name" required maxLength={160} placeholder="First semester examinations" className="h-10 w-full rounded-lg border border-slate-200 px-3 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100" /></label>
          <label><span className="mb-1.5 block text-xs font-medium text-slate-700">Academic session</span><input name="academic_session" required pattern="\d{4}/\d{4}" placeholder="2026/2027" className="h-10 w-full rounded-lg border border-slate-200 px-3 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100" /></label>
          <label><span className="mb-1.5 block text-xs font-medium text-slate-700">Semester</span><select name="semester" required defaultValue="1" className="h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm"><option value="1">First semester</option><option value="2">Second semester</option></select></label>
          <label><span className="mb-1.5 block text-xs font-medium text-slate-700">Starts</span><input name="start_date" type="date" required className="h-10 w-full rounded-lg border border-slate-200 px-3 text-sm" /></label>
          <label><span className="mb-1.5 block text-xs font-medium text-slate-700">Ends</span><input name="end_date" type="date" required className="h-10 w-full rounded-lg border border-slate-200 px-3 text-sm" /></label>
        </div>
        <button className="mt-5 h-10 rounded-lg bg-violet-800 px-4 text-sm font-semibold text-white hover:bg-violet-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-700">Create draft session</button>
      </form>

      <section className="rounded-xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-100 px-5 py-4"><h2 className="font-semibold text-slate-900">Sessions</h2><p className="mt-1 text-xs text-slate-500">Activate a session before publishing exams in its date range.</p></div>
        {sessions.length ? <ul className="divide-y divide-slate-100">{sessions.map((session) => <li key={session.id} className="px-5 py-4">
          <div><div className="flex flex-wrap items-center gap-2"><p className="text-sm font-semibold text-slate-900">{session.name}</p><SessionStatus status={session.status} /></div><p className="mt-1 text-xs text-slate-500">{session.academic_session} · Semester {session.semester} · {session.start_date} to {session.end_date}</p></div>
          {(session.status === "draft" || session.status === "active") ? <form action={updateExamSession} className="mt-3 grid gap-3 rounded-lg border border-slate-200 bg-slate-50/70 p-3 sm:grid-cols-2">
            <input type="hidden" name="id" value={session.id} />
            <label className="sm:col-span-2"><span className="mb-1 block text-[11px] font-medium text-slate-700">Session name</span><input name="name" required maxLength={160} defaultValue={session.name} className="h-9 w-full rounded-lg border border-slate-200 bg-white px-2.5 text-xs" /></label>
            <label><span className="mb-1 block text-[11px] font-medium text-slate-700">Academic session</span><input name="academic_session" required pattern="\d{4}/\d{4}" defaultValue={session.academic_session} className="h-9 w-full rounded-lg border border-slate-200 bg-white px-2.5 text-xs" /></label>
            <label><span className="mb-1 block text-[11px] font-medium text-slate-700">Semester</span><select name="semester" defaultValue={String(session.semester)} className="h-9 w-full rounded-lg border border-slate-200 bg-white px-2.5 text-xs"><option value="1">First semester</option><option value="2">Second semester</option></select></label>
            <label><span className="mb-1 block text-[11px] font-medium text-slate-700">Starts</span><input name="start_date" type="date" required defaultValue={session.start_date} className="h-9 w-full rounded-lg border border-slate-200 bg-white px-2.5 text-xs" /></label>
            <label><span className="mb-1 block text-[11px] font-medium text-slate-700">Ends</span><input name="end_date" type="date" required defaultValue={session.end_date} className="h-9 w-full rounded-lg border border-slate-200 bg-white px-2.5 text-xs" /></label>
            <button className="h-9 w-fit rounded-lg border border-violet-200 bg-white px-3 text-xs font-semibold text-violet-800 hover:bg-violet-50">Save session</button>
          </form> : null}
          <div className="mt-3 flex flex-wrap gap-2">
            {session.status === "draft" ? <form action={activateExamSession}><input type="hidden" name="id" value={session.id} /><ConfirmSubmitButton confirmation="Activate this examination session?" className="h-9 rounded-lg border border-violet-200 px-3 text-xs font-semibold text-violet-800 hover:bg-violet-50">Activate session</ConfirmSubmitButton></form> : null}
            {session.status === "active" ? <form action={changeExamSessionStatus}><input type="hidden" name="id" value={session.id} /><input type="hidden" name="from" value="active" /><input type="hidden" name="to" value="completed" /><ConfirmSubmitButton confirmation="Mark this examination session completed?" className="h-9 rounded-lg border border-slate-200 px-3 text-xs font-semibold text-slate-700 hover:bg-slate-50">Mark completed</ConfirmSubmitButton></form> : null}
            {session.status === "completed" ? <form action={changeExamSessionStatus}><input type="hidden" name="id" value={session.id} /><input type="hidden" name="from" value="completed" /><input type="hidden" name="to" value="archived" /><ConfirmSubmitButton confirmation="Archive this completed examination session?" className="h-9 rounded-lg border border-slate-200 px-3 text-xs font-semibold text-slate-700 hover:bg-slate-50">Archive</ConfirmSubmitButton></form> : null}
            {session.status === "draft" ? <form action={deleteExamSession}><input type="hidden" name="id" value={session.id} /><ConfirmSubmitButton confirmation="Delete this unused draft session?" className="h-9 rounded-lg px-3 text-xs font-semibold text-rose-700 hover:bg-rose-50">Delete</ConfirmSubmitButton></form> : null}
          </div>
        </li>)}</ul> : <p className="px-5 py-10 text-center text-sm text-slate-500">No examination sessions yet.</p>}
      </section>
    </section>
  </div>;
}
