import type { ReactNode } from "react";
import { DashboardShell } from "@/src/components/layout/dashboard-shell";
import { requireRole } from "@/src/lib/auth/current-user";

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const current = await requireRole("admin");
  const displayName = [current.profile.first_name, current.profile.last_name].filter(Boolean).join(" ") || current.profile.email;
  return <DashboardShell area="admin" displayName={displayName}>{children}</DashboardShell>;
}
