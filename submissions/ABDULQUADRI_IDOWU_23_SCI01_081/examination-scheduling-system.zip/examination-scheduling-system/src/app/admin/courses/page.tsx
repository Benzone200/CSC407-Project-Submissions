import { CatalogField, CatalogForm, CatalogPageFrame, CatalogSelect, CatalogSubmit, catalogField } from "@/src/components/catalog/catalog-page-frame";
import { getAdminCatalogWorkspace } from "@/src/lib/catalog/queries";
import { CourseRecordForm } from "../_components/catalog-record-forms";

export default async function CoursesPage({ searchParams }: { searchParams: Promise<{ result?: string }> }) {
  const [{ result }, data] = await Promise.all([searchParams, getAdminCatalogWorkspace()]);
  const departments = new Map(data.departments.map((item) => [item.id, item.code]));
  const departmentOptions = data.departments.map((item) => ({ id: item.id, label: `${item.name} (${item.code})` }));
  return <CatalogPageFrame title="Courses" description="Add courses that can be included in examination sessions and student enrollments." result={result}
    form={<CatalogForm entity="course" title="Add a course" hint="Each course belongs to a department and semester.">{data.departments.length ? <div className="grid gap-4"><CatalogSelect label="Department" name="department_id" placeholder="Select department" options={data.departments.map((item) => ({ id: item.id, label: `${item.name} (${item.code})` }))} /><CatalogField label="Course code" name="code" maxLength={20} required placeholder="CSC407" /><CatalogField label="Course title" name="title" maxLength={200} required placeholder="Software Engineering" /><div className="grid grid-cols-2 gap-4"><label className="block"><span className="mb-1.5 block text-xs font-medium text-slate-700">Level</span><select name="level" required defaultValue="100" className={catalogField}><option value="100">100</option><option value="200">200</option><option value="300">300</option><option value="400">400</option><option value="500">500</option><option value="600">600</option></select></label><CatalogField label="Credit units" name="credit_units" type="number" min={1} max={30} required defaultValue="3" /></div><label className="block"><span className="mb-1.5 block text-xs font-medium text-slate-700">Semester</span><select name="semester" required defaultValue="1" className={catalogField}><option value="1">First semester</option><option value="2">Second semester</option></select></label></div> : <p className="text-sm text-slate-600">Add a department before creating courses.</p>}<CatalogSubmit disabled={!data.departments.length} /></CatalogForm>}
    records={data.courses.length ? <ul className="divide-y divide-slate-100">{data.courses.map((item) => <li key={item.id} className="px-5 py-4">
      <p className="text-sm font-medium text-slate-900">{item.code} · {item.title}</p>
      <p className="mt-1 text-xs text-slate-500">{departments.get(item.department_id) ?? "Department"} · Level {item.level} · Semester {item.semester} · {item.credit_units} units</p>
      <CourseRecordForm course={item} departments={departmentOptions} />
    </li>)}</ul> : <p className="px-5 py-10 text-center text-sm text-slate-500">No courses have been added.</p>} />;
}
