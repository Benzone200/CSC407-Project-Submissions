import { CircleUserRound, Shield } from "lucide-react";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { getAdminProfiles } from "@/src/lib/catalog/queries";
import Link from "next/link";

export default async function AdminUsersPage({ searchParams }: { searchParams: Promise<{ query?: string; role?: string }> }) {
  const [params, profiles] = await Promise.all([searchParams, getAdminProfiles()]);
  const query = params.query?.trim().toLowerCase().slice(0, 100) ?? "";
  const role = ["admin", "student", "invigilator"].includes(params.role ?? "") ? params.role : "";
  const filtered = profiles.filter((profile) => {
    const text = `${profile.first_name ?? ""} ${profile.last_name ?? ""} ${profile.email} ${profile.auth_user_id ?? "unlinked"}`.toLowerCase();
    return (!query || text.includes(query)) && (!role || profile.role === role);
  });

  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Access management" title="Users" description="Search application profiles and verify their trusted database-backed role." />
    <form method="get" className="mb-5 grid gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:grid-cols-[1fr_220px_auto]"><label><span className="mb-1 block text-xs font-medium text-slate-700">Search users</span><input name="query" type="search" maxLength={100} defaultValue={query} placeholder="Name, email, or Auth ID" className="h-10 w-full rounded-lg border border-slate-200 px-3 text-sm" /></label><label><span className="mb-1 block text-xs font-medium text-slate-700">Role</span><select name="role" defaultValue={role ?? ""} className="h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm"><option value="">All roles</option><option value="admin">Admin</option><option value="student">Student</option><option value="invigilator">Invigilator</option></select></label><div className="flex items-end gap-2"><button className="h-10 rounded-lg bg-violet-800 px-4 text-xs font-semibold text-white">Apply</button><Link href="/admin/users" className="inline-flex h-10 items-center px-3 text-xs font-semibold text-slate-600">Clear</Link></div></form>
    <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm"><div className="border-b border-slate-100 px-5 py-4"><h2 className="font-semibold text-slate-900">Application profiles</h2><p className="mt-1 text-xs text-slate-500">Showing {filtered.length} of {profiles.length}. Role and restriction changes remain privileged database operations.</p></div>{filtered.length ? <ul className="divide-y divide-slate-100">{filtered.map((profile) => <li key={profile.id} className="flex flex-wrap items-center gap-4 px-5 py-4"><span className="grid size-10 place-items-center rounded-full bg-violet-50 text-violet-800"><CircleUserRound className="size-5" /></span><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-slate-900">{[profile.first_name, profile.last_name].filter(Boolean).join(" ") || "Name not provided"}</p><p className="truncate text-xs text-slate-500">{profile.email}</p><p className="mt-1 truncate font-mono text-[10px] text-slate-400">{profile.auth_user_id ?? "Legacy profile not linked"}</p></div><span className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium capitalize text-slate-700"><Shield className="size-3" />{profile.role} · {profile.account_status}</span></li>)}</ul> : <p className="px-5 py-10 text-center text-sm text-slate-500">No profiles match these filters.</p>}</section>
  </div>;
}
