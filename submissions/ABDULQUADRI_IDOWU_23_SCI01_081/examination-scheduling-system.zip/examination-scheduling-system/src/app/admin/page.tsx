import Link from "next/link";
import { Activity, AlertTriangle, BookOpen, CalendarDays, DoorOpen, GraduationCap, UserRoundCog } from "lucide-react";
import { EmptyState } from "@/src/components/dashboard/empty-state";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { StatCard } from "@/src/components/dashboard/stat-card";
import { getAdminCatalogWorkspace } from "@/src/lib/catalog/queries";
import { campusDateKey, getAdminActivityLogs, getAdminConflicts, getAdminScheduleWorkspace } from "@/src/lib/scheduling/queries";

export default async function AdminDashboard() {
  const [catalog, scheduling, conflicts, activity] = await Promise.all([
    getAdminCatalogWorkspace(),
    getAdminScheduleWorkspace(),
    getAdminConflicts(),
    getAdminActivityLogs(),
  ]);
  const unresolved = conflicts.filter((item) => !item.resolved);
  const today = campusDateKey();
  const upcoming = scheduling.schedules
    .filter((item) => item.status === "scheduled" || item.status === "published")
    .filter((item) => item.exam_date >= today)
    .sort((first, second) => first.exam_date.localeCompare(second.exam_date) || first.start_time.localeCompare(second.start_time))
    .slice(0, 5);
  const courses = new Map(catalog.courses.map((item) => [item.id, item]));
  const departments = new Map(catalog.departments.map((item) => [item.id, item]));
  const sessions = new Map(scheduling.sessions.map((item) => [item.id, item]));
  const venues = new Map(scheduling.venues.map((item) => [item.id, item]));
  const departmentCounts = new Map<string, number>();
  for (const schedule of scheduling.schedules) {
    if (schedule.status !== "scheduled" && schedule.status !== "published") continue;
    const departmentId = courses.get(schedule.course_id)?.department_id;
    if (departmentId) departmentCounts.set(departmentId, (departmentCounts.get(departmentId) ?? 0) + 1);
  }

  const stats = [
    ["Examinations", scheduling.schedules.length, "All schedule records", CalendarDays],
    ["Courses", catalog.courses.length, "Course catalogue", BookOpen],
    ["Students", catalog.students.length, "Assigned student records", GraduationCap],
    ["Venues", catalog.venues.length, "Active and inactive venues", DoorOpen],
    ["Invigilators", catalog.invigilators.length, "Assigned staff records", UserRoundCog],
    ["Open conflicts", unresolved.length, "Stored conflict records", AlertTriangle],
  ] as const;

  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Administration" title="Planning overview" description="Current examination operations from the secured application database." />
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">{stats.map(([label, count, detail, icon]) => <StatCard key={label} label={label} value={String(count)} detail={detail} icon={icon} />)}</div>
    <div className="mt-6 grid gap-4 xl:grid-cols-2">
      <section className="overflow-hidden rounded-xl border border-slate-200/90 bg-white"><div className="border-b border-slate-100 px-5 py-4"><h2 className="text-sm font-semibold">Recent activity</h2><p className="mt-1 text-xs text-slate-500">Latest administrative changes</p></div>{activity.length ? <ul className="divide-y divide-slate-100">{activity.slice(0, 5).map((entry) => <li key={entry.id} className="px-5 py-3"><p className="text-sm font-medium text-slate-800">{entry.action.replaceAll("_", " ").replaceAll(".", " · ")}</p><p className="mt-1 text-xs text-slate-500">{entry.actor?.email ?? "System account"} · {new Date(entry.created_at).toLocaleString()}</p></li>)}</ul> : <EmptyState icon={Activity} title="No activity to display" description="Administrative changes will be recorded here." />}</section>
      <section className="overflow-hidden rounded-xl border border-slate-200/90 bg-white"><div className="border-b border-slate-100 px-5 py-4"><h2 className="text-sm font-semibold">Upcoming examinations</h2><p className="mt-1 text-xs text-slate-500">Scheduled and published from today onward</p></div>{upcoming.length ? <ul className="divide-y divide-slate-100">{upcoming.map((item) => <li key={item.id} className="px-5 py-3"><p className="text-sm font-medium text-slate-800">{courses.get(item.course_id)?.code ?? "Course"} · {courses.get(item.course_id)?.title ?? "Unavailable"}</p><p className="mt-1 text-xs text-slate-500">{item.exam_date} · {item.start_time.slice(0, 5)}–{item.end_time.slice(0, 5)} · {venues.get(item.venue_id)?.name ?? "Venue"} · {sessions.get(item.exam_session_id)?.name ?? "Session"}</p></li>)}</ul> : <EmptyState icon={CalendarDays} title="No upcoming examinations" description="Validated schedules will appear here." />}</section>
      <section className="overflow-hidden rounded-xl border border-slate-200/90 bg-white"><div className="border-b border-slate-100 px-5 py-4"><h2 className="text-sm font-semibold">Scheduling conflicts</h2><p className="mt-1 text-xs text-slate-500">Stored unresolved conflict records</p></div>{unresolved.length ? <ul className="divide-y divide-slate-100">{unresolved.slice(0, 5).map((item) => <li key={item.id} className="px-5 py-3"><p className="text-sm font-medium capitalize text-slate-800">{item.conflict_type.replaceAll("_", " ")} · {item.severity}</p><p className="mt-1 text-xs text-slate-600">{item.description}</p></li>)}</ul> : <EmptyState icon={AlertTriangle} title="No stored conflicts" description="Invalid schedule changes are blocked before saving and are not currently recorded here." />}</section>
      <section className="overflow-hidden rounded-xl border border-slate-200/90 bg-white"><div className="border-b border-slate-100 px-5 py-4"><h2 className="text-sm font-semibold">Examinations by department</h2><p className="mt-1 text-xs text-slate-500">Scheduled and published exam count</p></div>{departmentCounts.size ? <ul className="divide-y divide-slate-100">{[...departmentCounts.entries()].map(([id, count]) => <li key={id} className="flex items-center justify-between px-5 py-3 text-sm"><span className="text-slate-700">{departments.get(id)?.name ?? departments.get(id)?.code ?? "Department"}</span><span className="font-semibold text-slate-900">{count}</span></li>)}</ul> : <EmptyState icon={GraduationCap} title="No scheduled exams by department" description="This breakdown appears after exams are scheduled or published." />}</section>
    </div>
    <div className="mt-5 flex flex-wrap gap-2"><Link href="/admin/scheduling" className="rounded-lg bg-violet-800 px-4 py-2.5 text-sm font-semibold text-white hover:bg-violet-900">Manage examinations</Link><Link href="/admin/courses" className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">Manage courses</Link><Link href="/admin/venues" className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">Manage venues</Link><Link href="/admin/sessions" className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">Manage sessions</Link></div>
  </div>;
}
