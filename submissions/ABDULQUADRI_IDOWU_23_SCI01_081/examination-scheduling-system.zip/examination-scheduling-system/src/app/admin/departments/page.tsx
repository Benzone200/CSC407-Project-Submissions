import { CatalogField, CatalogForm, CatalogPageFrame, CatalogSubmit } from "@/src/components/catalog/catalog-page-frame";
import { getAdminCatalogWorkspace } from "@/src/lib/catalog/queries";
import { DepartmentRecordForm } from "../_components/catalog-record-forms";

export default async function DepartmentsPage({ searchParams }: { searchParams: Promise<{ result?: string }> }) {
  const [{ result }, data] = await Promise.all([searchParams, getAdminCatalogWorkspace()]);
  return <CatalogPageFrame title="Departments" description="Add academic departments used to organize courses, students and invigilator assignments." result={result}
    form={<CatalogForm entity="department" title="Add a department" hint="Department codes are unique and use uppercase letters or numbers."><div className="grid gap-4"><CatalogField label="Department name" name="name" maxLength={160} required placeholder="Computer Science" /><CatalogField label="Department code" name="code" maxLength={16} required pattern="[A-Za-z0-9][A-Za-z0-9_-]{1,15}" placeholder="CSC" /></div><CatalogSubmit /></CatalogForm>}
    records={data.departments.length ? <ul className="divide-y divide-slate-100">{data.departments.map((item) => <li key={item.id} className="px-5 py-4"><p className="text-sm font-medium text-slate-900">{item.name}</p><p className="mt-1 text-xs text-slate-500">{item.code}</p><DepartmentRecordForm department={item} /></li>)}</ul> : <p className="px-5 py-10 text-center text-sm text-slate-500">No departments have been added.</p>} />;
}
