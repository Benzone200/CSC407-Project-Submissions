import { ListChecks } from "lucide-react";
import { EmptyState } from "@/src/components/dashboard/empty-state";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { getAdminActivityLogs } from "@/src/lib/scheduling/queries";

export default async function ActivityLogsPage() {
  const entries = await getAdminActivityLogs();
  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Administration" title="Activity logs" description="Append-only history of administrative changes to scheduling and catalogue records." />
    <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 px-5 py-4"><h2 className="font-semibold text-slate-900">Recent activity</h2><p className="mt-1 text-xs text-slate-500">Showing the latest {entries.length} of up to 200 entries.</p></div>
      {entries.length ? <ul className="divide-y divide-slate-100">{entries.map((entry) => <li key={entry.id} className="px-5 py-4"><div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between"><p className="text-sm font-medium text-slate-900">{entry.action.replaceAll("_", " ").replaceAll(".", " · ")}</p><time className="text-xs text-slate-500" dateTime={entry.created_at}>{new Date(entry.created_at).toLocaleString()}</time></div><p className="mt-1 text-xs text-slate-600">{entry.actor ? [entry.actor.first_name, entry.actor.last_name].filter(Boolean).join(" ") || entry.actor.email : "System account"} · {entry.entity_type} · {entry.entity_id ?? "No entity reference"}</p></li>)}</ul> : <EmptyState icon={ListChecks} title="No administrative activity yet" description="Session, schedule, course, department, venue, student and invigilator setup changes will be recorded here." />}
    </section>
  </div>;
}
