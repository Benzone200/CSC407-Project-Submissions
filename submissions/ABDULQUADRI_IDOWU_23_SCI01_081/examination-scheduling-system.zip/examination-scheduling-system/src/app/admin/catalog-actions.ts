"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireRole } from "@/src/lib/auth/current-user";
import {
  catalogDeleteInputSchema,
  catalogEditInputSchema,
  catalogInputSchema,
  type CatalogDeleteInput,
} from "@/src/lib/catalog/validation";
import { createServerSupabaseClient } from "@/src/lib/supabase/server";

const routes = {
  department: "/admin/departments",
  course: "/admin/courses",
  venue: "/admin/venues",
  student: "/admin/students",
  invigilator: "/admin/invigilators",
  enrollment: "/admin/students",
} as const;

function text(formData: FormData, key: string): string {
  const value = formData.get(key);
  return typeof value === "string" ? value : "";
}

function routeForEntity(entity: string): string {
  return entity in routes ? routes[entity as keyof typeof routes] : "/admin";
}

function catalogErrorCode(error: { code?: string }): string {
  if (error.code === "23505") return "duplicate";
  if (error.code === "23503") return "referenced";
  if (error.code === "P0015") return "capacity";
  if (error.code === "P0017") return "period";
  if (error.code === "P0018") return "profile";
  if (error.code === "P0021") return "profile";
  if (error.code === "P0022") return "period";
  return "unavailable";
}

function revalidateCatalogPaths(): void {
  for (const path of [
    "/admin",
    "/admin/scheduling",
    "/admin/courses",
    "/admin/departments",
    "/admin/venues",
    "/admin/students",
    "/admin/invigilators",
    "/admin/sessions",
    "/admin/timetable",
    "/admin/activity-logs",
    "/student",
    "/student/exams",
    "/student/timetable",
    "/student/search",
    "/invigilator",
    "/invigilator/exams",
    "/invigilator/timetable",
  ]) {
    revalidatePath(path);
  }
}

export async function createCatalogRecord(formData: FormData): Promise<never> {
  await requireRole("admin");
  const parsed = catalogInputSchema.safeParse({
    entity: text(formData, "entity"),
    name: text(formData, "name"),
    code: text(formData, "code"),
    department_id: text(formData, "department_id"),
    title: text(formData, "title"),
    level: text(formData, "level"),
    credit_units: text(formData, "credit_units"),
    semester: text(formData, "semester"),
    location: text(formData, "location"),
    capacity: text(formData, "capacity"),
    status: text(formData, "status"),
    profile_id: text(formData, "profile_id"),
    matric_number: text(formData, "matric_number"),
    staff_id: text(formData, "staff_id"),
    student_id: text(formData, "student_id"),
    course_id: text(formData, "course_id"),
    academic_session: text(formData, "academic_session"),
  });

  const route = parsed.success ? routes[parsed.data.entity] : "/admin";
  if (!parsed.success) redirect(`${route}?result=invalid`);
  const input = parsed.data;
  const supabase = await createServerSupabaseClient();

  let error: { code?: string } | null = null;
  if (input.entity === "department") {
    ({ error } = await supabase.from("departments").insert({ name: input.name, code: input.code }));
  } else if (input.entity === "course") {
    ({ error } = await supabase.from("courses").insert({
      department_id: input.department_id,
      code: input.code,
      title: input.title,
      level: input.level,
      credit_units: input.credit_units,
      semester: input.semester,
    }));
  } else if (input.entity === "venue") {
    ({ error } = await supabase.from("venues").insert({
      name: input.name,
      location: input.location,
      capacity: input.capacity,
      status: input.status,
    }));
  } else if (input.entity === "student" || input.entity === "invigilator") {
    const expectedRole = input.entity;
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("id")
      .eq("id", input.profile_id)
      .eq("role", expectedRole)
      .maybeSingle();
    if (profileError || !profile) redirect(`${route}?result=profile`);

    if (input.entity === "student") {
      ({ error } = await supabase.from("students").insert({
        profile_id: profile.id,
        matric_number: input.matric_number,
        department_id: input.department_id,
        level: input.level,
      }));
    } else {
      ({ error } = await supabase.from("invigilators").insert({
        profile_id: profile.id,
        staff_id: input.staff_id,
        department_id: input.department_id,
      }));
    }
  } else {
    const { data: course, error: courseError } = await supabase
      .from("courses")
      .select("semester")
      .eq("id", input.course_id)
      .maybeSingle();
    if (courseError || !course || course.semester !== input.semester) {
      redirect(`${route}?result=period`);
    }
    ({ error } = await supabase.from("course_enrollments").insert({
      student_id: input.student_id,
      course_id: input.course_id,
      academic_session: input.academic_session,
      semester: input.semester,
    }));
  }

  if (error) redirect(`${route}?result=${catalogErrorCode(error)}`);
  revalidateCatalogPaths();
  redirect(`${route}?result=saved`);
}

export async function updateCatalogRecord(formData: FormData): Promise<never> {
  await requireRole("admin");

  const entity = text(formData, "entity");
  const route = routeForEntity(entity);
  const parsed = catalogEditInputSchema.safeParse({
    entity,
    id: text(formData, "id"),
    code: text(formData, "code"),
    title: text(formData, "title"),
    name: text(formData, "name"),
    location: text(formData, "location"),
    capacity: text(formData, "capacity"),
    status: text(formData, "status"),
    department_id: text(formData, "department_id"),
    level: text(formData, "level"),
    credit_units: text(formData, "credit_units"),
    semester: text(formData, "semester"),
    matric_number: text(formData, "matric_number"),
    staff_id: text(formData, "staff_id"),
  });
  if (!parsed.success) redirect(`${route}?result=invalid`);

  const input = parsed.data;
  const supabase = await createServerSupabaseClient();
  const result = input.entity === "department"
    ? await supabase.from("departments").update({ name: input.name, code: input.code }).eq("id", input.id).select("id").maybeSingle()
    : input.entity === "course"
      ? await supabase.from("courses").update({ department_id: input.department_id, code: input.code, title: input.title, level: input.level, credit_units: input.credit_units, semester: input.semester }).eq("id", input.id).select("id").maybeSingle()
      : input.entity === "venue"
        ? await supabase.from("venues").update({ name: input.name, location: input.location, capacity: input.capacity, status: input.status }).eq("id", input.id).select("id").maybeSingle()
        : input.entity === "student"
          ? await supabase.from("students").update({ matric_number: input.matric_number, department_id: input.department_id, level: input.level }).eq("id", input.id).select("id").maybeSingle()
          : await supabase.from("invigilators").update({ staff_id: input.staff_id, department_id: input.department_id }).eq("id", input.id).select("id").maybeSingle();

  if (result.error) {
    redirect(`${route}?result=${catalogErrorCode(result.error)}`);
  }
  if (!result.data) redirect(`${route}?result=unavailable`);

  revalidateCatalogPaths();
  redirect(`${route}?result=updated`);
}

export async function deleteCatalogRecord(formData: FormData): Promise<never> {
  await requireRole("admin");
  const parsed = catalogDeleteInputSchema.safeParse({
    entity: text(formData, "entity"),
    id: text(formData, "id"),
  });
  const route = routeForEntity(text(formData, "entity"));
  if (!parsed.success) redirect(`${route}?result=invalid`);

  const supabase = await createServerSupabaseClient();
  const input: CatalogDeleteInput = parsed.data;
  const result = input.entity === "department"
    ? await supabase.from("departments").delete().eq("id", input.id).select("id").maybeSingle()
    : input.entity === "course"
      ? await supabase.from("courses").delete().eq("id", input.id).select("id").maybeSingle()
      : input.entity === "venue"
        ? await supabase.from("venues").delete().eq("id", input.id).select("id").maybeSingle()
        : input.entity === "student"
          ? await supabase.from("students").delete().eq("id", input.id).select("id").maybeSingle()
          : input.entity === "invigilator"
            ? await supabase.from("invigilators").delete().eq("id", input.id).select("id").maybeSingle()
            : await supabase.from("course_enrollments").delete().eq("id", input.id).select("id").maybeSingle();

  if (result.error) redirect(`${route}?result=${catalogErrorCode(result.error)}`);
  if (!result.data) redirect(`${route}?result=unavailable`);
  revalidateCatalogPaths();
  redirect(`${route}?result=${input.entity === "enrollment" ? "unenrolled" : "deleted"}`);
}
