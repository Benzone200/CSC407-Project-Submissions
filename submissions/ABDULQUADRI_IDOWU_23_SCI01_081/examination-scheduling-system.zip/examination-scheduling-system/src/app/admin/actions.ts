"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireRole } from "@/src/lib/auth/current-user";
import { createServerSupabaseClient } from "@/src/lib/supabase/server";
import { examScheduleInputSchema, examSessionEditSchema, examSessionInputSchema } from "@/src/lib/scheduling/validation";
import { z } from "zod";

function getText(data: FormData, key: string): string {
  const value = data.get(key);
  return typeof value === "string" ? value : "";
}

function databaseErrorCode(error: { code?: string }): string {
  switch (error.code) {
    case "P0011": return "period";
    case "P0012": return "venue-conflict";
    case "P0013": return "invigilator-conflict";
    case "P0014": return "student-conflict";
    case "P0015": return "capacity";
    case "P0016": return "venue-inactive";
    case "P0020": return "lifecycle";
    case "P0022": return "semester";
    case "23503": return "referenced";
    case "23505": return "duplicate";
    default: return "unavailable";
  }
}

async function revalidateExamViews(): Promise<void> {
  for (const path of ["/admin", "/admin/scheduling", "/admin/timetable", "/admin/conflicts", "/student", "/student/exams", "/student/timetable", "/student/search", "/student/notifications", "/invigilator", "/invigilator/exams", "/invigilator/timetable"]) {
    revalidatePath(path);
  }
}

async function refreshRejectedConflicts(scheduleId: string): Promise<void> {
  const supabase = await createServerSupabaseClient();
  await supabase.rpc("refresh_schedule_conflicts", { p_schedule_id: scheduleId });
  revalidatePath("/admin/conflicts");
}

export async function createExamSession(formData: FormData): Promise<never> {
  await requireRole("admin");
  const input = examSessionInputSchema.safeParse({
    name: getText(formData, "name"),
    academic_session: getText(formData, "academic_session"),
    semester: getText(formData, "semester"),
    start_date: getText(formData, "start_date"),
    end_date: getText(formData, "end_date"),
  });
  if (!input.success) redirect("/admin/sessions?result=invalid");

  const supabase = await createServerSupabaseClient();
  const { error } = await supabase.from("exam_sessions").insert({
    ...input.data,
    status: "draft",
  });
  if (error) redirect(`/admin/sessions?result=${databaseErrorCode(error)}`);
  revalidatePath("/admin/sessions");
  revalidatePath("/admin/scheduling");
  redirect("/admin/sessions?result=created");
}

export async function activateExamSession(formData: FormData): Promise<never> {
  await requireRole("admin");
  const id = getText(formData, "id");
  const { success, data: sessionId } = z.string().uuid().safeParse(id);
  if (!success) redirect("/admin/sessions?result=invalid");

  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase.from("exam_sessions").update({ status: "active" }).eq("id", sessionId).select("id").maybeSingle();
  if (error || !data) redirect("/admin/sessions?result=unavailable");
  revalidatePath("/admin/sessions");
  revalidatePath("/admin/scheduling");
  redirect("/admin/sessions?result=activated");
}

export async function updateExamSession(formData: FormData): Promise<never> {
  await requireRole("admin");
  const input = examSessionEditSchema.safeParse({
    id: getText(formData, "id"), name: getText(formData, "name"),
    academic_session: getText(formData, "academic_session"), semester: getText(formData, "semester"),
    start_date: getText(formData, "start_date"), end_date: getText(formData, "end_date"),
  });
  if (!input.success) redirect("/admin/sessions?result=invalid");
  const { id, ...changes } = input.data;
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase.from("exam_sessions").update(changes).eq("id", id).in("status", ["draft", "active"]).select("id").maybeSingle();
  if (error) redirect(`/admin/sessions?result=${databaseErrorCode(error)}`);
  if (!data) redirect("/admin/sessions?result=unavailable");
  revalidatePath("/admin/sessions");
  revalidatePath("/admin/scheduling");
  redirect("/admin/sessions?result=updated");
}

export async function changeExamSessionStatus(formData: FormData): Promise<never> {
  await requireRole("admin");
  const parsed = z.object({
    id: z.string().uuid(),
    from: z.enum(["draft", "active", "completed"]),
    to: z.enum(["active", "completed", "archived"]),
  }).safeParse({ id: getText(formData, "id"), from: getText(formData, "from"), to: getText(formData, "to") });
  if (!parsed.success) redirect("/admin/sessions?result=invalid");
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase.from("exam_sessions").update({ status: parsed.data.to }).eq("id", parsed.data.id).eq("status", parsed.data.from).select("id").maybeSingle();
  if (error) redirect(`/admin/sessions?result=${databaseErrorCode(error)}`);
  if (!data) redirect("/admin/sessions?result=unavailable");
  revalidatePath("/admin/sessions");
  revalidatePath("/admin/scheduling");
  redirect(`/admin/sessions?result=${parsed.data.to}`);
}

export async function deleteExamSession(formData: FormData): Promise<never> {
  await requireRole("admin");
  const parsed = z.string().uuid().safeParse(getText(formData, "id"));
  if (!parsed.success) redirect("/admin/sessions?result=invalid");
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase.from("exam_sessions").delete().eq("id", parsed.data).eq("status", "draft").select("id").maybeSingle();
  if (error) redirect(`/admin/sessions?result=${databaseErrorCode(error)}`);
  if (!data) redirect("/admin/sessions?result=unavailable");
  revalidatePath("/admin/sessions");
  redirect("/admin/sessions?result=deleted");
}

export async function saveExamSchedule(formData: FormData): Promise<never> {
  await requireRole("admin");
  const input = examScheduleInputSchema.safeParse({
    id: getText(formData, "id"),
    exam_session_id: getText(formData, "exam_session_id"),
    course_id: getText(formData, "course_id"),
    venue_id: getText(formData, "venue_id"),
    invigilator_id: getText(formData, "invigilator_id"),
    exam_date: getText(formData, "exam_date"),
    start_time: getText(formData, "start_time"),
    end_time: getText(formData, "end_time"),
  });
  if (!input.success) redirect("/admin/scheduling?result=invalid");

  const supabase = await createServerSupabaseClient();
  const { id, ...schedule } = input.data;
  const result = id
    ? await supabase.from("exam_schedules").update(schedule).eq("id", id).eq("status", "draft").select("id").maybeSingle()
    : await supabase.from("exam_schedules").insert({ ...schedule, status: "draft" }).select("id").maybeSingle();

  if (result.error) redirect(`/admin/scheduling?result=${databaseErrorCode(result.error)}`);
  if (!result.data) redirect("/admin/scheduling?result=unavailable");
  await revalidateExamViews();
  redirect(`/admin/scheduling?result=${id ? "updated" : "saved"}`);
}

export async function scheduleExam(formData: FormData): Promise<never> {
  await requireRole("admin");
  const id = getText(formData, "id");
  const { success, data: scheduleId } = z.string().uuid().safeParse(id);
  if (!success) redirect("/admin/scheduling?result=invalid");

  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase
    .from("exam_schedules")
    .update({ status: "scheduled", published_at: null })
    .eq("id", scheduleId)
    .eq("status", "draft")
    .select("id")
    .maybeSingle();
  if (error) {
    await refreshRejectedConflicts(scheduleId);
    redirect(`/admin/scheduling?result=${databaseErrorCode(error)}`);
  }
  if (!data) redirect("/admin/scheduling?result=unavailable");
  await revalidateExamViews();
  redirect("/admin/scheduling?result=scheduled");
}

export async function publishExamSchedule(formData: FormData): Promise<never> {
  await requireRole("admin");
  const id = getText(formData, "id");
  const { success, data: scheduleId } = z.string().uuid().safeParse(id);
  if (!success) redirect("/admin/scheduling?result=invalid");

  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase
    .from("exam_schedules")
    .update({ status: "published", published_at: new Date().toISOString() })
    .eq("id", scheduleId)
    .eq("status", "scheduled")
    .select("id")
    .maybeSingle();
  if (error) {
    await refreshRejectedConflicts(scheduleId);
    redirect(`/admin/scheduling?result=${databaseErrorCode(error)}`);
  }
  if (!data) redirect("/admin/scheduling?result=unavailable");
  await revalidateExamViews();
  redirect("/admin/scheduling?result=published");
}

export async function unpublishExamSchedule(formData: FormData): Promise<never> {
  await requireRole("admin");
  const id = getText(formData, "id");
  const { success, data: scheduleId } = z.string().uuid().safeParse(id);
  if (!success) redirect("/admin/scheduling?result=invalid");

  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase
    .from("exam_schedules")
    .update({ status: "scheduled", published_at: null })
    .eq("id", scheduleId)
    .eq("status", "published")
    .select("id")
    .maybeSingle();
  if (error) redirect(`/admin/scheduling?result=${databaseErrorCode(error)}`);
  if (!data) redirect("/admin/scheduling?result=unavailable");
  await revalidateExamViews();
  redirect("/admin/scheduling?result=unpublished");
}

export async function cancelExamSchedule(formData: FormData): Promise<never> {
  await requireRole("admin");
  const id = getText(formData, "id");
  const { success, data: scheduleId } = z.string().uuid().safeParse(id);
  if (!success) redirect("/admin/scheduling?result=invalid");

  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase.from("exam_schedules").update({ status: "cancelled", published_at: null }).eq("id", scheduleId).neq("status", "cancelled").select("id").maybeSingle();
  if (error || !data) redirect("/admin/scheduling?result=unavailable");
  await revalidateExamViews();
  redirect("/admin/scheduling?result=cancelled");
}
