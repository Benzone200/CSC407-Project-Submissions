import { CatalogField, CatalogForm, CatalogPageFrame, CatalogSubmit, catalogField } from "@/src/components/catalog/catalog-page-frame";
import { getAdminCatalogWorkspace } from "@/src/lib/catalog/queries";
import { VenueRecordForm } from "../_components/catalog-record-forms";

export default async function VenuesPage({ searchParams }: { searchParams: Promise<{ result?: string }> }) {
  const [{ result }, data] = await Promise.all([searchParams, getAdminCatalogWorkspace()]);
  return <CatalogPageFrame title="Venues" description="Add examination rooms and their seating capacity. Only active venues can be scheduled." result={result}
    form={<CatalogForm entity="venue" title="Add a venue" hint="Capacity must be a positive whole number."><div className="grid gap-4"><CatalogField label="Venue name" name="name" maxLength={160} required placeholder="Main Hall" /><CatalogField label="Location" name="location" maxLength={240} required placeholder="North Campus" /><CatalogField label="Capacity" name="capacity" type="number" min={1} required placeholder="250" /><label className="block"><span className="mb-1.5 block text-xs font-medium text-slate-700">Status</span><select name="status" required defaultValue="active" className={catalogField}><option value="active">Active</option><option value="inactive">Inactive</option><option value="maintenance">Maintenance</option></select></label></div><CatalogSubmit /></CatalogForm>}
    records={data.venues.length ? <ul className="divide-y divide-slate-100">{data.venues.map((item) => <li key={item.id} className="px-5 py-4">
      <div className="flex flex-wrap items-center justify-between gap-2"><p className="text-sm font-medium text-slate-900">{item.name}</p><span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs capitalize text-slate-700">{item.status}</span></div>
      <p className="mt-1 text-xs text-slate-500">{item.location} · {item.capacity} seats</p>
      <VenueRecordForm venue={item} />
    </li>)}</ul> : <p className="px-5 py-10 text-center text-sm text-slate-500">No venues have been added.</p>} />;
}
