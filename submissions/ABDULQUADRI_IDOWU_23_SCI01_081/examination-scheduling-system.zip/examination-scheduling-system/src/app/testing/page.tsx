import { CheckCircle2, ClipboardCheck } from "lucide-react";
import { SystemInfoPage } from "@/src/components/system-info-page";

const categories = ["Authorization and restricted-account rules", "Scheduling and catalogue validation", "PostgreSQL migration, trigger and RLS integration", "Responsive navigation and confirmation controls", "Keepalive safety and desktop/mobile browser smoke tests"];

export default function TestingPage() {
  return <SystemInfoPage eyebrow="Quality assurance" title="Testing workspace" description="Repository verification coverage and the boundary between local checks and environment-dependent tests.">
    <div className="mb-5 rounded-xl border border-violet-200 bg-violet-50 p-4"><p className="text-xs font-semibold text-violet-950">Automated checks are included</p><p className="mt-1 text-xs leading-5 text-violet-900/80">Run <code>pnpm verify</code> for source checks, <code>pnpm test:db</code> for executable PostgreSQL trigger/RLS checks, and <code>pnpm test:e2e</code> for browser smoke coverage. Authenticated browser workflows require dedicated Supabase Auth test accounts.</p></div>
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white"><div className="border-b border-slate-100 px-5 py-4"><h2 className="text-sm font-semibold">Verification categories</h2><p className="mt-1 text-xs text-slate-500">These categories have automated repository coverage; environment-specific checks remain separately reported.</p></div><ul className="divide-y divide-slate-100">{categories.map((category) => <li key={category} className="flex items-center justify-between gap-4 px-5 py-4"><span className="flex items-center gap-3 text-xs font-medium text-slate-800"><ClipboardCheck className="size-4 text-violet-700" />{category}</span><span className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-[10px] font-medium text-emerald-700"><CheckCircle2 className="size-3" />Automated</span></li>)}</ul></div>
  </SystemInfoPage>;
}
