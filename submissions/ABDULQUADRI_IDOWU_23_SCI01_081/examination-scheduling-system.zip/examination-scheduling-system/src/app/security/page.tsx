import { CheckCircle2, Clock3, ShieldCheck } from "lucide-react";
import { SystemInfoPage } from "@/src/components/system-info-page";

const items = [
  { title: "Supabase authentication", status: "Implemented", text: "Supabase Auth provides email/password sign-in, sign-up, confirmation and server-managed session handling." },
  { title: "Row Level Security", status: "Implemented", text: "RLS policies scope administrative writes by trusted profile role and restrict student, invigilator and notification reads to the authenticated subject. New migrations still require environment-specific application." },
  { title: "Role-based authorization", status: "Implemented", text: "Protected student, admin and invigilator layouts resolve the current role from the application profile in Supabase. A mismatch is redirected to that role’s own area. No client-supplied role is trusted." },
  { title: "Input validation", status: "Implemented", text: "Server actions validate identifiers, dates, times, academic terms and catalogue fields with Zod before issuing database mutations." },
  { title: "SQL injection prevention", status: "Implemented", text: "Application data access uses Supabase's parameterized query builder, and database functions use fixed SQL rather than concatenating browser input." },
  { title: "XSS prevention", status: "Framework baseline", text: "React escapes rendered text by default. Any future rich content or unsafe HTML rendering will need explicit sanitization and review." },
  { title: "Session management", status: "Implemented", text: "Secure cookies carry the Supabase session; the Next.js proxy verifies and refreshes claims before protected server rendering." },
  { title: "Access control", status: "Implemented", text: "Server layouts enforce the database-backed role while RLS resolves the linked profile through auth.uid(). Restricted accounts receive no application data." },
  { title: "Environment variables", status: "Configured", text: "Only the browser-safe Supabase project URL and publishable key are used by application code; no service-role key is exposed." },
  { title: "HTTPS", status: "Deployment dependent", text: "Use an HTTPS deployment and secure production environment configuration. Production deployment settings have not been verified here." },
];

export default function SecurityPage() {
  return <SystemInfoPage eyebrow="Trust and access" title="Security overview" description="A transparent summary of implemented protections and deployment-dependent controls.">
    <div className="mb-5 flex items-start gap-3 rounded-xl border border-violet-100 bg-violet-50/70 p-4"><ShieldCheck className="mt-0.5 size-5 shrink-0 text-violet-800" /><p className="text-xs leading-5 text-violet-950">The trusted database profile role is the application authorization source. Browser input and Supabase user metadata cannot grant administrator privileges, and signed-in access alone does not imply administrative permission.</p></div>
    <div className="grid gap-3 md:grid-cols-2">{items.map((item) => { const implemented = item.status === "Implemented" || item.status === "Configured"; return <article key={item.title} className="rounded-xl border border-slate-200 bg-white p-5"><div className="flex items-start justify-between gap-3"><h2 className="text-sm font-semibold text-slate-900">{item.title}</h2><span className={`inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-1 text-[10px] font-medium ${implemented ? "bg-emerald-50 text-emerald-800" : "bg-slate-100 text-slate-600"}`}>{implemented ? <CheckCircle2 className="size-3" /> : <Clock3 className="size-3" />}{item.status}</span></div><p className="mt-2 text-xs leading-5 text-slate-600">{item.text}</p></article>; })}</div>
  </SystemInfoPage>;
}
