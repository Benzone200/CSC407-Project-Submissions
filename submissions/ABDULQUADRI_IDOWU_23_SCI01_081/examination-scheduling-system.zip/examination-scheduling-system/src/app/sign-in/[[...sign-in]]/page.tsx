import Link from "next/link";
import { ArrowRight, CalendarDays, CircleCheck, LockKeyhole, ShieldCheck } from "lucide-react";
import { SiteHeader } from "@/src/components/site-header";
import { SignInForm } from "@/src/components/auth/sign-in-form";

const signInFeatures = [
  { icon: CircleCheck, label: "Coordinate sessions, courses, and venues" },
  { icon: ShieldCheck, label: "Review schedules with conflict checks" },
  { icon: LockKeyhole, label: "Access information through your account" },
];

export default function SignInPage() {
  return <>
    <SiteHeader />
    <main className="flex flex-1 items-center justify-center bg-[#f7f6fa] px-4 py-8 sm:px-6 sm:py-12">
      <div className="grid w-full max-w-6xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-[0_24px_80px_-36px_rgba(35,24,50,0.28)] md:min-h-[620px] md:grid-cols-[0.92fr_1.08fr]">
        <section className="relative flex flex-col justify-between overflow-hidden bg-violet-950 px-6 py-8 text-white sm:px-9 sm:py-10 lg:px-12 lg:py-12">
          <div aria-hidden="true" className="pointer-events-none absolute -right-24 -top-24 size-72 rounded-full border border-white/10" />
          <div>
            <Link href="/" className="inline-flex items-center gap-3 rounded-md focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white"><span className="grid size-10 place-items-center rounded-xl bg-white/10 ring-1 ring-white/15"><CalendarDays className="size-5" /></span><span className="text-base font-semibold tracking-tight">ExamSchedule</span></Link>
            <p className="mt-12 text-xs font-semibold uppercase tracking-[0.18em] text-violet-200 sm:mt-16">CSC 407 Examination Scheduling</p>
            <h1 className="mt-4 max-w-md text-3xl font-semibold leading-tight tracking-tight sm:text-4xl lg:text-[2.65rem]">A clearer way to plan examination periods.</h1>
            <p className="mt-4 max-w-md text-sm leading-6 text-violet-100/80 sm:text-base sm:leading-7">Sign in to the secure workspace for examination planning and timetable access.</p>
          </div>
          <ul className="mt-9 grid gap-3 border-t border-white/15 pt-6 sm:mt-12 sm:pt-7">{signInFeatures.map(({ icon: Icon, label }) => <li key={label} className="flex items-start gap-3 text-sm text-violet-50/90"><Icon aria-hidden="true" className="mt-0.5 size-4 shrink-0 text-violet-200" /><span>{label}</span></li>)}</ul>
          <Link href="/security" className="mt-7 inline-flex w-fit items-center gap-2 text-xs font-medium text-violet-200 hover:text-white">Read about account security <ArrowRight className="size-3.5" /></Link>
        </section>
        <section className="flex flex-col justify-center px-5 py-9 sm:px-9 sm:py-12 lg:px-14">
          <div className="mx-auto w-full max-w-md">
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-violet-800">Welcome back</p>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">Sign in to your workspace</h2>
            <p className="mt-2 text-sm leading-6 text-slate-500">Use the email address and password registered with ExamSchedule.</p>
            <SignInForm />
            <p className="mt-5 text-center text-sm text-slate-600">Need an account? <Link href="/sign-up" className="font-semibold text-violet-800 hover:text-violet-950">Create one</Link></p>
          </div>
        </section>
      </div>
    </main>
  </>;
}
