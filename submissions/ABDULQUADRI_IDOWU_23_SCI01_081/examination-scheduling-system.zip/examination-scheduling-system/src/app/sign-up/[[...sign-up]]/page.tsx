import Link from "next/link";
import { CalendarDays } from "lucide-react";
import { SiteHeader } from "@/src/components/site-header";
import { SignUpForm } from "@/src/components/auth/sign-up-form";

export default function SignUpPage() {
  return <>
    <SiteHeader />
    <main className="flex flex-1 items-center justify-center bg-[#f7f6fa] px-4 py-8 sm:px-6 sm:py-12">
      <section className="w-full max-w-xl rounded-2xl border border-slate-200 bg-white p-6 shadow-[0_24px_80px_-36px_rgba(35,24,50,0.28)] sm:p-10">
        <Link href="/" className="inline-flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-violet-100 text-violet-800"><CalendarDays className="size-5" /></span><span className="font-semibold text-slate-950">ExamSchedule</span></Link>
        <p className="mt-8 text-xs font-semibold uppercase tracking-[0.16em] text-violet-800">Create account</p>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-950">Join your examination workspace</h1>
        <p className="mt-3 text-sm leading-6 text-slate-500">New accounts begin with the student role. Academic records and additional responsibilities are assigned only by an administrator.</p>
        <SignUpForm />
        <p className="mt-5 text-center text-sm text-slate-600">Already registered? <Link href="/sign-in" className="font-semibold text-violet-800 hover:text-violet-950">Sign in</Link></p>
      </section>
    </main>
  </>;
}
