import Link from "next/link";
import { notFound } from "next/navigation";
import { z } from "zod";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { getInvigilatorExamById } from "@/src/lib/scheduling/queries";

export default async function InvigilatorExamDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!z.string().uuid().safeParse(id).success) notFound();
  const exam = await getInvigilatorExamById(id);
  if (!exam) notFound();
  return <div className="mx-auto w-full max-w-[1000px] px-4 py-7 sm:px-7 sm:py-9">
    <PageHeading eyebrow="Invigilator" title={`${exam.course.code} · ${exam.course.title}`} description="Assigned examination details from the secured timetable." action={<Link href="/invigilator/exams" className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">Back to exams</Link>} />
    <dl className="grid gap-4 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:grid-cols-2 sm:p-7">
      <div><dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">Date</dt><dd className="mt-1 text-sm text-slate-900">{exam.exam_date}</dd></div>
      <div><dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">Time</dt><dd className="mt-1 text-sm text-slate-900">{exam.start_time.slice(0, 5)}–{exam.end_time.slice(0, 5)}</dd></div>
      <div><dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">Venue</dt><dd className="mt-1 text-sm text-slate-900">{exam.venue.name} · {exam.venue.location}</dd></div>
      <div><dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">Status</dt><dd className="mt-1 text-sm capitalize text-slate-900">{exam.status}</dd></div>
      <div className="sm:col-span-2"><dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">Examination session</dt><dd className="mt-1 text-sm text-slate-900">{exam.session.name} · {exam.session.academic_session} · Semester {exam.session.semester}</dd></div>
    </dl>
  </div>;
}
