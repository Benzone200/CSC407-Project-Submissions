import { PageHeading } from "@/src/components/dashboard/page-heading";
import { StudentExamList } from "@/src/components/dashboard/student-exam-list";
import { PaginationNav } from "@/src/components/dashboard/pagination-nav";
import { getInvigilatorExamPage } from "@/src/lib/scheduling/queries";
import { parsePage } from "@/src/lib/scheduling/pagination";

export default async function InvigilatorExamsPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const params = await searchParams;
  const result = await getInvigilatorExamPage({ page: parsePage(params.page) });
  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Invigilator" title="Assigned examinations" description="Scheduled and published exams assigned to your staff record." />
    <StudentExamList exams={result.items} detailHref={(id) => `/invigilator/exams/${id}`} />
    <PaginationNav page={result.page} totalPages={result.totalPages} href={(page) => `/invigilator/exams?page=${page}`} />
  </div>;
}
