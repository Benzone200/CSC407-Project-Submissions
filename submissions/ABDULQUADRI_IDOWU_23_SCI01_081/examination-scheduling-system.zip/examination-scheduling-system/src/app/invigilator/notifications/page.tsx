import { Bell } from "lucide-react";
import { EmptyState } from "@/src/components/dashboard/empty-state";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { getInvigilatorNotifications } from "@/src/lib/scheduling/queries";
import { markInvigilatorNotificationRead } from "../actions";

export default async function InvigilatorNotificationsPage({ searchParams }: { searchParams: Promise<{ result?: string }> }) {
  const [{ result }, notifications] = await Promise.all([searchParams, getInvigilatorNotifications()]);
  return <div className="mx-auto w-full max-w-[1200px] px-4 py-7 sm:px-7 sm:py-9">
    <PageHeading eyebrow="Invigilator" title="Notifications" description="Publication, timetable and cancellation updates addressed to your staff profile." />
    {result === "read" ? <p role="status" className="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">Notification marked as read.</p> : null}
    <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">{notifications.length ? <ul className="divide-y divide-slate-100">{notifications.map((item) => <li key={item.id} className="px-5 py-4"><div className="flex flex-wrap items-center gap-2"><p className="text-sm font-semibold text-slate-900">{item.title}</p>{!item.read_at ? <span className="rounded-full bg-violet-50 px-2 py-0.5 text-[10px] font-semibold text-violet-800">New</span> : null}</div><p className="mt-1 text-sm leading-6 text-slate-600">{item.message}</p><div className="mt-2 flex flex-wrap items-center justify-between gap-3"><p className="text-xs text-slate-400">{new Date(item.created_at).toLocaleString()}</p>{!item.read_at ? <form action={markInvigilatorNotificationRead}><input type="hidden" name="id" value={item.id} /><button className="rounded-lg border border-violet-200 px-3 py-1.5 text-xs font-semibold text-violet-800 hover:bg-violet-50">Mark as read</button></form> : <span className="text-xs text-slate-400">Read</span>}</div></li>)}</ul> : <EmptyState icon={Bell} title="No notifications" description="Assigned examination updates will appear here." />}</section>
  </div>;
}
