import { UserRound } from "lucide-react";
import { requireRole } from "@/src/lib/auth/current-user";
import { getInvigilatorProfileDetails } from "@/src/lib/scheduling/queries";

export default async function InvigilatorProfilePage() {
  const [current, staff] = await Promise.all([requireRole("invigilator"), getInvigilatorProfileDetails()]);
  const fullName = [current.profile.first_name, current.profile.last_name].filter(Boolean).join(" ").trim();
  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <h1 className="text-2xl font-semibold tracking-tight text-slate-950">Profile</h1>
    <p className="mt-2 text-sm text-slate-500">Authenticated account and application role.</p>
    <section className="mt-6 max-w-2xl rounded-xl border border-slate-200 bg-white p-5">
      <div className="flex items-center gap-3"><UserRound className="size-5 text-violet-800" /><div><h2 className="text-sm font-semibold">{fullName || "Name not provided"}</h2><p className="mt-1 text-xs text-slate-500">{current.profile.email}</p></div></div>
      <dl className="mt-4 grid gap-4 sm:grid-cols-2"><div><dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">Application role</dt><dd className="mt-1 text-sm capitalize text-slate-800">{current.profile.role}</dd></div><div><dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">Staff ID</dt><dd className="mt-1 text-sm text-slate-800">{staff?.staff_id ?? "Not assigned"}</dd></div><div className="sm:col-span-2"><dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">Department</dt><dd className="mt-1 text-sm text-slate-800">{staff?.department ? `${staff.department.name} (${staff.department.code})` : "Not assigned"}</dd></div></dl>
      {!staff ? <p className="mt-4 rounded-lg bg-amber-50 px-4 py-3 text-xs text-amber-800">Your account is an invigilator, but no staff record has been assigned yet.</p> : null}
    </section>
  </div>;
}
