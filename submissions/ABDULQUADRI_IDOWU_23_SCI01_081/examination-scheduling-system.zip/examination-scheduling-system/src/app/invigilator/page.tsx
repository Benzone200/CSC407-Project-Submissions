import Link from "next/link";
import { ClipboardCheck } from "lucide-react";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { StudentExamList } from "@/src/components/dashboard/student-exam-list";
import { getInvigilatorExamPage } from "@/src/lib/scheduling/queries";

export default async function InvigilatorDashboard() {
  const exams = await getInvigilatorExamPage({ pageSize: 5 });
  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Invigilator workspace" title="Assigned examinations" description="Exams currently scheduled or published for your invigilator record." action={<Link href="/invigilator/timetable" className="inline-flex h-10 items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 text-xs font-semibold text-slate-700 hover:bg-slate-50"><ClipboardCheck className="size-4" /> View timetable</Link>} />
    <p className="mb-4 text-sm text-slate-600">{exams.total} assigned {exams.total === 1 ? "examination" : "examinations"}; showing the next {exams.items.length}.</p>
    <StudentExamList exams={exams.items} detailHref={(id) => `/invigilator/exams/${id}`} />
  </div>;
}
