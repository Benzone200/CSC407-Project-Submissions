"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { requireRole } from "@/src/lib/auth/current-user";
import { createServerSupabaseClient } from "@/src/lib/supabase/server";

export async function markInvigilatorNotificationRead(formData: FormData): Promise<never> {
  await requireRole("invigilator");
  const parsed = z.string().uuid().safeParse(formData.get("id"));
  if (!parsed.success) redirect("/invigilator/notifications?result=invalid");
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase.from("notifications").update({ read_at: new Date().toISOString() }).eq("id", parsed.data).is("read_at", null).select("id").maybeSingle();
  if (error) redirect("/invigilator/notifications?result=unavailable");
  if (!data) redirect("/invigilator/notifications?result=unchanged");
  revalidatePath("/invigilator/notifications");
  redirect("/invigilator/notifications?result=read");
}
