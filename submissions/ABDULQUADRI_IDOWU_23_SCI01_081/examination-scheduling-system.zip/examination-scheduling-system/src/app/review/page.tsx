import { Activity, BookOpenCheck, Bug, CircleHelp, Cloud, LockKeyhole, Sparkles } from "lucide-react";
import { SystemInfoPage } from "@/src/components/system-info-page";

const sections = [
  ["System overview", "ExamSchedule is a CSC 407 examination scheduling system built with Next.js and Supabase Auth/PostgreSQL for administrators, students and invigilators."],
  ["Features", "Administrators manage academic records, sessions and examination lifecycles. Students receive published timetables and notifications, while invigilators see only assigned examinations."],
  ["Security", "Supabase Auth verifies users, trusted database profiles provide roles, and RLS plus validation triggers protect records even when the API is called directly."],
  ["Testing", "The repository includes validation, authorization, migration-contract and browser smoke tests. See the Testing page and completion report for the latest executed results."],
  ["Deployment", "The project is configured for a standard Next.js deployment workflow. Production environment variables and hosting configuration still require operator verification."],
  ["Limitations", "Automated timetable optimization, bulk import and deployment are outside this academic-project scope. New migrations must be applied to each Supabase environment before their protections become active."],
  ["Future improvements", "Possible extensions include optimization-assisted scheduling, calendar export, richer reports and institution-managed identity synchronization."],
] as const;
const icons = [BookOpenCheck, Activity, LockKeyhole, Bug, Cloud, CircleHelp, Sparkles] as const;

export default function ReviewPage() {
  return <SystemInfoPage eyebrow="Project notes" title="Project review" description="A concise overview of the system foundation, current scope and next steps.">
    <div className="grid gap-3 md:grid-cols-2">{sections.map(([title, text], i) => { const Icon = icons[i]; return <article key={title} className="rounded-xl border border-slate-200 bg-white p-5"><span className="grid size-9 place-items-center rounded-lg bg-violet-50 text-violet-800"><Icon className="size-4" /></span><h2 className="mt-4 text-sm font-semibold">{title}</h2><p className="mt-2 text-xs leading-5 text-slate-600">{text}</p></article>; })}</div>
  </SystemInfoPage>;
}
