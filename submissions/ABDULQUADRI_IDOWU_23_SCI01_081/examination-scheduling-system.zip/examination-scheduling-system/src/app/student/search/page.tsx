import { CalendarDays, Search } from "lucide-react";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { StudentExamList } from "@/src/components/dashboard/student-exam-list";
import { PaginationNav } from "@/src/components/dashboard/pagination-nav";
import { getStudentExamPage } from "@/src/lib/scheduling/queries";
import { parsePage } from "@/src/lib/scheduling/pagination";
import { studentExamFilterSchema } from "@/src/lib/scheduling/validation";

export default async function StudentSearchPage({ searchParams }: { searchParams: Promise<{ q?: string; date?: string; page?: string }> }) {
  const params = await searchParams;
  const parsed = studentExamFilterSchema.safeParse({ query: params.q ?? "", date: params.date || undefined });
  const result = parsed.success ? await getStudentExamPage({ query: parsed.data.query, date: parsed.data.date, page: parsePage(params.page) }) : null;
  const exams = result?.items ?? [];
  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Find an exam" title="Search examinations" description="Search published examinations for courses in your own enrollment." />
    {!parsed.success ? <p role="alert" className="mb-4 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">Enter a search term under 100 characters and choose a valid date.</p> : null}
    <form action="/student/search" method="get" className="mb-5 grid gap-3 rounded-xl border border-slate-200 bg-white p-4 sm:grid-cols-[1fr_190px_auto] sm:items-end sm:p-5">
      <label className="block"><span className="mb-1.5 block text-xs font-medium text-slate-700">Course or exam</span><span className="relative block"><Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" /><input name="q" maxLength={100} defaultValue={params.q} placeholder="Search course code or title" className="h-10 w-full rounded-lg border border-slate-200 bg-white pl-9 pr-3 text-sm outline-none placeholder:text-slate-400 focus:border-violet-400 focus:ring-2 focus:ring-violet-100" /></span></label>
      <label className="block"><span className="mb-1.5 block text-xs font-medium text-slate-700">Date</span><input name="date" type="date" defaultValue={params.date} className="h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-600 outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100" /></label>
      <button type="submit" className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-violet-800 px-4 text-xs font-semibold text-white hover:bg-violet-900"><Search className="size-4" /> Search</button>
    </form>
    {parsed.success && !exams.length && !params.q && !params.date ? <div className="rounded-xl border border-slate-200 bg-white py-12 text-center"><CalendarDays className="mx-auto size-8 text-violet-500" /><h2 className="mt-3 text-sm font-semibold text-slate-900">No published exams to search</h2><p className="mt-1 text-sm text-slate-500">Your eligible published examinations will appear here.</p></div> : <StudentExamList exams={exams} />}
    {result ? <PaginationNav page={result.page} totalPages={result.totalPages} href={(page) => { const query = new URLSearchParams(); if (params.q) query.set("q", params.q); if (params.date) query.set("date", params.date); query.set("page", String(page)); return `/student/search?${query.toString()}`; }} /> : null}
  </div>;
}
