import { PageHeading } from "@/src/components/dashboard/page-heading";
import { StudentExamList } from "@/src/components/dashboard/student-exam-list";
import { PaginationNav } from "@/src/components/dashboard/pagination-nav";
import { getStudentExamPage } from "@/src/lib/scheduling/queries";
import { parsePage } from "@/src/lib/scheduling/pagination";

export default async function StudentTimetablePage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const params = await searchParams;
  const result = await getStudentExamPage({ page: parsePage(params.page) });
  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Student" title="My timetable" description="Published examinations for your enrolled courses." />
    <StudentExamList exams={result.items} />
    <PaginationNav page={result.page} totalPages={result.totalPages} href={(page) => `/student/timetable?page=${page}`} />
  </div>;
}
