import { ArrowRight, CalendarDays, CheckCircle2, CircleAlert, ClipboardList, Search } from "lucide-react";
import Link from "next/link";
import { EmptyState } from "@/src/components/dashboard/empty-state";
import { PageHeading } from "@/src/components/dashboard/page-heading";
import { StatCard } from "@/src/components/dashboard/stat-card";
import { StudentExamList } from "@/src/components/dashboard/student-exam-list";
import { requireRole } from "@/src/lib/auth/current-user";
import { getStudentDashboardData } from "@/src/lib/scheduling/queries";

export default async function StudentDashboard() {
  const [current, dashboard] = await Promise.all([requireRole("student"), getStudentDashboardData()]);
  const name = current.profile.first_name.trim()
    || [current.profile.first_name, current.profile.last_name].filter(Boolean).join(" ").trim()
    || "there";
  const upcoming = dashboard.upcoming;
  return <div className="mx-auto w-full max-w-[1440px] px-4 py-7 sm:px-7 sm:py-9 lg:px-9">
    <PageHeading eyebrow="Student workspace" title={`Welcome, ${name}`} description="Your examination information is based on published exams for your enrolled courses." action={<Link href="/student/search" className="inline-flex h-10 items-center gap-2 rounded-lg bg-violet-800 px-4 text-xs font-semibold text-white hover:bg-violet-900">Find an exam <Search className="size-4" /></Link>} />
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      <StatCard label="Total examinations" value={String(dashboard.total)} detail="Published for your enrolled courses" icon={ClipboardList} />
      <StatCard label="Upcoming" value={String(dashboard.upcomingCount)} detail="Today or later, campus local date" icon={CalendarDays} />
      <StatCard label="Completed" value={String(dashboard.completedCount)} detail="Earlier published exam dates" icon={CheckCircle2} />
      <StatCard label="Conflict records" value="—" detail="Student conflict records are not exposed" icon={CircleAlert} />
    </div>
    <section className="mt-6 overflow-hidden rounded-xl border border-slate-200/90 bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4"><div><h2 className="text-sm font-semibold text-slate-900">Upcoming examinations</h2><p className="mt-1 text-xs text-slate-500">Published exams associated with your courses</p></div><Link href="/student/timetable" className="inline-flex items-center gap-1 text-xs font-semibold text-violet-800 hover:text-violet-950">View timetable <ArrowRight className="size-3.5" /></Link></div>
      {upcoming.length ? <div className="p-4 sm:p-5"><StudentExamList exams={upcoming} /></div> : <EmptyState icon={CalendarDays} title="No upcoming examinations" description="New eligible exams will appear here after an administrator publishes the timetable." />}
    </section>
  </div>;
}
