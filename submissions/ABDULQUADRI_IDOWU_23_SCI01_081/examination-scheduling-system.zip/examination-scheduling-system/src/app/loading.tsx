export default function ApplicationLoading() {
  return <main aria-busy="true" aria-label="Loading page" className="mx-auto w-full max-w-[1440px] flex-1 px-4 py-8 sm:px-7 lg:px-9">
    <span className="sr-only" role="status">Loading page…</span>
    <div aria-hidden="true" className="animate-pulse space-y-6">
      <div className="space-y-3"><div className="h-3 w-24 rounded bg-violet-100" /><div className="h-8 w-72 max-w-full rounded bg-slate-200" /><div className="h-4 w-[32rem] max-w-full rounded bg-slate-100" /></div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{Array.from({ length: 4 }, (_, index) => <div key={index} className="h-28 rounded-xl border border-slate-200 bg-white" />)}</div>
      <div className="h-64 rounded-xl border border-slate-200 bg-white" />
    </div>
  </main>;
}
