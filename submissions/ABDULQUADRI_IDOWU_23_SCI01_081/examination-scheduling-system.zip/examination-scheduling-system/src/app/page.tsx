import Link from "next/link";
import { ArrowRight, CalendarCheck2, Check, LockKeyhole, SearchCheck, UsersRound } from "lucide-react";

const features = [
  { icon: CalendarCheck2, title: "Timetable management", text: "Bring examination sessions, courses, venues and time slots into a clear planning workspace." },
  { icon: SearchCheck, title: "Conflict-aware planning", text: "Give scheduling teams a place to review potential overlaps and resolve issues before publication." },
  { icon: UsersRound, title: "One shared workspace", text: "Support the coordination needs of administrators, students and invigilators in one product." },
];

export default function Home() {
  return <div className="min-h-screen bg-white text-slate-900">
    <header className="border-b border-slate-200/80 bg-white">
      <nav aria-label="Main navigation" className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-5 sm:px-8">
        <Link href="/" className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-violet-800 text-white"><span className="font-bold">E</span></span><span><span className="block text-[15px] font-semibold tracking-tight">ExamSchedule</span><span className="block text-[11px] text-slate-500">CSC 407 · Examination Scheduling</span></span></Link>
        <div className="hidden items-center gap-7 md:flex"><a href="#features" className="text-sm text-slate-600 hover:text-violet-800">Features</a><a href="#workflow" className="text-sm text-slate-600 hover:text-violet-800">How it works</a><Link href="/security" className="text-sm text-slate-600 hover:text-violet-800">Security</Link></div>
        <div className="flex items-center gap-2 sm:gap-3"><Link href="/sign-in" className="rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">Log in</Link><Link href="/sign-up" className="rounded-lg bg-violet-800 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-violet-900">Get started</Link></div>
      </nav>
    </header>

    <main>
      <section className="overflow-hidden border-b border-violet-100 bg-[#f8f5fc]">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-16 sm:px-8 sm:py-20 lg:grid-cols-[1.08fr_.92fr] lg:py-24">
          <div className="max-w-2xl"><span className="inline-flex items-center gap-2 rounded-full border border-violet-200 bg-white px-3 py-1.5 text-xs font-medium text-violet-800"><span className="size-1.5 rounded-full bg-violet-600" />An organized approach to examination planning</span>
            <h1 className="mt-6 text-[2.65rem] font-semibold leading-[1.08] tracking-[-0.04em] text-slate-950 sm:text-5xl lg:text-[58px]">Smarter Examination Scheduling for a Better Academic Experience</h1>
            <p className="mt-6 max-w-xl text-base leading-7 text-slate-600 sm:text-lg sm:leading-8">Coordinate examination timetables with tools that help academic teams plan clearly and help students find the information they need.</p>
            <div className="mt-8 flex flex-wrap gap-3"><Link href="/sign-up" className="inline-flex h-12 items-center gap-2 rounded-lg bg-violet-800 px-5 text-sm font-semibold text-white shadow-sm transition hover:bg-violet-900">Get started <ArrowRight className="size-4" /></Link><Link href="/sign-in" className="inline-flex h-12 items-center rounded-lg border border-slate-300 bg-white px-5 text-sm font-semibold text-slate-700 transition hover:border-violet-300 hover:text-violet-800">Log in</Link></div>
            <div className="mt-8 flex flex-wrap gap-x-5 gap-y-2 text-xs text-slate-500"><span className="inline-flex items-center gap-1.5"><Check className="size-3.5 text-violet-700" />Student timetable access</span><span className="inline-flex items-center gap-1.5"><Check className="size-3.5 text-violet-700" />Administrative planning</span></div>
          </div>
          <div aria-label="Illustrative timetable interface preview" className="relative mx-auto w-full max-w-[540px] rounded-2xl border border-violet-100 bg-white p-4 shadow-[0_24px_70px_rgba(64,42,94,.11)] sm:p-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4"><div><p className="text-[10px] font-semibold uppercase tracking-[.16em] text-violet-700">Workspace preview</p><p className="mt-1 text-sm font-semibold text-slate-900">Examination timetable</p></div><span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-medium text-slate-500">Illustration</span></div>
            <div className="mt-5 grid grid-cols-[70px_repeat(5,minmax(0,1fr))] gap-1.5 text-center text-[9px] text-slate-400 sm:gap-2 sm:text-[10px]"><span />{["Mon", "Tue", "Wed", "Thu", "Fri"].map((d) => <span key={d} className="py-2 font-medium">{d}</span>)}
              {["09:00", "11:00", "13:00", "15:00"].map((time, row) => <div className="contents" key={time}><span className="py-3 text-right">{time}</span>{[0, 1, 2, 3, 4].map((col) => <span key={col} className={`min-h-14 rounded-md border ${((row + col) % 4 === 1) ? "border-violet-100 bg-violet-50" : "border-slate-100 bg-slate-50/70"}`} />)}</div>)}
            </div><p className="mt-4 text-center text-[10px] text-slate-400">A visual preview only · no examination data shown</p>
          </div>
        </div>
      </section>

      <section id="features" className="mx-auto max-w-7xl scroll-mt-10 px-5 py-16 sm:px-8 sm:py-20">
        <div className="max-w-2xl"><p className="text-xs font-semibold uppercase tracking-[.16em] text-violet-700">A clearer process</p><h2 className="mt-3 text-3xl font-semibold tracking-tight text-slate-950 sm:text-4xl">Tools for the whole examination cycle</h2><p className="mt-3 text-sm leading-6 text-slate-600 sm:text-base">ExamSchedule provides a shared foundation for the people involved in planning and accessing examination information.</p></div>
        <div className="mt-9 grid gap-4 md:grid-cols-3">{features.map(({ icon: Icon, title, text }) => <article key={title} className="rounded-xl border border-slate-200 bg-white p-6 transition hover:border-violet-200 hover:shadow-sm"><span className="grid size-10 place-items-center rounded-lg bg-violet-50 text-violet-800"><Icon className="size-5" strokeWidth={1.8} /></span><h3 className="mt-5 text-base font-semibold">{title}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{text}</p></article>)}</div>
      </section>

      <section className="border-y border-slate-200 bg-[#fcfbfd]"><div className="mx-auto grid max-w-7xl gap-9 px-5 py-14 sm:px-8 md:grid-cols-[.8fr_1.2fr] md:items-center md:py-16"><div><span className="grid size-11 place-items-center rounded-xl bg-violet-100 text-violet-800"><LockKeyhole className="size-5" /></span><h2 className="mt-4 text-2xl font-semibold tracking-tight">Access designed with care</h2><p className="mt-3 text-sm leading-6 text-slate-600">Supabase Auth protects each session while PostgreSQL row-level security limits every role to the records it is allowed to use.</p><Link href="/security" className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-violet-800 hover:text-violet-950">Explore security details <ArrowRight className="size-4" /></Link></div><div className="grid gap-3 sm:grid-cols-2"><div className="rounded-xl border border-slate-200 bg-white p-5"><h3 className="text-sm font-semibold">For students</h3><p className="mt-2 text-xs leading-5 text-slate-600">A straightforward place to check published exams and stay informed.</p></div><div className="rounded-xl border border-slate-200 bg-white p-5"><h3 className="text-sm font-semibold">For administrators</h3><p className="mt-2 text-xs leading-5 text-slate-600">A structured workspace for examination planning and coordination.</p></div></div></div></section>

      <section id="workflow" className="mx-auto max-w-7xl scroll-mt-10 px-5 py-16 sm:px-8 sm:py-20"><div className="text-center"><p className="text-xs font-semibold uppercase tracking-[.16em] text-violet-700">A simple workflow</p><h2 className="mt-3 text-3xl font-semibold tracking-tight">From planning to a published timetable</h2></div><ol className="mt-10 grid gap-4 md:grid-cols-3">{[{n:"01",t:"Prepare",d:"Organize the examination session, courses and available venues."},{n:"02",t:"Review",d:"Coordinate proposed times and review potential scheduling conflicts."},{n:"03",t:"Share",d:"Make published examination information available to the university community."}].map((s) => <li key={s.n} className="flex gap-4 rounded-xl border border-slate-200 bg-white p-5"><span className="font-mono text-xs font-semibold text-violet-700">{s.n}</span><div><h3 className="text-sm font-semibold">{s.t}</h3><p className="mt-1.5 text-xs leading-5 text-slate-600">{s.d}</p></div></li>)}</ol></section>

      <section className="px-5 pb-16 sm:px-8 sm:pb-20"><div className="mx-auto flex max-w-7xl flex-col justify-between gap-6 rounded-2xl bg-violet-950 px-6 py-9 text-white sm:px-10 sm:py-11 md:flex-row md:items-center"><div><p className="text-xs font-medium text-violet-200">CSC 407 Examination Scheduling System</p><h2 className="mt-2 text-2xl font-semibold tracking-tight">Make examination planning easier to follow.</h2><p className="mt-2 text-sm text-violet-100/75">Sign in to continue to your workspace.</p></div><Link href="/sign-in" className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-lg bg-white px-4 text-sm font-semibold text-violet-950 hover:bg-violet-50">Go to sign in <ArrowRight className="size-4" /></Link></div></section>
    </main>
    <footer className="border-t border-slate-200"><div className="mx-auto flex max-w-7xl flex-col gap-3 px-5 py-6 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between sm:px-8"><span>© {new Date().getFullYear()} ExamSchedule · CSC 407</span><span className="flex gap-4"><Link href="/security" className="hover:text-violet-800">Security</Link><Link href="/sign-in" className="hover:text-violet-800">Log in</Link></span></div></footer>
  </div>;
}
