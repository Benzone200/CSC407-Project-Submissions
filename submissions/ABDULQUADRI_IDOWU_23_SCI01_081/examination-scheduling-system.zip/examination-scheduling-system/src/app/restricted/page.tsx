import Link from "next/link";
import { ShieldAlert } from "lucide-react";
import { signOutAction } from "@/src/app/auth/actions";

export default function RestrictedAccountPage() {
  return (
    <main className="grid min-h-screen place-items-center bg-slate-50 px-5 py-16">
      <section className="w-full max-w-lg rounded-2xl border border-slate-200 bg-white p-7 text-center shadow-sm sm:p-10">
        <span className="mx-auto grid size-12 place-items-center rounded-full bg-amber-50 text-amber-800">
          <ShieldAlert aria-hidden="true" className="size-6" />
        </span>
        <p className="mt-5 text-xs font-semibold uppercase tracking-[.16em] text-amber-800">
          Account restricted
        </p>
        <h1 className="mt-2 text-2xl font-semibold tracking-tight text-slate-950">
          This account cannot access ExamSchedule
        </h1>
        <p className="mt-3 text-sm leading-6 text-slate-600">
          Contact the examination administrator if you believe this restriction is incorrect.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <form action={signOutAction}>
            <button className="h-10 rounded-lg bg-violet-800 px-4 text-sm font-semibold text-white hover:bg-violet-900">
              Sign out
            </button>
          </form>
          <Link href="/" className="inline-flex h-10 items-center rounded-lg border border-slate-200 px-4 text-sm font-semibold text-slate-700 hover:bg-slate-50">
            Return home
          </Link>
        </div>
      </section>
    </main>
  );
}
