-- Replace Clerk's external JWT subject with Supabase Auth while preserving all
-- existing profile IDs and their student/invigilator/audit relationships.

alter table public.profiles
  add column if not exists auth_user_id uuid,
  add column if not exists account_status text not null default 'active';

alter table public.profiles
  alter column clerk_user_id drop not null;

alter table public.profiles
  drop constraint if exists profiles_account_status_check;

alter table public.profiles
  add constraint profiles_account_status_check
  check (account_status in ('active', 'restricted'));

alter table public.profiles
  drop constraint if exists profiles_auth_user_id_fkey;

alter table public.profiles
  add constraint profiles_auth_user_id_fkey
  foreign key (auth_user_id) references auth.users (id) on delete restrict;

create unique index if not exists profiles_auth_user_id_uidx
  on public.profiles (auth_user_id)
  where auth_user_id is not null;

create or replace function private.current_profile_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $function$
  select p.id
  from public.profiles as p
  where p.auth_user_id = (select auth.uid())
    and p.account_status = 'active'
  limit 1
$function$;

create or replace function private.current_profile_role()
returns text
language sql
stable
security definer
set search_path = ''
as $function$
  select p.role
  from public.profiles as p
  where p.auth_user_id = (select auth.uid())
    and p.account_status = 'active'
  limit 1
$function$;

drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles
  for select to authenticated
  using (auth_user_id = (select auth.uid()));

drop policy if exists departments_select_authenticated on public.departments;
create policy departments_select_authenticated on public.departments
  for select to authenticated
  using ((select private.current_profile_id()) is not null);

-- Auth metadata supplies display names only. It is deliberately impossible to
-- choose a role or account status through sign-up metadata.
create or replace function private.create_profile_for_auth_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
begin
  if new.email is null or pg_catalog.length(pg_catalog.btrim(new.email)) = 0 then
    raise exception using errcode = '23514', message = 'An email address is required.';
  end if;

  if exists (
    select 1 from public.profiles as profile
    where pg_catalog.lower(profile.email) = pg_catalog.lower(new.email)
      and profile.auth_user_id is distinct from new.id
  ) then
    -- Creating an Auth account that matches a legacy profile must never inherit
    -- that profile's role. A trusted operator links it later by exact UUID.
    return new;
  end if;

  insert into public.profiles (
    auth_user_id,
    clerk_user_id,
    email,
    first_name,
    last_name,
    role,
    account_status
  ) values (
    new.id,
    null,
    new.email,
    pg_catalog.left(pg_catalog.btrim(coalesce(new.raw_user_meta_data ->> 'first_name', '')), 100),
    pg_catalog.left(pg_catalog.btrim(coalesce(new.raw_user_meta_data ->> 'last_name', '')), 100),
    'student',
    'active'
  );

  return new;
end;
$function$;

revoke all on function private.create_profile_for_auth_user() from public, anon, authenticated;

create or replace function private.link_existing_profile_to_auth_user(
  p_profile_id uuid,
  p_auth_user_id uuid
)
returns void
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_profile_email text;
  v_auth_email text;
  v_email_confirmed_at timestamptz;
begin
  select profile.email into v_profile_email
  from public.profiles as profile
  where profile.id = p_profile_id
    and profile.auth_user_id is null
  for update;

  if not found then
    raise exception using
      errcode = 'P0022',
      message = 'The application profile does not exist or is already linked.';
  end if;

  select auth_user.email, auth_user.email_confirmed_at
  into v_auth_email, v_email_confirmed_at
  from auth.users as auth_user
  where auth_user.id = p_auth_user_id;

  if not found then
    raise exception using
      errcode = 'P0022',
      message = 'The Supabase Auth user does not exist.';
  end if;

  if v_email_confirmed_at is null then
    raise exception using
      errcode = 'P0023',
      message = 'The Supabase Auth email must be confirmed before linking.';
  end if;

  if v_auth_email is null
    or pg_catalog.lower(v_profile_email) <> pg_catalog.lower(v_auth_email) then
    raise exception using
      errcode = 'P0024',
      message = 'The application profile and Supabase Auth emails do not match.';
  end if;

  if exists (
    select 1 from public.profiles as profile
    where profile.auth_user_id = p_auth_user_id
      and profile.id <> p_profile_id
  ) then
    raise exception using
      errcode = '23505',
      message = 'The Supabase Auth user is already linked to another profile.';
  end if;

  update public.profiles
  set auth_user_id = p_auth_user_id,
      email = v_auth_email,
      updated_at = pg_catalog.now()
  where id = p_profile_id;
end;
$function$;

revoke all on function private.link_existing_profile_to_auth_user(uuid, uuid)
  from public, anon, authenticated;

drop trigger if exists auth_users_create_application_profile on auth.users;
create trigger auth_users_create_application_profile
  after insert on auth.users
  for each row execute function private.create_profile_for_auth_user();

comment on column public.profiles.auth_user_id is
  'Verified Supabase Auth identity. Existing Clerk-era rows remain null until explicitly linked.';
comment on column public.profiles.clerk_user_id is
  'Legacy Clerk identifier retained only for controlled migration and rollback evidence.';
comment on function private.link_existing_profile_to_auth_user(uuid, uuid) is
  'Trusted exact-ID link for a confirmed Supabase Auth user and a matching legacy profile email.';
