-- Phase 3: application data schema and Clerk-backed row-level access.
-- No Supabase Auth users are created. Clerk's JWT `sub` is the external identity.

create schema if not exists private;
revoke all on schema private from public;

create table public.profiles (
  id uuid primary key default gen_random_uuid(),
  clerk_user_id text not null unique check (length(btrim(clerk_user_id)) > 0),
  email text not null check (length(btrim(email)) > 0),
  first_name text not null default '' check (length(btrim(first_name)) <= 100),
  last_name text not null default '' check (length(btrim(last_name)) <= 100),
  role text not null check (role in ('admin', 'student', 'invigilator')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index profiles_email_lower_uidx on public.profiles (lower(email));

create table public.departments (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(btrim(name)) between 1 and 160),
  code text not null check (code = upper(code) and code ~ '^[A-Z0-9][A-Z0-9_-]{1,15}$'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint departments_name_key unique (name),
  constraint departments_code_key unique (code)
);

create table public.students (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null unique references public.profiles (id) on delete restrict,
  matric_number text not null check (length(btrim(matric_number)) between 1 and 40),
  department_id uuid not null references public.departments (id) on delete restrict,
  level smallint not null check (level in (100, 200, 300, 400, 500, 600)),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint students_matric_number_key unique (matric_number)
);

create index students_department_level_idx on public.students (department_id, level);

create table public.courses (
  id uuid primary key default gen_random_uuid(),
  department_id uuid not null references public.departments (id) on delete restrict,
  code text not null check (code = upper(code) and code ~ '^[A-Z0-9][A-Z0-9_-]{1,19}$'),
  title text not null check (length(btrim(title)) between 1 and 200),
  level smallint not null check (level in (100, 200, 300, 400, 500, 600)),
  credit_units smallint not null check (credit_units between 1 and 30),
  semester smallint not null check (semester in (1, 2)),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint courses_department_code_key unique (department_id, code)
);

create index courses_level_semester_idx on public.courses (level, semester);

create table public.course_enrollments (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students (id) on delete restrict,
  course_id uuid not null references public.courses (id) on delete restrict,
  academic_session text not null check (academic_session ~ '^[0-9]{4}/[0-9]{4}$'),
  semester smallint not null check (semester in (1, 2)),
  created_at timestamptz not null default now(),
  constraint course_enrollments_student_course_term_key
    unique (student_id, course_id, academic_session, semester)
);

create index course_enrollments_course_term_idx
  on public.course_enrollments (course_id, academic_session, semester);
create index course_enrollments_student_term_idx
  on public.course_enrollments (student_id, academic_session, semester);

create table public.venues (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(btrim(name)) between 1 and 160),
  location text not null check (length(btrim(location)) between 1 and 240),
  capacity integer not null check (capacity > 0),
  status text not null default 'active' check (status in ('active', 'inactive', 'maintenance')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint venues_name_location_key unique (name, location)
);

create index venues_status_capacity_idx on public.venues (status, capacity);

create table public.invigilators (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null unique references public.profiles (id) on delete restrict,
  staff_id text not null unique check (length(btrim(staff_id)) between 1 and 40),
  department_id uuid not null references public.departments (id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index invigilators_department_idx on public.invigilators (department_id);

create table public.exam_sessions (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(btrim(name)) between 1 and 160),
  academic_session text not null check (academic_session ~ '^[0-9]{4}/[0-9]{4}$'),
  semester smallint not null check (semester in (1, 2)),
  start_date date not null,
  end_date date not null,
  status text not null default 'draft' check (status in ('draft', 'active', 'completed', 'archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint exam_sessions_date_range_check check (end_date >= start_date),
  constraint exam_sessions_name_term_key unique (name, academic_session, semester)
);

create index exam_sessions_status_dates_idx
  on public.exam_sessions (status, start_date, end_date);
create index exam_sessions_term_idx
  on public.exam_sessions (academic_session, semester);
create unique index exam_sessions_one_active_per_term_uidx
  on public.exam_sessions (academic_session, semester)
  where status = 'active';

create table public.exam_schedules (
  id uuid primary key default gen_random_uuid(),
  exam_session_id uuid not null references public.exam_sessions (id) on delete restrict,
  course_id uuid not null references public.courses (id) on delete restrict,
  venue_id uuid not null references public.venues (id) on delete restrict,
  invigilator_id uuid not null references public.invigilators (id) on delete restrict,
  exam_date date not null,
  start_time time without time zone not null,
  end_time time without time zone not null,
  scheduled_period tsrange generated always as (
    tsrange(exam_date + start_time, exam_date + end_time, '[)')
  ) stored not null,
  status text not null default 'draft' check (status in ('draft', 'scheduled', 'published', 'cancelled')),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint exam_schedules_time_range_check check (end_time > start_time),
  constraint exam_schedules_published_at_check check (status <> 'published' or published_at is not null)
);

-- These indexes support later overlap and period checks; they do not implement
-- scheduling policy or prevent draft conflicts from being recorded and reviewed.
create index exam_schedules_session_date_idx
  on public.exam_schedules (exam_session_id, exam_date);
create index exam_schedules_course_date_idx
  on public.exam_schedules (course_id, exam_date);
create index exam_schedules_venue_date_idx
  on public.exam_schedules (venue_id, exam_date);
create index exam_schedules_invigilator_date_idx
  on public.exam_schedules (invigilator_id, exam_date);
create index exam_schedules_status_date_idx
  on public.exam_schedules (status, exam_date);
create index exam_schedules_period_gist_idx
  on public.exam_schedules using gist (scheduled_period);

create table public.schedule_conflicts (
  id uuid primary key default gen_random_uuid(),
  exam_schedule_id uuid not null references public.exam_schedules (id) on delete cascade,
  conflict_type text not null check (
    conflict_type in ('venue', 'student', 'invigilator', 'capacity', 'time', 'examination_period')
  ),
  severity text not null default 'warning' check (severity in ('info', 'warning', 'error', 'critical')),
  description text not null check (length(btrim(description)) between 1 and 2000),
  resolved boolean not null default false,
  resolved_at timestamptz,
  created_at timestamptz not null default now(),
  constraint schedule_conflicts_resolution_check check (
    (resolved and resolved_at is not null) or (not resolved and resolved_at is null)
  )
);

create index schedule_conflicts_schedule_resolved_idx
  on public.schedule_conflicts (exam_schedule_id, resolved);
create index schedule_conflicts_type_created_idx
  on public.schedule_conflicts (conflict_type, created_at desc);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles (id) on delete cascade,
  type text not null check (length(btrim(type)) between 1 and 80),
  title text not null check (length(btrim(title)) between 1 and 200),
  message text not null check (length(btrim(message)) between 1 and 4000),
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index notifications_profile_created_idx
  on public.notifications (profile_id, created_at desc);
create index notifications_unread_profile_idx
  on public.notifications (profile_id, created_at desc)
  where read_at is null;

create table public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references public.profiles (id) on delete set null,
  action text not null check (length(btrim(action)) between 1 and 120),
  entity_type text not null check (length(btrim(entity_type)) between 1 and 80),
  entity_id uuid,
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz not null default now()
);

create index activity_logs_profile_created_idx
  on public.activity_logs (profile_id, created_at desc);
create index activity_logs_entity_idx
  on public.activity_logs (entity_type, entity_id, created_at desc);
create index activity_logs_created_idx on public.activity_logs (created_at desc);

comment on column public.exam_schedules.scheduled_period is
  'Half-open local campus time range [start,end); indexed for later overlap detection.';
comment on table public.activity_logs is
  'Append-oriented audit record. Client roles receive SELECT only; trusted server operations own writes.';

create function private.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $function$
begin
  new.updated_at := pg_catalog.now();
  return new;
end;
$function$;

create trigger profiles_set_updated_at before update on public.profiles
  for each row execute function private.set_updated_at();
create trigger departments_set_updated_at before update on public.departments
  for each row execute function private.set_updated_at();
create trigger students_set_updated_at before update on public.students
  for each row execute function private.set_updated_at();
create trigger courses_set_updated_at before update on public.courses
  for each row execute function private.set_updated_at();
create trigger venues_set_updated_at before update on public.venues
  for each row execute function private.set_updated_at();
create trigger invigilators_set_updated_at before update on public.invigilators
  for each row execute function private.set_updated_at();
create trigger exam_sessions_set_updated_at before update on public.exam_sessions
  for each row execute function private.set_updated_at();
create trigger exam_schedules_set_updated_at before update on public.exam_schedules
  for each row execute function private.set_updated_at();

create function private.reject_activity_log_mutation()
returns trigger
language plpgsql
set search_path = ''
as $function$
begin
  raise exception 'activity_logs is append-only; % is not permitted', tg_op
    using errcode = '55000';
end;
$function$;

create trigger activity_logs_append_only
  before update or delete on public.activity_logs
  for each row execute function private.reject_activity_log_mutation();

-- Clerk's verified JWT subject is the only identity source used by these helpers.
-- The app's profile role is deliberately not consulted for client authorization.
create function private.current_profile_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $function$
  select p.id
  from public.profiles as p
  where p.clerk_user_id = (select auth.jwt() ->> 'sub')
  limit 1
$function$;

create function private.current_student_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $function$
  select s.id
  from public.students as s
  where s.profile_id = (select private.current_profile_id())
  limit 1
$function$;

create function private.current_invigilator_id()
returns uuid
language sql
stable
security definer
set search_path = ''
as $function$
  select i.id
  from public.invigilators as i
  where i.profile_id = (select private.current_profile_id())
  limit 1
$function$;

create function private.is_student_enrolled_in_exam(p_course_id uuid, p_exam_session_id uuid)
returns boolean
language sql
stable
security definer
set search_path = ''
as $function$
  select exists (
    select 1
    from public.course_enrollments as enrollment
    join public.students as student on student.id = enrollment.student_id
    join public.exam_sessions as exam_session
      on exam_session.academic_session = enrollment.academic_session
      and exam_session.semester = enrollment.semester
    where student.profile_id = (select private.current_profile_id())
      and enrollment.course_id = p_course_id
      and exam_session.id = p_exam_session_id
  )
$function$;

revoke all on all functions in schema private from public;
revoke all on all functions in schema private from anon;
grant usage on schema private to authenticated;
grant execute on function private.current_profile_id() to authenticated;
grant execute on function private.current_student_id() to authenticated;
grant execute on function private.current_invigilator_id() to authenticated;
grant execute on function private.is_student_enrolled_in_exam(uuid, uuid) to authenticated;

alter table public.profiles enable row level security;
alter table public.departments enable row level security;
alter table public.students enable row level security;
alter table public.courses enable row level security;
alter table public.course_enrollments enable row level security;
alter table public.venues enable row level security;
alter table public.invigilators enable row level security;
alter table public.exam_sessions enable row level security;
alter table public.exam_schedules enable row level security;
alter table public.schedule_conflicts enable row level security;
alter table public.notifications enable row level security;
alter table public.activity_logs enable row level security;

create policy profiles_select_own on public.profiles
  for select to authenticated
  using (clerk_user_id = (select auth.jwt() ->> 'sub'));

create policy departments_select_authenticated on public.departments
  for select to authenticated using (true);

create policy students_select_own on public.students
  for select to authenticated
  using (profile_id = (select private.current_profile_id()));

create policy courses_select_relevant on public.courses
  for select to authenticated
  using (
    exists (
      select 1
      from public.course_enrollments as enrollment
      where enrollment.course_id = courses.id
        and enrollment.student_id = (select private.current_student_id())
    )
    or exists (
      select 1
      from public.exam_schedules as schedule
      where schedule.course_id = courses.id
        and schedule.invigilator_id = (select private.current_invigilator_id())
    )
  );

create policy course_enrollments_select_own on public.course_enrollments
  for select to authenticated
  using (student_id = (select private.current_student_id()));

create policy venues_select_assigned_or_published_relevant on public.venues
  for select to authenticated
  using (
    exists (
      select 1
      from public.exam_schedules as schedule
      where schedule.venue_id = venues.id
        and (
          schedule.invigilator_id = (select private.current_invigilator_id())
          or (
            schedule.status = 'published'
            and (select private.is_student_enrolled_in_exam(schedule.course_id, schedule.exam_session_id))
          )
        )
    )
  );

create policy invigilators_select_own on public.invigilators
  for select to authenticated
  using (profile_id = (select private.current_profile_id()));

create policy exam_sessions_select_assigned_or_published_relevant on public.exam_sessions
  for select to authenticated
  using (
    exists (
      select 1
      from public.exam_schedules as schedule
      where schedule.exam_session_id = exam_sessions.id
        and (
          schedule.invigilator_id = (select private.current_invigilator_id())
          or (
            schedule.status = 'published'
            and (select private.is_student_enrolled_in_exam(schedule.course_id, schedule.exam_session_id))
          )
        )
    )
  );

create policy exam_schedules_select_assigned_or_published_relevant on public.exam_schedules
  for select to authenticated
  using (
    invigilator_id = (select private.current_invigilator_id())
    or (
      status = 'published'
      and (select private.is_student_enrolled_in_exam(course_id, exam_session_id))
    )
  );

create policy notifications_select_own on public.notifications
  for select to authenticated
  using (profile_id = (select private.current_profile_id()));

create policy activity_logs_select_own on public.activity_logs
  for select to authenticated
  using (profile_id = (select private.current_profile_id()));

-- Every application table is readable only through its RLS policy. No client
-- role receives write privileges in this foundation migration. Admin policies
-- are intentionally omitted until a trusted server-side authorization path exists.
revoke all on table
  public.profiles,
  public.departments,
  public.students,
  public.courses,
  public.course_enrollments,
  public.venues,
  public.invigilators,
  public.exam_sessions,
  public.exam_schedules,
  public.schedule_conflicts,
  public.notifications,
  public.activity_logs
from public, anon, authenticated;

grant select on table
  public.profiles,
  public.departments,
  public.students,
  public.courses,
  public.course_enrollments,
  public.venues,
  public.invigilators,
  public.exam_sessions,
  public.exam_schedules,
  public.schedule_conflicts,
  public.notifications,
  public.activity_logs
to authenticated;
