-- Harmless external activity probe for Free Plan project-pausing prevention.
-- It deliberately reads and writes no application data.
create function public.keep_project_active()
returns boolean
language sql
stable
security invoker
set search_path = ''
as $function$
  select true
$function$;

revoke all on function public.keep_project_active() from public;
revoke all on function public.keep_project_active() from authenticated;
grant execute on function public.keep_project_active() to anon;
