-- Complete academic-project integrity rules without rewriting existing data.
-- Existing invalid rows stop this migration with an actionable error instead
-- of being deleted or silently rewritten.

do $migration_check$
begin
  if exists (
    select 1
    from public.students as student
    join public.profiles as profile on profile.id = student.profile_id
    where profile.role <> 'student'
  ) then
    raise exception 'Cannot apply integrity migration: a student record references a non-student profile.';
  end if;

  if exists (
    select 1
    from public.invigilators as invigilator
    join public.profiles as profile on profile.id = invigilator.profile_id
    where profile.role <> 'invigilator'
  ) then
    raise exception 'Cannot apply integrity migration: an invigilator record references a non-invigilator profile.';
  end if;

  if exists (
    select 1
    from public.course_enrollments as enrollment
    join public.courses as course on course.id = enrollment.course_id
    where enrollment.semester <> course.semester
  ) then
    raise exception 'Cannot apply integrity migration: an enrollment semester differs from its course semester.';
  end if;

  if exists (
    select 1
    from public.exam_schedules as schedule
    join public.exam_sessions as exam_session on exam_session.id = schedule.exam_session_id
    join public.courses as course on course.id = schedule.course_id
    where exam_session.semester <> course.semester
  ) then
    raise exception 'Cannot apply integrity migration: an examination course and session use different semesters.';
  end if;

  if exists (
    select 1 from public.exam_schedules
    where (status = 'published' and published_at is null)
       or (status <> 'published' and published_at is not null)
  ) then
    raise exception 'Cannot apply integrity migration: examination publication timestamps are inconsistent.';
  end if;
end
$migration_check$;

-- Audit entries are produced by trusted trigger functions, never directly by
-- ordinary authenticated clients.
drop policy if exists activity_logs_insert_admin on public.activity_logs;
revoke insert on public.activity_logs from authenticated;

create or replace function private.validate_profile_assignment()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_required_role text := tg_argv[0];
  v_actual_role text;
begin
  if (select auth.jwt() ->> 'sub') is not null
    and (select private.current_profile_role()) is distinct from 'admin' then
    raise exception using errcode = '42501', message = 'not authorized';
  end if;

  -- Serialize both sides of the profile/role invariant so a concurrent role
  -- change cannot race a student or invigilator assignment.
  perform pg_catalog.pg_advisory_xact_lock(4072026, 1);

  select profile.role into v_actual_role
  from public.profiles as profile
  where profile.id = new.profile_id;

  if v_actual_role is distinct from v_required_role then
    raise exception using
      errcode = 'P0021',
      message = pg_catalog.format('The selected profile must have the %s role.', v_required_role);
  end if;
  return new;
end;
$function$;

revoke all on function private.validate_profile_assignment() from public, anon, authenticated;

create trigger students_validate_profile_role_before_write
  before insert or update of profile_id on public.students
  for each row execute function private.validate_profile_assignment('student');

create trigger invigilators_validate_profile_role_before_write
  before insert or update of profile_id on public.invigilators
  for each row execute function private.validate_profile_assignment('invigilator');

create or replace function private.validate_profile_role_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
begin
  if new.role is not distinct from old.role then
    return new;
  end if;

  perform pg_catalog.pg_advisory_xact_lock(4072026, 1);

  if exists (select 1 from public.students where profile_id = old.id)
    and new.role <> 'student' then
    raise exception using
      errcode = 'P0021',
      message = 'A profile linked to a student record must keep the student role.';
  end if;

  if exists (select 1 from public.invigilators where profile_id = old.id)
    and new.role <> 'invigilator' then
    raise exception using
      errcode = 'P0021',
      message = 'A profile linked to an invigilator record must keep the invigilator role.';
  end if;
  return new;
end;
$function$;

revoke all on function private.validate_profile_role_change() from public, anon, authenticated;

create trigger profiles_validate_linked_role_before_update
  before update of role on public.profiles
  for each row execute function private.validate_profile_role_change();

create or replace function private.validate_enrollment_semester()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_course_semester smallint;
begin
  if (select auth.jwt() ->> 'sub') is not null
    and (select private.current_profile_role()) is distinct from 'admin' then
    raise exception using errcode = '42501', message = 'not authorized';
  end if;

  perform pg_catalog.pg_advisory_xact_lock(4072026, 1);

  select course.semester into v_course_semester
  from public.courses as course
  where course.id = new.course_id;

  if v_course_semester is null or new.semester <> v_course_semester then
    raise exception using
      errcode = 'P0022',
      message = 'The enrollment semester must match the course semester.';
  end if;
  return new;
end;
$function$;

revoke all on function private.validate_enrollment_semester() from public, anon, authenticated;

create trigger course_enrollments_validate_semester_before_write
  before insert or update of course_id, semester on public.course_enrollments
  for each row execute function private.validate_enrollment_semester();

create or replace function private.validate_course_semester_update()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
begin
  perform pg_catalog.pg_advisory_xact_lock(4072026, 1);

  if new.semester <> old.semester and (
    exists (select 1 from public.course_enrollments where course_id = old.id)
    or exists (select 1 from public.exam_schedules where course_id = old.id)
  ) then
    raise exception using
      errcode = 'P0022',
      message = 'A course semester cannot change after enrollments or examinations exist.';
  end if;
  return new;
end;
$function$;

revoke all on function private.validate_course_semester_update() from public, anon, authenticated;

create trigger courses_validate_semester_before_update
  before update of semester on public.courses
  for each row execute function private.validate_course_semester_update();

create or replace function private.validate_venue_status_update()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
begin
  perform pg_catalog.pg_advisory_xact_lock(4072026, 1);

  if new.status <> 'active' and exists (
    select 1
    from public.exam_schedules as schedule
    where schedule.venue_id = old.id
      and schedule.status <> 'cancelled'
  ) then
    raise exception using
      errcode = 'P0016',
      message = 'A venue with draft, scheduled, or published examinations must remain active.';
  end if;
  return new;
end;
$function$;

revoke all on function private.validate_venue_status_update() from public, anon, authenticated;

create trigger venues_validate_status_before_update
  before update of status on public.venues
  for each row execute function private.validate_venue_status_update();

create or replace function private.validate_exam_schedule_lifecycle()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_course_semester smallint;
  v_session_semester smallint;
begin
  if (select auth.jwt() ->> 'sub') is not null
    and (select private.current_profile_role()) is distinct from 'admin' then
    raise exception using errcode = '42501', message = 'not authorized';
  end if;

  perform pg_catalog.pg_advisory_xact_lock(4072026, 1);

  select course.semester into v_course_semester
  from public.courses as course where course.id = new.course_id;
  select exam_session.semester into v_session_semester
  from public.exam_sessions as exam_session where exam_session.id = new.exam_session_id;

  if v_course_semester is null or v_session_semester is null
    or v_course_semester <> v_session_semester then
    raise exception using
      errcode = 'P0022',
      message = 'The examination course must belong to the session semester.';
  end if;

  if tg_op = 'INSERT' then
    if new.status <> 'draft' or new.published_at is not null then
      raise exception using
        errcode = 'P0020',
        message = 'New examinations must begin as unpublished drafts.';
    end if;
  else
    if old.status = 'cancelled' then
      raise exception using
        errcode = 'P0020',
        message = 'A cancelled examination cannot be changed.';
    end if;

    if old.status <> 'draft' and (
      new.exam_session_id is distinct from old.exam_session_id
      or new.course_id is distinct from old.course_id
      or new.venue_id is distinct from old.venue_id
      or new.invigilator_id is distinct from old.invigilator_id
      or new.exam_date is distinct from old.exam_date
      or new.start_time is distinct from old.start_time
      or new.end_time is distinct from old.end_time
    ) then
      raise exception using
        errcode = 'P0020',
        message = 'Only draft examination details can be edited.';
    end if;

    if new.status <> old.status and not (
      (old.status = 'draft' and new.status in ('scheduled', 'cancelled'))
      or (old.status = 'scheduled' and new.status in ('published', 'cancelled'))
      or (old.status = 'published' and new.status in ('scheduled', 'cancelled'))
    ) then
      raise exception using
        errcode = 'P0020',
        message = pg_catalog.format('Invalid examination transition from %s to %s.', old.status, new.status);
    end if;

    if new.status is not distinct from old.status
      and new.published_at is distinct from old.published_at then
      raise exception using
        errcode = 'P0020',
        message = 'The publication timestamp is managed by the examination lifecycle.';
    end if;

    if new.status = 'published' and old.status <> 'published' then
      new.published_at := pg_catalog.now();
    elsif new.status <> 'published' then
      new.published_at := null;
    end if;
  end if;

  if (new.status = 'published' and new.published_at is null)
    or (new.status <> 'published' and new.published_at is not null) then
    raise exception using
      errcode = 'P0020',
      message = 'The publication timestamp must match the examination status.';
  end if;
  return new;
end;
$function$;

revoke all on function private.validate_exam_schedule_lifecycle() from public, anon, authenticated;

create trigger exam_schedules_integrity_before_write
  before insert or update on public.exam_schedules
  for each row execute function private.validate_exam_schedule_lifecycle();

-- Keep examination-session state changes monotonic. Details remain editable
-- only while a session is a draft or active; the older trigger continues to
-- protect dates and academic-period references.
create or replace function private.validate_exam_session_lifecycle()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
begin
  if (select auth.jwt() ->> 'sub') is not null
    and (select private.current_profile_role()) is distinct from 'admin' then
    raise exception using errcode = '42501', message = 'not authorized';
  end if;

  if tg_op = 'INSERT' then
    if new.status <> 'draft' then
      raise exception using
        errcode = 'P0020',
        message = 'New examination sessions must begin as drafts.';
    end if;
    return new;
  end if;

  if new.status <> old.status and not (
    (old.status = 'draft' and new.status = 'active')
    or (old.status = 'active' and new.status = 'completed')
    or (old.status = 'completed' and new.status = 'archived')
  ) then
    raise exception using errcode = 'P0020', message = 'Invalid examination-session lifecycle transition.';
  end if;

  if old.status in ('completed', 'archived') and new is distinct from old then
    raise exception using errcode = 'P0020', message = 'Completed or archived examination sessions cannot be edited.';
  end if;
  return new;
end;
$function$;

revoke all on function private.validate_exam_session_lifecycle() from public, anon, authenticated;

create trigger exam_sessions_lifecycle_before_write
  before insert or update on public.exam_sessions
  for each row execute function private.validate_exam_session_lifecycle();

-- Complete the intentionally limited admin CRUD surface. Foreign-key RESTRICT
-- remains the final guard against deleting referenced academic records.
create policy departments_update_admin on public.departments
  for update to authenticated
  using ((select private.current_profile_role()) = 'admin')
  with check ((select private.current_profile_role()) = 'admin');
create policy departments_delete_admin on public.departments
  for delete to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy courses_delete_admin on public.courses
  for delete to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy students_update_admin on public.students
  for update to authenticated
  using ((select private.current_profile_role()) = 'admin')
  with check ((select private.current_profile_role()) = 'admin');
create policy students_delete_admin on public.students
  for delete to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy course_enrollments_delete_admin on public.course_enrollments
  for delete to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy venues_delete_admin on public.venues
  for delete to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy invigilators_update_admin on public.invigilators
  for update to authenticated
  using ((select private.current_profile_role()) = 'admin')
  with check ((select private.current_profile_role()) = 'admin');
create policy invigilators_delete_admin on public.invigilators
  for delete to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy exam_sessions_delete_admin on public.exam_sessions
  for delete to authenticated
  using ((select private.current_profile_role()) = 'admin');

grant update (name, code) on public.departments to authenticated;
grant update (department_id, code, title, level, credit_units, semester) on public.courses to authenticated;
grant update (profile_id, matric_number, department_id, level) on public.students to authenticated;
grant update (name, location, capacity, status) on public.venues to authenticated;
grant update (profile_id, staff_id, department_id) on public.invigilators to authenticated;
grant delete on public.departments, public.courses, public.students,
  public.course_enrollments, public.venues, public.invigilators, public.exam_sessions
to authenticated;

-- Students may change only the read timestamp on notifications belonging to
-- their own profile. Notification creation remains trigger-owned.
create policy notifications_update_own on public.notifications
  for update to authenticated
  using (profile_id = (select private.current_profile_id()))
  with check (profile_id = (select private.current_profile_id()));
grant update (read_at) on public.notifications to authenticated;

create or replace function private.notify_exam_schedule_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_course public.courses%rowtype;
  v_session public.exam_sessions%rowtype;
  v_venue public.venues%rowtype;
  v_type text;
  v_title text;
  v_message text;
begin
  if old.status is not distinct from new.status then
    return new;
  end if;
  if new.status not in ('published', 'scheduled', 'cancelled') then
    return new;
  end if;
  if new.status = 'scheduled' and old.status <> 'published' then
    return new;
  end if;
  if new.status = 'cancelled' and old.status not in ('scheduled', 'published') then
    return new;
  end if;

  select * into v_course from public.courses where id = new.course_id;
  select * into v_session from public.exam_sessions where id = new.exam_session_id;
  select * into v_venue from public.venues where id = new.venue_id;

  if new.status = 'published' then
    v_type := 'exam_published';
    v_title := v_course.code || ' examination published';
    v_message := pg_catalog.format(
      '%s is scheduled for %s from %s to %s at %s.',
      v_course.title, new.exam_date, new.start_time, new.end_time, v_venue.name
    );
  elsif new.status = 'scheduled' then
    v_type := 'exam_unpublished';
    v_title := v_course.code || ' examination updated';
    v_message := 'This examination has been removed from the published timetable while it is reviewed.';
  else
    v_type := 'exam_cancelled';
    v_title := v_course.code || ' examination cancelled';
    v_message := pg_catalog.format('The %s examination scheduled for %s has been cancelled.', v_course.title, new.exam_date);
  end if;

  insert into public.notifications (profile_id, type, title, message)
  select student.profile_id, v_type, v_title, v_message
  from public.course_enrollments as enrollment
  join public.students as student on student.id = enrollment.student_id
  where enrollment.course_id = new.course_id
    and enrollment.academic_session = v_session.academic_session
    and enrollment.semester = v_session.semester;

  insert into public.notifications (profile_id, type, title, message)
  select invigilator.profile_id, v_type, v_title, v_message
  from public.invigilators as invigilator
  where invigilator.id = new.invigilator_id;

  return new;
end;
$function$;

revoke all on function private.notify_exam_schedule_change() from public, anon, authenticated;

create trigger exam_schedules_notify_after_status_change
  after update of status on public.exam_schedules
  for each row execute function private.notify_exam_schedule_change();

-- Recompute actual conflicts for a saved draft after a failed scheduling
-- transition. Because the failed update and this RPC are separate transactions,
-- the conflict records persist without weakening the validation trigger.
create or replace function public.refresh_schedule_conflicts(p_schedule_id uuid)
returns integer
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_schedule public.exam_schedules%rowtype;
  v_session public.exam_sessions%rowtype;
  v_venue public.venues%rowtype;
  v_count integer := 0;
begin
  if private.current_profile_role() is distinct from 'admin' then
    raise exception using errcode = '42501', message = 'not authorized';
  end if;

  select * into v_schedule from public.exam_schedules where id = p_schedule_id;
  if not found then
    raise exception using errcode = 'P0002', message = 'Examination schedule not found.';
  end if;
  select * into v_session from public.exam_sessions where id = v_schedule.exam_session_id;
  select * into v_venue from public.venues where id = v_schedule.venue_id;

  delete from public.schedule_conflicts
  where exam_schedule_id = p_schedule_id and not resolved;

  if v_schedule.exam_date < v_session.start_date
    or v_schedule.exam_date > v_session.end_date
    or v_session.status <> 'active' then
    insert into public.schedule_conflicts(exam_schedule_id, conflict_type, severity, description)
    values (p_schedule_id, 'examination_period', 'error', 'The examination date is outside an active examination session.');
    v_count := v_count + 1;
  end if;

  if v_venue.status <> 'active' then
    insert into public.schedule_conflicts(exam_schedule_id, conflict_type, severity, description)
    values (p_schedule_id, 'venue', 'error', pg_catalog.format('Venue %s is not active.', v_venue.name));
    v_count := v_count + 1;
  end if;

  if (
    select pg_catalog.count(*)
    from public.course_enrollments as enrollment
    where enrollment.course_id = v_schedule.course_id
      and enrollment.academic_session = v_session.academic_session
      and enrollment.semester = v_session.semester
  ) > v_venue.capacity then
    insert into public.schedule_conflicts(exam_schedule_id, conflict_type, severity, description)
    values (p_schedule_id, 'capacity', 'error', pg_catalog.format('Enrollment exceeds the %s-seat capacity of %s.', v_venue.capacity, v_venue.name));
    v_count := v_count + 1;
  end if;

  if exists (
    select 1 from public.exam_schedules as other
    where other.id <> p_schedule_id
      and other.status in ('scheduled', 'published')
      and other.venue_id = v_schedule.venue_id
      and other.scheduled_period && v_schedule.scheduled_period
  ) then
    insert into public.schedule_conflicts(exam_schedule_id, conflict_type, severity, description)
    values (p_schedule_id, 'venue', 'error', pg_catalog.format('Venue %s already has an overlapping examination.', v_venue.name));
    v_count := v_count + 1;
  end if;

  if exists (
    select 1 from public.exam_schedules as other
    where other.id <> p_schedule_id
      and other.status in ('scheduled', 'published')
      and other.invigilator_id = v_schedule.invigilator_id
      and other.scheduled_period && v_schedule.scheduled_period
  ) then
    insert into public.schedule_conflicts(exam_schedule_id, conflict_type, severity, description)
    values (p_schedule_id, 'invigilator', 'error', 'The assigned invigilator already has an overlapping examination.');
    v_count := v_count + 1;
  end if;

  if exists (
    select 1
    from public.exam_schedules as other
    join public.exam_sessions as other_session on other_session.id = other.exam_session_id
    join public.course_enrollments as current_enrollment
      on current_enrollment.course_id = v_schedule.course_id
      and current_enrollment.academic_session = v_session.academic_session
      and current_enrollment.semester = v_session.semester
    join public.course_enrollments as other_enrollment
      on other_enrollment.student_id = current_enrollment.student_id
      and other_enrollment.course_id = other.course_id
      and other_enrollment.academic_session = other_session.academic_session
      and other_enrollment.semester = other_session.semester
    where other.id <> p_schedule_id
      and other.status in ('scheduled', 'published')
      and other.scheduled_period && v_schedule.scheduled_period
  ) then
    insert into public.schedule_conflicts(exam_schedule_id, conflict_type, severity, description)
    values (p_schedule_id, 'student', 'error', 'One or more enrolled students have an overlapping examination.');
    v_count := v_count + 1;
  end if;

  return v_count;
end;
$function$;

revoke all on function public.refresh_schedule_conflicts(uuid) from public, anon;
grant execute on function public.refresh_schedule_conflicts(uuid) to authenticated;

-- Trusted audit entries for newly editable/deletable catalogue records.
create or replace function private.log_admin_entity_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_entity_type text := tg_argv[0];
  v_row_id uuid := ((case when tg_op = 'DELETE' then pg_catalog.to_jsonb(old) else pg_catalog.to_jsonb(new) end) ->> 'id')::uuid;
begin
  insert into public.activity_logs(profile_id, action, entity_type, entity_id)
  values ((select private.current_profile_id()), v_entity_type || '.' || pg_catalog.lower(tg_op), v_entity_type, v_row_id);
  return case when tg_op = 'DELETE' then old else new end;
end;
$function$;

revoke all on function private.log_admin_entity_change() from public, anon, authenticated;

create trigger departments_audit_after_change after update or delete on public.departments
  for each row execute function private.log_admin_entity_change('department');
create trigger courses_audit_after_delete after delete on public.courses
  for each row execute function private.log_admin_entity_change('course');
create trigger students_audit_after_change after update or delete on public.students
  for each row execute function private.log_admin_entity_change('student');
create trigger course_enrollments_audit_after_delete after delete on public.course_enrollments
  for each row execute function private.log_admin_entity_change('course_enrollment');
create trigger venues_audit_after_delete after delete on public.venues
  for each row execute function private.log_admin_entity_change('venue');
create trigger invigilators_audit_after_change after update or delete on public.invigilators
  for each row execute function private.log_admin_entity_change('invigilator');
create trigger exam_sessions_audit_after_delete after delete on public.exam_sessions
  for each row execute function private.log_admin_entity_change('exam_session');

create index courses_code_lower_idx on public.courses (pg_catalog.lower(code) text_pattern_ops);
create index courses_title_lower_idx on public.courses (pg_catalog.lower(title) text_pattern_ops);
create index profiles_role_email_idx on public.profiles (role, pg_catalog.lower(email));
create index exam_schedules_status_order_idx
  on public.exam_schedules (status, exam_date, start_time, id);
