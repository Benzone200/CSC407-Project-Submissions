-- Allow trusted administrators to manage exam periods and schedules without
-- bypassing RLS. The role comes from the profile matched to Clerk's verified
-- JWT subject; client-supplied role fields and Clerk public metadata are not used.

create or replace function private.current_profile_role()
returns text
language sql
stable
security definer
set search_path = ''
as $function$
  select p.role
  from public.profiles as p
  where p.clerk_user_id = (select auth.jwt() ->> 'sub')
  limit 1
$function$;

revoke all on function private.current_profile_role() from public, anon;
grant execute on function private.current_profile_role() to authenticated;

create policy profiles_select_admin on public.profiles
  for select to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy departments_select_admin on public.departments
  for select to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy departments_insert_admin on public.departments
  for insert to authenticated
  with check ((select private.current_profile_role()) = 'admin');

create policy students_select_admin on public.students
  for select to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy students_insert_admin on public.students
  for insert to authenticated
  with check ((select private.current_profile_role()) = 'admin');

create policy courses_select_admin on public.courses
  for select to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy courses_insert_admin on public.courses
  for insert to authenticated
  with check ((select private.current_profile_role()) = 'admin');

create policy course_enrollments_select_admin on public.course_enrollments
  for select to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy course_enrollments_insert_admin on public.course_enrollments
  for insert to authenticated
  with check ((select private.current_profile_role()) = 'admin');

create policy venues_select_admin on public.venues
  for select to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy venues_insert_admin on public.venues
  for insert to authenticated
  with check ((select private.current_profile_role()) = 'admin');

create policy invigilators_select_admin on public.invigilators
  for select to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy invigilators_insert_admin on public.invigilators
  for insert to authenticated
  with check ((select private.current_profile_role()) = 'admin');

create policy exam_sessions_select_admin on public.exam_sessions
  for select to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy exam_sessions_insert_admin on public.exam_sessions
  for insert to authenticated
  with check ((select private.current_profile_role()) = 'admin');

create policy exam_sessions_update_admin on public.exam_sessions
  for update to authenticated
  using ((select private.current_profile_role()) = 'admin')
  with check ((select private.current_profile_role()) = 'admin');

create policy exam_schedules_select_admin on public.exam_schedules
  for select to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy exam_schedules_insert_admin on public.exam_schedules
  for insert to authenticated
  with check ((select private.current_profile_role()) = 'admin');

create policy exam_schedules_update_admin on public.exam_schedules
  for update to authenticated
  using ((select private.current_profile_role()) = 'admin')
  with check ((select private.current_profile_role()) = 'admin');

create policy schedule_conflicts_select_admin on public.schedule_conflicts
  for select to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy activity_logs_select_admin on public.activity_logs
  for select to authenticated
  using ((select private.current_profile_role()) = 'admin');

create policy activity_logs_insert_admin on public.activity_logs
  for insert to authenticated
  with check (
    (select private.current_profile_role()) = 'admin'
    and profile_id = (select private.current_profile_id())
  );

grant select on public.profiles, public.departments, public.students, public.courses,
  public.course_enrollments, public.venues, public.invigilators, public.exam_sessions,
  public.exam_schedules, public.schedule_conflicts, public.activity_logs
to authenticated;

grant insert, update on public.exam_sessions, public.exam_schedules to authenticated;
grant insert on public.activity_logs to authenticated;
grant insert on public.departments, public.courses, public.students, public.course_enrollments,
  public.venues, public.invigilators to authenticated;

-- A single serialized constraint trigger keeps concurrent schedule writes from
-- slipping past application-side checks. Draft rows are editable; only scheduled
-- and published exams reserve rooms, invigilators, and enrolled students.
create or replace function private.validate_exam_schedule()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_session public.exam_sessions%rowtype;
  v_venue public.venues%rowtype;
  v_student_count bigint;
  v_new_period tsrange;
begin
  if (select auth.jwt() ->> 'sub') is not null
    and (select private.current_profile_role()) is distinct from 'admin' then
    raise exception using errcode = '42501', message = 'not authorized';
  end if;

  perform pg_catalog.pg_advisory_xact_lock(4072026, 1);
  v_new_period := pg_catalog.tsrange(new.exam_date + new.start_time, new.exam_date + new.end_time, '[)');

  select * into v_session
  from public.exam_sessions
  where id = new.exam_session_id;

  if not found or new.exam_date < v_session.start_date or new.exam_date > v_session.end_date then
    raise exception using errcode = 'P0011', message = 'Exam date is outside the examination session.';
  end if;

  if new.status in ('scheduled', 'published') and v_session.status <> 'active' then
    raise exception using errcode = 'P0011', message = 'Activate the examination session before scheduling or publishing its exams.';
  end if;

  select * into v_venue from public.venues where id = new.venue_id;
  if not found or v_venue.status <> 'active' then
    raise exception using errcode = 'P0016', message = 'Choose an active examination venue.';
  end if;

  select count(*) into v_student_count
  from public.course_enrollments as enrollment
  where enrollment.course_id = new.course_id
    and enrollment.academic_session = v_session.academic_session
    and enrollment.semester = v_session.semester;

  if v_student_count > v_venue.capacity then
    raise exception using errcode = 'P0015', message = 'Enrolled students exceed the venue capacity.';
  end if;

  if new.status in ('scheduled', 'published') then
    if exists (
      select 1 from public.exam_schedules as other
      where other.id <> new.id
        and other.status in ('scheduled', 'published')
        and other.venue_id = new.venue_id
        and other.scheduled_period && v_new_period
    ) then
      raise exception using errcode = 'P0012', message = 'This venue already has an overlapping examination.';
    end if;

    if exists (
      select 1 from public.exam_schedules as other
      where other.id <> new.id
        and other.status in ('scheduled', 'published')
        and other.invigilator_id = new.invigilator_id
        and other.scheduled_period && v_new_period
    ) then
      raise exception using errcode = 'P0013', message = 'This invigilator already has an overlapping examination.';
    end if;

    if exists (
      select 1
      from public.exam_schedules as other
      join public.exam_sessions as other_session on other_session.id = other.exam_session_id
      join public.course_enrollments as current_enrollment
        on current_enrollment.course_id = new.course_id
        and current_enrollment.academic_session = v_session.academic_session
        and current_enrollment.semester = v_session.semester
      join public.course_enrollments as other_enrollment
        on other_enrollment.student_id = current_enrollment.student_id
        and other_enrollment.course_id = other.course_id
        and other_enrollment.academic_session = other_session.academic_session
        and other_enrollment.semester = other_session.semester
      where other.id <> new.id
        and other.status in ('scheduled', 'published')
        and other.scheduled_period && v_new_period
    ) then
      raise exception using errcode = 'P0014', message = 'One or more enrolled students have an overlapping examination.';
    end if;
  end if;

  return new;
end;
$function$;

revoke all on function private.validate_exam_schedule() from public, anon, authenticated;

create trigger exam_schedules_validate_before_write
  before insert or update on public.exam_schedules
  for each row execute function private.validate_exam_schedule();

create or replace function private.validate_exam_session_update()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
begin
  if (select auth.jwt() ->> 'sub') is not null
    and (select private.current_profile_role()) is distinct from 'admin' then
    raise exception using errcode = '42501', message = 'not authorized';
  end if;
  perform pg_catalog.pg_advisory_xact_lock(4072026, 1);

  if (new.academic_session <> old.academic_session or new.semester <> old.semester)
    and exists (select 1 from public.exam_schedules where exam_session_id = old.id) then
    raise exception using errcode = 'P0011', message = 'An examination term cannot change after schedules have been created.';
  end if;

  if exists (
    select 1 from public.exam_schedules as schedule
    where schedule.exam_session_id = old.id
      and schedule.status in ('scheduled', 'published')
      and (schedule.exam_date < new.start_date or schedule.exam_date > new.end_date)
  ) then
    raise exception using errcode = 'P0011', message = 'Session dates cannot exclude scheduled or published exams.';
  end if;
  return new;
end;
$function$;

revoke all on function private.validate_exam_session_update() from public, anon, authenticated;

create trigger exam_sessions_validate_before_update
  before update on public.exam_sessions
  for each row execute function private.validate_exam_session_update();

create or replace function private.validate_course_enrollment_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_student_count bigint;
  v_excluded_enrollment_id uuid;
begin
  if (select auth.jwt() ->> 'sub') is not null
    and (select private.current_profile_role()) is distinct from 'admin' then
    raise exception using errcode = '42501', message = 'not authorized';
  end if;
  perform pg_catalog.pg_advisory_xact_lock(4072026, 1);
  if tg_op = 'UPDATE' then
    v_excluded_enrollment_id := old.id;
  end if;

  select pg_catalog.count(*) + 1 into v_student_count
  from public.course_enrollments as enrollment
  where enrollment.course_id = new.course_id
    and enrollment.academic_session = new.academic_session
    and enrollment.semester = new.semester
    and (v_excluded_enrollment_id is null or enrollment.id <> v_excluded_enrollment_id);

  if exists (
    select 1
    from public.exam_schedules as schedule
    join public.exam_sessions as exam_session on exam_session.id = schedule.exam_session_id
    join public.venues as venue on venue.id = schedule.venue_id
    where schedule.course_id = new.course_id
      and exam_session.academic_session = new.academic_session
      and exam_session.semester = new.semester
      and schedule.status in ('scheduled', 'published')
      and v_student_count > venue.capacity
  ) then
    raise exception using errcode = 'P0015', message = 'This enrollment would exceed an assigned venue capacity.';
  end if;

  if exists (
    select 1
    from public.exam_schedules as target
    join public.exam_sessions as target_session on target_session.id = target.exam_session_id
    join public.exam_schedules as other
      on other.id <> target.id
      and other.status in ('scheduled', 'published')
      and other.scheduled_period && target.scheduled_period
    join public.exam_sessions as other_session on other_session.id = other.exam_session_id
    join public.course_enrollments as other_enrollment
      on other_enrollment.student_id = new.student_id
      and other_enrollment.course_id = other.course_id
      and other_enrollment.academic_session = other_session.academic_session
      and other_enrollment.semester = other_session.semester
      and (v_excluded_enrollment_id is null or other_enrollment.id <> v_excluded_enrollment_id)
    where target.course_id = new.course_id
      and target_session.academic_session = new.academic_session
      and target_session.semester = new.semester
      and target.status in ('scheduled', 'published')
  ) then
    raise exception using errcode = 'P0014', message = 'This enrollment would create an overlapping examination for the student.';
  end if;
  return new;
end;
$function$;

revoke all on function private.validate_course_enrollment_change() from public, anon, authenticated;

create trigger course_enrollments_validate_before_write
  before insert or update on public.course_enrollments
  for each row execute function private.validate_course_enrollment_change();

create or replace function private.log_exam_schedule_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
begin
  insert into public.activity_logs (profile_id, action, entity_type, entity_id, metadata)
  values (
    (select private.current_profile_id()),
    case when tg_op = 'INSERT' then 'exam_schedule.created' else 'exam_schedule.updated' end,
    'exam_schedule',
    new.id,
    pg_catalog.jsonb_build_object('status', new.status)
  );
  return new;
end;
$function$;

revoke all on function private.log_exam_schedule_change() from public, anon, authenticated;

create trigger exam_schedules_audit_after_write
  after insert or update on public.exam_schedules
  for each row execute function private.log_exam_schedule_change();

create or replace function private.log_exam_session_change()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
begin
  insert into public.activity_logs (profile_id, action, entity_type, entity_id, metadata)
  values (
    (select private.current_profile_id()),
    case when tg_op = 'INSERT' then 'exam_session.created' else 'exam_session.updated' end,
    'exam_session',
    new.id,
    pg_catalog.jsonb_build_object(
      'status', new.status,
      'academic_session', new.academic_session,
      'semester', new.semester
    )
  );
  return new;
end;
$function$;

revoke all on function private.log_exam_session_change() from public, anon, authenticated;

create trigger exam_sessions_audit_after_write
  after insert or update on public.exam_sessions
  for each row execute function private.log_exam_session_change();

create or replace function private.log_admin_entity_create()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_entity_type text := tg_argv[0];
begin
  insert into public.activity_logs (profile_id, action, entity_type, entity_id, metadata)
  values (
    (select private.current_profile_id()),
    v_entity_type || '.created',
    v_entity_type,
    ((pg_catalog.to_jsonb(new) ->> 'id')::uuid),
    '{}'::jsonb
  );
  return new;
end;
$function$;

revoke all on function private.log_admin_entity_create() from public, anon, authenticated;

create trigger departments_audit_after_insert after insert on public.departments
  for each row execute function private.log_admin_entity_create('department');
create trigger courses_audit_after_insert after insert on public.courses
  for each row execute function private.log_admin_entity_create('course');
create trigger students_audit_after_insert after insert on public.students
  for each row execute function private.log_admin_entity_create('student');
create trigger course_enrollments_audit_after_insert after insert on public.course_enrollments
  for each row execute function private.log_admin_entity_create('course_enrollment');
create trigger venues_audit_after_insert after insert on public.venues
  for each row execute function private.log_admin_entity_create('venue');
create trigger invigilators_audit_after_insert after insert on public.invigilators
  for each row execute function private.log_admin_entity_create('invigilator');

-- This product uses the institution's local campus time as entered in the
-- timetable. Intervals are half-open, so adjacent exams do not overlap.
comment on column public.exam_schedules.scheduled_period is
  'Campus-local half-open interval [start,end); scheduled/published rows reserve resources.';
