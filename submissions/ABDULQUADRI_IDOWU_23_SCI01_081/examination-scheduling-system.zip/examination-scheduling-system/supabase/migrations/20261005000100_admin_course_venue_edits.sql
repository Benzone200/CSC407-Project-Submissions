-- Admins can edit only the catalogue fields exposed by the Admin UI.
-- Roles are resolved from the verified Clerk JWT subject through the profile.

create policy courses_update_admin on public.courses
  for update to authenticated
  using ((select private.current_profile_role()) = 'admin')
  with check ((select private.current_profile_role()) = 'admin');

create policy venues_update_admin on public.venues
  for update to authenticated
  using ((select private.current_profile_role()) = 'admin')
  with check ((select private.current_profile_role()) = 'admin');

grant update (code, title) on public.courses to authenticated;
grant update (name, location, capacity) on public.venues to authenticated;

create or replace function private.validate_venue_capacity_update()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
begin
  if (select auth.jwt() ->> 'sub') is not null
    and (select private.current_profile_role()) is distinct from 'admin' then
    raise exception using errcode = '42501', message = 'not authorized';
  end if;

  perform pg_catalog.pg_advisory_xact_lock(4072026, 1);

  if exists (
    select 1
    from public.exam_schedules as schedule
    join public.exam_sessions as exam_session on exam_session.id = schedule.exam_session_id
    join public.course_enrollments as enrollment
      on enrollment.course_id = schedule.course_id
      and enrollment.academic_session = exam_session.academic_session
      and enrollment.semester = exam_session.semester
    where schedule.venue_id = new.id
      and schedule.status in ('scheduled', 'published')
    group by schedule.id
    having pg_catalog.count(*) > new.capacity
  ) then
    raise exception using errcode = 'P0015', message = 'Venue capacity cannot be lower than its scheduled enrollment.';
  end if;

  return new;
end;
$function$;

revoke all on function private.validate_venue_capacity_update() from public, anon, authenticated;

create trigger venues_validate_capacity_before_update
  before update of capacity on public.venues
  for each row execute function private.validate_venue_capacity_update();

create or replace function private.log_admin_catalog_update()
returns trigger
language plpgsql
security definer
set search_path = ''
as $function$
begin
  insert into public.activity_logs(profile_id, action, entity_type, entity_id)
  values (
    (select private.current_profile_id()),
    tg_table_name || '.updated',
    tg_table_name,
    new.id
  );
  return new;
end;
$function$;

revoke all on function private.log_admin_catalog_update() from public, anon, authenticated;

create trigger courses_audit_after_update after update on public.courses
  for each row execute function private.log_admin_catalog_update();

create trigger venues_audit_after_update after update on public.venues
  for each row execute function private.log_admin_catalog_update();
