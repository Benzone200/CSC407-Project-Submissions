import { expect, test } from "@playwright/test";

test.describe("public application surfaces", () => {
  test("landing page exposes its primary actions", async ({ page }) => {
    await page.goto("/", { waitUntil: "domcontentloaded" });

    await expect(
      page.getByRole("heading", {
        level: 1,
        name: /smarter examination scheduling/i,
      }),
    ).toBeVisible();
    await expect(page.getByRole("link", { name: /get started/i }).first()).toBeVisible();
    await expect(page.getByRole("link", { name: /log in/i }).first()).toBeVisible();
  });

  for (const route of ["/security", "/review", "/testing"]) {
    test(`${route} renders a visible page heading`, async ({ page }) => {
      await page.goto(route, { waitUntil: "domcontentloaded" });

      await expect(page.locator("h1")).toBeVisible();
      await expect(page).toHaveURL(new RegExp(`${route.replace("/", "\\/")}/?$`));
    });
  }
});

test.describe("protected workspaces", () => {
  for (const route of ["/dashboard", "/student", "/admin", "/invigilator"]) {
    test(`${route} redirects an unauthenticated visitor to sign in`, async ({ page }) => {
      await page.goto(route, { waitUntil: "domcontentloaded" });

      await expect(page).toHaveURL(/\/sign-in(?:\/|\?|$)/, { timeout: 30_000 });
    });
  }
});
