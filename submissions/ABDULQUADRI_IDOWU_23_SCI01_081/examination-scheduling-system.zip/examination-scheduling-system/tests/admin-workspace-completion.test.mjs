import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("student administration provides server-rendered search and academic filters", async () => {
  const page = await readFile(new URL("../src/app/admin/students/page.tsx", import.meta.url), "utf8");
  assert.match(page, /query\?: string/);
  assert.match(page, /department\?: string/);
  assert.match(page, /level\?: string/);
  assert.match(page, /name="query"/);
  assert.match(page, /name="department"/);
  assert.match(page, /name="level"/);
  assert.match(page, /filteredStudents/);
});

test("invigilator administration displays real assigned examination records", async () => {
  const page = await readFile(new URL("../src/app/admin/invigilators/page.tsx", import.meta.url), "utf8");
  assert.match(page, /getAdminScheduleWorkspace/);
  assert.match(page, /schedule\.invigilator_id/);
  assert.match(page, /Assigned examinations/);
  assert.doesNotMatch(page, /mock data|coming soon|next implementation phase/i);
});
