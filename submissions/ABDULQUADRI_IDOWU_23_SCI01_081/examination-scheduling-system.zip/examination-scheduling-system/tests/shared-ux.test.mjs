import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { test } from "node:test";

test("protected shell provides skip navigation and restores mobile focus", async () => {
  const [shell, header] = await Promise.all([
    readFile(new URL("../src/components/layout/dashboard-shell.tsx", import.meta.url), "utf8"),
    readFile(new URL("../src/components/layout/app-header.tsx", import.meta.url), "utf8"),
  ]);
  assert.match(shell, /href="#main-content"/);
  assert.match(shell, /id="main-content"/);
  assert.match(shell, /menuButtonRef\.current\?\.focus/);
  assert.match(header, /ref=\{menuButtonRef\}/);
});

test("important actions have a reusable confirmation submit control", async () => {
  const button = await readFile(new URL("../src/components/forms/confirm-submit-button.tsx", import.meta.url), "utf8");
  assert.match(button, /window\.confirm\(confirmation\)/);
  assert.match(button, /useFormStatus/);
  assert.match(button, /disabled=\{disabled \|\| pending\}/);
});

test("public project pages no longer claim implemented workflows are absent", async () => {
  const [review, security, testing] = await Promise.all([
    readFile(new URL("../src/app/review/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../src/app/security/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../src/app/testing/page.tsx", import.meta.url), "utf8"),
  ]);
  assert.doesNotMatch(review, /Scheduling workflows remain unimplemented|No database CRUD/i);
  assert.doesNotMatch(security, /Input validation.*Planned|No resource queries or mutations/i);
  assert.doesNotMatch(testing, /No test results recorded/i);
});
