import assert from "node:assert/strict";
import { test } from "node:test";
import nextConfig from "../next.config.ts";

test("development canonicalizes the loopback IP for stable auth callback URLs", async () => {
  const originalNodeEnv = process.env.NODE_ENV;
  process.env.NODE_ENV = "development";
  try {
    assert.equal(typeof nextConfig.redirects, "function");
    assert.deepEqual(await nextConfig.redirects(), [{
      source: "/:path*",
      has: [{ type: "host", value: "127.0.0.1" }],
      destination: "http://localhost:3000/:path*",
      permanent: false,
    }]);
  } finally {
    if (originalNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = originalNodeEnv;
  }
});

test("production does not impose the local development host redirect", async () => {
  const originalNodeEnv = process.env.NODE_ENV;
  process.env.NODE_ENV = "production";
  try {
    assert.equal(typeof nextConfig.redirects, "function");
    assert.deepEqual(await nextConfig.redirects(), []);
  } finally {
    if (originalNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = originalNodeEnv;
  }
});
