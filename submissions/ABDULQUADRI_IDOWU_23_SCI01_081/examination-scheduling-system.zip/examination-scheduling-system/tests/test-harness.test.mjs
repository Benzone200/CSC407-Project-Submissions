import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { parsePage, normalizePagination, totalPages } from "../src/lib/scheduling/pagination.ts";

test("Playwright smoke coverage includes public and protected routes", async () => {
  const source = await readFile(
    new URL("./e2e/public-and-auth.spec.ts", import.meta.url),
    "utf8",
  );

  for (const route of ["/", "/security", "/review", "/testing", "/student", "/admin", "/invigilator"]) {
    assert.ok(source.includes(`"${route}"`), `${route} must remain covered by the smoke suite`);
  }
  assert.match(source, /redirects an unauthenticated visitor to sign in/);
});

test("quality workflow gates source, tests, build, audit, and browser smoke coverage", async () => {
  const source = await readFile(
    new URL("../.github/workflows/quality.yml", import.meta.url),
    "utf8",
  );

  for (const command of [
    "pnpm lint",
    "pnpm exec tsc --noEmit",
    "pnpm test",
    "pnpm test:db",
    "pnpm build",
    "pnpm audit --prod",
    "pnpm test:e2e",
  ]) {
    assert.ok(source.includes(command), `${command} must remain a CI gate`);
  }
  assert.match(source, /permissions:\s*\n\s*contents:\s*read/);
  assert.doesNotMatch(source, /SUPABASE_SECRET_KEY|service.role/i);
});

test("pagination normalizes unsafe input and caps result sizes", () => {
  assert.deepEqual(normalizePagination({ page: -2, pageSize: 500 }), { page: 1, pageSize: 50, from: 0, to: 49 });
  assert.deepEqual(normalizePagination({ page: 3, pageSize: 25 }), { page: 3, pageSize: 25, from: 50, to: 74 });
  assert.equal(parsePage("not-a-page"), 1);
  assert.equal(parsePage("2"), 2);
  assert.equal(totalPages(51, 25), 3);
});

test("invigilator examination details use the RLS-backed assigned-exam query", async () => {
  const [page, queries] = await Promise.all([
    readFile(new URL("../src/app/invigilator/exams/[id]/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../src/lib/scheduling/queries.ts", import.meta.url), "utf8"),
  ]);
  assert.match(page, /getInvigilatorExamById\(id\)/);
  assert.match(queries, /getInvigilatorExamById[\s\S]*?requireRole\("invigilator"\)[\s\S]*?from\("exam_schedules"\)/);
});
