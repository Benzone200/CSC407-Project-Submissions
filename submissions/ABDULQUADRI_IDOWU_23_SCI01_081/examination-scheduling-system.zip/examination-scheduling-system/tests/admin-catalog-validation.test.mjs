import assert from "node:assert/strict";
import { test } from "node:test";
import {
  catalogDeleteInputSchema,
  catalogEditInputSchema,
} from "../src/lib/catalog/validation.ts";

const id = "11111111-1111-4111-8111-111111111111";
const departmentId = "22222222-2222-4222-8222-222222222222";

test("catalog edits validate complete department, course, student, invigilator, and venue records", () => {
  assert.equal(catalogEditInputSchema.safeParse({ entity: "department", id, name: "Computer Science", code: "CSC" }).success, true);
  assert.equal(catalogEditInputSchema.safeParse({ entity: "course", id, department_id: departmentId, code: "CSC407", title: "Software Engineering", level: "400", credit_units: "3", semester: "1" }).success, true);
  assert.equal(catalogEditInputSchema.safeParse({ entity: "student", id, matric_number: "CSC/2026/001", department_id: departmentId, level: "400" }).success, true);
  assert.equal(catalogEditInputSchema.safeParse({ entity: "invigilator", id, staff_id: "STAFF-001", department_id: departmentId }).success, true);
  assert.equal(catalogEditInputSchema.safeParse({ entity: "venue", id, name: "Main Hall", location: "North Campus", capacity: "250", status: "active" }).success, true);
});

test("catalog edits reject incomplete and inconsistent values", () => {
  assert.equal(catalogEditInputSchema.safeParse({ entity: "course", id, department_id: departmentId, code: "bad code", title: "", level: "150", credit_units: "0", semester: "3" }).success, false);
  assert.equal(catalogEditInputSchema.safeParse({ entity: "student", id, matric_number: "", department_id: "bad", level: "900" }).success, false);
  assert.equal(catalogEditInputSchema.safeParse({ entity: "venue", id, name: "Hall", location: "Campus", capacity: "0", status: "unknown" }).success, false);
});

test("catalog delete accepts only supported entities and UUID identifiers", () => {
  for (const entity of ["department", "course", "venue", "student", "invigilator", "enrollment"]) {
    assert.equal(catalogDeleteInputSchema.safeParse({ entity, id }).success, true);
  }
  assert.equal(catalogDeleteInputSchema.safeParse({ entity: "profile", id }).success, false);
  assert.equal(catalogDeleteInputSchema.safeParse({ entity: "course", id: "not-a-uuid" }).success, false);
});
