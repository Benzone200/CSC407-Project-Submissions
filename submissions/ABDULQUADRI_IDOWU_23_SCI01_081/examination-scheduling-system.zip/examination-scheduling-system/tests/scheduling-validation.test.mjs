import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import {
  examScheduleInputSchema,
  examSessionInputSchema,
  isWithinPeriod,
  overlapsHalfOpen,
} from "../src/lib/scheduling/validation.ts";
import { adminExamFilterSchema, filterAdminExams } from "../src/lib/scheduling/admin-filters.ts";
import { catalogEditInputSchema, catalogInputSchema } from "../src/lib/catalog/validation.ts";

const migration = await readFile(
  new URL("../supabase/migrations/20261002000100_trusted_admin_scheduling_access.sql", import.meta.url),
  "utf8",
);
const catalogEditMigration = await readFile(
  new URL("../supabase/migrations/20261005000100_admin_course_venue_edits.sql", import.meta.url),
  "utf8",
);

test("overlapping examinations in the same venue are rejected by the database trigger", () => {
  assert.match(migration, /other\.venue_id\s*=\s*new\.venue_id[\s\S]*?other\.scheduled_period\s*&&\s*v_new_period/);
  assert.match(migration, /errcode\s*=\s*'P0012'/);
});

test("half-open intervals accept adjacent exams and reject actual overlaps", () => {
  assert.equal(overlapsHalfOpen({ start: 9 * 60, end: 10 * 60 }, { start: 10 * 60, end: 11 * 60 }), false);
  assert.equal(overlapsHalfOpen({ start: 9 * 60, end: 10 * 60 }, { start: 9 * 60 + 30, end: 10 * 60 + 30 }), true);
  assert.match(migration, /scheduled_period\s*&&\s*v_new_period/);
});

test("overlapping enrolled students are detected without exposing student identities", () => {
  assert.match(migration, /join public\.course_enrollments as current_enrollment/);
  assert.match(migration, /other_enrollment\.student_id\s*=\s*current_enrollment\.student_id/);
  assert.match(migration, /One or more enrolled students have an overlapping examination/);
  assert.match(migration, /errcode\s*=\s*'P0014'/);
});

test("venue capacity and examination period are validated by the database", () => {
  assert.match(migration, /v_student_count\s*>\s*v_venue\.capacity/);
  assert.match(migration, /new\.exam_date < v_session\.start_date or new\.exam_date > v_session\.end_date/);
  assert.equal(isWithinPeriod("2026-11-02", "2026-11-02", "2026-11-08"), true);
  assert.equal(isWithinPeriod("2026-11-09", "2026-11-02", "2026-11-08"), false);
});

test("schedule edits exclude the row being edited from its own overlap checks", () => {
  assert.equal((migration.match(/other\.id <> new\.id/g) ?? []).length, 3);
});

test("server input validation rejects missing references and invalid time ordering", () => {
  const validSchedule = {
    exam_session_id: "00000000-0000-4000-8000-000000000001",
    course_id: "00000000-0000-4000-8000-000000000002",
    venue_id: "00000000-0000-4000-8000-000000000003",
    invigilator_id: "00000000-0000-4000-8000-000000000004",
    exam_date: "2026-11-02",
    start_time: "09:00",
    end_time: "10:00",
  };
  assert.equal(examScheduleInputSchema.safeParse(validSchedule).success, true);
  assert.equal(examScheduleInputSchema.safeParse({ ...validSchedule, course_id: "" }).success, false);
  assert.equal(examScheduleInputSchema.safeParse({ ...validSchedule, end_time: "09:00" }).success, false);
  assert.equal(examScheduleInputSchema.safeParse({ ...validSchedule, exam_date: "2026-02-30" }).success, false);
});

test("session validation rejects invalid term labels and reversed date ranges", () => {
  const validSession = {
    name: "First semester examinations",
    academic_session: "2026/2027",
    semester: "1",
    start_date: "2026-11-02",
    end_date: "2026-11-08",
  };
  assert.equal(examSessionInputSchema.safeParse(validSession).success, true);
  assert.equal(examSessionInputSchema.safeParse({ ...validSession, academic_session: "next year" }).success, false);
  assert.equal(examSessionInputSchema.safeParse({ ...validSession, end_date: "2026-11-01" }).success, false);
});

test("only scheduled and published exams reserve resources and same-row updates are skipped", () => {
  assert.match(migration, /new\.status in \('scheduled', 'published'\)/);
  assert.match(migration, /other\.status in \('scheduled', 'published'\)/);
  assert.match(migration, /other\.id <> new\.id/);
});

test("admin RLS derives authorization from the linked Supabase Auth subject and gives no delete path", () => {
  assert.match(migration, /private\.current_profile_role\(\)/);
  assert.match(migration, /private\.current_profile_role\(\)\)\s*=\s*'admin'/);
  assert.doesNotMatch(migration, /grant\s+delete\s+on\s+public\.exam_(sessions|schedules)/i);
  assert.match(migration, /activity_logs_insert_admin/);
});

test("enrollment changes recheck venue capacity and shared-student overlap", () => {
  assert.match(migration, /validate_course_enrollment_change/);
  assert.match(migration, /This enrollment would exceed an assigned venue capacity/);
  assert.match(migration, /This enrollment would create an overlapping examination for the student/);
  assert.match(migration, /course_enrollments_validate_before_write/);
});

test("catalog forms validate bounded input and do not accept client role assignment", () => {
  const validDepartment = { entity: "department", name: "Computer Science", code: "CSC" };
  assert.equal(catalogInputSchema.safeParse(validDepartment).success, true);
  assert.equal(catalogInputSchema.safeParse({ ...validDepartment, code: "c" }).success, false);
  assert.equal(catalogInputSchema.safeParse({ entity: "venue", name: "Hall", location: "Campus", capacity: "0", status: "active" }).success, false);
  const studentRecord = {
    entity: "student",
    profile_id: "00000000-0000-4000-8000-000000000001",
    matric_number: "TST/001",
    department_id: "00000000-0000-4000-8000-000000000002",
    level: "100",
    role: "admin",
  };
  const parsed = catalogInputSchema.safeParse(studentRecord);
  assert.equal(parsed.success, true);
  assert.equal("role" in parsed.data, false);
});

test("course and venue edits accept only their editable fields and validate positive capacity", () => {
  const course = {
    entity: "course",
    id: "00000000-0000-4000-8000-000000000001",
    department_id: "00000000-0000-4000-8000-000000000010",
    code: "CSC407",
    title: "Software Engineering",
    level: "400",
    credit_units: "3",
    semester: "1",
    role: "admin",
  };
  const parsedCourse = catalogEditInputSchema.safeParse(course);
  assert.equal(parsedCourse.success, true);
  assert.equal("role" in parsedCourse.data, false);
  assert.equal(catalogEditInputSchema.safeParse({ ...course, code: "c" }).success, false);

  const venue = {
    entity: "venue",
    id: "00000000-0000-4000-8000-000000000002",
    name: "Main Hall",
    location: "North Campus",
    capacity: "300",
    status: "active",
  };
  assert.equal(catalogEditInputSchema.safeParse(venue).success, true);
  assert.equal(catalogEditInputSchema.safeParse({ ...venue, capacity: "0" }).success, false);
});

test("admin catalogue edits are role-checked and constrained by additive RLS column grants", async () => {
  const actions = await readFile(new URL("../src/app/admin/catalog-actions.ts", import.meta.url), "utf8");
  assert.match(actions, /export async function updateCatalogRecord[\s\S]*?await requireRole\("admin"\)/);
  assert.match(actions, /from\("courses"\)\.update\(\{ department_id: input\.department_id, code: input\.code, title: input\.title, level: input\.level, credit_units: input\.credit_units, semester: input\.semester \}\)/);
  assert.match(actions, /from\("venues"\)\.update\(\{ name: input\.name, location: input\.location, capacity: input\.capacity, status: input\.status \}\)/);
  assert.match(catalogEditMigration, /courses_update_admin[\s\S]*?private\.current_profile_role\(\)\) = 'admin'/);
  assert.match(catalogEditMigration, /grant update \(code, title\) on public\.courses to authenticated/i);
  assert.match(catalogEditMigration, /grant update \(name, location, capacity\) on public\.venues to authenticated/i);
  assert.doesNotMatch(catalogEditMigration, /grant update on public\.(courses|venues)\b/i);
});

test("venue capacity edits preserve scheduled enrollment capacity and audit changes", () => {
  assert.match(catalogEditMigration, /pg_advisory_xact_lock\(4072026, 1\)/);
  assert.match(catalogEditMigration, /schedule\.status in \('scheduled', 'published'\)/);
  assert.match(catalogEditMigration, /having pg_catalog\.count\(\*\) > new\.capacity/);
  assert.match(catalogEditMigration, /venues_validate_capacity_before_update/);
  assert.match(catalogEditMigration, /courses_audit_after_update/);
  assert.match(catalogEditMigration, /venues_audit_after_update/);
});

test("admin exam search retains unpublished records and applies validated filters", () => {
  const exams = [
    { courseCode: "CSC407", courseTitle: "Software Engineering", examDate: "2026-11-02", examSessionId: "00000000-0000-4000-8000-000000000001", sessionName: "First semester", status: "draft" },
    { courseCode: "CSC401", courseTitle: "Algorithms", examDate: "2026-11-03", examSessionId: "00000000-0000-4000-8000-000000000001", sessionName: "First semester", status: "published" },
  ];
  assert.equal(filterAdminExams(exams, {}).length, 2);
  assert.equal(filterAdminExams(exams, { query: "csc407" })[0]?.status, "draft");
  assert.equal(filterAdminExams(exams, { status: "published", date: "2026-11-03" }).length, 1);
  assert.equal(adminExamFilterSchema.safeParse({ status: "admin" }).success, false);
  assert.equal(adminExamFilterSchema.safeParse({ date: "2026-02-30" }).success, false);
});

test("schedule lifecycle server actions require admin and guard each state transition", async () => {
  const actions = await readFile(new URL("../src/app/admin/actions.ts", import.meta.url), "utf8");
  for (const action of ["saveExamSchedule", "scheduleExam", "publishExamSchedule", "unpublishExamSchedule", "cancelExamSchedule"]) {
    assert.match(actions, new RegExp(`export async function ${action}\\([\\s\\S]*?await requireRole\\("admin"\\)`));
  }
  assert.match(actions, /\.eq\("status", "draft"\)/);
  assert.match(actions, /\.eq\("status", "scheduled"\)/);
  assert.match(actions, /\.eq\("status", "published"\)/);
  assert.match(actions, /status: "scheduled", published_at: null/);
  assert.match(actions, /status: "cancelled", published_at: null/);
  assert.match(actions, /refreshRejectedConflicts\(scheduleId\)/);
  assert.match(actions, /\.update\(schedule\)\.eq\("id", id\)\.eq\("status", "draft"\)/);
});

test("student and invigilator notification actions are role checked and ownership remains RLS enforced", async () => {
  const [studentActions, invigilatorActions] = await Promise.all([
    readFile(new URL("../src/app/student/actions.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/app/invigilator/actions.ts", import.meta.url), "utf8"),
  ]);
  assert.match(studentActions, /await requireRole\("student"\)/);
  assert.match(invigilatorActions, /await requireRole\("invigilator"\)/);
  for (const source of [studentActions, invigilatorActions]) {
    assert.match(source, /from\("notifications"\)/);
    assert.match(source, /\.update\(\{ read_at: new Date\(\)\.toISOString\(\) \}\)/);
    assert.doesNotMatch(source, /profile_id\s*:/);
  }
});

test("catalog mutations are admin-only and student/invigilator accounts are role-checked server-side", async () => {
  const actions = await readFile(new URL("../src/app/admin/catalog-actions.ts", import.meta.url), "utf8");
  assert.match(actions, /await requireRole\("admin"\)/);
  assert.match(actions, /\.eq\("role", expectedRole\)/);
  assert.match(migration, /courses_insert_admin/);
  assert.match(migration, /course_enrollments_insert_admin/);
  assert.doesNotMatch(migration, /grant\s+update\s+on\s+public\.(departments|courses|students|course_enrollments|venues|invigilators)/i);
});
