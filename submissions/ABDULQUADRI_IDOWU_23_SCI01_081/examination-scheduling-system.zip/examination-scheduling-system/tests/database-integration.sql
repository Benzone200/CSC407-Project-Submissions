\set ON_ERROR_STOP on

set request.jwt.claims = '{"sub":"90000000-0000-0000-0000-000000000001"}';

insert into public.profiles (id, auth_user_id, clerk_user_id, email, role) values
  ('00000000-0000-0000-0000-000000000001', '90000000-0000-0000-0000-000000000001', 'clerk_admin', 'admin@example.test', 'admin'),
  ('00000000-0000-0000-0000-000000000002', '90000000-0000-0000-0000-000000000002', 'clerk_student', 'student@example.test', 'student'),
  ('00000000-0000-0000-0000-000000000003', '90000000-0000-0000-0000-000000000003', 'clerk_invigilator', 'invigilator@example.test', 'invigilator'),
  ('00000000-0000-0000-0000-000000000004', '90000000-0000-0000-0000-000000000004', 'clerk_unrelated', 'unrelated@example.test', 'student'),
  ('00000000-0000-0000-0000-000000000005', '90000000-0000-0000-0000-000000000005', 'clerk_invigilator_2', 'invigilator2@example.test', 'invigilator');

insert into public.departments (id, name, code)
values ('10000000-0000-0000-0000-000000000001', 'Computer Science', 'CSC');

insert into public.students (id, profile_id, matric_number, department_id, level) values
  ('20000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000002', 'CSC/2026/001', '10000000-0000-0000-0000-000000000001', 400),
  ('20000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000004', 'CSC/2026/002', '10000000-0000-0000-0000-000000000001', 400);

insert into public.invigilators (id, profile_id, staff_id, department_id) values
  ('30000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000003', 'STAFF-001', '10000000-0000-0000-0000-000000000001'),
  ('30000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000005', 'STAFF-002', '10000000-0000-0000-0000-000000000001');

insert into public.courses (id, department_id, code, title, level, credit_units, semester) values
  ('40000000-0000-0000-0000-000000000001', '10000000-0000-0000-0000-000000000001', 'CSC407', 'Software Engineering', 400, 3, 1),
  ('40000000-0000-0000-0000-000000000002', '10000000-0000-0000-0000-000000000001', 'CSC408', 'Compiler Construction', 400, 3, 1),
  ('40000000-0000-0000-0000-000000000003', '10000000-0000-0000-0000-000000000001', 'CSC409', 'Distributed Systems', 400, 3, 1);

insert into public.course_enrollments (student_id, course_id, academic_session, semester) values
  ('20000000-0000-0000-0000-000000000001', '40000000-0000-0000-0000-000000000001', '2026/2027', 1),
  ('20000000-0000-0000-0000-000000000001', '40000000-0000-0000-0000-000000000002', '2026/2027', 1),
  ('20000000-0000-0000-0000-000000000001', '40000000-0000-0000-0000-000000000003', '2026/2027', 1),
  ('20000000-0000-0000-0000-000000000002', '40000000-0000-0000-0000-000000000003', '2026/2027', 1);

insert into public.venues (id, name, location, capacity, status) values
  ('50000000-0000-0000-0000-000000000001', 'Main Hall', 'North Campus', 100, 'active'),
  ('50000000-0000-0000-0000-000000000002', 'Annex Hall', 'South Campus', 100, 'active'),
  ('50000000-0000-0000-0000-000000000003', 'Seminar Room', 'North Campus', 1, 'active');

insert into public.exam_sessions (id, name, academic_session, semester, start_date, end_date)
values ('60000000-0000-0000-0000-000000000001', 'First Semester Examinations', '2026/2027', 1, '2026-12-01', '2026-12-20');

update public.exam_sessions
set status = 'active'
where id = '60000000-0000-0000-0000-000000000001';

do $test$
begin
  begin
    insert into public.exam_sessions (name, academic_session, semester, start_date, end_date, status)
    values ('Invalid Session', '2027/2028', 1, '2027-12-01', '2027-12-02', 'active');
    raise exception 'Expected a non-draft session insertion to fail.';
  exception when sqlstate 'P0020' then
    null;
  end;
end
$test$;

insert into public.exam_schedules (
  id, exam_session_id, course_id, venue_id, invigilator_id,
  exam_date, start_time, end_time
) values (
  '70000000-0000-0000-0000-000000000001',
  '60000000-0000-0000-0000-000000000001',
  '40000000-0000-0000-0000-000000000001',
  '50000000-0000-0000-0000-000000000001',
  '30000000-0000-0000-0000-000000000001',
  '2026-12-10', '09:00', '11:00'
);

update public.exam_schedules
set status = 'scheduled'
where id = '70000000-0000-0000-0000-000000000001';

do $test$
begin
  begin
    update public.exam_schedules
    set start_time = '10:00', end_time = '12:00'
    where id = '70000000-0000-0000-0000-000000000001';
    raise exception 'Expected non-draft examination details to be immutable.';
  exception when sqlstate 'P0020' then
    null;
  end;
end
$test$;

update public.exam_schedules
set status = 'published', published_at = '2000-01-01T00:00:00Z'
where id = '70000000-0000-0000-0000-000000000001';

insert into public.exam_schedules (
  id, exam_session_id, course_id, venue_id, invigilator_id, exam_date, start_time, end_time
) values (
  '70000000-0000-0000-0000-000000000002', '60000000-0000-0000-0000-000000000001',
  '40000000-0000-0000-0000-000000000002', '50000000-0000-0000-0000-000000000001',
  '30000000-0000-0000-0000-000000000002', '2026-12-10', '09:00', '11:00'
);

do $test$
begin
  begin
    update public.exam_schedules set status = 'scheduled'
    where id = '70000000-0000-0000-0000-000000000002';
    raise exception 'Expected a venue overlap to fail.';
  exception when sqlstate 'P0012' then
    null;
  end;
end
$test$;
delete from public.exam_schedules where id = '70000000-0000-0000-0000-000000000002';

insert into public.exam_schedules (
  id, exam_session_id, course_id, venue_id, invigilator_id, exam_date, start_time, end_time
) values (
  '70000000-0000-0000-0000-000000000003', '60000000-0000-0000-0000-000000000001',
  '40000000-0000-0000-0000-000000000002', '50000000-0000-0000-0000-000000000002',
  '30000000-0000-0000-0000-000000000001', '2026-12-10', '09:00', '11:00'
);

do $test$
begin
  begin
    update public.exam_schedules set status = 'scheduled'
    where id = '70000000-0000-0000-0000-000000000003';
    raise exception 'Expected an invigilator overlap to fail.';
  exception when sqlstate 'P0013' then
    null;
  end;
end
$test$;
delete from public.exam_schedules where id = '70000000-0000-0000-0000-000000000003';

insert into public.exam_schedules (
  id, exam_session_id, course_id, venue_id, invigilator_id, exam_date, start_time, end_time
) values (
  '70000000-0000-0000-0000-000000000004', '60000000-0000-0000-0000-000000000001',
  '40000000-0000-0000-0000-000000000002', '50000000-0000-0000-0000-000000000002',
  '30000000-0000-0000-0000-000000000002', '2026-12-10', '09:00', '11:00'
);

do $test$
begin
  begin
    update public.exam_schedules set status = 'scheduled'
    where id = '70000000-0000-0000-0000-000000000004';
    raise exception 'Expected a shared-student overlap to fail.';
  exception when sqlstate 'P0014' then
    null;
  end;
end
$test$;
delete from public.exam_schedules where id = '70000000-0000-0000-0000-000000000004';

do $test$
begin
  begin
    insert into public.exam_schedules (
      id, exam_session_id, course_id, venue_id, invigilator_id, exam_date, start_time, end_time
    ) values (
      '70000000-0000-0000-0000-000000000005', '60000000-0000-0000-0000-000000000001',
      '40000000-0000-0000-0000-000000000003', '50000000-0000-0000-0000-000000000003',
      '30000000-0000-0000-0000-000000000002', '2026-12-12', '09:00', '11:00'
    );
    raise exception 'Expected venue capacity enforcement to fail.';
  exception when sqlstate 'P0015' then
    null;
  end;
end
$test$;

insert into public.exam_schedules (
  id, exam_session_id, course_id, venue_id, invigilator_id, exam_date, start_time, end_time
) values (
  '70000000-0000-0000-0000-000000000006', '60000000-0000-0000-0000-000000000001',
  '40000000-0000-0000-0000-000000000002', '50000000-0000-0000-0000-000000000002',
  '30000000-0000-0000-0000-000000000002', '2026-12-15', '09:00', '11:00'
);

do $test$
begin
  begin
    update public.exam_schedules set status = 'published', published_at = pg_catalog.now()
    where id = '70000000-0000-0000-0000-000000000006';
    raise exception 'Expected a draft-to-published transition to fail.';
  exception when sqlstate 'P0020' then
    null;
  end;
end
$test$;
delete from public.exam_schedules where id = '70000000-0000-0000-0000-000000000006';

do $test$
declare
  actual_published_at timestamptz;
begin
  select published_at into actual_published_at
  from public.exam_schedules
  where id = '70000000-0000-0000-0000-000000000001';
  if actual_published_at < pg_catalog.now() - interval '1 minute' then
    raise exception 'The database did not own the publication timestamp.';
  end if;
end
$test$;

do $test$
begin
  begin
    update public.venues set status = 'maintenance'
    where id = '50000000-0000-0000-0000-000000000001';
    raise exception 'Expected an assigned venue to remain active.';
  exception when sqlstate 'P0016' then
    null;
  end;
end
$test$;

do $test$
begin
  begin
    update public.profiles set role = 'invigilator'
    where id = '00000000-0000-0000-0000-000000000002';
    raise exception 'Expected a linked student profile to retain its role.';
  exception when sqlstate 'P0021' then
    null;
  end;
end
$test$;

insert into auth.users (id, email, raw_user_meta_data)
values (
  '90000000-0000-0000-0000-000000000006',
  'new-student@example.test',
  '{"first_name":"New","last_name":"Student","role":"admin"}'::jsonb
);

do $test$
declare
  provisioned_role text;
begin
  select role into provisioned_role
  from public.profiles
  where auth_user_id = '90000000-0000-0000-0000-000000000006';
  if provisioned_role is distinct from 'student' then
    raise exception 'Supabase Auth metadata escalated the provisioned application role.';
  end if;
end
$test$;

insert into public.profiles (id, clerk_user_id, email, role)
values (
  '00000000-0000-0000-0000-000000000007',
  'clerk_legacy_admin',
  'legacy-admin@example.test',
  'admin'
);
insert into auth.users (id, email, email_confirmed_at)
values (
  '90000000-0000-0000-0000-000000000007',
  'legacy-admin@example.test',
  pg_catalog.now()
);

do $test$
begin
  if exists (
    select 1 from public.profiles
    where id = '00000000-0000-0000-0000-000000000007'
      and auth_user_id is not null
  ) then
    raise exception 'A matching email automatically inherited a legacy profile.';
  end if;
end
$test$;

select private.link_existing_profile_to_auth_user(
  '00000000-0000-0000-0000-000000000007',
  '90000000-0000-0000-0000-000000000007'
);

do $test$
declare
  linked_role text;
begin
  select role into linked_role from public.profiles
  where id = '00000000-0000-0000-0000-000000000007'
    and auth_user_id = '90000000-0000-0000-0000-000000000007';
  if linked_role is distinct from 'admin' then
    raise exception 'Trusted exact-ID linking did not preserve the legacy profile role.';
  end if;
end
$test$;

insert into public.profiles (id, clerk_user_id, email, role)
values (
  '00000000-0000-0000-0000-000000000008',
  'clerk_unverified_student',
  'unverified-student@example.test',
  'student'
);
insert into auth.users (id, email, email_confirmed_at)
values (
  '90000000-0000-0000-0000-000000000008',
  'unverified-student@example.test',
  null
);

do $test$
begin
  begin
    perform private.link_existing_profile_to_auth_user(
      '00000000-0000-0000-0000-000000000008',
      '90000000-0000-0000-0000-000000000008'
    );
    raise exception 'Expected an unconfirmed Supabase Auth user link to fail.';
  exception when sqlstate 'P0023' then
    null;
  end;

  if exists (
    select 1 from public.profiles
    where id = '00000000-0000-0000-0000-000000000008'
      and auth_user_id is not null
  ) then
    raise exception 'An unconfirmed Supabase Auth user was linked.';
  end if;
end
$test$;

set role authenticated;

do $test$
begin
  begin
    perform private.link_existing_profile_to_auth_user(
      '00000000-0000-0000-0000-000000000008',
      '90000000-0000-0000-0000-000000000008'
    );
    raise exception 'Expected authenticated clients to be unable to link profiles.';
  exception when insufficient_privilege then
    null;
  end;
end
$test$;

do $test$
begin
  begin
    insert into public.activity_logs (profile_id, action, entity_type)
    values ('00000000-0000-0000-0000-000000000001', 'forged', 'exam_schedule');
    raise exception 'Expected direct activity-log insertion to be denied.';
  exception when insufficient_privilege then
    null;
  end;
end
$test$;

set request.jwt.claims = '{"sub":"90000000-0000-0000-0000-000000000002"}';

do $test$
begin
  begin
    insert into public.exam_schedules (
      exam_session_id, course_id, venue_id, invigilator_id,
      exam_date, start_time, end_time
    ) values (
      '60000000-0000-0000-0000-000000000001',
      '40000000-0000-0000-0000-000000000001',
      '50000000-0000-0000-0000-000000000002',
      '30000000-0000-0000-0000-000000000002',
      '2026-12-18', '09:00', '11:00'
    );
    raise exception 'Expected a student schedule insert to be denied.';
  exception when insufficient_privilege then
    null;
  end;
end
$test$;

do $test$
declare
  changed_rows integer;
begin
  update public.venues
  set capacity = capacity + 1
  where id = '50000000-0000-0000-0000-000000000002';
  get diagnostics changed_rows = row_count;
  if changed_rows <> 0 then
    raise exception 'A student changed an administrative catalogue row.';
  end if;
end
$test$;

do $test$
begin
  begin
    perform public.refresh_schedule_conflicts('70000000-0000-0000-0000-000000000001');
    raise exception 'Expected a student conflict refresh to be denied.';
  exception when insufficient_privilege then
    null;
  end;
end
$test$;

do $test$
declare
  changed_rows integer;
begin
  begin
    update public.profiles
    set role = 'admin'
    where id = '00000000-0000-0000-0000-000000000002';
    get diagnostics changed_rows = row_count;
    if changed_rows <> 0 then
      raise exception 'A student changed a trusted application role.';
    end if;
  exception when insufficient_privilege then
    null;
  end;
end
$test$;

do $test$
declare
  visible_exams integer;
  own_notifications integer;
begin
  select pg_catalog.count(*) into visible_exams from public.exam_schedules;
  select pg_catalog.count(*) into own_notifications from public.notifications;
  if visible_exams <> 1 then
    raise exception 'The enrolled student should see exactly one published examination.';
  end if;
  if own_notifications <> 1 then
    raise exception 'The enrolled student should see exactly one publication notification.';
  end if;
end
$test$;

do $test$
declare
  changed_rows integer;
begin
  update public.notifications
  set read_at = pg_catalog.now()
  where profile_id = '00000000-0000-0000-0000-000000000003';
  get diagnostics changed_rows = row_count;
  if changed_rows <> 0 then
    raise exception 'A student changed another recipient''s notification.';
  end if;
end
$test$;

set request.jwt.claims = '{"sub":"90000000-0000-0000-0000-000000000004"}';

do $test$
declare
  visible_exams integer;
begin
  select pg_catalog.count(*) into visible_exams from public.exam_schedules;
  if visible_exams <> 0 then
    raise exception 'An unenrolled student saw an unrelated examination.';
  end if;
end
$test$;

set request.jwt.claims = '{"sub":"90000000-0000-0000-0000-000000000003"}';

do $test$
declare
  assigned_exams integer;
begin
  select pg_catalog.count(*) into assigned_exams from public.exam_schedules;
  if assigned_exams <> 1 then
    raise exception 'The invigilator should see exactly the assigned examination.';
  end if;
end
$test$;

reset role;
set request.jwt.claims = '{"sub":"90000000-0000-0000-0000-000000000001"}';

update public.profiles
set account_status = 'restricted'
where id = '00000000-0000-0000-0000-000000000002';

set role authenticated;
set request.jwt.claims = '{"sub":"90000000-0000-0000-0000-000000000002"}';

do $test$
declare
  visible_exams integer;
  visible_departments integer;
begin
  select pg_catalog.count(*) into visible_exams from public.exam_schedules;
  if visible_exams <> 0 then
    raise exception 'A restricted account retained direct examination access.';
  end if;

  select pg_catalog.count(*) into visible_departments from public.departments;
  if visible_departments <> 0 then
    raise exception 'A restricted account retained direct department access.';
  end if;
end
$test$;

reset role;
set request.jwt.claims = '{"sub":"90000000-0000-0000-0000-000000000001"}';

update public.exam_schedules
set status = 'cancelled', published_at = null
where id = '70000000-0000-0000-0000-000000000001';

update public.venues
set status = 'maintenance'
where id = '50000000-0000-0000-0000-000000000001';

select 'database integration assertions passed' as result;
