import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { test } from "node:test";
import {
  assertAccountActive,
  assertRoleAccess,
  ForbiddenAuthorizationError,
  homeForRole,
  RestrictedAccountError,
  UnauthenticatedAuthorizationError,
} from "../src/lib/auth/authorization-policy.ts";
import {
  authCookieName,
  createAuthCookieMutations,
  decodeAuthCookie,
  encodeAuthCookie,
  readAuthCookie,
} from "../src/lib/supabase/auth-cookies.ts";

test("unauthenticated identity is rejected", () => {
  assert.throws(() => assertRoleAccess(null, ["student"]), UnauthenticatedAuthorizationError);
});

test("restricted accounts are rejected before role authorization", () => {
  assert.doesNotThrow(() => assertAccountActive("active"));
  assert.throws(() => assertAccountActive("restricted"), RestrictedAccountError);
});

test("students can enter only the student area", () => {
  assert.doesNotThrow(() => assertRoleAccess("student", ["student"]));
  assert.throws(() => assertRoleAccess("student", ["admin"]), ForbiddenAuthorizationError);
  assert.throws(() => assertRoleAccess("student", ["invigilator"]), ForbiddenAuthorizationError);
});

test("admins can enter admin area and are excluded from student-only area", () => {
  assert.doesNotThrow(() => assertRoleAccess("admin", ["admin"]));
  assert.throws(() => assertRoleAccess("admin", ["student"]), ForbiddenAuthorizationError);
});

test("invigilators can enter invigilator area but not admin area", () => {
  assert.doesNotThrow(() => assertRoleAccess("invigilator", ["invigilator"]));
  assert.throws(() => assertRoleAccess("invigilator", ["admin"]), ForbiddenAuthorizationError);
});

test("wrong-role navigation resolves to the role's own safe home", () => {
  assert.equal(homeForRole("student"), "/student");
  assert.equal(homeForRole("admin"), "/admin");
  assert.equal(homeForRole("invigilator"), "/invigilator");
});

test("Supabase session storage uses namespaced reversible cookie encoding", () => {
  const session = JSON.stringify({ access_token: "header.payload.signature", refresh_token: "refresh/value" });
  const encoded = encodeAuthCookie(session);
  assert.notEqual(encoded, session);
  assert.equal(decodeAuthCookie(encoded), session);
  assert.equal(authCookieName("sb-project-auth-token"), "exam-schedule-sb-project-auth-token");
});

test("large Supabase sessions are split across bounded cookies and reassembled", () => {
  const storageKey = "sb-project-auth-token";
  const session = JSON.stringify({
    access_token: "a".repeat(8_000),
    refresh_token: "r".repeat(4_000),
    user: { metadata: "m".repeat(4_000) },
  });
  const jar = new Map();
  const mutations = createAuthCookieMutations(storageKey, session, (name) => jar.get(name));

  for (const mutation of mutations) {
    if (mutation.value === null) jar.delete(mutation.name);
    else jar.set(mutation.name, mutation.value);
  }

  assert.ok(Number(jar.get(`${authCookieName(storageKey)}.chunks`)) > 1);
  assert.equal(jar.has(authCookieName(storageKey)), false);
  assert.equal(readAuthCookie(storageKey, (name) => jar.get(name)), session);

  const removals = createAuthCookieMutations(storageKey, null, (name) => jar.get(name));
  for (const mutation of removals) jar.delete(mutation.name);
  assert.equal(readAuthCookie(storageKey, (name) => jar.get(name)), null);
  assert.equal(jar.size, 0);
});

test("Supabase Auth is the only application authentication provider", async () => {
  const [packageJson, layout, proxy, resolver, serverClient, browserClient] = await Promise.all([
    readFile(new URL("../package.json", import.meta.url), "utf8"),
    readFile(new URL("../src/app/layout.tsx", import.meta.url), "utf8"),
    readFile(new URL("../src/proxy.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/lib/auth/current-user.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/lib/supabase/server.ts", import.meta.url), "utf8"),
    readFile(new URL("../src/lib/supabase/client.ts", import.meta.url), "utf8"),
  ]);

  for (const source of [packageJson, layout, proxy, resolver, serverClient, browserClient]) {
    assert.doesNotMatch(source, /@clerk|ClerkProvider|clerkMiddleware|currentUser\(/i);
  }
  assert.match(packageJson, /@supabase\/supabase-js/);
  assert.match(serverClient, /storage:[\s\S]*?getItem[\s\S]*?setItem[\s\S]*?removeItem/);
  assert.match(browserClient, /createBrowserSupabaseClient/);
  assert.match(browserClient, /persistSession:\s*false/);
  assert.match(browserClient, /autoRefreshToken:\s*false/);
  assert.match(proxy, /auth\.getClaims\(\)/);
  assert.match(proxy, /Cache-Control", "private, no-store"/);
  assert.match(resolver, /auth\.getClaims\(\)/);
});

test("protected application layouts enforce their exclusive server-side role", async () => {
  const layoutPaths = [
    ["../src/app/admin/layout.tsx", 'requireRole("admin")'],
    ["../src/app/student/layout.tsx", 'requireRole("student")'],
    ["../src/app/invigilator/layout.tsx", 'requireRole("invigilator")'],
  ];
  for (const [path, guard] of layoutPaths) {
    const source = await readFile(new URL(path, import.meta.url), "utf8");
    assert.ok(source.includes(guard), `${path} must enforce ${guard}`);
  }
});

test("Supabase sign-in validates input and returns generic credential failures", async () => {
  const [signIn, form, actions] = await Promise.all([
    readFile(new URL("../src/app/sign-in/[[...sign-in]]/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../src/components/auth/sign-in-form.tsx", import.meta.url), "utf8"),
    readFile(new URL("../src/app/auth/actions.ts", import.meta.url), "utf8"),
  ]);
  assert.match(signIn, /SignInForm/);
  assert.match(form, /signInAction/);
  assert.match(actions, /signInWithPassword/);
  assert.match(actions, /z\.object/);
  assert.match(actions, /Sign-in could not be completed\. Check your details and try again\./);
  assert.doesNotMatch(actions, /error\.message/);
});

test("Supabase Auth migration binds profiles to auth.uid and provisions only student roles", async () => {
  const migration = await readFile(new URL("../supabase/migrations/20261116000100_migrate_to_supabase_auth.sql", import.meta.url), "utf8");
  assert.match(migration, /auth_user_id\s+uuid/i);
  assert.match(migration, /references\s+auth\.users\s*\(id\)/i);
  assert.match(migration, /where\s+p\.auth_user_id\s*=\s*\(select auth\.uid\(\)\)/i);
  assert.match(migration, /new\.id[\s\S]*?'student'/i);
  assert.doesNotMatch(migration, /raw_user_meta_data[\s\S]*?->>\s*'role'/i);
  assert.match(migration, /link_existing_profile_to_auth_user/i);
  assert.match(migration, /email_confirmed_at/i);
  assert.doesNotMatch(migration, /pending_auth_profile_links/i);
});
