import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const migration = await readFile(
  new URL("../supabase/migrations/20261113000100_complete_academic_integrity.sql", import.meta.url),
  "utf8",
);

test("ordinary authenticated clients cannot forge audit entries", () => {
  assert.match(migration, /drop policy if exists activity_logs_insert_admin/i);
  assert.match(migration, /revoke insert on public\.activity_logs from authenticated/i);
  assert.doesNotMatch(migration, /grant insert on public\.activity_logs to authenticated/i);
});

test("profile assignments and academic semesters are database invariants", () => {
  assert.match(migration, /validate_profile_assignment/);
  assert.match(migration, /students_validate_profile_role_before_write/);
  assert.match(migration, /invigilators_validate_profile_role_before_write/);
  assert.match(migration, /validate_profile_role_change/);
  assert.match(migration, /profiles_validate_linked_role_before_update/);
  assert.match(migration, /validate_enrollment_semester/);
  assert.match(migration, /The examination course must belong to the session semester/);
  const serializedInvariantChecks = migration.match(/pg_advisory_xact_lock\(4072026, 1\)/g) ?? [];
  assert.ok(serializedInvariantChecks.length >= 6, "cross-table integrity checks must share the scheduling transaction lock");
});

test("venues with non-cancelled examinations cannot be made unavailable", () => {
  assert.match(migration, /validate_venue_status_update/);
  assert.match(migration, /schedule\.status <> 'cancelled'/);
  assert.match(migration, /A venue with draft, scheduled, or published examinations must remain active/);
});

test("schedule lifecycle and publication timestamps are database protected", () => {
  assert.match(migration, /validate_exam_schedule_lifecycle/);
  assert.match(migration, /old\.status = 'draft' and new\.status in \('scheduled', 'cancelled'\)/);
  assert.match(migration, /old\.status = 'scheduled' and new\.status in \('published', 'cancelled'\)/);
  assert.match(migration, /old\.status = 'published' and new\.status in \('scheduled', 'cancelled'\)/);
  assert.match(migration, /A cancelled examination cannot be changed/);
  assert.match(migration, /Only draft examination details can be edited/);
  assert.match(migration, /new\.published_at := pg_catalog\.now\(\)/);
  assert.match(migration, /publication timestamp must match/i);
});

test("examination-session lifecycle is monotonic and completed records are immutable", () => {
  assert.match(migration, /validate_exam_session_lifecycle/);
  assert.match(migration, /New examination sessions must begin as drafts/);
  assert.match(migration, /before insert or update on public\.exam_sessions/);
  assert.match(migration, /old\.status = 'draft' and new\.status = 'active'/);
  assert.match(migration, /old\.status = 'active' and new\.status = 'completed'/);
  assert.match(migration, /old\.status = 'completed' and new\.status = 'archived'/);
  assert.match(migration, /old\.status in \('completed', 'archived'\) and new is distinct from old/);
});

test("admin CRUD uses role-scoped policies and leaves referential safety to foreign keys", () => {
  for (const policy of [
    "departments_update_admin",
    "departments_delete_admin",
    "students_update_admin",
    "students_delete_admin",
    "course_enrollments_delete_admin",
    "invigilators_update_admin",
    "invigilators_delete_admin",
    "exam_sessions_delete_admin",
  ]) {
    assert.match(migration, new RegExp(`create policy ${policy}`));
  }
  assert.match(migration, /private\.current_profile_role\(\)\) = 'admin'/);
  assert.doesNotMatch(migration, /on delete cascade[\s\S]*departments/i);
});

test("notifications are trigger-generated and recipients can mark only their own rows read", () => {
  assert.match(migration, /notifications_update_own/);
  assert.match(migration, /grant update \(read_at\) on public\.notifications/i);
  assert.match(migration, /notify_exam_schedule_change/);
  assert.match(migration, /exam_published/);
  assert.match(migration, /exam_unpublished/);
  assert.match(migration, /exam_cancelled/);
  assert.doesNotMatch(migration, /grant insert on public\.notifications to authenticated/i);
});

test("conflict refresh records only conflicts recomputed from saved schedule data", () => {
  assert.match(migration, /function public\.refresh_schedule_conflicts\(p_schedule_id uuid\)/i);
  assert.match(migration, /private\.current_profile_role\(\) is distinct from 'admin'/);
  assert.match(migration, /other\.venue_id = v_schedule\.venue_id/);
  assert.match(migration, /other\.invigilator_id = v_schedule\.invigilator_id/);
  assert.match(migration, /other_enrollment\.student_id = current_enrollment\.student_id/);
  assert.match(migration, /grant execute on function public\.refresh_schedule_conflicts\(uuid\) to authenticated/i);
});
