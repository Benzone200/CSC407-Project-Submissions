import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { test } from "node:test";
import {
  readSupabaseKeepaliveConfig,
  runSupabaseKeepalive,
} from "../scripts/supabase-keepalive.mjs";

const validEnv = {
  SUPABASE_URL: "https://example.supabase.co/",
  SUPABASE_PUBLISHABLE_KEY: "sb_publishable_test_key",
};

function createLegacySupabaseJwt(role) {
  const encode = (value) => Buffer.from(JSON.stringify(value)).toString("base64url");
  return `${encode({ alg: "HS256", typ: "JWT" })}.${encode({ role })}.signature`;
}

test("keepalive configuration requires a safe HTTPS URL and publishable key", () => {
  assert.deepEqual(readSupabaseKeepaliveConfig(validEnv), {
    url: "https://example.supabase.co",
    publishableKey: "sb_publishable_test_key",
  });

  assert.throws(() => readSupabaseKeepaliveConfig({}), /SUPABASE_URL/);
  assert.throws(
    () => readSupabaseKeepaliveConfig({ ...validEnv, SUPABASE_URL: "http://example.supabase.co" }),
    /HTTPS/,
  );
  assert.throws(
    () => readSupabaseKeepaliveConfig({ ...validEnv, SUPABASE_URL: "https://user:pass@example.supabase.co" }),
    /credentials/,
  );
  assert.throws(
    () => readSupabaseKeepaliveConfig({ ...validEnv, SUPABASE_PUBLISHABLE_KEY: "" }),
    /SUPABASE_PUBLISHABLE_KEY/,
  );
  assert.throws(
    () => readSupabaseKeepaliveConfig({ ...validEnv, SUPABASE_URL: "https://supabase.co.example.com" }),
    /hosted Supabase project URL/,
  );
  assert.throws(
    () => readSupabaseKeepaliveConfig({ ...validEnv, SUPABASE_URL: "https://example.supabase.co/rest/v1" }),
    /project origin/,
  );
  assert.throws(
    () => readSupabaseKeepaliveConfig({ ...validEnv, SUPABASE_PUBLISHABLE_KEY: "sb_secret_test_key" }),
    /must not be a secret or service-role key/,
  );
  assert.throws(
    () => readSupabaseKeepaliveConfig({
      ...validEnv,
      SUPABASE_PUBLISHABLE_KEY: createLegacySupabaseJwt("service_role"),
    }),
    /must not be a secret or service-role key/,
  );
});

test("keepalive makes three calls only to the narrow RPC with the publishable key", async () => {
  const requests = [];
  const fetchImpl = async (url, init) => {
    requests.push({ url, init });
    return new Response("true", { status: 200 });
  };

  await runSupabaseKeepalive({ env: validEnv, fetchImpl });

  assert.equal(requests.length, 3);
  for (const request of requests) {
    assert.equal(request.url, "https://example.supabase.co/rest/v1/rpc/keep_project_active");
    assert.equal(request.init.method, "POST");
    assert.deepEqual(Object.keys(request.init.headers).sort(), ["apikey", "content-type"]);
    assert.equal(request.init.headers.apikey, validEnv.SUPABASE_PUBLISHABLE_KEY);
    assert.equal(request.init.headers["content-type"], "application/json");
    assert.equal(request.init.body, "{}");
    assert.equal(request.init.redirect, "error");
    assert.ok(request.init.signal instanceof AbortSignal);
    assert.equal("authorization" in request.init.headers, false);
  }
});

test("keepalive stops after a later network failure without leaking details", async () => {
  let requestCount = 0;
  const fetchImpl = async () => {
    requestCount += 1;
    if (requestCount === 1) return new Response("true", { status: 200 });
    throw new Error("network detail containing sb_publishable_test_key");
  };

  await assert.rejects(
    runSupabaseKeepalive({ env: validEnv, fetchImpl }),
    (error) => {
      assert.equal(
        error.message,
        "Supabase keepalive request failed before receiving a response.",
      );
      assert.doesNotMatch(error.message, /network detail|publishable_test_key/);
      return true;
    },
  );
  assert.equal(requestCount, 2);
});

test("keepalive failures expose the HTTP status but not response contents or keys", async () => {
  const fetchImpl = async () => new Response("internal detail containing sb_secret_value", { status: 503 });

  await assert.rejects(
    runSupabaseKeepalive({ env: validEnv, fetchImpl }),
    (error) => {
      assert.match(error.message, /503/);
      assert.doesNotMatch(error.message, /internal detail|sb_secret|publishable_test_key/);
      return true;
    },
  );
});

test("keepalive migration and workflow remain narrowly scoped", async () => {
  const [migration, workflow] = await Promise.all([
    readFile(
      new URL(
        "../supabase/migrations/20261111000100_add_keepalive_rpc.sql",
        import.meta.url,
      ),
      "utf8",
    ),
    readFile(new URL("../.github/workflows/supabase-keepalive.yml", import.meta.url), "utf8"),
  ]);

  assert.match(migration, /create\s+function\s+public\.keep_project_active\(\)/i);
  assert.match(migration, /returns\s+boolean/i);
  assert.match(migration, /language\s+sql/i);
  assert.match(migration, /stable/i);
  assert.match(migration, /security\s+invoker/i);
  assert.match(migration, /set\s+search_path\s*=\s*''/i);
  assert.match(migration, /select\s+true/i);
  assert.match(migration, /revoke\s+all\s+on\s+function\s+public\.keep_project_active\(\)\s+from\s+public/i);
  assert.match(migration, /grant\s+execute\s+on\s+function\s+public\.keep_project_active\(\)\s+to\s+anon/i);
  assert.doesNotMatch(migration, /insert|update|delete/i);

  assert.match(workflow, /schedule:/);
  assert.match(workflow, /cron:\s*["']17 5 \* \* \*["']/);
  assert.match(workflow, /workflow_dispatch:/);
  assert.match(workflow, /contents:\s*read/);
  assert.match(workflow, /secrets\.SUPABASE_URL/);
  assert.match(workflow, /secrets\.SUPABASE_PUBLISHABLE_KEY/);
  assert.doesNotMatch(workflow, /SERVICE_ROLE|SUPABASE_SECRET_KEY/i);
});
