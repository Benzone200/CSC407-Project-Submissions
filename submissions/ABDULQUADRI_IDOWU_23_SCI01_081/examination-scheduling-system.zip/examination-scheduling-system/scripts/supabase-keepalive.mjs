import { pathToFileURL } from "node:url";

const keepalivePath = "/rest/v1/rpc/keep_project_active";
const requestTimeoutMs = 10_000;
const keepaliveRequestCount = 3;

function readRequiredString(env, name) {
  const value = env[name]?.trim();
  if (!value) throw new Error(`${name} is required.`);
  return value;
}

function assertPublishableKey(publishableKey) {
  if (/^(?:sb_secret_|service_role)/i.test(publishableKey)) {
    throw new Error("SUPABASE_PUBLISHABLE_KEY must not be a secret or service-role key.");
  }

  if (publishableKey.startsWith("sb_publishable_")) return;

  const jwtParts = publishableKey.split(".");
  if (jwtParts.length !== 3) {
    throw new Error("SUPABASE_PUBLISHABLE_KEY must be a publishable or legacy anon key.");
  }

  try {
    const payload = JSON.parse(Buffer.from(jwtParts[1], "base64url").toString("utf8"));
    if (payload.role === "service_role") {
      throw new Error("SUPABASE_PUBLISHABLE_KEY must not be a secret or service-role key.");
    }
    if (payload.role !== "anon") {
      throw new Error("SUPABASE_PUBLISHABLE_KEY must be a publishable or legacy anon key.");
    }
  } catch (error) {
    if (error instanceof Error && error.message.startsWith("SUPABASE_PUBLISHABLE_KEY")) {
      throw error;
    }
    throw new Error("SUPABASE_PUBLISHABLE_KEY must be a publishable or legacy anon key.");
  }
}

export function readSupabaseKeepaliveConfig(env = process.env) {
  const rawUrl = readRequiredString(env, "SUPABASE_URL");
  const publishableKey = readRequiredString(env, "SUPABASE_PUBLISHABLE_KEY");

  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new Error("SUPABASE_URL must be a valid URL.");
  }

  if (url.protocol !== "https:") {
    throw new Error("SUPABASE_URL must use HTTPS.");
  }
  if (url.username || url.password) {
    throw new Error("SUPABASE_URL must not contain credentials.");
  }
  if (url.port || url.pathname !== "/" || url.search || url.hash) {
    throw new Error("SUPABASE_URL must contain only the Supabase project origin.");
  }
  if (!/^[a-z0-9-]+\.supabase\.co$/i.test(url.hostname)) {
    throw new Error("SUPABASE_URL must be a hosted Supabase project URL.");
  }
  assertPublishableKey(publishableKey);

  return {
    url: url.origin,
    publishableKey,
  };
}

export async function runSupabaseKeepalive({
  env = process.env,
  fetchImpl = fetch,
} = {}) {
  const config = readSupabaseKeepaliveConfig(env);
  for (let attempt = 0; attempt < keepaliveRequestCount; attempt += 1) {
    let response;

    try {
      response = await fetchImpl(`${config.url}${keepalivePath}`, {
        method: "POST",
        headers: {
          apikey: config.publishableKey,
          "content-type": "application/json",
        },
        body: "{}",
        redirect: "error",
        signal: AbortSignal.timeout(requestTimeoutMs),
      });
    } catch {
      throw new Error("Supabase keepalive request failed before receiving a response.");
    }

    if (!response.ok) {
      throw new Error(`Supabase keepalive request failed with HTTP ${response.status}.`);
    }
  }
}

const isDirectExecution =
  process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url;

if (isDirectExecution) {
  try {
    await runSupabaseKeepalive();
    console.log("Supabase keepalive completed successfully.");
  } catch (error) {
    console.error(error instanceof Error ? error.message : "Supabase keepalive failed.");
    process.exitCode = 1;
  }
}
