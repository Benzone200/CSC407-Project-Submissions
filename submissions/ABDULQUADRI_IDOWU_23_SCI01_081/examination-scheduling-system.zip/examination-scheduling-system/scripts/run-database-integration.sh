#!/usr/bin/env bash

set -euo pipefail

if command -v pg_config >/dev/null 2>&1; then
  export PATH="$(pg_config --bindir):$PATH"
fi

for executable in initdb pg_ctl psql; do
  if ! command -v "$executable" >/dev/null 2>&1; then
    echo "Database integration tests require PostgreSQL and the '$executable' executable." >&2
    exit 1
  fi
done

database_directory="$(mktemp -d /tmp/exam-schedule-pg.XXXXXX)"
database_port="${DB_TEST_PORT:-55439}"

stop_database() {
  pg_ctl -D "$database_directory" -m immediate stop >/dev/null 2>&1 || true
}
trap stop_database EXIT

initdb -D "$database_directory" -A trust --no-locale >/dev/null
pg_ctl -D "$database_directory" -o "-p $database_port" -w start >/dev/null

psql -X -v ON_ERROR_STOP=1 -p "$database_port" postgres <<'SQL'
create role anon;
create role authenticated;
create schema auth;
create table auth.users (
  id uuid primary key,
  email text,
  email_confirmed_at timestamptz,
  raw_user_meta_data jsonb not null default '{}'::jsonb
);
create function auth.jwt()
returns jsonb
language sql
stable
as $function$
  select coalesce(current_setting('request.jwt.claims', true), '{}')::jsonb
$function$;
create function auth.uid()
returns uuid
language sql
stable
as $function$
  select nullif(auth.jwt() ->> 'sub', '')::uuid
$function$;
insert into auth.users (id, email, email_confirmed_at) values
  ('90000000-0000-0000-0000-000000000001', 'admin@example.test', now()),
  ('90000000-0000-0000-0000-000000000002', 'student@example.test', now()),
  ('90000000-0000-0000-0000-000000000003', 'invigilator@example.test', now()),
  ('90000000-0000-0000-0000-000000000004', 'unrelated@example.test', now()),
  ('90000000-0000-0000-0000-000000000005', 'invigilator2@example.test', now());
SQL

for migration in supabase/migrations/*.sql; do
  psql -X -v ON_ERROR_STOP=1 -p "$database_port" postgres -f "$migration" >/dev/null
  echo "Applied $(basename "$migration")"
done

psql -X -v ON_ERROR_STOP=1 -p "$database_port" postgres -f tests/database-integration.sql

# Prove the shared transaction lock closes the check-then-write race between
# a course-semester change and a concurrent enrollment insert.
psql -X -v ON_ERROR_STOP=1 -p "$database_port" postgres <<'SQL' >/dev/null
insert into public.courses (
  id, department_id, code, title, level, credit_units, semester
) values (
  '40000000-0000-0000-0000-000000000009',
  '10000000-0000-0000-0000-000000000001',
  'CSC499', 'Concurrency fixture', 400, 3, 1
);
SQL

psql -X -v ON_ERROR_STOP=1 -p "$database_port" postgres <<'SQL' >"$database_directory/concurrent-course-update.log" 2>&1 &
begin;
select pg_catalog.pg_advisory_xact_lock(4072026, 1);
update public.courses
set semester = 2
where id = '40000000-0000-0000-0000-000000000009';
select pg_catalog.pg_sleep(1);
commit;
SQL
course_update_pid=$!

sleep 0.2
if psql -X -v ON_ERROR_STOP=1 -p "$database_port" postgres <<'SQL' >"$database_directory/concurrent-enrollment.log" 2>&1
insert into public.course_enrollments (
  student_id, course_id, academic_session, semester
) values (
  '20000000-0000-0000-0000-000000000001',
  '40000000-0000-0000-0000-000000000009',
  '2026/2027', 1
);
SQL
then
  echo "Concurrent enrollment unexpectedly bypassed the course-semester invariant." >&2
  wait "$course_update_pid"
  exit 1
fi
wait "$course_update_pid"

invalid_enrollments="$(psql -X -A -t -v ON_ERROR_STOP=1 -p "$database_port" postgres <<'SQL'
select pg_catalog.count(*)
from public.course_enrollments as enrollment
join public.courses as course on course.id = enrollment.course_id
where enrollment.semester <> course.semester;
SQL
)"
if [[ "$invalid_enrollments" != "0" ]]; then
  echo "Concurrent writes left an invalid course enrollment." >&2
  exit 1
fi
echo "Concurrent course/enrollment invariant test passed."
echo "Database integration tests passed. Temporary cluster: $database_directory"
