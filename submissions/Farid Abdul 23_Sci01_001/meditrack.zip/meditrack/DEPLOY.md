# From development to a live site

## 1. Environments
- **Development:** `flask --app app run --debug`, SQLite file in `instance/`, random throwaway secret key, cookies work over http.
- **Production:** `APP_ENV=production` switches on Secure cookies, HSTS and file logging, and the app refuses to start without `SECRET_KEY`.

## 2. Configuration (environment variables)
Copy `.env.example` to `.env` (never commit it). Generate the key with `python -c "import secrets; print(secrets.token_hex(32))"`. `DATABASE` points to a path outside the code folder, such as `/var/lib/meditrack/hospital.db`, owned by the app user with mode 600.

## 3. Server (Ubuntu VPS example)
```
sudo apt install python3-venv nginx certbot python3-certbot-nginx
git clone <your-repo> /srv/meditrack && cd /srv/meditrack
python3 -m venv venv && venv/bin/pip install -r requirements.txt
set -a; . ./.env; set +a; venv/bin/flask --app app create-admin yourname
```
Run the app with gunicorn under systemd (`/etc/systemd/system/meditrack.service`):
```
[Service]
User=meditrack
WorkingDirectory=/srv/meditrack
EnvironmentFile=/srv/meditrack/.env
ExecStart=/srv/meditrack/venv/bin/gunicorn -w 3 -b 127.0.0.1:8000 app:app
Restart=always
```
Nginx proxies to it (`proxy_pass http://127.0.0.1:8000;` with `X-Forwarded-For` and `X-Forwarded-Proto` headers) and only the nginx ports 80/443 are open in the firewall (`ufw allow 'Nginx Full'`).

## 4. Domain, HTTPS and SSL
Point an A record for your domain at the server IP, then run `sudo certbot --nginx -d yourdomain.com`. Certbot installs a free Let's Encrypt certificate, redirects http to https and renews it automatically. Check the result at ssllabs.com/ssltest.

## 5. Deployment process
1. Develop and run `python -m pytest` locally. 2. Push to Git. 3. On the server: `git pull`, `venv/bin/pip install -r requirements.txt`, `sudo systemctl restart meditrack`. 4. Open the site and check login and a patient search. 5. If something breaks, `git checkout <previous-commit>` and restart.

## 6. Backups
Back up the database nightly with SQLite's safe copy, not a plain file copy:
`sqlite3 /var/lib/meditrack/hospital.db ".backup '/backups/hospital-$(date +%F).db'"` from cron, keep 14 days, copy them off the server, and test a restore. Encrypt backups and the disk, because they contain patient data.

## 7. Error and log monitoring
In production the app writes to `logs/app.log` (rotating, 5 x 1 MB), including failed logins and unhandled errors. Gunicorn and nginx logs live in `journalctl -u meditrack` and `/var/log/nginx/`. The admin Users page shows the audit log. Add a free uptime monitor such as UptimeRobot on the login URL, and review failed-login spikes weekly.

## Hosting alternatives
PythonAnywhere or Render also work for a demo: set the same three environment variables in their dashboard, use `gunicorn app:app` as the start command, and they provide HTTPS for you. For free tiers with no persistent disk, point `DATABASE` at a mounted volume or switch to PostgreSQL.
