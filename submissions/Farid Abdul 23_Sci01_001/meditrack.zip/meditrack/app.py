"""MediTrack - hospital patient management system (Flask + SQLite)."""
import hmac
import logging
import os
import re
import secrets
import sqlite3
import time
from datetime import date, datetime, timedelta
from functools import wraps
from logging.handlers import RotatingFileHandler

import click
from flask import (Flask, abort, current_app, flash, g, redirect,
                   render_template, request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

DEPARTMENTS = ["General Medicine", "Pediatrics", "Surgery", "Maternity", "Emergency", "Cardiology"]
STATUSES = ["Outpatient", "Admitted", "Discharged"]
GENDERS = ["Female", "Male", "Other"]
MAX_ATTEMPTS, LOCK_SECONDS = 5, 300
USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,30}$")
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^[0-9+\-\s]{7,20}$")
NAME_RE = re.compile(r"^[^\W\d_][\w .'\-]{1,99}$", re.UNICODE)
DUMMY_HASH = generate_password_hash("not-a-real-password")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('admin','user')),
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS patients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  dob TEXT NOT NULL,
  gender TEXT NOT NULL,
  phone TEXT,
  department TEXT NOT NULL,
  status TEXT NOT NULL,
  diagnosis TEXT,
  created_by INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  action TEXT NOT NULL,
  detail TEXT,
  ip TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def init_db(app):
    con = sqlite3.connect(app.config["DATABASE"])
    con.executescript(SCHEMA)
    con.commit()
    con.close()


def audit(action, detail=""):
    db = get_db()
    db.execute("INSERT INTO audit_log (user_id, action, detail, ip) VALUES (?,?,?,?)",
               (session.get("user_id"), action, detail, request.remote_addr))
    db.commit()


def password_errors(pw):
    errs = []
    if len(pw) < 8 or len(pw) > 128:
        errs.append("Password must be 8 to 128 characters.")
    if not (re.search(r"[A-Za-z]", pw) and re.search(r"\d", pw)):
        errs.append("Password must contain at least one letter and one number.")
    return errs


def escape_like(s):
    return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def validate_patient(form):
    d = {k: form.get(k, "").strip() for k in
         ("full_name", "dob", "gender", "phone", "department", "status", "diagnosis")}
    errs = []
    if not NAME_RE.match(d["full_name"]):
        errs.append("Enter a full name (2 to 100 characters; letters, spaces, . ' - only).")
    try:
        born = datetime.strptime(d["dob"], "%Y-%m-%d").date()
        if born > date.today() or born.year < 1900:
            raise ValueError
    except ValueError:
        errs.append("Enter a valid date of birth that is not in the future.")
    if d["gender"] not in GENDERS:
        errs.append("Choose a gender from the list.")
    if d["phone"] and not PHONE_RE.match(d["phone"]):
        errs.append("Phone may contain digits, spaces, + and - (7 to 20 characters).")
    if d["department"] not in DEPARTMENTS:
        errs.append("Choose a department from the list.")
    if d["status"] not in STATUSES:
        errs.append("Choose a status from the list.")
    if len(d["diagnosis"]) > 500:
        errs.append("Diagnosis notes must be 500 characters or fewer.")
    return d, errs


def create_app(test_config=None):
    app = Flask(__name__)
    prod = os.environ.get("APP_ENV") == "production"
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY"),
        DATABASE=os.environ.get("DATABASE", os.path.join(app.instance_path, "hospital.db")),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=prod,
        PERMANENT_SESSION_LIFETIME=timedelta(minutes=30),
        MAX_CONTENT_LENGTH=64 * 1024,
        PRODUCTION=prod,
    )
    if test_config:
        app.config.update(test_config)
    if not app.config["SECRET_KEY"]:
        if prod:
            raise RuntimeError("SECRET_KEY must be set in production.")
        app.config["SECRET_KEY"] = secrets.token_hex(32)  # dev only
    os.makedirs(os.path.dirname(os.path.abspath(app.config["DATABASE"])), exist_ok=True)
    init_db(app)

    if prod:  # error/log monitoring
        os.makedirs("logs", exist_ok=True)
        handler = RotatingFileHandler("logs/app.log", maxBytes=1_000_000, backupCount=5)
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        app.logger.addHandler(handler)
        app.logger.setLevel(logging.INFO)

    @app.teardown_appcontext
    def close_db(_exc):
        db = g.pop("db", None)
        if db is not None:
            db.close()

    @app.before_request
    def load_user_and_check_csrf():
        uid = session.get("user_id")
        g.user = None
        if uid:
            g.user = get_db().execute(
                "SELECT id, username, email, role FROM users WHERE id = ?", (uid,)).fetchone()
            if g.user is None:
                session.clear()
        if request.method == "POST":
            sent = request.form.get("csrf_token", "")
            good = session.get("csrf_token", "")
            if not good or not hmac.compare_digest(sent.encode(), good.encode()):
                abort(400)

    @app.context_processor
    def inject_globals():
        if "csrf_token" not in session:
            session["csrf_token"] = secrets.token_hex(16)
        return {"csrf_token": session["csrf_token"], "current_user": g.get("user"),
                "departments": DEPARTMENTS, "statuses": STATUSES, "genders": GENDERS}

    @app.after_request
    def security_headers(resp):
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; style-src 'self'; script-src 'self'; "
            "img-src 'self' data:; frame-ancestors 'none'; form-action 'self'; base-uri 'none'")
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "same-origin"
        if app.config["PRODUCTION"]:
            resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        if g.get("user"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    def login_required(view):
        @wraps(view)
        def wrapped(*a, **k):
            if g.user is None:
                return redirect(url_for("login"))
            return view(*a, **k)
        return wrapped

    def admin_required(view):
        @wraps(view)
        def wrapped(*a, **k):
            if g.user is None:
                return redirect(url_for("login"))
            if g.user["role"] != "admin":
                abort(403)
            return view(*a, **k)
        return wrapped

    # ---------- auth ----------
    @app.route("/")
    def index():
        return redirect(url_for("dashboard" if g.user else "login"))

    @app.route("/register", methods=["GET", "POST"])
    def register():
        errors, form = [], request.form
        if request.method == "POST":
            username = form.get("username", "").strip()
            email = form.get("email", "").strip().lower()
            pw, confirm = form.get("password", ""), form.get("confirm", "")
            if not USERNAME_RE.match(username):
                errors.append("Username must be 3 to 30 letters, numbers or underscores.")
            if not EMAIL_RE.match(email) or len(email) > 120:
                errors.append("Enter a valid email address.")
            errors += password_errors(pw)
            if pw != confirm:
                errors.append("Passwords do not match.")
            if not errors:
                try:
                    get_db().execute(
                        "INSERT INTO users (username, email, password_hash) VALUES (?,?,?)",
                        (username, email, generate_password_hash(pw)))
                    get_db().commit()
                except sqlite3.IntegrityError:
                    errors.append("That username or email is already registered.")
            if not errors:
                audit("register", username)
                flash("Account created. Sign in to continue.", "ok")
                return redirect(url_for("login"))
        return render_template("register.html", errors=errors, form=form)

    @app.route("/login", methods=["GET", "POST"])
    def login():
        error = None
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            pw = request.form.get("password", "")
            db, now = get_db(), int(time.time())
            user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
            if user and user["locked_until"] > now:
                check_password_hash(DUMMY_HASH, pw)
                error = "Too many failed attempts. Try again in a few minutes."
            elif user and check_password_hash(user["password_hash"], pw):
                db.execute("UPDATE users SET failed_attempts = 0, locked_until = 0 WHERE id = ?",
                           (user["id"],))
                db.commit()
                session.clear()  # new session on login (prevents fixation)
                session["user_id"] = user["id"]
                session["csrf_token"] = secrets.token_hex(16)
                session.permanent = True
                audit("login", username)
                return redirect(url_for("dashboard"))
            else:
                if user:
                    fails = user["failed_attempts"] + 1
                    lock = now + LOCK_SECONDS if fails >= MAX_ATTEMPTS else 0
                    db.execute("UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?",
                               (0 if lock else fails, lock, user["id"]))
                    db.commit()
                else:
                    check_password_hash(DUMMY_HASH, pw)  # equalise timing
                app.logger.warning("Failed login for %r from %s", username[:30], request.remote_addr)
                error = "Invalid username or password."
        return render_template("login.html", error=error)

    @app.route("/logout", methods=["POST"])
    @login_required
    def logout():
        audit("logout")
        session.clear()
        flash("You have been signed out.", "ok")
        return redirect(url_for("login"))

    # ---------- dashboard / profile ----------
    @app.route("/dashboard")
    @login_required
    def dashboard():
        db = get_db()
        counts = {s: db.execute("SELECT COUNT(*) FROM patients WHERE status = ?", (s,)).fetchone()[0]
                  for s in STATUSES}
        recent = db.execute("SELECT id, full_name, department, status FROM patients "
                            "ORDER BY id DESC LIMIT 5").fetchall()
        return render_template("dashboard.html", counts=counts, recent=recent,
                               total=sum(counts.values()))

    @app.route("/profile", methods=["GET", "POST"])
    @login_required
    def profile():
        errors = []
        if request.method == "POST":
            row = get_db().execute("SELECT password_hash FROM users WHERE id = ?",
                                   (g.user["id"],)).fetchone()
            new, confirm = request.form.get("new_password", ""), request.form.get("confirm", "")
            if not check_password_hash(row["password_hash"], request.form.get("current_password", "")):
                errors.append("Current password is incorrect.")
            errors += password_errors(new)
            if new != confirm:
                errors.append("New passwords do not match.")
            if not errors:
                get_db().execute("UPDATE users SET password_hash = ? WHERE id = ?",
                                 (generate_password_hash(new), g.user["id"]))
                get_db().commit()
                audit("password_change")
                flash("Password updated.", "ok")
                return redirect(url_for("profile"))
        return render_template("profile.html", errors=errors)

    # ---------- patients ----------
    @app.route("/patients")
    @login_required
    def patients():
        q = request.args.get("q", "").strip()[:100]
        dept, status = request.args.get("department", ""), request.args.get("status", "")
        sql = ("SELECT p.*, u.username AS creator FROM patients p "
               "JOIN users u ON u.id = p.created_by WHERE 1=1")
        params = []
        if q:
            sql += " AND p.full_name LIKE ? ESCAPE '\\'"
            params.append("%" + escape_like(q) + "%")
        if dept in DEPARTMENTS:
            sql += " AND p.department = ?"
            params.append(dept)
        if status in STATUSES:
            sql += " AND p.status = ?"
            params.append(status)
        rows = get_db().execute(sql + " ORDER BY p.id DESC", params).fetchall()
        return render_template("patients.html", rows=rows, q=q, dept=dept, status=status)

    def get_patient_or_404(pid):
        p = get_db().execute("SELECT * FROM patients WHERE id = ?", (pid,)).fetchone()
        if p is None:
            abort(404)
        return p

    @app.route("/patients/new", methods=["GET", "POST"])
    @login_required
    def patient_new():
        form, errors = {}, []
        if request.method == "POST":
            form, errors = validate_patient(request.form)
            if not errors:
                cur = get_db().execute(
                    "INSERT INTO patients (full_name, dob, gender, phone, department, status, "
                    "diagnosis, created_by) VALUES (?,?,?,?,?,?,?,?)",
                    (form["full_name"], form["dob"], form["gender"], form["phone"],
                     form["department"], form["status"], form["diagnosis"], g.user["id"]))
                get_db().commit()
                audit("patient_create", str(cur.lastrowid))
                flash("Patient record saved.", "ok")
                return redirect(url_for("patients"))
        return render_template("patient_form.html", form=form, errors=errors, editing=False)

    @app.route("/patients/<int:pid>/edit", methods=["GET", "POST"])
    @login_required
    def patient_edit(pid):
        p = get_patient_or_404(pid)
        if g.user["role"] != "admin" and p["created_by"] != g.user["id"]:
            abort(403)  # access-control check: owners and admins only
        form, errors = dict(p), []
        if request.method == "POST":
            form, errors = validate_patient(request.form)
            if not errors:
                get_db().execute(
                    "UPDATE patients SET full_name=?, dob=?, gender=?, phone=?, department=?, "
                    "status=?, diagnosis=? WHERE id=?",
                    (form["full_name"], form["dob"], form["gender"], form["phone"],
                     form["department"], form["status"], form["diagnosis"], pid))
                get_db().commit()
                audit("patient_update", str(pid))
                flash("Patient record updated.", "ok")
                return redirect(url_for("patients"))
        return render_template("patient_form.html", form=form, errors=errors, editing=True, pid=pid)

    @app.route("/patients/<int:pid>/delete", methods=["POST"])
    @admin_required
    def patient_delete(pid):
        get_patient_or_404(pid)
        get_db().execute("DELETE FROM patients WHERE id = ?", (pid,))
        get_db().commit()
        audit("patient_delete", str(pid))
        flash("Patient record deleted.", "ok")
        return redirect(url_for("patients"))

    # ---------- admin ----------
    @app.route("/admin/users")
    @admin_required
    def admin_users():
        db = get_db()
        users = db.execute("SELECT id, username, email, role, created_at FROM users ORDER BY id").fetchall()
        logs = db.execute("SELECT a.*, u.username FROM audit_log a LEFT JOIN users u "
                          "ON u.id = a.user_id ORDER BY a.id DESC LIMIT 20").fetchall()
        return render_template("admin_users.html", users=users, logs=logs)

    @app.route("/admin/users/<int:uid>/role", methods=["POST"])
    @admin_required
    def admin_set_role(uid):
        role = request.form.get("role")
        if role not in ("admin", "user") or uid == g.user["id"]:
            abort(400)
        get_db().execute("UPDATE users SET role = ? WHERE id = ?", (role, uid))
        get_db().commit()
        audit("role_change", f"user {uid} -> {role}")
        flash("Role updated.", "ok")
        return redirect(url_for("admin_users"))

    @app.route("/security")
    def security():
        return render_template("security.html")

    # ---------- error handling ----------
    messages = {400: "The request could not be verified. Reload the page and try again.",
                403: "You do not have permission to view this page.",
                404: "That page or record does not exist.",
                413: "That request was too large."}
    for code, msg in messages.items():
        app.register_error_handler(code, lambda e, c=code, m=msg: (
            render_template("error.html", code=c, message=m), c))

    @app.errorhandler(500)
    def server_error(_e):
        app.logger.exception("Unhandled error")
        return render_template("error.html", code=500,
                               message="Something went wrong on our side. It has been logged."), 500

    # ---------- CLI ----------
    @app.cli.command("create-admin")
    @click.argument("username")
    @click.option("--email", prompt=True)
    @click.password_option()
    def create_admin(username, email, password):
        """Create an administrator account."""
        if not USERNAME_RE.match(username) or password_errors(password):
            raise click.ClickException("Invalid username or weak password.")
        con = sqlite3.connect(app.config["DATABASE"])
        con.execute("INSERT INTO users (username, email, password_hash, role) VALUES (?,?,?, 'admin')",
                    (username, email.lower(), generate_password_hash(password)))
        con.commit()
        con.close()
        click.echo(f"Admin '{username}' created.")

    return app


app = create_app()  # gunicorn entry point: app:app
