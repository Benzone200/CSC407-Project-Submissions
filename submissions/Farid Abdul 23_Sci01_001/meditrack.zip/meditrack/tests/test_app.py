import re
import sqlite3
import pytest
from werkzeug.security import generate_password_hash
from app import create_app

PATIENT = {"full_name": "John Doe", "dob": "1990-05-01", "gender": "Male", "phone": "+234 801 234 5678",
           "department": "Cardiology", "status": "Admitted", "diagnosis": "Hypertension"}


@pytest.fixture
def app(tmp_path):
    return create_app({"TESTING": True, "DATABASE": str(tmp_path / "t.db"), "SECRET_KEY": "test"})


@pytest.fixture
def client(app):
    return app.test_client()


def token(c, path="/login"):
    html = c.get(path).get_data(as_text=True)
    return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)


def register(c, u="alice", p="Passw0rdX", **over):
    data = {"username": u, "email": f"{u}@example.com", "password": p, "confirm": p, **over}
    return c.post("/register", data={**data, "csrf_token": token(c, "/register")}, follow_redirects=True)


def login(c, u="alice", p="Passw0rdX"):
    return c.post("/login", data={"username": u, "password": p, "csrf_token": token(c)}, follow_redirects=True)


def add_patient(c, **over):
    return c.post("/patients/new", data={**PATIENT, **over, "csrf_token": token(c, "/patients/new")},
                  follow_redirects=True)


def signed_in(app, u="alice"):
    c = app.test_client()
    register(c, u)
    login(c, u)
    return c


# ---- functional / auth ----
def test_protected_pages_redirect_to_login(client):
    for path in ("/dashboard", "/patients", "/profile", "/admin/users"):
        r = client.get(path)
        assert r.status_code == 302 and "/login" in r.headers["Location"]


def test_register_login_logout(client):
    assert "Account created" in register(client).get_data(as_text=True)
    assert "Ward overview" in login(client).get_data(as_text=True)
    r = client.post("/logout", data={"csrf_token": token(client, "/dashboard")}, follow_redirects=True)
    assert "signed out" in r.get_data(as_text=True)
    assert client.get("/dashboard").status_code == 302


def test_password_is_hashed(app, client):
    register(client)
    row = sqlite3.connect(app.config["DATABASE"]).execute("SELECT password_hash FROM users").fetchone()
    assert "Passw0rdX" not in row[0] and row[0].startswith(("scrypt:", "pbkdf2:"))


# ---- validation ----
@pytest.mark.parametrize("over,msg", [
    ({"password": "short1", "confirm": "short1"}, "8 to 128"),
    ({"password": "onlyletters", "confirm": "onlyletters"}, "letter and one number"),
    ({"confirm": "Different1"}, "do not match"),
    ({"username": "a b!"}, "Username must be"),
    ({"email": "not-an-email"}, "valid email"),
])
def test_registration_validation(client, over, msg):
    assert msg in register(client, **over).get_data(as_text=True)


def test_duplicate_registration_rejected(client):
    register(client)
    assert "already registered" in register(client).get_data(as_text=True)


@pytest.mark.parametrize("over", [{"dob": "2999-01-01"}, {"phone": "abc"}, {"department": "Hacking"},
                                  {"full_name": "<b>x</b>"}, {"diagnosis": "x" * 501}])
def test_patient_validation(app, over):
    c = signed_in(app)
    assert "Patient record saved" not in add_patient(c, **over).get_data(as_text=True)


# ---- security ----
def test_wrong_password_generic_and_lockout(client):
    register(client)
    assert "Invalid username or password" in login(client, p="WrongPass1").get_data(as_text=True)
    for _ in range(4):
        login(client, p="WrongPass1")  # fifth failure locks the account
    assert "Too many failed attempts" in login(client).get_data(as_text=True)  # even the right password


def test_sql_injection_login(client):
    register(client)
    r = login(client, u="' OR '1'='1' --", p="x")
    assert "Invalid username or password" in r.get_data(as_text=True)


def test_sql_injection_search(app):
    c = signed_in(app)
    add_patient(c)
    html = c.get("/patients", query_string={"q": "' OR 1=1 --"}).get_data(as_text=True)
    assert "John Doe" not in html
    assert "John Doe" in c.get("/patients", query_string={"q": "john"}).get_data(as_text=True)


def test_xss_is_escaped(app):
    c = signed_in(app)
    add_patient(c, diagnosis="<script>alert(1)</script>")
    html = c.get("/patients").get_data(as_text=True)
    assert "<script>alert" not in html and "&lt;script&gt;" in html


def test_csrf_required(client):
    register(client)
    assert client.post("/login", data={"username": "alice", "password": "Passw0rdX"}).status_code == 400


def test_security_headers(client):
    h = client.get("/login").headers
    assert "default-src 'self'" in h["Content-Security-Policy"]
    assert h["X-Frame-Options"] == "DENY" and h["X-Content-Type-Options"] == "nosniff"


def test_session_cookie_flags(client):
    cookie = client.get("/login").headers.get("Set-Cookie", "")
    assert "HttpOnly" in cookie and "SameSite=Lax" in cookie


# ---- access control ----
def test_user_cannot_open_admin_pages(app):
    assert signed_in(app).get("/admin/users").status_code == 403


def test_admin_can_open_admin_pages(app):
    sqlite3.connect(app.config["DATABASE"]).execute(
        "INSERT INTO users (username,email,password_hash,role) VALUES ('boss','b@x.com',?, 'admin')",
        (generate_password_hash("Passw0rdX"),)).connection.commit()
    c = app.test_client()
    login(c, "boss")
    assert c.get("/admin/users").status_code == 200


def test_user_cannot_edit_or_delete_others_records(app):
    alice, bob = signed_in(app, "alice"), signed_in(app, "bob")
    add_patient(alice)
    assert bob.get("/patients/1/edit").status_code == 403
    assert bob.post("/patients/1/delete", data={"csrf_token": token(bob, "/patients")}).status_code == 403
    assert alice.get("/patients/1/edit").status_code == 200


# ---- database / search / errors / responsive ----
def test_create_and_filter_patients(app):
    c = signed_in(app)
    add_patient(c)
    add_patient(c, full_name="Mary Ade", department="Pediatrics", status="Outpatient")
    html = c.get("/patients", query_string={"department": "Pediatrics"}).get_data(as_text=True)
    assert "Mary Ade" in html and "John Doe" not in html


def test_edit_persists(app):
    c = signed_in(app)
    add_patient(c)
    c.post("/patients/1/edit", data={**PATIENT, "status": "Discharged", "csrf_token": token(c, "/patients/1/edit")})
    row = sqlite3.connect(app.config["DATABASE"]).execute("SELECT status FROM patients WHERE id=1").fetchone()
    assert row[0] == "Discharged"


def test_404_is_friendly(app):
    r = signed_in(app).get("/patients/999/edit")
    assert r.status_code == 404 and "does not exist" in r.get_data(as_text=True)


def test_viewport_meta_for_mobile(client):
    assert 'name="viewport"' in client.get("/login").get_data(as_text=True)
