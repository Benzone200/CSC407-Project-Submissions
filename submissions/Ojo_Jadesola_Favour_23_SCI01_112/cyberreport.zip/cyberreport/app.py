"""CyberReport: a cyber incident reporting system (Flask + SQLite)."""
import hashlib
import hmac
import logging
import os
import re
import secrets
import sqlite3
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from functools import wraps
from logging.handlers import RotatingFileHandler
from pathlib import Path

from flask import (Blueprint, Flask, abort, current_app, flash, g, redirect,
                   render_template, request, send_from_directory, session, url_for)
from markupsafe import Markup
from werkzeug.exceptions import HTTPException
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

BASE = Path(__file__).resolve().parent

# ---------------------------------------------------------------- constants
TYPES = ["Phishing or scam", "Ransomware or malware", "Account takeover", "Data breach",
         "Online fraud", "Harassment or impersonation", "Not sure"]
TYPE_WEIGHT = {"Phishing or scam": 2, "Ransomware or malware": 3, "Account takeover": 2,
               "Data breach": 3, "Online fraud": 2, "Harassment or impersonation": 1, "Not sure": 1}
IMPACTS = SEVERITIES = ["Low", "Medium", "High", "Critical"]
STATUSES = ["New", "Under review", "Investigating", "Resolved"]
STAGES = {"New": "Received", "Under review": "Under review",
          "Investigating": "Investigating", "Resolved": "Resolved"}
ROLES = ["user", "analyst", "admin"]
ALLOWED_EXT = {"png", "jpg", "jpeg", "pdf", "txt", "eml", "log"}
MAGIC = {"png": [b"\x89PNG\r\n\x1a\n"], "jpg": [b"\xff\xd8\xff"],
         "jpeg": [b"\xff\xd8\xff"], "pdf": [b"%PDF-"]}
MAX_FILE, MAX_FILES = 10 * 1024 * 1024, 5
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^[0-9+()\-\s]{7,20}$")
MAX_FAILED, LOCK_MINUTES, PER_PAGE = 5, 15, 10
DUMMY_HASH = generate_password_hash("not-a-real-password")  # equalises login timing

bp = Blueprint("main", __name__)


# ------------------------------------------------------------------ database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def query_db(sql, params=(), one=False):
    """Run a SELECT. Values are ALWAYS passed as `params` (parameterised queries)."""
    rows = get_db().execute(sql, params).fetchall()
    return (rows[0] if rows else None) if one else rows


def execute_db(sql, params=()):
    db = get_db()
    cur = db.execute(sql, params)
    db.commit()
    return cur.lastrowid


def init_db(app):
    db = sqlite3.connect(app.config["DATABASE"])
    try:
        db.executescript((BASE / "schema.sql").read_text(encoding="utf-8"))
    finally:
        db.close()


# ------------------------------------------------------------------- helpers
def now_utc():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def log_action(action, incident_id=None, details=None, user_id=None):
    uid = user_id if user_id is not None else (g.user["id"] if g.get("user") else None)
    execute_db("INSERT INTO audit_logs (user_id, action, incident_id, details, ip_address) "
               "VALUES (?,?,?,?,?)", (uid, action, incident_id, details, request.remote_addr))


_hits = defaultdict(deque)


def rate_limited(name, limit, window):
    """Simple in-memory limiter (per process). Use Nginx/Redis limits in production."""
    if current_app.config.get("TESTING") and not current_app.config.get("RATELIMIT_IN_TESTS"):
        return False
    key, now = f"{name}:{request.remote_addr}", time.time()
    q = _hits[key]
    while q and now - q[0] > window:
        q.popleft()
    if len(q) >= limit:
        return True
    q.append(now)
    return False


def password_problem(pw):
    if len(pw) < 10 or len(pw) > 128:
        return "Use a password of 10 to 128 characters."
    if not (re.search(r"[a-z]", pw) and re.search(r"[A-Z]", pw) and re.search(r"\d", pw)):
        return "Include an uppercase letter, a lowercase letter and a number."
    return None


def score_severity(itype, impact):
    total = TYPE_WEIGHT.get(itype, 1) + IMPACTS.index(impact)
    return "Critical" if total >= 5 else "High" if total == 4 else "Medium" if total >= 2 else "Low"


ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"


def new_tracking_id():
    year = datetime.now(timezone.utc).year
    for _ in range(10):
        tid = f"INC-{year}-" + "".join(secrets.choice(ALPHABET) for _ in range(6))
        if not query_db("SELECT 1 FROM incidents WHERE tracking_id=?", (tid,), one=True):
            return tid
    raise RuntimeError("could not generate a tracking id")


def parse_when(text):
    try:
        d = datetime.strptime(text, "%Y-%m-%dT%H:%M")
    except ValueError:
        return None
    if d > datetime.now() + timedelta(minutes=5) or d.year < 2000:
        return None
    return d


def read_upload(fs):
    """Validate one uploaded file. Returns ((data, ext, safe_name), None) or (None, error)."""
    safe = secure_filename(fs.filename or "") or "file"
    ext = safe.rsplit(".", 1)[-1].lower() if "." in safe else ""
    if ext not in ALLOWED_EXT:
        return None, f"{safe}: this file type is not allowed."
    data = fs.read(MAX_FILE + 1)
    if not data:
        return None, f"{safe}: the file is empty."
    if len(data) > MAX_FILE:
        return None, f"{safe}: larger than 10 MB."
    if ext in MAGIC:
        if not any(data.startswith(m) for m in MAGIC[ext]):
            return None, f"{safe}: the content does not match a .{ext} file."
    else:
        try:
            data.decode("utf-8")
        except UnicodeDecodeError:
            return None, f"{safe}: must be plain text."
        if b"\x00" in data:
            return None, f"{safe}: must be plain text."
    return (data, ext, safe), None


def page_info(total):
    pages = max((total + PER_PAGE - 1) // PER_PAGE, 1)
    page = min(max(request.args.get("page", 1, type=int), 1), pages)
    return page, pages, (page - 1) * PER_PAGE


def login_user(user):
    session.clear()                      # new session on login (prevents fixation)
    session["user_id"] = user["id"]
    session.permanent = True


def roles_required(*roles):
    def deco(view):
        @wraps(view)
        def wrapped(*a, **k):
            if g.user is None:
                return redirect(url_for("main.login", next=request.path))
            if g.user["role"] not in roles:
                abort(403)
            return view(*a, **k)
        return wrapped
    return deco


login_required = roles_required("user", "analyst", "admin")
staff_required = roles_required("analyst", "admin")
admin_required = roles_required("admin")


def safe_next(target):
    return target if target and target.startswith("/") and not target.startswith("//") else None


# -------------------------------------------------------------- public pages
@bp.route("/")
def home():
    return render_template("home.html", types=TYPES)


@bp.route("/security")
def security():
    return render_template("security.html")


@bp.route("/report", methods=["GET", "POST"])
def report():
    if request.method == "GET":
        return render_template("report.html", form={}, errors={}, types=TYPES, impacts=IMPACTS)
    if rate_limited("report", 10, 3600):
        abort(429)
    f, errors = request.form, {}
    itype, impact = f.get("incident_type", ""), f.get("impact", "")
    desc = f.get("description", "").strip()
    when = parse_when(f.get("date_occurred", ""))
    choice = f.get("contact_choice", "")
    if itype not in TYPES:
        errors["incident_type"] = "Choose a type from the list."
    if when is None:
        errors["date_occurred"] = "Enter a valid date and time that is not in the future."
    if not 10 <= len(desc) <= 5000:
        errors["description"] = "Describe what happened in 10 to 5000 characters."
    if impact not in IMPACTS:
        errors["impact"] = "Choose how serious the impact is."
    if choice not in ("share", "anonymous"):
        errors["contact_choice"] = "Choose whether to share your contact details."
    name = f.get("reporter_name", "").strip()
    email = f.get("reporter_email", "").strip()
    phone = f.get("reporter_phone", "").strip()
    org = f.get("reporter_org", "").strip()
    if choice == "share":
        if not 2 <= len(name) <= 100:
            errors["reporter_name"] = "Enter your full name (2 to 100 characters)."
        if len(email) > 254 or not EMAIL_RE.match(email):
            errors["reporter_email"] = "Enter a valid email address."
        if phone and not PHONE_RE.match(phone):
            errors["reporter_phone"] = "Use digits, spaces, + ( ) or - only."
        if len(org) > 100:
            errors["reporter_org"] = "Keep this under 100 characters."
        if f.get("consent") != "1":
            errors["consent"] = "Please agree to be contacted, or choose to stay anonymous."
    if f.get("accurate") != "1":
        errors["accurate"] = "Please confirm the information is accurate."
    uploads = [x for x in request.files.getlist("evidence") if x and x.filename]
    checked = []
    if len(uploads) > MAX_FILES:
        errors["evidence"] = f"You can upload up to {MAX_FILES} files."
    else:
        problems = []
        for fs in uploads:
            ok, err = read_upload(fs)
            (checked.append(ok) if ok else problems.append(err))
        if problems:
            errors["evidence"] = " ".join(problems)
    if errors:
        return render_template("report.html", form=f, errors=errors, types=TYPES,
                               impacts=IMPACTS), 400
    anon = choice == "anonymous"
    tid = new_tracking_id()
    inc_id = execute_db(
        "INSERT INTO incidents (tracking_id, incident_type, description, date_occurred, impact,"
        " severity, is_anonymous, reporter_name, reporter_email, reporter_phone, reporter_org, user_id)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        (tid, itype, desc, when.strftime("%Y-%m-%d %H:%M"), impact, score_severity(itype, impact),
         int(anon), None if anon else name, None if anon else email, None if anon or not phone else phone,
         None if anon or not org else org, None if anon or g.user is None else g.user["id"]))
    execute_db("INSERT INTO status_history (incident_id, old_status, new_status) VALUES (?,?,?)",
               (inc_id, None, "New"))
    for data, ext, safe in checked:
        stored = f"{secrets.token_hex(16)}.{ext}"
        (Path(current_app.config["UPLOAD_DIR"]) / stored).write_bytes(data)
        execute_db("INSERT INTO evidence (incident_id, file_name, stored_name, file_hash, size_bytes)"
                   " VALUES (?,?,?,?,?)", (inc_id, safe, stored, hashlib.sha256(data).hexdigest(), len(data)))
    log_action("Report submitted", inc_id, f"{len(checked)} file(s)")
    session["last_tid"] = tid
    return redirect(url_for("main.submitted"))


@bp.route("/report/submitted")
def submitted():
    tid = session.get("last_tid")
    if not tid:
        return redirect(url_for("main.report"))
    return render_template("submitted.html", tid=tid)


@bp.route("/track", methods=["GET", "POST"])
def track():
    inc, searched = None, False
    if request.method == "POST":
        if rate_limited("track", 30, 300):
            abort(429)
        tid = request.form.get("tracking_id", "").strip().upper()[:30]
        inc = query_db("SELECT tracking_id, incident_type, severity, status, public_update, created_at,"
                       " updated_at FROM incidents WHERE tracking_id=?", (tid,), one=True)
        searched = True
    stage = STATUSES.index(inc["status"]) if inc else 0
    return render_template("track.html", inc=inc, searched=searched, stage=stage, stages=STAGES)


# ------------------------------------------------------------- accounts/auth
@bp.route("/register", methods=["GET", "POST"])
def register():
    errors, form = {}, request.form
    if request.method == "POST":
        if rate_limited("register", 10, 3600):
            abort(429)
        name, email = form.get("full_name", "").strip(), form.get("email", "").strip().lower()
        pw, pw2 = form.get("password", ""), form.get("confirm", "")
        if not 2 <= len(name) <= 100:
            errors["full_name"] = "Enter your full name (2 to 100 characters)."
        if len(email) > 254 or not EMAIL_RE.match(email):
            errors["email"] = "Enter a valid email address."
        elif query_db("SELECT 1 FROM users WHERE email=?", (email,), one=True):
            errors["email"] = "An account with this email already exists."
        if password_problem(pw):
            errors["password"] = password_problem(pw)
        elif pw != pw2:
            errors["confirm"] = "The passwords do not match."
        if not errors:
            uid = execute_db("INSERT INTO users (full_name, email, password_hash) VALUES (?,?,?)",
                             (name, email, generate_password_hash(pw)))
            log_action("Registered", user_id=uid)
            flash("Account created. You can log in now.", "success")
            return redirect(url_for("main.login"))
    return render_template("register.html", errors=errors, form=form), (400 if errors else 200)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if rate_limited("login", 20, 300):
            abort(429)
        email, pw = request.form.get("email", "").strip().lower(), request.form.get("password", "")
        user = query_db("SELECT * FROM users WHERE email=? AND is_active=1", (email,), one=True)
        locked = bool(user and user["locked_until"] and user["locked_until"] > now_utc())
        ok = check_password_hash(user["password_hash"] if user else DUMMY_HASH, pw)
        if user and ok and not locked:
            execute_db("UPDATE users SET failed_logins=0, locked_until=NULL, last_login=? WHERE id=?",
                       (now_utc(), user["id"]))
            login_user(user)
            log_action("Login", user_id=user["id"])
            nxt = safe_next(request.args.get("next"))
            return redirect(nxt or url_for("main.dashboard" if user["role"] != "user" else "main.profile"))
        if user and not locked:
            fails = user["failed_logins"] + 1
            until = (datetime.now(timezone.utc) + timedelta(minutes=LOCK_MINUTES)).strftime("%Y-%m-%d %H:%M:%S") \
                if fails >= MAX_FAILED else None
            execute_db("UPDATE users SET failed_logins=?, locked_until=? WHERE id=?",
                       (0 if until else fails, until, user["id"]))
            log_action("Failed login", details=f"attempt {fails} for {email}", user_id=user["id"])
        elif not user:
            log_action("Failed login", details=f"unknown account {email[:60]}")
        flash("Invalid email or password, or the account is temporarily locked.", "error")
        return render_template("login.html"), 401
    return render_template("login.html")


@bp.post("/logout")
def logout():
    if g.user:
        log_action("Logout")
    session.clear()
    return redirect(url_for("main.home"))


@bp.route("/profile")
@login_required
def profile():
    mine = query_db("SELECT tracking_id, incident_type, severity, status, created_at FROM incidents "
                    "WHERE user_id=? ORDER BY created_at DESC", (g.user["id"],))
    return render_template("profile.html", mine=mine, errors={})


@bp.post("/profile/password")
@login_required
def change_password():
    cur, new, conf = (request.form.get(k, "") for k in ("current", "new", "confirm"))
    errors = {}
    if not check_password_hash(g.user["password_hash"], cur):
        errors["current"] = "Your current password is not correct."
    if password_problem(new):
        errors["new"] = password_problem(new)
    elif new != conf:
        errors["confirm"] = "The passwords do not match."
    if errors:
        mine = query_db("SELECT tracking_id, incident_type, severity, status, created_at FROM incidents "
                        "WHERE user_id=? ORDER BY created_at DESC", (g.user["id"],))
        return render_template("profile.html", mine=mine, errors=errors), 400
    execute_db("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), g.user["id"]))
    log_action("Changed password")
    login_user(g.user)
    flash("Password updated.", "success")
    return redirect(url_for("main.profile"))


# ---------------------------------------------------------------- staff area
def _filters():
    a, where, params = request.args, [], []
    for key, col, allowed in (("status", "i.status", STATUSES), ("severity", "i.severity", SEVERITIES),
                              ("type", "i.incident_type", TYPES)):
        if a.get(key) in allowed:
            where.append(f"{col} = ?")
            params.append(a[key])
    asg = a.get("assigned", "")
    if asg == "unassigned":
        where.append("i.assigned_to IS NULL")
    elif asg.isdigit():
        where.append("i.assigned_to = ?")
        params.append(int(asg))
    text = a.get("q", "").strip()[:50]
    if text:
        like = "%" + text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        where.append("(i.tracking_id LIKE ? ESCAPE '\\' OR i.incident_type LIKE ? ESCAPE '\\')")
        params += [like, like]
    return where, params


def _case_list(title, mine):
    where, params = _filters()           # `where` holds only fixed SQL fragments; values are bound
    if mine:
        where.append("i.assigned_to = ?")
        params.append(g.user["id"])
    cond = ("WHERE " + " AND ".join(where)) if where else ""
    total = query_db(f"SELECT COUNT(*) AS c FROM incidents i {cond}", params, one=True)["c"]
    page, pages, offset = page_info(total)
    rows = query_db(f"SELECT i.*, u.full_name AS assignee FROM incidents i "
                    f"LEFT JOIN users u ON u.id = i.assigned_to {cond} "
                    f"ORDER BY i.created_at DESC, i.id DESC LIMIT ? OFFSET ?", params + [PER_PAGE, offset])
    staff = query_db("SELECT id, full_name FROM users WHERE role IN ('analyst','admin') AND is_active=1 "
                     "ORDER BY full_name")
    return render_template("admin/cases.html", title=title, mine=mine, rows=rows, total=total,
                           page=page, pages=pages, staff=staff, statuses=STATUSES,
                           severities=SEVERITIES, types=TYPES)


@bp.route("/admin")
@staff_required
def dashboard():
    one = lambda sql: query_db(sql, one=True)["c"]
    stats = {"new": one("SELECT COUNT(*) c FROM incidents WHERE status='New'"),
             "investigating": one("SELECT COUNT(*) c FROM incidents WHERE status='Investigating'"),
             "critical": one("SELECT COUNT(*) c FROM incidents WHERE severity='Critical' AND status!='Resolved'"),
             "avg_days": query_db("SELECT AVG(julianday(h.changed_at) - julianday(i.created_at)) AS d "
                                  "FROM status_history h JOIN incidents i ON i.id=h.incident_id "
                                  "WHERE h.new_status='Resolved'", one=True)["d"]}
    recent = query_db("SELECT i.*, u.full_name AS assignee FROM incidents i LEFT JOIN users u "
                      "ON u.id=i.assigned_to ORDER BY i.created_at DESC, i.id DESC LIMIT 5")
    return render_template("admin/dashboard.html", stats=stats, rows=recent)


@bp.route("/admin/cases")
@staff_required
def all_cases():
    return _case_list("All cases", False)


@bp.route("/admin/my-cases")
@staff_required
def my_cases():
    return _case_list("My cases", True)


def _get_case(tid):
    inc = query_db("SELECT i.*, u.full_name AS assignee FROM incidents i LEFT JOIN users u "
                   "ON u.id=i.assigned_to WHERE i.tracking_id=?", (tid,), one=True)
    return inc or abort(404)


@bp.route("/admin/cases/<tid>")
@staff_required
def case_detail(tid):
    inc = _get_case(tid)
    log_action("Viewed case", inc["id"])
    return render_template(
        "admin/case_detail.html", inc=inc, statuses=STATUSES, severities=SEVERITIES,
        evidence=query_db("SELECT * FROM evidence WHERE incident_id=?", (inc["id"],)),
        notes=query_db("SELECT n.*, u.full_name FROM case_notes n JOIN users u ON u.id=n.user_id "
                       "WHERE incident_id=? ORDER BY n.created_at DESC, n.id DESC", (inc["id"],)),
        history=query_db("SELECT h.*, u.full_name FROM status_history h LEFT JOIN users u "
                         "ON u.id=h.changed_by WHERE incident_id=? ORDER BY h.id DESC", (inc["id"],)),
        staff=query_db("SELECT id, full_name FROM users WHERE role IN ('analyst','admin') AND is_active=1 "
                       "ORDER BY full_name"))


@bp.post("/admin/cases/<tid>/update")
@staff_required
def case_update(tid):
    inc, f = _get_case(tid), request.form
    status, severity, assignee = f.get("status", ""), f.get("severity", ""), f.get("assigned_to", "")
    update = f.get("public_update", "").strip()
    if status not in STATUSES or severity not in SEVERITIES or len(update) > 1000:
        abort(400)
    if assignee:
        ok = assignee.isdigit() and query_db("SELECT 1 FROM users WHERE id=? AND is_active=1 AND "
                                             "role IN ('analyst','admin')", (int(assignee),), one=True)
        if not ok:
            abort(400)
    new_assignee = int(assignee) if assignee else None
    execute_db("UPDATE incidents SET status=?, severity=?, assigned_to=?, public_update=?, "
               "updated_at=? WHERE id=?", (status, severity, new_assignee, update or None, now_utc(), inc["id"]))
    if status != inc["status"]:
        execute_db("INSERT INTO status_history (incident_id, old_status, new_status, changed_by) "
                   "VALUES (?,?,?,?)", (inc["id"], inc["status"], status, g.user["id"]))
        log_action("Changed status", inc["id"], f"{inc['status']} to {status}")
    if new_assignee != inc["assigned_to"]:
        log_action("Assigned case", inc["id"], f"user id {new_assignee}")
    if severity != inc["severity"]:
        log_action("Changed severity", inc["id"], f"{inc['severity']} to {severity}")
    flash("Case updated.", "success")
    return redirect(url_for("main.case_detail", tid=tid))


@bp.post("/admin/cases/<tid>/note")
@staff_required
def case_note(tid):
    inc, note = _get_case(tid), request.form.get("note", "").strip()
    if not 1 <= len(note) <= 2000:
        flash("Write a note of up to 2000 characters.", "error")
    else:
        execute_db("INSERT INTO case_notes (incident_id, user_id, note) VALUES (?,?,?)",
                   (inc["id"], g.user["id"], note))
        log_action("Added note", inc["id"])
        flash("Note added.", "success")
    return redirect(url_for("main.case_detail", tid=tid))


@bp.route("/admin/evidence/<int:eid>")
@staff_required
def evidence_download(eid):
    ev = query_db("SELECT * FROM evidence WHERE id=?", (eid,), one=True) or abort(404)
    log_action("Downloaded evidence", ev["incident_id"], ev["file_name"])
    return send_from_directory(current_app.config["UPLOAD_DIR"], ev["stored_name"],
                               as_attachment=True, download_name=ev["file_name"])


@bp.route("/admin/analytics")
@staff_required
def analytics():
    total = query_db("SELECT COUNT(*) c FROM incidents", one=True)["c"]
    resolved = query_db("SELECT COUNT(*) c FROM incidents WHERE status='Resolved'", one=True)["c"]
    by_type = query_db("SELECT incident_type AS label, COUNT(*) AS n FROM incidents "
                       "GROUP BY incident_type ORDER BY n DESC")
    by_sev = {r["severity"]: r["n"] for r in query_db(
        "SELECT severity, COUNT(*) AS n FROM incidents GROUP BY severity")}
    months, today = [], datetime.now(timezone.utc).replace(day=1)
    counts = {r["m"]: r["n"] for r in query_db(
        "SELECT strftime('%Y-%m', created_at) AS m, COUNT(*) AS n FROM incidents GROUP BY m")}
    for i in range(5, -1, -1):
        y, m = divmod(today.year * 12 + today.month - 1 - i, 12)
        key = f"{y}-{m + 1:02d}"
        months.append({"label": datetime(y, m + 1, 1).strftime("%b %Y"), "n": counts.get(key, 0)})
    avg = query_db("SELECT AVG(julianday(h.changed_at) - julianday(i.created_at)) AS d FROM status_history h "
                   "JOIN incidents i ON i.id=h.incident_id WHERE h.new_status='Resolved'", one=True)["d"]
    return render_template("admin/analytics.html", total=total, resolved=resolved, avg=avg,
                           pct=round(resolved / total * 100) if total else 0, by_type=by_type,
                           months=months, by_sev=[(s, by_sev.get(s, 0)) for s in reversed(SEVERITIES)],
                           max_type=max([r["n"] for r in by_type] or [1]),
                           max_month=max([m["n"] for m in months] or [1]) or 1)


@bp.route("/admin/audit")
@admin_required
def audit():
    action = request.args.get("action", "")
    actions = [r["action"] for r in query_db("SELECT DISTINCT action FROM audit_logs ORDER BY action")]
    where, params = ("WHERE a.action = ?", [action]) if action in actions else ("", [])
    total = query_db(f"SELECT COUNT(*) c FROM audit_logs a {where}", params, one=True)["c"]
    page, pages, offset = page_info(total)
    rows = query_db(f"SELECT a.*, u.full_name, i.tracking_id FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id "
                    f"LEFT JOIN incidents i ON i.id=a.incident_id {where} ORDER BY a.id DESC LIMIT ? OFFSET ?",
                    params + [PER_PAGE, offset])
    return render_template("admin/audit.html", rows=rows, total=total, page=page, pages=pages,
                           actions=actions, action=action)


@bp.route("/admin/users")
@admin_required
def users():
    return render_template("admin/users.html", rows=query_db("SELECT * FROM users ORDER BY created_at"),
                           roles=ROLES, errors={}, form={})


@bp.post("/admin/users")
@admin_required
def user_create():
    f, errors = request.form, {}
    name, email, role = f.get("full_name", "").strip(), f.get("email", "").strip().lower(), f.get("role", "")
    pw = f.get("password", "")
    if not 2 <= len(name) <= 100:
        errors["full_name"] = "Enter a name (2 to 100 characters)."
    if len(email) > 254 or not EMAIL_RE.match(email):
        errors["email"] = "Enter a valid email address."
    elif query_db("SELECT 1 FROM users WHERE email=?", (email,), one=True):
        errors["email"] = "That email is already in use."
    if role not in ROLES:
        errors["role"] = "Choose a role."
    if password_problem(pw):
        errors["password"] = password_problem(pw)
    if errors:
        return render_template("admin/users.html", rows=query_db("SELECT * FROM users ORDER BY created_at"),
                               roles=ROLES, errors=errors, form=f), 400
    uid = execute_db("INSERT INTO users (full_name, email, password_hash, role) VALUES (?,?,?,?)",
                     (name, email, generate_password_hash(pw), role))
    log_action("Created user", details=f"user id {uid} as {role}")
    flash("User created. Share the temporary password securely.", "success")
    return redirect(url_for("main.users"))


@bp.post("/admin/users/<int:uid>")
@admin_required
def user_update(uid):
    role, active = request.form.get("role", ""), request.form.get("is_active") == "1"
    if role not in ROLES or not query_db("SELECT 1 FROM users WHERE id=?", (uid,), one=True):
        abort(400)
    if uid == g.user["id"]:
        flash("You cannot change your own role or disable your own account.", "error")
    else:
        execute_db("UPDATE users SET role=?, is_active=? WHERE id=?", (role, int(active), uid))
        log_action("Updated user", details=f"user id {uid}: role {role}, active {active}")
        flash("User updated.", "success")
    return redirect(url_for("main.users"))


# ---------------------------------------------------------------- app factory
ERROR_TEXT = {400: "The request could not be processed. Go back, reload the page and try again.",
              403: "You do not have permission to open this page.", 404: "We could not find that page.",
              413: "The files you sent are too large.", 429: "Too many requests. Please wait a few minutes.",
              500: "Something went wrong on our side. Please try again later."}


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    prod = os.environ.get("APP_ENV", "development") == "production"
    secret = os.environ.get("SECRET_KEY")
    if prod and not secret:
        raise RuntimeError("SECRET_KEY must be set when APP_ENV=production")
    app.config.update(
        SECRET_KEY=secret or secrets.token_hex(32), PRODUCTION=prod,
        DATABASE=os.environ.get("DATABASE_PATH", str(Path(app.instance_path) / "cyberreport.db")),
        UPLOAD_DIR=os.environ.get("UPLOAD_DIR", str(BASE / "uploads")),
        MAX_CONTENT_LENGTH=25 * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_SECURE=prod,
        PERMANENT_SESSION_LIFETIME=timedelta(minutes=30))
    if test_config:
        app.config.update(test_config)
    if os.environ.get("TRUST_PROXY") == "1":
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
    Path(app.config["DATABASE"]).parent.mkdir(parents=True, exist_ok=True)
    Path(app.config["UPLOAD_DIR"]).mkdir(parents=True, exist_ok=True)
    init_db(app)
    if not app.testing:
        (BASE / "logs").mkdir(exist_ok=True)
        handler = RotatingFileHandler(BASE / "logs" / "app.log", maxBytes=1_000_000, backupCount=5)
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        app.logger.addHandler(handler)
        app.logger.setLevel(logging.INFO)

    @app.teardown_appcontext
    def close_db(exc):
        db = g.pop("db", None)
        if db is not None:
            db.close()

    @app.before_request
    def load_user_and_check_csrf():
        g.user, uid = None, session.get("user_id")
        if uid:
            g.user = query_db("SELECT * FROM users WHERE id=? AND is_active=1", (uid,), one=True)
            if g.user is None:
                session.clear()
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            sent, expected = request.form.get("_csrf", ""), session.get("_csrf", "")
            if not sent or not hmac.compare_digest(sent.encode(), expected.encode()):
                abort(400)

    @app.after_request
    def security_headers(resp):
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; "
            "font-src https://fonts.gstatic.com; img-src 'self' data:; object-src 'none'; "
            "base-uri 'self'; form-action 'self'; frame-ancestors 'none'")
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        if app.config["PRODUCTION"]:
            resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        if g.get("user") or request.path.startswith("/admin"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.context_processor
    def inject():
        return {"csrf_field": lambda: Markup(
            '<input type="hidden" name="_csrf" value="%s">' % session.setdefault("_csrf", secrets.token_hex(16))),
            "STAGES": STAGES}

    @app.template_filter("dt")
    def fmt_dt(v):
        try:
            return datetime.strptime(v[:16], "%Y-%m-%d %H:%M").strftime("%d %b %Y, %H:%M")
        except (TypeError, ValueError):
            return v or ""

    @app.template_filter("d")
    def fmt_d(v):
        try:
            return datetime.strptime(v[:10], "%Y-%m-%d").strftime("%d %b %Y")
        except (TypeError, ValueError):
            return v or ""

    @app.errorhandler(HTTPException)
    def http_error(e):
        code = e.code or 500
        return render_template("error.html", code=code, text=ERROR_TEXT.get(code, e.name)), code

    @app.errorhandler(Exception)
    def server_error(e):
        app.logger.exception("Unhandled error: %s", e)
        return render_template("error.html", code=500, text=ERROR_TEXT[500]), 500

    app.register_blueprint(bp)
    return app


if __name__ == "__main__":
    create_app().run(debug=os.environ.get("FLASK_DEBUG") == "1")
