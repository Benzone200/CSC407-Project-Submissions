"""Automated tests: functional, validation, access control and security checks.
Run from the project folder with:  python -m unittest discover -s tests -v
"""
import io
import re
import sys
import shutil
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app import create_app, execute_db, query_db  # noqa: E402
from werkzeug.security import generate_password_hash  # noqa: E402

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 32
GOOD_PW = "Str0ngPassword!"


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.app = create_app({"TESTING": True, "DATABASE": f"{self.tmp}/t.db",
                               "UPLOAD_DIR": f"{self.tmp}/up", "SECRET_KEY": "test-key"})
        self.c = self.app.test_client()
        with self.app.app_context():
            for email, role in (("admin@t.com", "admin"), ("analyst@t.com", "analyst"), ("user@t.com", "user")):
                execute_db("INSERT INTO users (full_name,email,password_hash,role) VALUES (?,?,?,?)",
                           (role.title(), email, generate_password_hash(GOOD_PW), role))

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)   # Windows can keep files locked briefly

    def token(self, client=None, path="/login"):
        html = (client or self.c).get(path).get_data(as_text=True)
        return re.search(r'name="_csrf" value="([^"]+)"', html).group(1)

    def post(self, path, data=None, client=None, token_path="/login", **kw):
        client = client or self.c
        data = dict(data or {})
        data.setdefault("_csrf", self.token(client, token_path))
        return client.post(path, data=data, **kw)

    def login(self, email, pw=GOOD_PW, client=None):
        return self.post("/login", {"email": email, "password": pw}, client=client)

    def staff_client(self, email="analyst@t.com"):
        c = self.app.test_client()
        self.login(email, client=c)
        return c

    def report_data(self, **over):
        d = {"incident_type": "Phishing or scam", "date_occurred": "2026-01-05T09:30",
             "description": "I clicked a fake bank link and entered my login details.",
             "impact": "High", "contact_choice": "anonymous", "accurate": "1"}
        d.update(over)
        return d

    def submit(self, client=None, **over):
        files = over.pop("files", None)
        data = self.report_data(**over)
        if files:
            data["evidence"] = files
        return self.post("/report", data, client=client, token_path="/report",
                         content_type="multipart/form-data")

    def tid(self):
        with self.app.app_context():
            return query_db("SELECT tracking_id FROM incidents ORDER BY id DESC LIMIT 1", one=True)[0]


class FunctionalTests(Base):
    def test_public_pages_load(self):
        for p in ("/", "/report", "/track", "/login", "/register", "/security"):
            self.assertEqual(self.c.get(p).status_code, 200, p)

    def test_unknown_page_gives_friendly_404(self):
        r = self.c.get("/nope")
        self.assertEqual(r.status_code, 404)
        self.assertNotIn("Traceback", r.get_data(as_text=True))

    def test_valid_report_gets_tracking_id_and_can_be_tracked(self):
        r = self.submit()
        self.assertEqual(r.status_code, 302)
        tid = self.tid()
        self.assertRegex(tid, r"^INC-\d{4}-[A-Z2-9]{6}$")
        page = self.post("/track", {"tracking_id": tid.lower()}, token_path="/track").get_data(as_text=True)
        self.assertIn(tid, page)
        self.assertIn("Received", page)

    def test_unknown_tracking_id(self):
        page = self.post("/track", {"tracking_id": "INC-2026-ZZZZZZ"}, token_path="/track").get_data(as_text=True)
        self.assertIn("could not find", page)

    def test_anonymous_report_stores_no_contact_details(self):
        self.submit(reporter_name="Jane", reporter_email="j@x.com")
        with self.app.app_context():
            row = query_db("SELECT * FROM incidents", one=True)
        self.assertEqual(row["is_anonymous"], 1)
        self.assertIsNone(row["reporter_email"])
        self.assertIsNone(row["user_id"])

    def test_severity_is_scored(self):
        self.submit(incident_type="Ransomware or malware", impact="Critical")
        with self.app.app_context():
            self.assertEqual(query_db("SELECT severity FROM incidents", one=True)[0], "Critical")

    def test_staff_can_update_case_and_history_recorded(self):
        self.submit()
        tid = self.tid()
        c = self.staff_client()
        r = self.post(f"/admin/cases/{tid}/update", {"status": "Investigating", "severity": "High",
                      "assigned_to": "", "public_update": "We are checking the sender."},
                      client=c, token_path=f"/admin/cases/{tid}")
        self.assertEqual(r.status_code, 302)
        page = self.post("/track", {"tracking_id": tid}, token_path="/track").get_data(as_text=True)
        self.assertIn("We are checking the sender.", page)
        with self.app.app_context():
            self.assertEqual(query_db("SELECT COUNT(*) FROM status_history", one=True)[0], 2)

    def test_dashboard_and_lists_render_for_staff(self):
        self.submit()
        c = self.staff_client()
        for p in ("/admin", "/admin/cases", "/admin/my-cases", "/admin/analytics", "/admin/cases?status=New&q=phish"):
            self.assertEqual(c.get(p).status_code, 200, p)
        self.assertEqual(self.staff_client("admin@t.com").get("/admin/audit").status_code, 200)
        self.assertEqual(self.staff_client("admin@t.com").get("/admin/users").status_code, 200)

    def test_logout_ends_session(self):
        c = self.staff_client()
        self.post("/logout", client=c, token_path="/admin")
        self.assertEqual(c.get("/admin").status_code, 302)


class ValidationTests(Base):
    def test_register_rejects_weak_password(self):
        r = self.post("/register", {"full_name": "Ada Obi", "email": "ada@x.com", "password": "short",
                                    "confirm": "short"}, token_path="/register")
        self.assertEqual(r.status_code, 400)
        self.assertIn("10 to 128 characters", r.get_data(as_text=True))

    def test_register_rejects_duplicate_email_and_bad_email(self):
        r = self.post("/register", {"full_name": "A B", "email": "user@t.com", "password": GOOD_PW,
                                    "confirm": GOOD_PW}, token_path="/register")
        self.assertIn("already exists", r.get_data(as_text=True))
        r = self.post("/register", {"full_name": "A B", "email": "not-an-email", "password": GOOD_PW,
                                    "confirm": GOOD_PW}, token_path="/register")
        self.assertIn("valid email", r.get_data(as_text=True))

    def test_register_then_login(self):
        self.post("/register", {"full_name": "Ada Obi", "email": "ada@x.com", "password": GOOD_PW,
                                "confirm": GOOD_PW}, token_path="/register")
        r = self.login("ada@x.com")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/profile", r.headers["Location"])

    def test_passwords_are_hashed(self):
        with self.app.app_context():
            h = query_db("SELECT password_hash FROM users WHERE email='user@t.com'", one=True)[0]
        self.assertNotIn(GOOD_PW, h)
        self.assertTrue(h.startswith(("scrypt:", "pbkdf2:")))

    def test_wrong_password_and_unknown_user_give_same_message(self):
        a = self.login("user@t.com", "WrongPassword1").get_data(as_text=True)
        b = self.login("ghost@t.com", "WrongPassword1").get_data(as_text=True)
        self.assertIn("Invalid email or password", a)
        self.assertIn("Invalid email or password", b)

    def test_account_locks_after_five_failures(self):
        for _ in range(5):
            self.login("user@t.com", "WrongPassword1")
        r = self.login("user@t.com", GOOD_PW)
        self.assertEqual(r.status_code, 401)

    def test_report_validation_errors(self):
        cases = [{"incident_type": "Made up"}, {"description": "short"}, {"impact": "Huge"},
                 {"date_occurred": "2999-01-01T00:00"}, {"date_occurred": "garbage"}, {"accurate": ""},
                 {"contact_choice": "share", "reporter_name": "", "reporter_email": "bad", "consent": ""}]
        for over in cases:
            data = self.report_data(**over)
            r = self.post("/report", data, token_path="/report", content_type="multipart/form-data")
            self.assertEqual(r.status_code, 400, over)
        with self.app.app_context():
            self.assertEqual(query_db("SELECT COUNT(*) FROM incidents", one=True)[0], 0)

    def test_empty_login_fields_rejected(self):
        self.assertEqual(self.login("", "").status_code, 401)

    def test_upload_rules(self):
        bad_ext = self.submit(files=(io.BytesIO(b"MZ"), "virus.exe"))
        self.assertEqual(bad_ext.status_code, 400)
        fake_png = self.submit(files=(io.BytesIO(b"not really a png"), "shot.png"))
        self.assertEqual(fake_png.status_code, 400)
        ok = self.submit(files=(io.BytesIO(PNG), "shot.png"))
        self.assertEqual(ok.status_code, 302)
        too_big = self.submit(files=(io.BytesIO(PNG + b"0" * (10 * 1024 * 1024)), "big.png"))
        self.assertEqual(too_big.status_code, 400)

    def test_stored_upload_has_random_name_outside_static(self):
        self.submit(files=(io.BytesIO(PNG), "../../evil name.png"))
        with self.app.app_context():
            row = query_db("SELECT * FROM evidence", one=True)
        self.assertNotIn("evil", row["stored_name"])
        self.assertNotIn("/", row["file_name"])
        self.assertTrue((Path(self.tmp) / "up" / row["stored_name"]).exists())


class SecurityTests(Base):
    def test_post_without_csrf_token_is_rejected(self):
        self.assertEqual(self.c.post("/login", data={"email": "user@t.com", "password": GOOD_PW}).status_code, 400)
        self.assertEqual(self.c.post("/report", data=self.report_data()).status_code, 400)

    def test_anonymous_visitor_is_sent_to_login(self):
        for p in ("/admin", "/admin/cases", "/admin/analytics", "/profile"):
            r = self.c.get(p)
            self.assertEqual(r.status_code, 302, p)
            self.assertIn("/login", r.headers["Location"])

    def test_normal_user_cannot_open_staff_pages(self):
        c = self.staff_client("user@t.com")
        for p in ("/admin", "/admin/cases", "/admin/users", "/admin/audit"):
            self.assertEqual(c.get(p).status_code, 403, p)

    def test_analyst_cannot_open_admin_only_pages(self):
        c = self.staff_client("analyst@t.com")
        self.assertEqual(c.get("/admin/cases").status_code, 200)
        self.assertEqual(c.get("/admin/users").status_code, 403)
        self.assertEqual(c.get("/admin/audit").status_code, 403)
        r = self.post("/admin/users", {"full_name": "X Y", "email": "x@y.com", "role": "admin",
                                       "password": GOOD_PW}, client=c, token_path="/admin")
        self.assertEqual(r.status_code, 403)

    def test_admin_cannot_change_own_role(self):
        c = self.staff_client("admin@t.com")
        with self.app.app_context():
            uid = query_db("SELECT id FROM users WHERE email='admin@t.com'", one=True)[0]
        self.post(f"/admin/users/{uid}", {"role": "user"}, client=c, token_path="/admin/users")
        with self.app.app_context():
            self.assertEqual(query_db("SELECT role FROM users WHERE id=?", (uid,), one=True)[0], "admin")

    def test_evidence_download_needs_staff_login(self):
        self.submit(files=(io.BytesIO(PNG), "shot.png"))
        with self.app.app_context():
            eid = query_db("SELECT id FROM evidence", one=True)[0]
        self.assertEqual(self.c.get(f"/admin/evidence/{eid}").status_code, 302)
        r = self.staff_client().get(f"/admin/evidence/{eid}")
        self.assertEqual(r.status_code, 200)
        self.assertIn("attachment", r.headers["Content-Disposition"])

    def test_sql_injection_attempts_fail_safely(self):
        payloads = ["' OR '1'='1", "'; DROP TABLE incidents; --", "\" OR 1=1 --"]
        self.submit()
        for p in payloads:
            page = self.post("/track", {"tracking_id": p}, token_path="/track").get_data(as_text=True)
            self.assertIn("could not find", page)
            self.assertEqual(self.login(p, p).status_code, 401)
            c = self.staff_client()
            self.assertEqual(c.get("/admin/cases", query_string={"q": p, "status": p, "assigned": p}).status_code, 200)
        with self.app.app_context():
            self.assertEqual(query_db("SELECT COUNT(*) FROM incidents", one=True)[0], 1)

    def test_xss_payload_is_escaped_everywhere_it_is_shown(self):
        evil = "<script>alert(1)</script>"
        self.submit(description=evil + " plus enough text to pass")
        tid = self.tid()
        c = self.staff_client()
        html = c.get(f"/admin/cases/{tid}").get_data(as_text=True)
        self.assertNotIn(evil, html)
        self.assertIn("&lt;script&gt;", html)
        self.post(f"/admin/cases/{tid}/note", {"note": evil}, client=c, token_path=f"/admin/cases/{tid}")
        self.assertNotIn(evil, c.get(f"/admin/cases/{tid}").get_data(as_text=True))

    def test_security_headers_present(self):
        h = self.c.get("/").headers
        self.assertIn("script-src 'self'", h["Content-Security-Policy"])
        self.assertEqual(h["X-Content-Type-Options"], "nosniff")
        self.assertEqual(h["X-Frame-Options"], "DENY")

    def test_no_inline_scripts_or_styles_in_pages(self):
        for p in ("/", "/report", "/track", "/login"):
            html = self.c.get(p).get_data(as_text=True)
            self.assertIsNone(re.search(r"<script(?![^>]*\bsrc=)", html), p)
            self.assertNotIn(' style="', html, p)

    def test_session_cookie_flags(self):
        resp = self.post("/login", {"email": "user@t.com", "password": GOOD_PW})
        header = " ".join(resp.headers.getlist("Set-Cookie"))
        self.assertIn("HttpOnly", header)
        self.assertIn("SameSite=Lax", header)

    def test_open_redirect_is_blocked(self):
        r = self.post("/login?next=https://evil.example", {"email": "user@t.com", "password": GOOD_PW})
        self.assertNotIn("evil.example", r.headers["Location"])

    def test_rate_limit_on_login(self):
        self.app.config["RATELIMIT_IN_TESTS"] = True
        codes = [self.login("ghost@t.com", "x").status_code for _ in range(22)]
        self.assertEqual(codes[-1], 429)

    def test_production_requires_secret_key(self):
        import os
        os.environ["APP_ENV"] = "production"
        os.environ.pop("SECRET_KEY", None)
        try:
            with self.assertRaises(RuntimeError):
                create_app({"DATABASE": f"{self.tmp}/p.db", "UPLOAD_DIR": f"{self.tmp}/pu"})
        finally:
            os.environ.pop("APP_ENV")

    def test_change_password_needs_current_password(self):
        c = self.staff_client("user@t.com")
        r = self.post("/profile/password", {"current": "Wrong1Password", "new": "An0therGoodPass", "confirm": "An0therGoodPass"},
                      client=c, token_path="/profile")
        self.assertEqual(r.status_code, 400)


if __name__ == "__main__":
    unittest.main()
