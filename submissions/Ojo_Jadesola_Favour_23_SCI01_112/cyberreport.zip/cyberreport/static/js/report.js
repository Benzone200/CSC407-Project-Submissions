/* Multi-step report form: step switching, per-step checks, review summary, file picker. */
(function () {
  'use strict';
  document.documentElement.classList.add('js');
  var form = document.getElementById('report-form');
  var steps = Array.from(form.querySelectorAll('.step'));
  var pills = Array.from(document.querySelectorAll('#stepper li'));
  var tick = document.getElementById('tick-tpl');
  var current = 1;

  function field(name) { return form.elements[name]; }
  function clearErrors(scope) {
    scope.querySelectorAll('.field-error.js-err').forEach(function (e) { e.remove(); });
    scope.querySelectorAll('[aria-invalid]').forEach(function (e) { e.removeAttribute('aria-invalid'); });
  }
  function addError(el, msg) {
    var p = document.createElement('p');
    p.className = 'field-error js-err'; p.textContent = msg;
    var anchor = el.closest('fieldset') || el.closest('.opts') || el.closest('label.chk') || el;
    anchor.insertAdjacentElement('afterend', p);
    if (el.setAttribute) { el.setAttribute('aria-invalid', 'true'); }
  }

  function validate(n) {            // browser-side convenience only; the server checks again
    var section = steps[n - 1], problems = [];
    clearErrors(section);
    var sharing = field('contact_choice') && field('contact_choice').value !== 'anonymous';
    section.querySelectorAll('input, select, textarea').forEach(function (el) {
      if (el.type === 'file' || el.disabled || el.type === 'radio') { return; }
      if (el.closest('#contact-fields') && !sharing) { return; }
      if (el.id === 'consent' && !sharing) { return; }
      if (!el.checkValidity()) { problems.push([el, el.validationMessage || 'Please check this field.']); }
      else if (el.id === 'consent' && !el.checked) { problems.push([el, 'Please agree to be contacted, or choose to stay anonymous.']); }
    });
    if (n === 1 && !form.querySelector('input[name="impact"]:checked')) {
      problems.push([form.querySelector('input[name="impact"]'), 'Choose how serious the impact is.']);
    }
    if (n === 1) {
      var d = field('date_occurred');
      if (d.value && new Date(d.value) > new Date(Date.now() + 5 * 60000)) { problems.push([d, 'The date cannot be in the future.']); }
    }
    if (n === 4 && !field('accurate').checked) { problems.push([field('accurate'), 'Please confirm the information is accurate.']); }
    problems.forEach(function (p) { addError(p[0], p[1]); });
    if (problems.length) {
      window.showToast('Please fix ' + problems.length + (problems.length === 1 ? ' field' : ' fields') + ' before continuing.', 'error');
      problems[0][0].focus();
    }
    return problems.length === 0;
  }

  function review() {
    var dl = document.getElementById('review');
    dl.replaceChildren();
    var sharing = field('contact_choice').value !== 'anonymous';
    var rows = [['Type', field('incident_type').value], ['When', field('date_occurred').value.replace('T', ', ')],
      ['Impact', (form.querySelector('input[name="impact"]:checked') || {}).value || ''],
      ['What happened', field('description').value],
      ['Evidence', files.length ? files.map(function (f) { return f.name; }).join(', ') : 'No files']];
    if (sharing) { rows.push(['Name', field('reporter_name').value], ['Email', field('reporter_email').value]); }
    else { rows.push(['Contact', 'Anonymous']); }
    rows.forEach(function (r) {
      var wrap = document.createElement('div'), dt = document.createElement('dt'), dd = document.createElement('dd');
      dt.textContent = r[0]; dd.textContent = r[1] || 'Not given';
      wrap.append(dt, dd); dl.append(wrap);
    });
  }

  function show(n) {
    current = n;
    steps.forEach(function (s, i) { s.classList.toggle('is-active', i === n - 1); });
    pills.forEach(function (p, i) {
      var done = i < n - 1, on = i === n - 1, badge = p.querySelector('i');
      p.classList.toggle('dn', done); p.classList.toggle('on', on);
      badge.replaceChildren(done ? tick.content.cloneNode(true) : document.createTextNode(String(i + 1)));
      var hint = p.querySelector('.sr'); if (hint) { hint.remove(); }
      if (done) { var s = document.createElement('span'); s.className = 'sr'; s.textContent = ' (completed)'; p.append(s); }
    });
    if (n === 4) { review(); }
    var heading = steps[n - 1].querySelector('h1'); heading.focus();
    if (history.replaceState) { history.replaceState(null, '', '#step-' + n); }
    window.scrollTo(0, 0);
  }

  form.addEventListener('click', function (e) {
    if (e.target.closest('[data-next]')) { if (validate(current)) { show(current + 1); } }
    if (e.target.closest('[data-back]')) { show(current - 1); }
  });
  form.addEventListener('submit', function (e) {
    for (var n = 1; n <= 4; n++) { if (!validate(n)) { e.preventDefault(); show(n); return; } }
  });

  /* Anonymous option hides and disables the contact fields. */
  function syncContact() {
    var sharing = field('contact_choice').value !== 'anonymous', box = document.getElementById('contact-fields');
    box.hidden = !sharing;
    box.querySelectorAll('input').forEach(function (i) { i.disabled = !sharing; });
    field('reporter_name').required = sharing;
    field('reporter_email').required = sharing;
  }
  form.querySelectorAll('input[name="contact_choice"]').forEach(function (r) { r.addEventListener('change', syncContact); });
  syncContact();

  /* ---- File picker ---- */
  var input = document.getElementById('evidence'), zone = document.getElementById('dropzone');
  var list = document.getElementById('file-list'), errBox = document.getElementById('file-errors');
  var ALLOWED = ['png', 'jpg', 'jpeg', 'pdf', 'txt', 'eml', 'log'], MAX_SIZE = 10 * 1024 * 1024, MAX_FILES = 5;
  var files = [];

  function addFiles(incoming) {
    var errors = [];
    Array.from(incoming).forEach(function (f) {
      var ext = f.name.split('.').pop().toLowerCase();
      if (ALLOWED.indexOf(ext) === -1) { errors.push(f.name + ': this file type is not allowed'); }
      else if (f.size > MAX_SIZE) { errors.push(f.name + ': larger than 10 MB'); }
      else if (files.length >= MAX_FILES) { errors.push('You can add up to ' + MAX_FILES + ' files'); }
      else if (!files.some(function (x) { return x.name === f.name && x.size === f.size; })) { files.push(f); }
    });
    errBox.textContent = errors.join('. ');
    sync();
  }
  function sync() {
    var dt = new DataTransfer();
    files.forEach(function (f) { dt.items.add(f); });
    input.files = dt.files;                      // this is what the form submits
    list.replaceChildren();
    files.forEach(function (f, i) {
      var row = document.createElement('div'), label = document.createElement('span'), btn = document.createElement('button');
      row.className = 'row'; label.textContent = f.name + ' (' + Math.max(1, Math.round(f.size / 1024)) + ' KB)';
      btn.type = 'button'; btn.className = 'lnk r'; btn.textContent = 'Remove';
      btn.setAttribute('aria-label', 'Remove ' + f.name);
      btn.addEventListener('click', function () { files.splice(i, 1); sync(); });
      row.append(label, btn); list.append(row);
    });
  }
  input.addEventListener('change', function () { addFiles(input.files); });
  ['dragenter', 'dragover'].forEach(function (ev) { zone.addEventListener(ev, function (e) { e.preventDefault(); zone.classList.add('over'); }); });
  ['dragleave', 'drop'].forEach(function (ev) { zone.addEventListener(ev, function (e) { e.preventDefault(); zone.classList.remove('over'); }); });
  zone.addEventListener('drop', function (e) { addFiles(e.dataTransfer.files); });

  /* If the server rejected the form, jump to the first step with an error. */
  var bad = form.querySelector('.field-error[id^="err-"]');
  if (bad) {
    var sec = bad.closest('.step');
    show(steps.indexOf(sec) + 1);
    window.showToast('Please fix the highlighted fields.', 'error');
  }
})();
