/* Shared behaviour: menu toggle and toast notifications. */
(function () {
  'use strict';
  function showToast(message, type) {
    var box = document.getElementById('toasts');
    if (!box) { return; }
    var t = document.createElement('div');
    t.className = 'toast ' + (type || 'info');
    t.setAttribute('role', type === 'error' ? 'alert' : 'status');
    var p = document.createElement('span');
    p.textContent = message;                      // textContent: never innerHTML
    var close = document.createElement('button');
    close.type = 'button'; close.textContent = '×'; close.setAttribute('aria-label', 'Dismiss message');
    close.addEventListener('click', function () { t.remove(); });
    t.append(p, close);
    box.append(t);
    if (type !== 'error') { setTimeout(function () { t.remove(); }, 6000); }   // errors stay until closed
  }
  window.showToast = showToast;

  document.querySelectorAll('[data-toggle]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var target = document.querySelector(btn.getAttribute('data-toggle'));
      var open = target.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  });

  var flashes = document.querySelector('[data-flashes]');   // turn server messages into toasts
  if (flashes) {
    flashes.querySelectorAll('.flash').forEach(function (f) {
      showToast(f.textContent, f.classList.contains('error') ? 'error' : f.classList.contains('success') ? 'success' : 'info');
    });
    flashes.remove();
  }
})();
