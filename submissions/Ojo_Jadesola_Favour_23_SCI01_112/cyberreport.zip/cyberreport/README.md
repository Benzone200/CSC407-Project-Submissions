# CyberReport: cyber incident reporting system

Flask + SQLite web application for reporting, tracking and managing cyber incidents.
Built for the semester project *Building Web Applications: Web Application Security, Testing, Deployment and Review*.

**Stack:** HTML, CSS, JavaScript, Python (Flask, no Django) and SQL (SQLite).

## 1. Run it locally

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python seed.py --admin-email you@example.com --demo   # creates the admin (asks for a password) and sample reports
python app.py                                         # http://127.0.0.1:5000
```

Run the automated tests: `python -m unittest discover -s tests -v`

## 2. Pages

| Area | Pages |
|---|---|
| Public | Home, Report (4 steps), Report submitted, Track a report, Security, Register, Log in |
| Logged-in user | Profile (own reports, change password) |
| Staff (analyst, admin) | Dashboard, All cases, My cases, Case detail (update, notes, evidence), Analytics |
| Admin only | Audit log, Users and roles |

Reporting needs no account. Anonymous reports store no name, email, phone or user id.

## 3. Folder structure

```
app.py            routes, security helpers, app factory
schema.sql        tables (users, incidents, evidence, case_notes, status_history, audit_logs)
seed.py           first admin account and demo data
templates/        Jinja templates (base_public, base_admin, admin/)
static/css/       style.css (shared) and admin.css (staff only)
static/js/        app.js (menu, toasts), report.js (steps, file picker)
tests/            automated tests
```

## 4. Security measures (project section 2)

| Requirement | Where it is done |
|---|---|
| Authentication, login/logout | `login`, `logout` in app.py; new session on login |
| Password hashing | Werkzeug `generate_password_hash` (scrypt), never stored in plain text |
| Password policy, lockout | `password_problem()`; 5 failed logins lock the account 15 minutes |
| Role-based access | `roles_required`, `staff_required`, `admin_required` decorators on every protected route |
| Input validation | server-side checks in every route (type, length, format, allowed values) |
| SQL injection | all queries use `?` placeholders; filter SQL is built from fixed fragments only |
| XSS | Jinja auto-escaping, `textContent` in JavaScript, CSP without inline scripts or styles |
| CSRF | session token checked on every POST in `before_request` |
| Session management | HttpOnly, SameSite=Lax, Secure (production), 30 minute idle timeout |
| Access-control checks | staff routes return 403 for the wrong role; evidence downloads need staff login |
| Sensitive information | uploads stored outside static/, random names, SHA-256 recorded, attachment-only download |
| Rate limiting | login, register, track and report routes (in-memory; see limitations) |
| Audit logging | `log_action()` records logins, failures, views, changes, downloads |
| Security headers | CSP, nosniff, X-Frame-Options, Referrer-Policy, HSTS in production |

## 5. Testing (project section 3)

34 automated tests in `tests/test_app.py` (functional, validation, access control, security). Result of the last run: **34 passed, 0 failed**. Re-run them yourself and add manual tests (mobile devices, screen reader, real browsers) before submitting.

| Test | Expected result | Actual result | Status |
|---|---|---|---|
| Valid report submitted | Redirect, tracking ID like INC-2026-7K3QX9 | As expected | Pass |
| Track with a valid ID | Status page shown | As expected | Pass |
| Track with an unknown ID | "could not find" message | As expected | Pass |
| Register with weak password | Validation message | As expected | Pass |
| Register with a duplicate email | Validation message | As expected | Pass |
| Login with wrong password / unknown user | Same generic error | As expected | Pass |
| Five wrong passwords | Account locked | As expected | Pass |
| Empty or invalid report fields | 400 and nothing saved | As expected | Pass |
| Upload .exe, fake PNG, 10 MB+ file | Rejected | As expected | Pass |
| POST without CSRF token | 400 | As expected | Pass |
| Anonymous visitor opens /admin | Redirect to login | As expected | Pass |
| Normal user opens staff pages | 403 | As expected | Pass |
| Analyst opens users and audit pages | 403 | As expected | Pass |
| SQL injection strings in track, login, search | No error, no data leaked, tables intact | As expected | Pass |
| `<script>` in description and notes | Shown as escaped text | As expected | Pass |
| Login rate limit | 429 after 20 attempts | As expected | Pass |
| Missing SECRET_KEY in production | App refuses to start | As expected | Pass |

Manual checks still to do and record: responsive layout on a phone, keyboard-only use of the report form, usability test with a few people, load behaviour.

## 6. Deployment (project section 4)

1. **Server:** Linux VM, Python 3.10+, Nginx. Copy the project to `/srv/cyberreport`, create a venv and `pip install -r requirements.txt`.
2. **Environment variables** (see `.env.example`): `APP_ENV=production`, `SECRET_KEY`, `DATABASE_PATH`, `UPLOAD_DIR`, `TRUST_PROXY=1`. Keep the file outside the repository with `chmod 600`.
3. **Database:** `python seed.py --admin-email you@example.com` once, with the variables set.
4. **App server:** Gunicorn behind Nginx, managed by systemd.

```ini
# /etc/systemd/system/cyberreport.service
[Service]
User=cyberreport
WorkingDirectory=/srv/cyberreport
EnvironmentFile=/etc/cyberreport.env
ExecStart=/srv/cyberreport/.venv/bin/gunicorn -w 3 -b 127.0.0.1:8000 "app:create_app()"
Restart=always
[Install]
WantedBy=multi-user.target
```

```nginx
server {
  listen 443 ssl;
  server_name reports.example.com;
  client_max_body_size 25m;
  location / { proxy_pass http://127.0.0.1:8000;
    proxy_set_header Host $host; proxy_set_header X-Forwarded-For $remote_addr;
    proxy_set_header X-Forwarded-Proto $scheme; }
}
server { listen 80; server_name reports.example.com; return 301 https://$host$request_uri; }
```

5. **HTTPS:** get a free certificate with Certbot (`certbot --nginx -d reports.example.com`).
6. **Backups:** daily `sqlite3 /var/lib/cyberreport/cyberreport.db ".backup '/backups/db-$(date +%F).db'"` and copy the uploads folder, stored off the server.
7. **Monitoring:** application errors go to `logs/app.log` (rotated); use `journalctl -u cyberreport` for server output; review the in-app audit log for failed logins.
8. **Updating:** pull the new code, `pip install -r requirements.txt`, `systemctl restart cyberreport`, then run the tests on a copy first.

## 7. Review and evaluation (project section 5)

**What it does:** lets anyone report a cyber incident (anonymously if they wish), follow its progress with a tracking ID, and lets staff triage, assign, annotate and resolve cases with an audit trail.

**Limitations:** SQLite handles one writer at a time (use PostgreSQL or MySQL for heavy use); rate limiting is per process and resets on restart; uploads are checked by type and signature but not scanned for malware (add ClamAV); no email notifications; no two-way messaging with reporters; no two-step login for staff; no password reset by email; staff accounts are created by an admin.

**Future improvements:** malware scanning, email or SMS updates, two-step login, password reset, case merging for related reports, CSV export, multiple languages.

**To write yourself after testing:** performance observations and problems you encountered, with your own measurements and screenshots.
