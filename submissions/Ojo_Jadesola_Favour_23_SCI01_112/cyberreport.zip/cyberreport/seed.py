"""Create the first admin account (and optional demo data).

Usage:
    python seed.py --admin-email you@example.com            # asks for a password
    python seed.py --admin-email you@example.com --demo     # also adds sample reports
"""
import argparse
import getpass
import secrets

from werkzeug.security import generate_password_hash

from app import (create_app, execute_db, new_tracking_id, password_problem, query_db,
                 score_severity)

DEMO = [("Phishing or scam", "High", "I clicked a link in an email pretending to be my bank and entered my login details."),
        ("Ransomware or malware", "Critical", "Files on our office computer were encrypted and a ransom note appeared."),
        ("Account takeover", "High", "My email account sent messages I did not write and my password no longer works."),
        ("Online fraud", "Medium", "I paid for goods on a fake shop and the seller disappeared."),
        ("Harassment or impersonation", "Low", "Someone created a fake profile using my name and photos.")]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--admin-email", required=True)
    ap.add_argument("--admin-name", default="Administrator")
    ap.add_argument("--demo", action="store_true")
    args = ap.parse_args()
    app = create_app()
    with app.app_context():
        email = args.admin_email.strip().lower()
        if query_db("SELECT 1 FROM users WHERE email=?", (email,), one=True):
            print("That admin already exists.")
        else:
            pw = getpass.getpass("Admin password: ")
            problem = password_problem(pw)
            if problem or pw != getpass.getpass("Repeat password: "):
                raise SystemExit(problem or "Passwords do not match.")
            execute_db("INSERT INTO users (full_name, email, password_hash, role) VALUES (?,?,?,'admin')",
                       (args.admin_name, email, generate_password_hash(pw)))
            print("Admin created.")
        if args.demo:
            demo_pw = secrets.token_urlsafe(12) + "Aa1"
            if not query_db("SELECT 1 FROM users WHERE email='analyst@example.com'", one=True):
                execute_db("INSERT INTO users (full_name, email, password_hash, role) VALUES (?,?,?,'analyst')",
                           ("Demo Analyst", "analyst@example.com", generate_password_hash(demo_pw)))
                print(f"Demo analyst: analyst@example.com / {demo_pw}  (shown once, local use only)")
            for itype, impact, text in DEMO:
                inc = execute_db(
                    "INSERT INTO incidents (tracking_id, incident_type, description, date_occurred, impact, severity,"
                    " is_anonymous) VALUES (?,?,?,datetime('now','-2 days'),?,?,1)",
                    (new_tracking_id(), itype, text, impact, score_severity(itype, impact)))
                execute_db("INSERT INTO status_history (incident_id, new_status) VALUES (?, 'New')", (inc,))
            print(f"Added {len(DEMO)} demo reports.")


if __name__ == "__main__":
    main()
