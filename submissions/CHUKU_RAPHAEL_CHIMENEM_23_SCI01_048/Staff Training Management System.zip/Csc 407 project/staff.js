const staffNameInput = document.querySelector("#staff-name");
const departmentSelect = document.querySelector("#staff-department");
const addStaffButton = document.querySelector("#add-staff");
const staffTable = document.querySelector(".table");
const staffMessage = document.querySelector("#staff-message");

function addRemoveButton(row) {
  const name = row.cells[0].textContent.trim();
  const actionCell = row.cells[3];
  const button = document.createElement("button");

  button.type = "button";
  button.className = "remove-staff";
  button.textContent = "Remove";
  button.setAttribute("aria-label", `Remove ${name}`);
  actionCell.appendChild(button);
}

staffTable.querySelectorAll("tr").forEach(addRemoveButton);

addStaffButton.addEventListener("click", () => {
  const name = staffNameInput.value.trim();
  if (!name) {
    staffMessage.textContent = "Enter a staff member's name to add them.";
    staffNameInput.focus();
    return;
  }

  const row = staffTable.insertRow();
  row.insertCell().textContent = name;
  row.insertCell().textContent = departmentSelect.value;

  const completionCell = row.insertCell();
  completionCell.append("0%");
  const progress = document.createElement("div");
  progress.className = "progress col-12";
  progress.setAttribute("role", "progressbar");
  progress.setAttribute("aria-label", `${name} training completion`);
  progress.setAttribute("aria-valuemin", "0");
  progress.setAttribute("aria-valuemax", "100");
  progress.setAttribute("aria-valuenow", "0");
  const progressFill = document.createElement("div");
  progressFill.className = "show";
  progress.appendChild(progressFill);
  completionCell.appendChild(progress);

  row.insertCell();
  addRemoveButton(row);
  staffNameInput.value = "";
  staffMessage.textContent = `${name} added to ${departmentSelect.value}.`;
  staffNameInput.focus();
});

staffTable.addEventListener("click", (event) => {
  const button = event.target.closest(".remove-staff");
  if (!button) return;

  const row = button.closest("tr");
  const name = row.cells[0].textContent.trim();
  if (!window.confirm(`Remove ${name} from the staff list?`)) return;

  row.remove();
  staffMessage.textContent = `${name} removed from the staff list.`;
});
