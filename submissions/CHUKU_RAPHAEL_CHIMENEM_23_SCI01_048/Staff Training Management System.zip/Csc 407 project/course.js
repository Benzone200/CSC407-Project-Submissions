const categoryFilter = document.querySelector("#course-category");
const courseSearch = document.querySelector("#course-search");
const courses = Array.from(document.querySelectorAll(".course"));
const courseRows = Array.from(document.querySelectorAll(".course-content"));
const courseCount = document.querySelector("#course-count");
const noCourses = document.querySelector("#no-courses");

function filterCourses() {
  const category = categoryFilter.value.toLowerCase();
  const searchTerm = courseSearch.value.trim().toLowerCase();
  let visibleCount = 0;

  courses.forEach((course) => {
    const matchesCategory =
      category === "all" || course.dataset.category.toLowerCase() === category;
    const matchesSearch = course.querySelector("h4").textContent
      .toLowerCase()
      .includes(searchTerm);
    const isVisible = matchesCategory && matchesSearch;

    course.hidden = !isVisible;
    if (isVisible) visibleCount += 1;
  });

  courseRows.forEach((row) => {
    row.hidden = !row.querySelector(".course:not([hidden])");
  });

  courseCount.textContent = `${visibleCount} ${visibleCount === 1 ? "course" : "courses"}`;
  noCourses.hidden = visibleCount > 0;
}

categoryFilter.addEventListener("change", filterCourses);
courseSearch.addEventListener("input", filterCourses);

courses.forEach((course) => {
  const button = course.querySelector("button");
  button.addEventListener("click", () => {
    const isEnrolled = button.getAttribute("aria-pressed") === "true";
    button.setAttribute("aria-pressed", String(!isEnrolled));
    button.textContent = isEnrolled ? "Enroll" : "Enrolled";
  });
});

filterCourses();
