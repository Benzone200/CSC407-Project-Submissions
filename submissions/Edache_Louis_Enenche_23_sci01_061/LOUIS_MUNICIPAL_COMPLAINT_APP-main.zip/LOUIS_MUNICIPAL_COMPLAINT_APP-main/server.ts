import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import {
  getActiveDbPath,
  getDb,
  mapAuditRow,
  mapComplaintRow,
  mapUserRow,
  recordAuditEvent,
} from './src/server/db.ts';
import {
  clearSessionCookie,
  generateSessionToken,
  getSessionCookieFromRequest,
  getSessionExpiryIso,
  hashPassword,
  hashSessionToken,
  securityHeadersMiddleware,
  setSessionCookie,
  verifyPassword,
} from './src/server/security.ts';
import {
  analyzeSqlInjectionRisk,
  canAccessAdminResources,
  escapeHtml,
  neutralizeXss,
  sanitizeText,
  validateAdminStatusUpdate,
  validateComplaint,
  validateLogin,
  validateProfileUpdate,
  validateRegistration,
} from './src/shared/validation.ts';
import type {
  HealthReport,
  LiveTestCheckResult,
  PublicUser,
  SecurityHeaderReport,
  SecurityLabSqlResult,
} from './src/shared/types.ts';

interface AuthenticatedRequest extends Request {
  currentUser?: PublicUser;
  sessionTokenHash?: string;
}

const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';

function attachCurrentUser(req: AuthenticatedRequest, _res: Response, next: NextFunction): void {
  try {
    const rawToken = getSessionCookieFromRequest(req);
    if (!rawToken) {
      next();
      return;
    }

    const tokenHash = hashSessionToken(rawToken);
    const db = getDb();
    const row = db
      .prepare(
        `SELECT u.id, u.full_name, u.email, u.role, u.ward, u.phone, u.avatar_url, u.created_at, s.expires_at
         FROM sessions s
         JOIN users u ON u.id = s.user_id
         WHERE s.token_hash = ?`,
      )
      .get(tokenHash) as Record<string, unknown> | undefined;

    if (!row) {
      next();
      return;
    }

    if (new Date(String(row.expires_at)).getTime() <= Date.now()) {
      db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash);
      next();
      return;
    }

    req.currentUser = mapUserRow(row);
    req.sessionTokenHash = tokenHash;
    next();
  } catch (err) {
    next(err);
  }
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.currentUser) {
    res.status(401).json({
      error: 'Authentication required. Please sign in to perform this action.',
    });
    return;
  }
  next();
}

function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  if (!req.currentUser) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  if (req.currentUser.role !== 'admin') {
    recordAuditEvent({
      eventType: 'RBAC_ENFORCEMENT',
      actorEmail: req.currentUser.email,
      actorRole: req.currentUser.role,
      targetResource: `${req.method} ${req.path}`,
      outcome: 'DENIED',
      detail: 'Non-admin user attempted to access an administrator-only endpoint.',
    });
    res.status(403).json({
      error: 'Access denied. Administrator role is required for this resource.',
    });
    return;
  }
  next();
}

async function startServer(): Promise<void> {
  // Initialize SQLite schema & deterministic municipal seed data on boot
  getDb();

  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1);

  app.use(securityHeadersMiddleware(IS_PROD));
  app.use(express.json({ limit: '64kb' }));
  app.use(attachCurrentUser);

  // Health check with live SQLite & runtime telemetry
  app.get('/api/health', (_req, res) => {
    const db = getDb();
    const journalRow = db.prepare('PRAGMA journal_mode').get() as { journal_mode: string };
    const fkRow = db.prepare('PRAGMA foreign_keys').get() as { foreign_keys: number };
    const complaintsRow = db
      .prepare(
        "SELECT COUNT(*) AS total, SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) AS resolved FROM complaints",
      )
      .get() as { total: number; resolved: number | null };
    const usersRow = db.prepare('SELECT COUNT(*) AS count FROM users').get() as { count: number };
    const sessionsRow = db
      .prepare('SELECT COUNT(*) AS count FROM sessions WHERE expires_at > ?')
      .get(new Date().toISOString()) as { count: number };
    const auditsRow = db.prepare('SELECT COUNT(*) AS count FROM audit_logs').get() as {
      count: number;
    };

    let dbSizeBytes = 0;
    try {
      dbSizeBytes = fs.statSync(getActiveDbPath()).size;
    } catch {
      dbSizeBytes = 0;
    }

    const report: HealthReport = {
      status: 'ok',
      database: 'sqlite-wal',
      walEnabled: String(journalRow.journal_mode).toLowerCase() === 'wal',
      foreignKeysEnabled: Number(fkRow.foreign_keys) === 1,
      dbSizeBytes,
      complaintCount: Number(complaintsRow.total ?? 0),
      resolvedCount: Number(complaintsRow.resolved ?? 0),
      userCount: Number(usersRow.count ?? 0),
      activeSessionCount: Number(sessionsRow.count ?? 0),
      auditLogCount: Number(auditsRow.count ?? 0),
      environment: IS_PROD ? 'production' : 'development',
      nodeVersion: process.version,
      uptimeSeconds: Math.round(process.uptime()),
      timestamp: new Date().toISOString(),
    };

    res.json(report);
  });

  // Auth: Register
  app.post('/api/auth/register', (req: AuthenticatedRequest, res) => {
    const validation = validateRegistration(req.body ?? {});
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: 'Validation failed.', fieldErrors: validation.errors });
      return;
    }

    const db = getDb();
    const existing = db
      .prepare('SELECT id FROM users WHERE email = ?')
      .get(validation.data.email) as { id: number } | undefined;
    if (existing) {
      res.status(409).json({
        error: 'An account with this email already exists.',
        fieldErrors: { email: 'Email is already registered.' },
      });
      return;
    }

    const passwordHash = hashPassword(validation.data.password);
    const nowIso = new Date().toISOString();
    const result = db
      .prepare(
        `INSERT INTO users (full_name, email, password_hash, role, ward, phone, avatar_url, created_at)
         VALUES (?, ?, ?, 'resident', ?, ?, ?, ?)`,
      )
      .run(
        validation.data.fullName,
        validation.data.email,
        passwordHash,
        validation.data.ward,
        validation.data.phone ?? '',
        '/src/assets/images/avatar_citizen_1794860881512.jpg',
        nowIso,
      );

    const newUserId = Number(result.lastInsertRowid);
    const userRow = db
      .prepare(
        'SELECT id, full_name, email, role, ward, phone, avatar_url, created_at FROM users WHERE id = ?',
      )
      .get(newUserId) as Record<string, unknown>;

    const rawToken = generateSessionToken();
    const tokenHash = hashSessionToken(rawToken);
    const expiresAt = getSessionExpiryIso();
    const userAgent = sanitizeText(req.headers['user-agent'] ?? 'Unknown Client', 140);

    db.prepare(
      'INSERT INTO sessions (token_hash, user_id, user_agent, created_at, expires_at) VALUES (?, ?, ?, ?, ?)',
    ).run(tokenHash, newUserId, userAgent, nowIso, expiresAt);

    setSessionCookie(req, res, rawToken);
    recordAuditEvent({
      eventType: 'USER_REGISTER',
      actorEmail: validation.data.email,
      actorRole: 'resident',
      targetResource: `user:${newUserId}`,
      outcome: 'SUCCESS',
      detail: 'Registered new citizen account with scrypt password hash and HttpOnly session.',
    });

    res.status(201).json({ user: mapUserRow(userRow) });
  });

  // Auth: Login
  app.post('/api/auth/login', (req: AuthenticatedRequest, res) => {
    const validation = validateLogin(req.body ?? {});
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: 'Invalid login format.', fieldErrors: validation.errors });
      return;
    }

    const db = getDb();
    const row = db
      .prepare(
        'SELECT id, full_name, email, password_hash, role, ward, phone, avatar_url, created_at FROM users WHERE email = ?',
      )
      .get(validation.data.email) as Record<string, unknown> | undefined;

    if (!row || !verifyPassword(validation.data.password, String(row.password_hash))) {
      recordAuditEvent({
        eventType: 'LOGIN_FAILED',
        actorEmail: validation.data.email,
        actorRole: 'anonymous',
        targetResource: 'POST /api/auth/login',
        outcome: 'DENIED',
        detail: 'Rejected login due to invalid credentials (scrypt verification failed).',
      });
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const rawToken = generateSessionToken();
    const tokenHash = hashSessionToken(rawToken);
    const nowIso = new Date().toISOString();
    const expiresAt = getSessionExpiryIso();
    const userAgent = sanitizeText(req.headers['user-agent'] ?? 'Unknown Client', 140);

    db.prepare(
      'INSERT INTO sessions (token_hash, user_id, user_agent, created_at, expires_at) VALUES (?, ?, ?, ?, ?)',
    ).run(tokenHash, Number(row.id), userAgent, nowIso, expiresAt);

    setSessionCookie(req, res, rawToken);
    recordAuditEvent({
      eventType: 'USER_LOGIN',
      actorEmail: String(row.email),
      actorRole: String(row.role),
      targetResource: `user:${row.id}`,
      outcome: 'SUCCESS',
      detail: 'Authenticated user via scrypt and issued signed HttpOnly session cookie.',
    });

    res.json({ user: mapUserRow(row) });
  });

  // Auth: Logout
  app.post('/api/auth/logout', (req: AuthenticatedRequest, res) => {
    if (req.sessionTokenHash) {
      const db = getDb();
      db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(req.sessionTokenHash);
      if (req.currentUser) {
        recordAuditEvent({
          eventType: 'USER_LOGOUT',
          actorEmail: req.currentUser.email,
          actorRole: req.currentUser.role,
          targetResource: `user:${req.currentUser.id}`,
          outcome: 'SUCCESS',
          detail: 'Revoked server-side session token and cleared HttpOnly cookie.',
        });
      }
    }
    clearSessionCookie(req, res);
    res.json({ ok: true });
  });

  // Auth: Current session + user
  app.get('/api/auth/me', (req: AuthenticatedRequest, res) => {
    if (!req.currentUser || !req.sessionTokenHash) {
      res.json({ user: null, session: null });
      return;
    }

    const db = getDb();
    const sessionRow = db
      .prepare('SELECT token_hash, user_agent, created_at, expires_at FROM sessions WHERE token_hash = ?')
      .get(req.sessionTokenHash) as Record<string, unknown> | undefined;

    res.json({
      user: req.currentUser,
      session: sessionRow
        ? {
            sessionIdMasked: `${String(sessionRow.token_hash).slice(0, 10)}...${String(sessionRow.token_hash).slice(-6)}`,
            createdAt: String(sessionRow.created_at),
            expiresAt: String(sessionRow.expires_at),
            userAgent: String(sessionRow.user_agent),
          }
        : null,
    });
  });

  // Profile update
  app.patch('/api/profile', requireAuth, (req: AuthenticatedRequest, res) => {
    const validation = validateProfileUpdate(req.body ?? {});
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: 'Profile validation failed.', fieldErrors: validation.errors });
      return;
    }

    const db = getDb();
    db.prepare('UPDATE users SET full_name = ?, ward = ?, phone = ? WHERE id = ?').run(
      validation.data.fullName,
      validation.data.ward,
      validation.data.phone,
      req.currentUser!.id,
    );

    const updated = db
      .prepare(
        'SELECT id, full_name, email, role, ward, phone, avatar_url, created_at FROM users WHERE id = ?',
      )
      .get(req.currentUser!.id) as Record<string, unknown>;

    recordAuditEvent({
      eventType: 'PROFILE_UPDATE',
      actorEmail: req.currentUser!.email,
      actorRole: req.currentUser!.role,
      targetResource: `user:${req.currentUser!.id}`,
      outcome: 'SUCCESS',
      detail: 'Updated user profile details using parameterized SQL UPDATE.',
    });

    res.json({ user: mapUserRow(updated) });
  });

  // Password change
  app.post('/api/profile/password', requireAuth, (req: AuthenticatedRequest, res) => {
    const currentPassword = typeof req.body?.currentPassword === 'string' ? req.body.currentPassword : '';
    const newPassword = typeof req.body?.newPassword === 'string' ? req.body.newPassword : '';

    if (!currentPassword) {
      res.status(400).json({ error: 'Current password is required.' });
      return;
    }
    if (newPassword.length < 8 || !/[A-Z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
      res.status(400).json({
        error: 'New password must be at least 8 characters with an uppercase letter and a number.',
      });
      return;
    }

    const db = getDb();
    const userRow = db
      .prepare('SELECT password_hash FROM users WHERE id = ?')
      .get(req.currentUser!.id) as { password_hash: string } | undefined;

    if (!userRow || !verifyPassword(currentPassword, userRow.password_hash)) {
      res.status(401).json({ error: 'Current password is incorrect.' });
      return;
    }

    const nextHash = hashPassword(newPassword);
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(nextHash, req.currentUser!.id);

    recordAuditEvent({
      eventType: 'PASSWORD_CHANGE',
      actorEmail: req.currentUser!.email,
      actorRole: req.currentUser!.role,
      targetResource: `user:${req.currentUser!.id}`,
      outcome: 'SUCCESS',
      detail: 'Rotated user password hash with fresh 16-byte random salt.',
    });

    res.json({ ok: true });
  });

  // List & search complaints (parameterized queries)
  app.get('/api/complaints', (req, res) => {
    const db = getDb();
    const q = sanitizeText(req.query.q ?? '', 100);
    const status = sanitizeText(req.query.status ?? '', 30);
    const category = sanitizeText(req.query.category ?? '', 60);
    const priority = sanitizeText(req.query.priority ?? '', 30);
    const mine = req.query.mine === 'true';

    const clauses: string[] = [];
    const params: Array<string | number> = [];

    if (q) {
      const like = `%${q}%`;
      clauses.push(
        '(c.title LIKE ? OR c.reference_code LIKE ? OR c.address LIKE ? OR c.ward LIKE ? OR c.description LIKE ?)',
      );
      params.push(like, like, like, like, like);
    }
    if (status && status !== 'All') {
      clauses.push('c.status = ?');
      params.push(status);
    }
    if (category && category !== 'All') {
      clauses.push('c.category = ?');
      params.push(category);
    }
    if (priority && priority !== 'All') {
      clauses.push('c.priority = ?');
      params.push(priority);
    }

    const authReq = req as AuthenticatedRequest;
    if (mine) {
      if (!authReq.currentUser) {
        res.status(401).json({ error: 'Sign in to view your submitted complaints.' });
        return;
      }
      clauses.push('c.reporter_id = ?');
      params.push(authReq.currentUser.id);
    }

    const whereSql = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';
    const sql = `
      SELECT c.*, u.full_name AS reporter_name
      FROM complaints c
      JOIN users u ON u.id = c.reporter_id
      ${whereSql}
      ORDER BY c.id DESC
    `;

    const rows = db.prepare(sql).all(...params) as Array<Record<string, unknown>>;
    res.json({ complaints: rows.map(mapComplaintRow) });
  });

  // Create complaint (authenticated users)
  app.post('/api/complaints', requireAuth, (req: AuthenticatedRequest, res) => {
    const validation = validateComplaint(req.body ?? {});
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: 'Complaint validation failed.', fieldErrors: validation.errors });
      return;
    }

    const db = getDb();
    const nowIso = new Date().toISOString();
    const maxIdRow = db.prepare('SELECT COALESCE(MAX(id), 0) AS maxId FROM complaints').get() as {
      maxId: number;
    };
    const nextSeq = 1036 + Number(maxIdRow.maxId) + 1;
    const referenceCode = `CL-2026-${nextSeq}`;

    const deptByCategory: Record<string, string> = {
      'Roads & Potholes': 'Roads & Civil Works',
      'Street Lighting': 'Electrical Maintenance Unit',
      'Water & Drainage': 'Stormwater & Water Utility',
      'Waste & Sanitation': 'Municipal Sanitation Fleet',
      'Public Safety': 'Traffic & Civic Safety Ops',
      'Parks & Trees': 'Urban Forestry & Parks',
    };

    const assignedDept = deptByCategory[validation.data.category] ?? 'Central Triage Desk';

    const insertResult = db
      .prepare(
        `INSERT INTO complaints (
          reference_code, title, category, priority, status, ward, address,
          description, reporter_id, assigned_department, resolution_notes, created_at, updated_at
        ) VALUES (?, ?, ?, ?, 'Open', ?, ?, ?, ?, ?, '', ?, ?)`,
      )
      .run(
        referenceCode,
        validation.data.title,
        validation.data.category,
        validation.data.priority,
        validation.data.ward,
        validation.data.address,
        validation.data.description,
        req.currentUser!.id,
        assignedDept,
        nowIso,
        nowIso,
      );

    const created = db
      .prepare(
        `SELECT c.*, u.full_name AS reporter_name
         FROM complaints c
         JOIN users u ON u.id = c.reporter_id
         WHERE c.id = ?`,
      )
      .get(Number(insertResult.lastInsertRowid)) as Record<string, unknown>;

    recordAuditEvent({
      eventType: 'COMPLAINT_CREATED',
      actorEmail: req.currentUser!.email,
      actorRole: req.currentUser!.role,
      targetResource: `complaint:${referenceCode}`,
      outcome: 'SUCCESS',
      detail: `Submitted complaint in ${validation.data.ward} (${validation.data.priority} priority).`,
    });

    res.status(201).json({ complaint: mapComplaintRow(created) });
  });

  // Admin-only: Update complaint status & triage notes
  app.patch('/api/complaints/:id', requireAdmin, (req: AuthenticatedRequest, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      res.status(400).json({ error: 'Invalid complaint identifier.' });
      return;
    }

    const validation = validateAdminStatusUpdate(req.body ?? {});
    if (!validation.ok || !validation.data) {
      res.status(400).json({ error: 'Invalid triage update.', fieldErrors: validation.errors });
      return;
    }

    const db = getDb();
    const existing = db
      .prepare('SELECT id, reference_code FROM complaints WHERE id = ?')
      .get(id) as { id: number; reference_code: string } | undefined;

    if (!existing) {
      res.status(404).json({ error: 'Complaint record not found.' });
      return;
    }

    db.prepare(
      `UPDATE complaints
       SET status = ?, assigned_department = ?, resolution_notes = ?, updated_at = ?
       WHERE id = ?`,
    ).run(
      validation.data.status,
      validation.data.assignedDepartment,
      validation.data.resolutionNotes,
      new Date().toISOString(),
      id,
    );

    const updated = db
      .prepare(
        `SELECT c.*, u.full_name AS reporter_name
         FROM complaints c
         JOIN users u ON u.id = c.reporter_id
         WHERE c.id = ?`,
      )
      .get(id) as Record<string, unknown>;

    recordAuditEvent({
      eventType: 'COMPLAINT_TRIAGE',
      actorEmail: req.currentUser!.email,
      actorRole: req.currentUser!.role,
      targetResource: `complaint:${existing.reference_code}`,
      outcome: 'SUCCESS',
      detail: `Admin set status to ${validation.data.status} (${validation.data.assignedDepartment}).`,
    });

    res.json({ complaint: mapComplaintRow(updated) });
  });

  // Admin-only: Delete complaint
  app.delete('/api/complaints/:id', requireAdmin, (req: AuthenticatedRequest, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      res.status(400).json({ error: 'Invalid complaint identifier.' });
      return;
    }

    const db = getDb();
    const existing = db
      .prepare('SELECT id, reference_code FROM complaints WHERE id = ?')
      .get(id) as { id: number; reference_code: string } | undefined;

    if (!existing) {
      res.status(404).json({ error: 'Complaint not found.' });
      return;
    }

    db.prepare('DELETE FROM complaints WHERE id = ?').run(id);
    recordAuditEvent({
      eventType: 'COMPLAINT_DELETED',
      actorEmail: req.currentUser!.email,
      actorRole: req.currentUser!.role,
      targetResource: `complaint:${existing.reference_code}`,
      outcome: 'SUCCESS',
      detail: 'Administrator removed duplicate/invalid complaint record.',
    });

    res.json({ ok: true });
  });

  // Admin-only: Audit trail & user directory
  app.get('/api/admin/audit', requireAdmin, (_req: AuthenticatedRequest, res) => {
    const db = getDb();
    const logs = db
      .prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 40')
      .all() as Array<Record<string, unknown>>;
    const users = db
      .prepare('SELECT id, full_name, email, role, ward, phone, avatar_url, created_at FROM users ORDER BY id ASC')
      .all() as Array<Record<string, unknown>>;

    res.json({
      logs: logs.map(mapAuditRow),
      users: users.map(mapUserRow),
    });
  });

  // Admin-only: Real SQLite WAL checkpoint & JSON snapshot backup export
  app.get('/api/admin/backup', requireAdmin, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    db.exec('PRAGMA wal_checkpoint(PASSIVE);');

    const complaints = (
      db
        .prepare(
          `SELECT c.*, u.full_name AS reporter_name
           FROM complaints c
           JOIN users u ON u.id = c.reporter_id
           ORDER BY c.id ASC`,
        )
        .all() as Array<Record<string, unknown>>
    ).map(mapComplaintRow);

    const users = (
      db
        .prepare(
          'SELECT id, full_name, email, role, ward, phone, avatar_url, created_at FROM users ORDER BY id ASC',
        )
        .all() as Array<Record<string, unknown>>
    ).map(mapUserRow);

    const auditLogs = (
      db.prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 100').all() as Array<
        Record<string, unknown>
      >
    ).map(mapAuditRow);

    recordAuditEvent({
      eventType: 'BACKUP_EXPORT',
      actorEmail: req.currentUser!.email,
      actorRole: req.currentUser!.role,
      targetResource: 'GET /api/admin/backup',
      outcome: 'SUCCESS',
      detail: `Executed WAL checkpoint and exported ${complaints.length} complaints and ${users.length} sanitized user profiles.`,
    });

    const filename = `civicledger-backup-${new Date().toISOString().slice(0, 10)}.json`;
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(
      JSON.stringify(
        {
          exportedAt: new Date().toISOString(),
          exportedBy: req.currentUser!.email,
          engine: 'sqlite-wal',
          counts: {
            complaints: complaints.length,
            users: users.length,
            auditLogs: auditLogs.length,
          },
          complaints,
          users,
          auditLogs,
        },
        null,
        2,
      ),
    );
  });

  // Public operational audit summary (masked emails for Deployment log viewer)
  app.get('/api/operations/logs', (_req, res) => {
    const db = getDb();
    const rows = db
      .prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 15')
      .all() as Array<Record<string, unknown>>;

    const masked = rows.map((row) => {
      const entry = mapAuditRow(row);
      const [local, domain] = entry.actorEmail.split('@');
      const maskedEmail =
        local && domain ? `${local.slice(0, 2)}***@${domain}` : 'redacted';
      return {
        ...entry,
        actorEmail: maskedEmail,
      };
    });

    res.json({ logs: masked });
  });

  // Interactive Security Lab: SQL Injection Parameterization Probe
  app.post('/api/security/test-sqli', (req, res) => {
    const rawPayload = typeof req.body?.payload === 'string' ? req.body.payload.slice(0, 120) : '';
    const risk = analyzeSqlInjectionRisk(rawPayload);
    const db = getDb();

    // Execute REAL parameterized query against SQLite
    const rows = db
      .prepare('SELECT id, reference_code, title FROM complaints WHERE title LIKE ?')
      .all(`%${rawPayload}%`) as Array<{ id: number; reference_code: string; title: string }>;

    const result: SecurityLabSqlResult = {
      payload: rawPayload,
      vulnerableQueryPreview: `SELECT id, title FROM complaints WHERE title LIKE '%${rawPayload}%'`,
      parameterizedQueryPreview: 'SELECT id, reference_code, title FROM complaints WHERE title LIKE ?',
      boundParameter: `%${rawPayload}%`,
      matchedRowsInSafeQuery: rows.length,
      injectionNeutralized: true,
      explanation: risk.isLikelyInjectionAttempt
        ? `Detected ${risk.suspiciousTokens.join(', ')}. Because SQLite binds the entire payload as a single literal string parameter, SQL syntax tokens are never compiled or executed.`
        : 'Input treated strictly as a literal string parameter inside prepared statement binding.',
    };

    if (risk.isLikelyInjectionAttempt) {
      recordAuditEvent({
        eventType: 'SQLI_LAB_PROBE',
        actorEmail: (req as AuthenticatedRequest).currentUser?.email ?? 'lab-visitor@civicledger.gov',
        actorRole: (req as AuthenticatedRequest).currentUser?.role ?? 'visitor',
        targetResource: 'POST /api/security/test-sqli',
        outcome: 'BLOCKED',
        detail: `Parameterized statement neutralized payload containing: ${risk.suspiciousTokens.join(', ')}.`,
      });
    }

    res.json(result);
  });

  // Interactive Security Lab: XSS Neutralizer
  app.post('/api/security/test-xss', (req, res) => {
    const rawPayload = typeof req.body?.payload === 'string' ? req.body.payload.slice(0, 300) : '';
    const analysis = neutralizeXss(rawPayload);
    res.json({
      payload: rawPayload,
      ...analysis,
    });
  });

  // Security Headers Inspection
  app.get('/api/security/headers', (req, res) => {
    const report: SecurityHeaderReport = {
      headers: [
        {
          name: 'Content-Security-Policy',
          value: String(res.getHeader('Content-Security-Policy') ?? ''),
          purpose:
            'Restricts script, style, font, and frame-ancestors origins to prevent XSS and unauthorized framing.',
        },
        {
          name: 'X-Content-Type-Options',
          value: String(res.getHeader('X-Content-Type-Options') ?? ''),
          purpose: 'Prevents browsers from MIME-sniffing responses away from declared Content-Type.',
        },
        {
          name: 'Referrer-Policy',
          value: String(res.getHeader('Referrer-Policy') ?? ''),
          purpose: 'Limits referrer leakage across cross-origin requests.',
        },
        {
          name: 'Permissions-Policy',
          value: String(res.getHeader('Permissions-Policy') ?? ''),
          purpose: 'Explicitly disables unused browser hardware APIs (camera, microphone, geolocation).',
        },
      ],
      transportMode:
        req.secure || req.headers['x-forwarded-proto'] === 'https'
          ? 'HTTPS (TLS Terminated Proxy)'
          : 'HTTP Local Development (HTTPS + HSTS Enforced in Production)',
      cookiePolicy:
        'HttpOnly; Path=/; HMAC-SHA256 Signed; SameSite=None; Secure on HTTPS (SameSite=Lax on HTTP)',
      checkedAt: new Date().toISOString(),
    };

    res.json(report);
  });

  // Live Automated Verification Suite for the Testing Page (zero static/mock rows)
  app.post('/api/testing/run-live', async (_req, res) => {
    const results: LiveTestCheckResult[] = [];
    const db = getDb();

    // 1. FUNC-01: Functional Write & Read Roundtrip inside rolled-back SQLite SAVEPOINT
    const tFunc1 = performance.now();
    let funcWriteOk = false;
    let funcDetail = '';
    try {
      const reporter = db.prepare('SELECT id FROM users ORDER BY id ASC LIMIT 1').get() as
        | { id: number }
        | undefined;
      if (reporter) {
        const probeRef = `CL-PROBE-${Date.now()}`;
        const nowIso = new Date().toISOString();
        db.exec('SAVEPOINT live_func_probe;');
        db.prepare(
          `INSERT INTO complaints (
            reference_code, title, category, priority, status, ward, address,
            description, reporter_id, assigned_department, resolution_notes, created_at, updated_at
          ) VALUES (?, ?, 'Roads & Potholes', 'Medium', 'Open', 'Ward 1 — Central Business District', '10 Probe Ave',
            'Transactional verification check for complaint write and foreign key integrity.', ?, 'Roads & Civil Works', '', ?, ?)`,
        ).run(probeRef, 'Verification roundtrip check', reporter.id, nowIso, nowIso);
        const inserted = db
          .prepare('SELECT reference_code, status FROM complaints WHERE reference_code = ?')
          .get(probeRef) as { reference_code: string; status: string } | undefined;
        db.exec('ROLLBACK TO SAVEPOINT live_func_probe;');
        db.exec('RELEASE SAVEPOINT live_func_probe;');
        funcWriteOk = inserted?.reference_code === probeRef && inserted?.status === 'Open';
        funcDetail = funcWriteOk
          ? `SAVEPOINT insert+read verified (${probeRef}) and cleanly rolled back`
          : 'Roundtrip lookup failed';
      }
    } catch (err) {
      try {
        db.exec('ROLLBACK TO SAVEPOINT live_func_probe; RELEASE SAVEPOINT live_func_probe;');
      } catch {
        // Ignore cleanup errors
      }
      funcDetail = err instanceof Error ? err.message : 'Transaction check failed';
    }
    results.push({
      id: 'FUNC-01',
      category: 'Functional',
      name: 'Transactional complaint insert, FK check & registry readback',
      expectedResult: 'Complaint inserts with valid reporter_id FK, reads back, and rolls back cleanly',
      actualResult: funcDetail,
      status: funcWriteOk ? 'Pass' : 'Fail',
      durationMs: Math.max(1, Math.round(performance.now() - tFunc1)),
      automated: true,
    });

    // 2. FUNC-02: Parameterized Search & Status Filter Query
    const tFunc2 = performance.now();
    const searchRows = db
      .prepare('SELECT id, status FROM complaints WHERE (title LIKE ? OR ward LIKE ?) AND status != ?')
      .all('%Ward%', '%Ward%', 'NonExistentStatus') as Array<{ id: number; status: string }>;
    const statusOpenRows = db
      .prepare("SELECT COUNT(*) AS count FROM complaints WHERE status = 'Open'")
      .get() as { count: number };
    results.push({
      id: 'FUNC-02',
      category: 'Functional',
      name: 'Parameterized LIKE search & status filter query execution',
      expectedResult: 'Prepared LIKE + status filters execute cleanly against live SQLite index',
      actualResult: `WardMatches=${searchRows.length}, OpenTickets=${statusOpenRows.count}`,
      status: Array.isArray(searchRows) ? 'Pass' : 'Fail',
      durationMs: Math.max(1, Math.round(performance.now() - tFunc2)),
      automated: true,
    });

    // 3. AUTH-01: Salted scrypt Password Hashing & Verification against Live Users
    const tAuth1 = performance.now();
    const adminRow = db
      .prepare('SELECT email, role, password_hash FROM users WHERE role = ? LIMIT 1')
      .get('admin') as { email: string; role: string; password_hash: string } | undefined;
    const sampleHash = hashPassword('CivicVerify#2026');
    const verifiedValid = verifyPassword('CivicVerify#2026', sampleHash);
    const adminHasSaltedHash = Boolean(
      adminRow && adminRow.password_hash.includes(':') && adminRow.password_hash.length > 64,
    );
    results.push({
      id: 'AUTH-01',
      category: 'Login & Registration',
      name: 'Salted scrypt credential storage & live password verification',
      expectedResult: 'Stored users carry salted scrypt hashes and matching credentials verify true',
      actualResult: `AdminHashPresent=${adminHasSaltedHash}, VerifyMatch=${verifiedValid}, DigestLen=${sampleHash.length}`,
      status: verifiedValid && adminHasSaltedHash ? 'Pass' : 'Fail',
      durationMs: Math.max(1, Math.round(performance.now() - tAuth1)),
      automated: true,
    });

    // 4. AUTH-02: Wrong Password Rejection & Constant-Time Check
    const tAuth2 = performance.now();
    const verifiedWrong = verifyPassword('WrongPassword!99', sampleHash);
    const invalidLoginCheck = validateLogin({ email: 'bad-email', password: '' });
    results.push({
      id: 'AUTH-02',
      category: 'Login & Registration',
      name: 'Invalid password timingSafeEqual rejection & login validation',
      expectedResult: 'Wrong password returns false and malformed login payload yields field errors',
      actualResult: `WrongPassMatch=${verifiedWrong}, MalformedLoginOk=${invalidLoginCheck.ok}`,
      status: !verifiedWrong && !invalidLoginCheck.ok ? 'Pass' : 'Fail',
      durationMs: Math.max(1, Math.round(performance.now() - tAuth2)),
      automated: true,
    });

    // 5. VAL-01: Form Validation Enforcement
    const tVal = performance.now();
    const badReg = validateRegistration({ email: 'not-an-email', password: '123', fullName: '' });
    const badComplaint = validateComplaint({ title: 'Hi', description: 'Short', address: '' });
    results.push({
      id: 'VAL-01',
      category: 'Form Validation',
      name: 'Shared schema validation rejects malformed registration & complaint inputs',
      expectedResult: 'Registration and complaint validators return ok=false with field-level errors',
      actualResult: `RegErrors=${Object.keys(badReg.errors).length}, ComplaintErrors=${Object.keys(badComplaint.errors).length}`,
      status: !badReg.ok && !badComplaint.ok ? 'Pass' : 'Fail',
      durationMs: Math.max(1, Math.round(performance.now() - tVal)),
      automated: true,
    });

    // 6. SEC-01: RBAC Role Enforcement Check
    const tSec1 = performance.now();
    const residentAllowed = canAccessAdminResources('resident');
    const adminAllowed = canAccessAdminResources('admin');
    results.push({
      id: 'SEC-01',
      category: 'Security',
      name: 'Role-Based Access Control (RBAC) boundary enforcement',
      expectedResult: 'Resident role denied admin access; admin role authorized',
      actualResult: `ResidentAdminAccess=${residentAllowed}, AdminAccess=${adminAllowed}`,
      status: !residentAllowed && adminAllowed ? 'Pass' : 'Fail',
      durationMs: Math.max(1, Math.round(performance.now() - tSec1)),
      automated: true,
    });

    // 7. SEC-02: Parameterized SQL Injection Resistance
    const tSec2 = performance.now();
    const sqliPayload = "' OR '1'='1'; DROP TABLE complaints;--";
    const sqliRows = db
      .prepare('SELECT id FROM complaints WHERE title = ?')
      .all(sqliPayload) as Array<{ id: number }>;
    const tableCount = (
      db.prepare('SELECT COUNT(*) AS count FROM complaints').get() as { count: number }
    ).count;
    results.push({
      id: 'SEC-02',
      category: 'Security',
      name: 'Parameterized query SQL injection neutralization',
      expectedResult: '0 rows returned for tautology/DDL payload & complaints table intact',
      actualResult: `MatchedRows=${sqliRows.length}, ComplaintsIntact=${tableCount}`,
      status: sqliRows.length === 0 && tableCount >= 0 ? 'Pass' : 'Fail',
      durationMs: Math.max(1, Math.round(performance.now() - tSec2)),
      automated: true,
    });

    // 8. SEC-03: XSS Output Escaping
    const tSec3 = performance.now();
    const xssPayload = '<script>alert("xss")</script><img src=x onerror=alert(1)>';
    const xssAnalysis = neutralizeXss(xssPayload);
    const escaped = escapeHtml(xssPayload);
    results.push({
      id: 'SEC-03',
      category: 'Security',
      name: 'HTML entity escaping & vector detection against XSS payloads',
      expectedResult: 'Angle brackets escaped to &lt;/&gt; and attack vectors flagged',
      actualResult: `Vectors=${xssAnalysis.detectedVectors.length}, Escaped=${escaped.slice(0, 34)}...`,
      status:
        !escaped.includes('<script>') &&
        escaped.includes('&lt;script&gt;') &&
        xssAnalysis.detectedVectors.length >= 2
          ? 'Pass'
          : 'Fail',
      durationMs: Math.max(1, Math.round(performance.now() - tSec3)),
      automated: true,
    });

    // 9. SEC-04: Live HTTP Probe against Express requireAdmin middleware
    const tSec4 = performance.now();
    const unauthAdminRes = await fetch(`http://127.0.0.1:${PORT}/api/admin/audit`);
    results.push({
      id: 'SEC-04',
      category: 'Security',
      name: 'Live HTTP probe blocks unauthenticated /api/admin/audit request',
      expectedResult: 'Server rejects unauthenticated request with HTTP 401',
      actualResult: `HTTP ${unauthAdminRes.status} received from Express requireAdmin middleware`,
      status: unauthAdminRes.status === 401 ? 'Pass' : 'Fail',
      durationMs: Math.max(1, Math.round(performance.now() - tSec4)),
      automated: true,
    });

    // 10. ERR-01: Sensitive Credential Redaction
    const tErr1 = performance.now();
    const safeUserColumns = db
      .prepare('SELECT id, full_name, email, role, ward FROM users LIMIT 1')
      .get() as Record<string, unknown> | undefined;
    const leaksHash = safeUserColumns ? 'password_hash' in safeUserColumns : false;
    results.push({
      id: 'ERR-01',
      category: 'Error Handling',
      name: 'Sensitive credential exclusion on public user projections',
      expectedResult: 'password_hash omitted from all serialized user DTO projections',
      actualResult: leaksHash ? 'Hash exposed' : 'password_hash excluded from projection',
      status: Boolean(safeUserColumns) && !leaksHash ? 'Pass' : 'Fail',
      durationMs: Math.max(1, Math.round(performance.now() - tErr1)),
      automated: true,
    });

    // 11. ERR-02: Live HTTP 404 Error Handler without Stack Trace
    const tErr2 = performance.now();
    const missingRes = await fetch(`http://127.0.0.1:${PORT}/api/__nonexistent_probe__`);
    const missingJson = (await missingRes.json().catch(() => ({}))) as Record<string, unknown>;
    results.push({
      id: 'ERR-02',
      category: 'Error Handling',
      name: 'Unknown /api route returns sanitized JSON 404 without stack trace',
      expectedResult: 'HTTP 404 JSON error object returned cleanly',
      actualResult: `HTTP ${missingRes.status} · error="${String(missingJson.error ?? '')}"`,
      status:
        missingRes.status === 404 &&
        typeof missingJson.error === 'string' &&
        !('stack' in missingJson)
          ? 'Pass'
          : 'Fail',
      durationMs: Math.max(1, Math.round(performance.now() - tErr2)),
      automated: true,
    });

    // 12. DB-01: Database WAL, Foreign Keys & Integrity Check
    const tDb = performance.now();
    const journalRow = db.prepare('PRAGMA journal_mode').get() as { journal_mode: string };
    const fkRow = db.prepare('PRAGMA foreign_keys').get() as { foreign_keys: number };
    const totalComplaints = (
      db.prepare('SELECT COUNT(*) AS count FROM complaints').get() as { count: number }
    ).count;
    const totalUsers = (
      db.prepare('SELECT COUNT(*) AS count FROM users').get() as { count: number }
    ).count;
    results.push({
      id: 'DB-01',
      category: 'Database',
      name: 'SQLite WAL journal, FK enforcement & live schema counts',
      expectedResult: 'WAL mode active, foreign_keys=1, and users/complaints tables live',
      actualResult: `Journal=${journalRow.journal_mode}, FK=${fkRow.foreign_keys}, Users=${totalUsers}, Complaints=${totalComplaints}`,
      status:
        journalRow.journal_mode.toLowerCase() === 'wal' &&
        Number(fkRow.foreign_keys) === 1 &&
        totalUsers >= 1
          ? 'Pass'
          : 'Fail',
      durationMs: Math.max(1, Math.round(performance.now() - tDb)),
      automated: true,
    });

    res.json({
      executedAt: new Date().toISOString(),
      results,
    });
  });

  // Unknown API routes return clean JSON 404 (never stack trace)
  app.use('/api', (_req, res) => {
    res.status(404).json({ error: 'Requested API endpoint does not exist.' });
  });

  // Centralized error handler (sanitized response without stack leaks)
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    console.error('[Server Error]', err);
    res.status(500).json({ error: 'An internal server error occurred.' });
  });

  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found. Run npm run build.');
      }
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CivicLedger Municipal Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
