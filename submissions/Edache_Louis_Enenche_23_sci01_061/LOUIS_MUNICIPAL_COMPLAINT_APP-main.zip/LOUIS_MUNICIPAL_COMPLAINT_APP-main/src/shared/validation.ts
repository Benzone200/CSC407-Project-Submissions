import {
  COMPLAINT_CATEGORIES,
  COMPLAINT_PRIORITIES,
  COMPLAINT_STATUSES,
  MUNICIPAL_WARDS,
} from './types.ts';
import type {
  ComplaintCategory,
  ComplaintInput,
  ComplaintPriority,
  ComplaintStatus,
  LoginInput,
  ProfileUpdateInput,
  RegistrationInput,
  UserRole,
  ValidationResult,
} from './types.ts';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const CONTROL_CHARS_PATTERN = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

export function sanitizeText(value: unknown, maxLength = 500): string {
  if (typeof value !== 'string') {
    return '';
  }
  return value.replace(CONTROL_CHARS_PATTERN, '').trim().slice(0, maxLength);
}

export function escapeHtml(raw: string): string {
  return raw
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .replace(/\//g, '&#x2F;');
}

export function neutralizeXss(payload: string): {
  rawLength: number;
  escapedOutput: string;
  detectedVectors: string[];
} {
  const vectors: string[] = [];
  if (/<\s*script/i.test(payload)) vectors.push('Inline <script> tag');
  if (/on\w+\s*=/i.test(payload)) vectors.push('Inline event handler (onerror/onload)');
  if (/javascript\s*:/i.test(payload)) vectors.push('javascript: URI scheme');
  if (/<\s*(iframe|object|embed|svg)/i.test(payload)) vectors.push('Executable HTML/SVG container');

  return {
    rawLength: payload.length,
    escapedOutput: escapeHtml(payload),
    detectedVectors: vectors,
  };
}

export function analyzeSqlInjectionRisk(payload: string): {
  suspiciousTokens: string[];
  isLikelyInjectionAttempt: boolean;
} {
  const patterns: Array<{ label: string; regex: RegExp }> = [
    { label: 'Single-quote string breakout', regex: /'/ },
    { label: 'Boolean tautology (OR 1=1)', regex: /\bOR\b\s+['"]?\d+['"]?\s*=\s*['"]?\d+/i },
    { label: 'Statement terminator (;)', regex: /;/ },
    { label: 'SQL comment sequence (-- or /*)', regex: /(--|\/\*)/ },
    { label: 'UNION SELECT injection', regex: /\bUNION\b\s+\bSELECT\b/i },
    { label: 'Destructive DDL keyword (DROP/ALTER/DELETE)', regex: /\b(DROP|ALTER|TRUNCATE|DELETE)\b/i },
  ];

  const suspiciousTokens = patterns
    .filter((item) => item.regex.test(payload))
    .map((item) => item.label);

  return {
    suspiciousTokens,
    isLikelyInjectionAttempt: suspiciousTokens.length > 0,
  };
}

export function validateRegistration(input: Partial<RegistrationInput>): ValidationResult<RegistrationInput> {
  const errors: Record<string, string> = {};
  const fullName = sanitizeText(input.fullName, 80);
  const email = sanitizeText(input.email, 120).toLowerCase();
  const password = typeof input.password === 'string' ? input.password : '';
  const ward = sanitizeText(input.ward, 80);
  const phone = sanitizeText(input.phone ?? '', 25);

  if (fullName.length < 2) {
    errors.fullName = 'Full name must be at least 2 characters.';
  }
  if (!EMAIL_PATTERN.test(email)) {
    errors.email = 'Enter a valid email address.';
  }
  if (password.length < 8) {
    errors.password = 'Password must be at least 8 characters.';
  } else if (!/[A-Z]/.test(password) || !/[0-9]/.test(password)) {
    errors.password = 'Password must include at least one uppercase letter and one number.';
  }
  if (!MUNICIPAL_WARDS.includes(ward as (typeof MUNICIPAL_WARDS)[number])) {
    errors.ward = 'Select a valid municipal ward.';
  }
  if (phone && !/^[+\d\s()-]{7,20}$/.test(phone)) {
    errors.phone = 'Enter a valid contact phone number or leave blank.';
  }

  if (Object.keys(errors).length > 0) {
    return { ok: false, errors };
  }

  return {
    ok: true,
    errors: {},
    data: { fullName, email, password, ward, phone },
  };
}

export function validateLogin(input: Partial<LoginInput>): ValidationResult<LoginInput> {
  const errors: Record<string, string> = {};
  const email = sanitizeText(input.email, 120).toLowerCase();
  const password = typeof input.password === 'string' ? input.password : '';

  if (!EMAIL_PATTERN.test(email)) {
    errors.email = 'Enter a valid account email address.';
  }
  if (password.length === 0) {
    errors.password = 'Password is required.';
  }

  if (Object.keys(errors).length > 0) {
    return { ok: false, errors };
  }

  return {
    ok: true,
    errors: {},
    data: { email, password },
  };
}

export function validateComplaint(input: Partial<ComplaintInput>): ValidationResult<ComplaintInput> {
  const errors: Record<string, string> = {};
  const title = sanitizeText(input.title, 120);
  const category = sanitizeText(input.category, 60) as ComplaintCategory;
  const priority = sanitizeText(input.priority, 30) as ComplaintPriority;
  const ward = sanitizeText(input.ward, 80);
  const address = sanitizeText(input.address, 140);
  const description = sanitizeText(input.description, 1500);

  if (title.length < 5) {
    errors.title = 'Complaint title must be at least 5 characters.';
  }
  if (!COMPLAINT_CATEGORIES.includes(category)) {
    errors.category = 'Select a recognized municipal category.';
  }
  if (!COMPLAINT_PRIORITIES.includes(priority)) {
    errors.priority = 'Select a valid priority level.';
  }
  if (!MUNICIPAL_WARDS.includes(ward as (typeof MUNICIPAL_WARDS)[number])) {
    errors.ward = 'Select a valid municipal ward.';
  }
  if (address.length < 5) {
    errors.address = 'Provide a street address or intersection (at least 5 characters).';
  }
  if (description.length < 15) {
    errors.description = 'Description must be at least 15 characters so crews can triage the issue.';
  }

  if (Object.keys(errors).length > 0) {
    return { ok: false, errors };
  }

  return {
    ok: true,
    errors: {},
    data: {
      title,
      category,
      priority,
      ward,
      address,
      description,
    },
  };
}

export function validateProfileUpdate(
  input: Partial<ProfileUpdateInput>,
): ValidationResult<ProfileUpdateInput> {
  const errors: Record<string, string> = {};
  const fullName = sanitizeText(input.fullName, 80);
  const ward = sanitizeText(input.ward, 80);
  const phone = sanitizeText(input.phone ?? '', 25);

  if (fullName.length < 2) {
    errors.fullName = 'Full name must be at least 2 characters.';
  }
  if (!MUNICIPAL_WARDS.includes(ward as (typeof MUNICIPAL_WARDS)[number])) {
    errors.ward = 'Select a valid municipal ward.';
  }
  if (phone && !/^[+\d\s()-]{7,20}$/.test(phone)) {
    errors.phone = 'Phone number format is invalid.';
  }

  if (Object.keys(errors).length > 0) {
    return { ok: false, errors };
  }

  return {
    ok: true,
    errors: {},
    data: { fullName, ward, phone },
  };
}

export function validateAdminStatusUpdate(input: {
  status?: unknown;
  assignedDepartment?: unknown;
  resolutionNotes?: unknown;
}): ValidationResult<{
  status: ComplaintStatus;
  assignedDepartment: string;
  resolutionNotes: string;
}> {
  const errors: Record<string, string> = {};
  const status = sanitizeText(input.status, 30) as ComplaintStatus;
  const assignedDepartment = sanitizeText(input.assignedDepartment, 80);
  const resolutionNotes = sanitizeText(input.resolutionNotes, 1000);

  if (!COMPLAINT_STATUSES.includes(status)) {
    errors.status = 'Invalid complaint workflow status.';
  }
  if (assignedDepartment.length < 2) {
    errors.assignedDepartment = 'Specify an assigned municipal department.';
  }

  if (Object.keys(errors).length > 0) {
    return { ok: false, errors };
  }

  return {
    ok: true,
    errors: {},
    data: { status, assignedDepartment, resolutionNotes },
  };
}

export function canAccessAdminResources(role: UserRole | null | undefined): boolean {
  return role === 'admin';
}

export function calculatePasswordStrength(password: string): {
  score: number;
  label: 'Weak' | 'Fair' | 'Strong';
} {
  if (!password) return { score: 0, label: 'Weak' };
  let score = 0;
  if (password.length >= 8) score += 1;
  if (password.length >= 12) score += 1;
  if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score += 1;
  if (/[0-9]/.test(password)) score += 1;
  if (/[^A-Za-z0-9]/.test(password)) score += 1;

  if (score <= 2) return { score, label: 'Weak' };
  if (score <= 3) return { score, label: 'Fair' };
  return { score, label: 'Strong' };
}
