import test from 'node:test';
import assert from 'node:assert/strict';
import { MUNICIPAL_WARDS } from './types.ts';
import {
  analyzeSqlInjectionRisk,
  calculatePasswordStrength,
  canAccessAdminResources,
  escapeHtml,
  neutralizeXss,
  validateAdminStatusUpdate,
  validateComplaint,
  validateLogin,
  validateProfileUpdate,
  validateRegistration,
} from './validation.ts';

test('validateRegistration rejects empty fields and weak passwords', () => {
  const empty = validateRegistration({});
  assert.equal(empty.ok, false);
  assert.ok(empty.errors.fullName);
  assert.ok(empty.errors.email);
  assert.ok(empty.errors.password);
  assert.ok(empty.errors.ward);

  const weakPass = validateRegistration({
    fullName: 'Edache Enenche',
    email: 'edache@example.com',
    password: 'password',
    ward: MUNICIPAL_WARDS[0],
  });
  assert.equal(weakPass.ok, false);
  assert.ok(weakPass.errors.password);
});

test('validateRegistration accepts valid normalized citizen input', () => {
  const valid = validateRegistration({
    fullName: '  Ada Okafor  ',
    email: 'ADA@CIVIC.GOV',
    password: 'CivicPass2026',
    ward: MUNICIPAL_WARDS[1],
    phone: '+234 803 555 0192',
  });
  assert.equal(valid.ok, true);
  assert.equal(valid.data?.email, 'ada@civic.gov');
  assert.equal(valid.data?.fullName, 'Ada Okafor');
});

test('validateLogin enforces valid email and non-empty password', () => {
  assert.equal(validateLogin({ email: 'bad-email', password: '' }).ok, false);
  assert.equal(validateLogin({ email: 'user@civic.gov', password: 'Secret123' }).ok, true);
});

test('validateComplaint rejects short descriptions and unknown categories', () => {
  const invalid = validateComplaint({
    title: 'Fix',
    category: 'Unknown' as never,
    priority: 'High',
    ward: MUNICIPAL_WARDS[0],
    address: '1st',
    description: 'Too short',
  });
  assert.equal(invalid.ok, false);
  assert.ok(invalid.errors.title);
  assert.ok(invalid.errors.category);
  assert.ok(invalid.errors.address);
  assert.ok(invalid.errors.description);
});

test('validateComplaint accepts valid municipal complaint', () => {
  const valid = validateComplaint({
    title: 'Collapsed storm drain cover near Market Junction',
    category: 'Water & Drainage',
    priority: 'Critical',
    ward: MUNICIPAL_WARDS[2],
    address: '412 Herbert Macaulay Way',
    description: 'Heavy rain dislodged the cast iron drain grate creating a road hazard for cyclists.',
  });
  assert.equal(valid.ok, true);
  assert.equal(valid.data?.priority, 'Critical');
});

test('escapeHtml and neutralizeXss neutralize script and event handler payloads', () => {
  const payload = '<script>alert("xss")</script><img src=x onerror=alert(1)>';
  const escaped = escapeHtml(payload);
  assert.equal(escaped.includes('<script>'), false);
  assert.equal(escaped.includes('&lt;script&gt;'), true);

  const analysis = neutralizeXss(payload);
  assert.ok(analysis.detectedVectors.includes('Inline <script> tag'));
  assert.ok(analysis.detectedVectors.includes('Inline event handler (onerror/onload)'));
});

test('analyzeSqlInjectionRisk detects common SQLi payloads', () => {
  const benign = analyzeSqlInjectionRisk('Broken streetlight on Ahmadu Bello Way');
  assert.equal(benign.isLikelyInjectionAttempt, false);

  const attack = analyzeSqlInjectionRisk("' OR 1=1; DROP TABLE complaints;--");
  assert.equal(attack.isLikelyInjectionAttempt, true);
  assert.ok(attack.suspiciousTokens.length >= 3);
});

test('RBAC helper restricts admin endpoints strictly to admin role', () => {
  assert.equal(canAccessAdminResources('admin'), true);
  assert.equal(canAccessAdminResources('resident'), false);
  assert.equal(canAccessAdminResources(null), false);
});

test('validateProfileUpdate and validateAdminStatusUpdate enforce allowed enums', () => {
  assert.equal(
    validateProfileUpdate({
      fullName: 'Grace Bello',
      ward: MUNICIPAL_WARDS[3],
      phone: '555-0142',
    }).ok,
    true,
  );
  assert.equal(
    validateAdminStatusUpdate({
      status: 'Resolved',
      assignedDepartment: 'Public Works — Electrical',
      resolutionNotes: 'Replaced ballast and restored pole lighting.',
    }).ok,
    true,
  );
  assert.equal(
    validateAdminStatusUpdate({
      status: 'DeletedForever',
      assignedDepartment: 'X',
    }).ok,
    false,
  );
});

test('calculatePasswordStrength classifies weak, fair, and strong passwords', () => {
  assert.equal(calculatePasswordStrength('abc').label, 'Weak');
  assert.equal(calculatePasswordStrength('Password1').label, 'Fair');
  assert.equal(calculatePasswordStrength('CivicLedger#2026!').label, 'Strong');
});
