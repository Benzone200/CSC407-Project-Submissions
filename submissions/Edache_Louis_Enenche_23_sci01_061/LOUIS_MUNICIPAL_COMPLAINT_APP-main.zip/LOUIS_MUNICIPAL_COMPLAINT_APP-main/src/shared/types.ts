export const USER_ROLES = ['resident', 'admin'] as const;
export type UserRole = (typeof USER_ROLES)[number];

export const COMPLAINT_CATEGORIES = [
  'Roads & Potholes',
  'Street Lighting',
  'Water & Drainage',
  'Waste & Sanitation',
  'Public Safety',
  'Parks & Trees',
] as const;
export type ComplaintCategory = (typeof COMPLAINT_CATEGORIES)[number];

export const COMPLAINT_PRIORITIES = ['Low', 'Medium', 'High', 'Critical'] as const;
export type ComplaintPriority = (typeof COMPLAINT_PRIORITIES)[number];

export const COMPLAINT_STATUSES = ['Open', 'In Review', 'In Progress', 'Resolved'] as const;
export type ComplaintStatus = (typeof COMPLAINT_STATUSES)[number];

export const MUNICIPAL_WARDS = [
  'Ward 1 — Central Business District',
  'Ward 2 — Garki Area 11',
  'Ward 3 — Wuse Zone 4',
  'Ward 4 — Maitama North',
  'Ward 5 — Gwarinpa Estate',
  'Ward 6 — Nyanya Transit Corridor',
] as const;
export type MunicipalWard = (typeof MUNICIPAL_WARDS)[number];

export interface PublicUser {
  id: number;
  fullName: string;
  email: string;
  role: UserRole;
  ward: string;
  phone: string;
  avatarUrl: string;
  createdAt: string;
}

export interface SessionInfo {
  sessionIdMasked: string;
  createdAt: string;
  expiresAt: string;
  userAgent: string;
}

export interface Complaint {
  id: number;
  referenceCode: string;
  title: string;
  category: ComplaintCategory;
  priority: ComplaintPriority;
  status: ComplaintStatus;
  ward: string;
  address: string;
  description: string;
  reporterId: number;
  reporterName: string;
  assignedDepartment: string;
  resolutionNotes: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLogEntry {
  id: number;
  eventType: string;
  actorEmail: string;
  actorRole: string;
  targetResource: string;
  outcome: 'SUCCESS' | 'DENIED' | 'BLOCKED' | 'ERROR';
  detail: string;
  createdAt: string;
}

export interface ValidationResult<T> {
  ok: boolean;
  data?: T;
  errors: Record<string, string>;
}

export interface RegistrationInput {
  fullName: string;
  email: string;
  password: string;
  ward: string;
  phone?: string;
}

export interface LoginInput {
  email: string;
  password: string;
}

export interface ComplaintInput {
  title: string;
  category: ComplaintCategory;
  priority: ComplaintPriority;
  ward: string;
  address: string;
  description: string;
}

export interface ProfileUpdateInput {
  fullName: string;
  ward: string;
  phone: string;
}

export interface SecurityLabSqlResult {
  payload: string;
  vulnerableQueryPreview: string;
  parameterizedQueryPreview: string;
  boundParameter: string;
  matchedRowsInSafeQuery: number;
  injectionNeutralized: boolean;
  explanation: string;
}

export interface SecurityHeaderReport {
  headers: Array<{
    name: string;
    value: string;
    purpose: string;
  }>;
  transportMode: string;
  cookiePolicy: string;
  checkedAt: string;
}

export interface LiveTestCheckResult {
  id: string;
  category:
    | 'Functional'
    | 'Login & Registration'
    | 'Form Validation'
    | 'Security'
    | 'Usability'
    | 'Responsive & Mobile'
    | 'Error Handling'
    | 'Database';
  name: string;
  expectedResult: string;
  actualResult: string;
  status: 'Pass' | 'Fail';
  durationMs: number;
  automated: boolean;
}

export interface HealthReport {
  status: string;
  database: string;
  walEnabled: boolean;
  foreignKeysEnabled: boolean;
  dbSizeBytes: number;
  complaintCount: number;
  resolvedCount: number;
  userCount: number;
  activeSessionCount: number;
  auditLogCount: number;
  environment: string;
  nodeVersion: string;
  uptimeSeconds: number;
  timestamp: string;
}

export type AppSection =
  | 'dashboard'
  | 'submit'
  | 'auth'
  | 'profile'
  | 'security'
  | 'testing'
  | 'deployment'
  | 'review';
