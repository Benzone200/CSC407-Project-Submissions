import React, { useCallback, useEffect, useState } from 'react';
import type {
  AppSection,
  Complaint,
  ComplaintStatus,
  PublicUser,
  SessionInfo,
} from './shared/types.ts';
import { api } from './services/api.ts';
import { Layout } from './components/Layout.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { SubmitComplaintView } from './components/SubmitComplaintView.tsx';
import { AuthView } from './components/AuthView.tsx';
import { ProfileView } from './components/ProfileView.tsx';
import { SecurityView } from './components/SecurityView.tsx';
import { TestingView } from './components/TestingView.tsx';
import { DeploymentView } from './components/DeploymentView.tsx';
import { ReviewView } from './components/ReviewView.tsx';

export default function App() {
  const [activeSection, setActiveSection] = useState<AppSection>('dashboard');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof document !== 'undefined') {
      return document.documentElement.classList.contains('dark');
    }
    return false;
  });

  const [user, setUser] = useState<PublicUser | null>(null);
  const [session, setSession] = useState<SessionInfo | null>(null);

  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [loadingComplaints, setLoadingComplaints] = useState<boolean>(true);
  const [complaintsError, setComplaintsError] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [mineOnly, setMineOnly] = useState(false);

  const toggleDarkMode = useCallback(() => {
    setDarkMode((prev) => {
      const next = !prev;
      document.documentElement.classList.toggle('dark', next);
      try {
        localStorage.setItem('civicledger_theme', next ? 'dark' : 'light');
      } catch {
        // Ignore storage errors
      }
      return next;
    });
  }, []);

  const refreshSession = useCallback(async () => {
    try {
      const data = await api.getSession();
      setUser(data.user);
      setSession(data.session);
    } catch {
      setUser(null);
      setSession(null);
    }
  }, []);

  const fetchComplaints = useCallback(async () => {
    setLoadingComplaints(true);
    setComplaintsError(null);
    try {
      const res = await api.listComplaints({
        q: searchQuery.trim(),
        status: statusFilter,
        category: categoryFilter,
        priority: priorityFilter,
        mine: mineOnly && Boolean(user),
      });
      setComplaints(res.complaints);
    } catch (err) {
      setComplaintsError(
        err instanceof Error ? err.message : 'Unable to fetch municipal complaints.',
      );
    } finally {
      setLoadingComplaints(false);
    }
  }, [searchQuery, statusFilter, categoryFilter, priorityFilter, mineOnly, user]);

  useEffect(() => {
    refreshSession();
  }, [refreshSession]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      fetchComplaints();
    }, 100);
    return () => window.clearTimeout(timer);
  }, [fetchComplaints]);

  const handleAuthenticated = async (authedUser: PublicUser) => {
    setUser(authedUser);
    await refreshSession();
    setActiveSection('dashboard');
  };

  const handleLogout = async () => {
    await api.logout().catch(() => undefined);
    setUser(null);
    setSession(null);
    setMineOnly(false);
    if (activeSection === 'profile') {
      setActiveSection('dashboard');
    }
  };

  const handleComplaintCreated = (created: Complaint) => {
    setComplaints((prev) => [created, ...prev]);
  };

  const handleAdminUpdate = async (
    id: number,
    payload: { status: ComplaintStatus; assignedDepartment: string; resolutionNotes: string },
  ) => {
    const res = await api.updateComplaintAdmin(id, payload);
    setComplaints((prev) => prev.map((c) => (c.id === id ? res.complaint : c)));
  };

  const handleAdminDelete = async (id: number) => {
    await api.deleteComplaintAdmin(id);
    setComplaints((prev) => prev.filter((c) => c.id !== id));
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setStatusFilter('All');
    setCategoryFilter('All');
    setPriorityFilter('All');
    setMineOnly(false);
  };

  return (
    <Layout
      activeSection={activeSection}
      onNavigate={setActiveSection}
      user={user}
      onLogout={handleLogout}
      darkMode={darkMode}
      onToggleDarkMode={toggleDarkMode}
    >
      {activeSection === 'dashboard' && (
        <DashboardView
          complaints={complaints}
          loading={loadingComplaints}
          error={complaintsError}
          searchQuery={searchQuery}
          statusFilter={statusFilter}
          categoryFilter={categoryFilter}
          priorityFilter={priorityFilter}
          mineOnly={mineOnly}
          onSearchChange={setSearchQuery}
          onStatusFilterChange={setStatusFilter}
          onCategoryFilterChange={setCategoryFilter}
          onPriorityFilterChange={setPriorityFilter}
          onMineOnlyChange={setMineOnly}
          onClearFilters={handleClearFilters}
          onNavigate={setActiveSection}
          user={user}
          onAdminUpdate={handleAdminUpdate}
          onAdminDelete={handleAdminDelete}
        />
      )}

      {activeSection === 'submit' && (
        <SubmitComplaintView
          user={user}
          onComplaintCreated={handleComplaintCreated}
          onNavigate={setActiveSection}
        />
      )}

      {activeSection === 'auth' && <AuthView onAuthenticated={handleAuthenticated} />}

      {activeSection === 'profile' && (
        <ProfileView
          user={user}
          session={session}
          onUserUpdated={setUser}
          onNavigate={setActiveSection}
        />
      )}

      {activeSection === 'security' && <SecurityView user={user} />}

      {activeSection === 'testing' && <TestingView />}

      {activeSection === 'deployment' && <DeploymentView user={user} />}

      {activeSection === 'review' && <ReviewView complaints={complaints} />}
    </Layout>
  );
}
