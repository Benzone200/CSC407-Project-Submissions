import React, { useState } from 'react';
import {
  COMPLAINT_CATEGORIES,
  COMPLAINT_PRIORITIES,
  MUNICIPAL_WARDS,
} from '../shared/types.ts';
import type {
  AppSection,
  Complaint,
  ComplaintCategory,
  ComplaintPriority,
  PublicUser,
} from '../shared/types.ts';
import { validateComplaint } from '../shared/validation.ts';
import { api, ApiError } from '../services/api.ts';

interface SubmitComplaintViewProps {
  user: PublicUser | null;
  onComplaintCreated: (complaint: Complaint) => void;
  onNavigate: (section: AppSection) => void;
}

export function SubmitComplaintView({
  user,
  onComplaintCreated,
  onNavigate,
}: SubmitComplaintViewProps) {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ComplaintCategory>('Roads & Potholes');
  const [priority, setPriority] = useState<ComplaintPriority>('Medium');
  const [ward, setWard] = useState<string>(user?.ward || MUNICIPAL_WARDS[0]);
  const [address, setAddress] = useState('');
  const [description, setDescription] = useState('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setServerError(null);

    const validation = validateComplaint({
      title,
      category,
      priority,
      ward,
      address,
      description,
    });

    if (!validation.ok || !validation.data) {
      setFieldErrors(validation.errors);
      return;
    }

    setFieldErrors({});
    setSubmitting(true);
    try {
      const res = await api.createComplaint(validation.data);
      onComplaintCreated(res.complaint);
      setTitle('');
      setAddress('');
      setDescription('');
      onNavigate('dashboard');
    } catch (err) {
      if (err instanceof ApiError) {
        setServerError(err.message);
        if (err.fieldErrors) setFieldErrors(err.fieldErrors);
      } else {
        setServerError('Unable to submit complaint. Please verify your connection.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (!user) {
    return (
      <section className="max-w-2xl mx-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center space-y-4">
        <h1 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">
          Authentication Required to Submit a Complaint
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          To prevent spam and maintain an accountable municipal audit trail, residents must sign in
          before filing new service requests.
        </p>
        <div className="pt-2 flex flex-wrap justify-center gap-3">
          <button
            type="button"
            onClick={() => onNavigate('auth')}
            className="px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
          >
            Sign In or Create Account
          </button>
          <button
            type="button"
            onClick={() => onNavigate('dashboard')}
            className="px-5 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg"
          >
            Back to Dashboard
          </button>
        </div>
      </section>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100">
          Submit a Municipal Complaint
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
          Filing as {user.fullName} ({user.email}). All inputs undergo strict client and server
          validation before parameterized SQLite storage.
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        noValidate
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 space-y-5"
      >
        {serverError && (
          <div
            role="alert"
            className="p-3 text-sm text-red-800 dark:text-red-300 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 rounded-lg"
          >
            {serverError}
          </div>
        )}

        <div>
          <label
            htmlFor="complaint-title"
            className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1.5"
          >
            Issue Title
          </label>
          <input
            id="complaint-title"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g., Broken streetlight pole outside Community Clinic"
            className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
          {fieldErrors.title && (
            <p className="mt-1 text-xs text-red-700 dark:text-red-400">{fieldErrors.title}</p>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="complaint-category"
              className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1.5"
            >
              Service Category
            </label>
            <select
              id="complaint-category"
              value={category}
              onChange={(e) => setCategory(e.target.value as ComplaintCategory)}
              className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              {COMPLAINT_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
            {fieldErrors.category && (
              <p className="mt-1 text-xs text-red-700 dark:text-red-400">{fieldErrors.category}</p>
            )}
          </div>

          <div>
            <label
              htmlFor="complaint-priority"
              className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1.5"
            >
              Urgency Priority
            </label>
            <select
              id="complaint-priority"
              value={priority}
              onChange={(e) => setPriority(e.target.value as ComplaintPriority)}
              className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              {COMPLAINT_PRIORITIES.map((prio) => (
                <option key={prio} value={prio}>
                  {prio}
                </option>
              ))}
            </select>
            {fieldErrors.priority && (
              <p className="mt-1 text-xs text-red-700 dark:text-red-400">{fieldErrors.priority}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="complaint-ward"
              className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1.5"
            >
              Municipal Ward
            </label>
            <select
              id="complaint-ward"
              value={ward}
              onChange={(e) => setWard(e.target.value)}
              className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              {MUNICIPAL_WARDS.map((w) => (
                <option key={w} value={w}>
                  {w}
                </option>
              ))}
            </select>
            {fieldErrors.ward && (
              <p className="mt-1 text-xs text-red-700 dark:text-red-400">{fieldErrors.ward}</p>
            )}
          </div>

          <div>
            <label
              htmlFor="complaint-address"
              className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1.5"
            >
              Street Address or Intersection
            </label>
            <input
              id="complaint-address"
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="e.g., 142 Independence Avenue"
              className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
            {fieldErrors.address && (
              <p className="mt-1 text-xs text-red-700 dark:text-red-400">{fieldErrors.address}</p>
            )}
          </div>
        </div>

        <div>
          <label
            htmlFor="complaint-description"
            className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1.5"
          >
            Detailed Description
          </label>
          <textarea
            id="complaint-description"
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the hazard, affected landmarks, and how long the issue has persisted..."
            className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
          <div className="mt-1 flex items-center justify-between text-xs">
            {fieldErrors.description ? (
              <span className="text-red-700 dark:text-red-400">{fieldErrors.description}</span>
            ) : (
              <span className="text-slate-500 dark:text-slate-400">
                Minimum 15 characters required
              </span>
            )}
            <span className="font-mono text-slate-500 dark:text-slate-400 tabular-nums">
              {description.length}/1500
            </span>
          </div>
        </div>

        <div className="pt-2 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={() => onNavigate('dashboard')}
            className="px-4 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={submitting}
            className="px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg disabled:opacity-60"
          >
            {submitting ? 'Submitting...' : 'Submit Complaint'}
          </button>
        </div>
      </form>
    </div>
  );
}
