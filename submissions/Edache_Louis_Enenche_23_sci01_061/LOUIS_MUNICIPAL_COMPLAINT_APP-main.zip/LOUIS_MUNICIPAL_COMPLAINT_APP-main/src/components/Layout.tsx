import React, { useState } from 'react';
import { Menu, Moon, Sun, X } from 'lucide-react';
import type { AppSection, PublicUser } from '../shared/types.ts';

interface LayoutProps {
  activeSection: AppSection;
  onNavigate: (section: AppSection) => void;
  user: PublicUser | null;
  onLogout: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  children: React.ReactNode;
}

const PRIMARY_NAV: Array<{ id: AppSection; label: string }> = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'submit', label: 'Submit Complaint' },
  { id: 'security', label: 'Security' },
  { id: 'testing', label: 'Testing & QA' },
  { id: 'deployment', label: 'Deployment' },
  { id: 'review', label: 'Project Review' },
];

export function Layout({
  activeSection,
  onNavigate,
  user,
  onLogout,
  darkMode,
  onToggleDarkMode,
  children,
}: LayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNav = (section: AppSection) => {
    onNavigate(section);
    setMobileMenuOpen(false);
  };

  const sectionLabels: Record<AppSection, string> = {
    dashboard: 'Complaints',
    submit: 'Submit Complaint',
    auth: 'Account Access',
    profile: 'User Profile',
    security: 'Security Lab',
    testing: 'Testing & QA',
    deployment: 'Deployment',
    review: 'Project Review',
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex">
      {/* Desktop Sidebar */}
      <aside
        aria-label="Primary sidebar navigation"
        className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 z-30"
      >
        <div className="h-16 px-5 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={() => handleNav('dashboard')}
            className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-slate-100 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-blue-600 rounded"
          >
            CivicLedger
          </button>

          <button
            type="button"
            onClick={onToggleDarkMode}
            aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
            className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>

        <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto" aria-label="Workspace sections">
          {PRIMARY_NAV.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                aria-current={isActive ? 'page' : undefined}
                className={`w-full px-3.5 py-2.5 text-sm font-medium rounded-lg transition-colors text-left whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {item.label}
              </button>
            );
          })}

          <div className="pt-4 mt-4 border-t border-slate-200 dark:border-slate-800 space-y-1">
            {user ? (
              <button
                type="button"
                onClick={() => handleNav('profile')}
                aria-current={activeSection === 'profile' ? 'page' : undefined}
                className={`w-full px-3.5 py-2.5 text-sm font-medium rounded-lg transition-colors text-left whitespace-nowrap ${
                  activeSection === 'profile'
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                User Profile
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleNav('auth')}
                aria-current={activeSection === 'auth' ? 'page' : undefined}
                className={`w-full px-3.5 py-2.5 text-sm font-medium rounded-lg transition-colors text-left whitespace-nowrap ${
                  activeSection === 'auth'
                    ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                Sign In / Register
              </button>
            )}
          </div>
        </nav>

        <div className="p-4 border-t border-slate-200 dark:border-slate-800">
          {user ? (
            <div className="space-y-3">
              <button
                type="button"
                onClick={() => handleNav('profile')}
                className="w-full flex items-center gap-3 text-left rounded-lg p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <img
                  src={user.avatarUrl || '/src/assets/images/avatar_citizen_1794860881512.jpg'}
                  alt={user.fullName}
                  referrerPolicy="no-referrer"
                  className="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                    {user.fullName}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {user.role === 'admin' ? 'Administrator' : 'Resident'}
                  </p>
                </div>
              </button>
              <button
                type="button"
                onClick={onLogout}
                className="w-full px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
              >
                Sign Out
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                Sign in to file municipal complaints or access admin triage.
              </p>
              <button
                type="button"
                onClick={() => handleNav('auth')}
                className="w-full px-3 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap"
              >
                Sign In / Create Account
              </button>
            </div>
          )}
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <header className="sticky top-0 z-20 h-14 lg:h-16 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4 xl:gap-8">
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden p-2 -ml-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg min-h-[44px] min-w-[44px] flex items-center justify-center shrink-0"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="font-display text-sm sm:text-base font-semibold text-slate-900 dark:text-slate-100 truncate">
              {sectionLabels[activeSection]}
            </span>
          </div>

          <nav
            aria-label="Quick section links"
            className="hidden md:flex items-center gap-4 lg:gap-5 xl:gap-6 shrink-0 text-sm font-medium text-slate-600 dark:text-slate-300"
          >
            <button
              type="button"
              onClick={() => handleNav('dashboard')}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                activeSection === 'dashboard'
                  ? 'border-slate-900 dark:border-slate-100 text-slate-900 dark:text-white'
                  : 'border-transparent hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Dashboard
            </button>
            <button
              type="button"
              onClick={() => handleNav('security')}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                activeSection === 'security'
                  ? 'border-slate-900 dark:border-slate-100 text-slate-900 dark:text-white'
                  : 'border-transparent hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Security
            </button>
            <button
              type="button"
              onClick={() => handleNav('testing')}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                activeSection === 'testing'
                  ? 'border-slate-900 dark:border-slate-100 text-slate-900 dark:text-white'
                  : 'border-transparent hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Testing
            </button>
            <button
              type="button"
              onClick={() => handleNav('deployment')}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                activeSection === 'deployment'
                  ? 'border-slate-900 dark:border-slate-100 text-slate-900 dark:text-white'
                  : 'border-transparent hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Deployment
            </button>
            <button
              type="button"
              onClick={() => handleNav('review')}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                activeSection === 'review'
                  ? 'border-slate-900 dark:border-slate-100 text-slate-900 dark:text-white'
                  : 'border-transparent hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Review
            </button>
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={() => handleNav(activeSection === 'submit' ? 'dashboard' : 'submit')}
              className="px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              {activeSection === 'submit' ? 'View Queue' : 'Report Issue'}
            </button>
          </div>
        </header>

        {/* Mobile Drawer */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <div
              className="fixed inset-0 bg-slate-950/60"
              onClick={() => setMobileMenuOpen(false)}
              aria-hidden="true"
            />
            <div className="relative w-72 max-w-[85vw] bg-white dark:bg-slate-900 h-full border-r border-slate-200 dark:border-slate-800 flex flex-col z-10">
              <div className="h-14 px-4 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
                <span className="font-display text-base font-bold text-slate-900 dark:text-slate-100">
                  CivicLedger
                </span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={onToggleDarkMode}
                    aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
                    className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg min-h-[44px] min-w-[44px] flex items-center justify-center"
                  >
                    {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => setMobileMenuOpen(false)}
                    aria-label="Close navigation menu"
                    className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg min-h-[44px] min-w-[44px] flex items-center justify-center"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <nav className="flex-1 p-3 space-y-1 overflow-y-auto" aria-label="Mobile navigation">
                {PRIMARY_NAV.map((item) => {
                  const isActive = activeSection === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleNav(item.id)}
                      className={`w-full px-3.5 py-3 text-sm font-medium rounded-lg text-left ${
                        isActive
                          ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                          : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      {item.label}
                    </button>
                  );
                })}
                <div className="pt-3 mt-3 border-t border-slate-200 dark:border-slate-800 space-y-1">
                  {user ? (
                    <>
                      <button
                        type="button"
                        onClick={() => handleNav('profile')}
                        className="w-full px-3.5 py-3 text-sm font-medium rounded-lg text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                      >
                        Profile ({user.fullName})
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setMobileMenuOpen(false);
                          onLogout();
                        }}
                        className="w-full px-3.5 py-3 text-sm font-medium rounded-lg text-left text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/50"
                      >
                        Sign Out
                      </button>
                    </>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleNav('auth')}
                      className="w-full px-3.5 py-3 text-sm font-medium rounded-lg text-left text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/50"
                    >
                      Sign In / Register
                    </button>
                  )}
                </div>
              </nav>
            </div>
          </div>
        )}

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">{children}</main>

        <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 sm:px-6 lg:px-8 py-5 text-xs text-slate-500 dark:text-slate-400 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <p>CivicLedger Municipal Complaint Management System · Edache Louis Enenche</p>
          <p>Web Application Security, Testing, Deployment and Review</p>
        </footer>
      </div>
    </div>
  );
}
