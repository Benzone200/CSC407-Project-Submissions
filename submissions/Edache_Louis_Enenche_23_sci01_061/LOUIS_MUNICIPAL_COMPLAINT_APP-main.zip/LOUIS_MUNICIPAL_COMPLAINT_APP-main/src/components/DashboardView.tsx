import React, { useMemo, useState } from 'react';
import { FilterX, Search, Trash2 } from 'lucide-react';
import {
  COMPLAINT_CATEGORIES,
  COMPLAINT_PRIORITIES,
  COMPLAINT_STATUSES,
} from '../shared/types.ts';
import type {
  AppSection,
  Complaint,
  ComplaintStatus,
  PublicUser,
} from '../shared/types.ts';

interface DashboardViewProps {
  complaints: Complaint[];
  loading: boolean;
  error: string | null;
  searchQuery: string;
  statusFilter: string;
  categoryFilter: string;
  priorityFilter: string;
  mineOnly: boolean;
  onSearchChange: (value: string) => void;
  onStatusFilterChange: (value: string) => void;
  onCategoryFilterChange: (value: string) => void;
  onPriorityFilterChange: (value: string) => void;
  onMineOnlyChange: (value: boolean) => void;
  onClearFilters: () => void;
  onNavigate: (section: AppSection) => void;
  user: PublicUser | null;
  onAdminUpdate: (
    id: number,
    payload: { status: ComplaintStatus; assignedDepartment: string; resolutionNotes: string },
  ) => Promise<void>;
  onAdminDelete: (id: number) => Promise<void>;
}

const STATUS_STYLE: Record<ComplaintStatus, string> = {
  Open: 'text-red-700 dark:text-red-400',
  'In Review': 'text-amber-700 dark:text-amber-400',
  'In Progress': 'text-blue-700 dark:text-blue-400',
  Resolved: 'text-emerald-700 dark:text-emerald-400',
};

export function DashboardView({
  complaints,
  loading,
  error,
  searchQuery,
  statusFilter,
  categoryFilter,
  priorityFilter,
  mineOnly,
  onSearchChange,
  onStatusFilterChange,
  onCategoryFilterChange,
  onPriorityFilterChange,
  onMineOnlyChange,
  onClearFilters,
  onNavigate,
  user,
  onAdminUpdate,
  onAdminDelete,
}: DashboardViewProps) {
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const [triageStatus, setTriageStatus] = useState<ComplaintStatus>('In Progress');
  const [triageDept, setTriageDept] = useState('');
  const [triageNotes, setTriageNotes] = useState('');
  const [triageBusy, setTriageBusy] = useState(false);
  const [triageMessage, setTriageMessage] = useState<string | null>(null);

  const metrics = useMemo(() => {
    const total = complaints.length;
    const openCount = complaints.filter((c) => c.status === 'Open').length;
    const activeCount = complaints.filter(
      (c) => c.status === 'In Review' || c.status === 'In Progress',
    ).length;
    const resolvedCount = complaints.filter((c) => c.status === 'Resolved').length;
    return { total, openCount, activeCount, resolvedCount };
  }, [complaints]);

  const openInspector = (complaint: Complaint) => {
    setSelectedComplaint(complaint);
    setTriageStatus(complaint.status);
    setTriageDept(complaint.assignedDepartment);
    setTriageNotes(complaint.resolutionNotes);
    setTriageMessage(null);
  };

  const handleSaveTriage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedComplaint) return;
    setTriageBusy(true);
    setTriageMessage(null);
    try {
      await onAdminUpdate(selectedComplaint.id, {
        status: triageStatus,
        assignedDepartment: triageDept,
        resolutionNotes: triageNotes,
      });
      setSelectedComplaint((prev) =>
        prev
          ? {
              ...prev,
              status: triageStatus,
              assignedDepartment: triageDept,
              resolutionNotes: triageNotes,
            }
          : null,
      );
      setTriageMessage('Triage update saved to SQLite and logged in audit trail.');
    } catch (err) {
      setTriageMessage(err instanceof Error ? err.message : 'Unable to save update.');
    } finally {
      setTriageBusy(false);
    }
  };

  const handleDeleteRecord = async (id: number) => {
    setTriageBusy(true);
    try {
      await onAdminDelete(id);
      setSelectedComplaint(null);
    } finally {
      setTriageBusy(false);
    }
  };

  const hasFilters =
    searchQuery.trim() !== '' ||
    statusFilter !== 'All' ||
    categoryFilter !== 'All' ||
    priorityFilter !== 'All' ||
    mineOnly;

  return (
    <div className="space-y-8">
      {/* Hero / Civic Context Split */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between gap-6">
          <div className="space-y-3">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Municipal Operations Portal · Civic Infrastructure &amp; Service Delivery
            </p>
            <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100 text-balance">
              Municipal Complaint Management System
            </h1>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
              Track public infrastructure reports, enforce role-based administrative triage, and
              verify full-stack web application security, automated testing, deployment readiness,
              and project evaluation.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onNavigate('submit')}
              className="px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap"
            >
              Submit New Complaint
            </button>
            <button
              type="button"
              onClick={() => onNavigate('security')}
              className="px-5 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
            >
              Inspect Security Lab
            </button>
          </div>
        </div>

        <div className="lg:col-span-5 relative min-h-[200px] lg:min-h-full bg-slate-100 dark:bg-slate-800 border-t lg:border-t-0 lg:border-l border-slate-200 dark:border-slate-800">
          <img
            src="/src/assets/images/municipal_civic_hall_1794860881520.jpg"
            alt="Municipal civic center exterior"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover lg:absolute lg:inset-0"
          />
        </div>
      </section>

      {/* 4-Column KPI Strip */}
      <section aria-label="Complaint summary metrics" className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Visible Tickets</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
            {metrics.total}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Open Triage</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-red-700 dark:text-red-400 tabular-nums">
            {metrics.openCount}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">In Review / Progress</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-blue-700 dark:text-blue-400 tabular-nums">
            {metrics.activeCount}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Resolved Cases</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
            {metrics.resolvedCount}
          </p>
        </div>
      </section>

      {/* Search & Filter Toolbar + Data Table */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-lg font-semibold text-slate-900 dark:text-slate-100">
                Municipal Complaint Registry
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Live SQLite records queried with parameterized search and status filters
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {user && (
                <div
                  role="group"
                  aria-label="Ownership scope"
                  className="inline-flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg"
                >
                  <button
                    type="button"
                    onClick={() => onMineOnlyChange(false)}
                    className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                      !mineOnly
                        ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 shadow-xs'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    All Reports
                  </button>
                  <button
                    type="button"
                    onClick={() => onMineOnlyChange(true)}
                    className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                      mineOnly
                        ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 shadow-xs'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    My Reports
                  </button>
                </div>
              )}

              {hasFilters && (
                <button
                  type="button"
                  onClick={onClearFilters}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors whitespace-nowrap"
                >
                  <FilterX className="w-3.5 h-3.5" />
                  Clear Filters
                </button>
              )}
            </div>
          </div>

          {/* Search & Dropdown Filters */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            <div className="md:col-span-5 relative">
              <label htmlFor="complaint-search" className="sr-only">
                Search complaints
              </label>
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="complaint-search"
                type="search"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search by ticket ID, street, ward, or keyword..."
                className="w-full pl-9 pr-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="md:col-span-4">
              <label htmlFor="category-filter" className="sr-only">
                Filter by category
              </label>
              <select
                id="category-filter"
                value={categoryFilter}
                onChange={(e) => onCategoryFilterChange(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="All">All Categories</option>
                {COMPLAINT_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div className="md:col-span-3">
              <label htmlFor="priority-filter" className="sr-only">
                Filter by priority
              </label>
              <select
                id="priority-filter"
                value={priorityFilter}
                onChange={(e) => onPriorityFilterChange(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="All">All Priorities</option>
                {COMPLAINT_PRIORITIES.map((prio) => (
                  <option key={prio} value={prio}>
                    {prio}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Interactive Status Segmented Control */}
          <div
            role="group"
            aria-label="Filter by complaint status"
            className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg w-fit max-w-full"
          >
            {(['All', ...COMPLAINT_STATUSES] as const).map((status) => {
              const active = statusFilter === status;
              return (
                <button
                  key={status}
                  type="button"
                  onClick={() => onStatusFilterChange(status)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {status}
                </button>
              );
            })}
          </div>
        </div>

        {/* Error State */}
        {error && (
          <div className="p-6 text-sm text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/40 border-b border-red-200 dark:border-red-900">
            {error}
          </div>
        )}

        {/* Loading State */}
        {loading ? (
          <div className="p-6 space-y-3" aria-busy="true" aria-label="Loading complaints">
            {[1, 2, 3, 4].map((row) => (
              <div key={row} className="h-11 bg-slate-100 dark:bg-slate-800 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : complaints.length === 0 ? (
          <div className="p-10 text-center space-y-3">
            <p className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              No matching complaints found
            </p>
            <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">
              Adjust your search terms or status filters, or submit a new municipal report.
            </p>
            <div className="pt-2 flex items-center justify-center gap-3">
              {hasFilters && (
                <button
                  type="button"
                  onClick={onClearFilters}
                  className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg"
                >
                  Reset Filters
                </button>
              )}
              <button
                type="button"
                onClick={() => onNavigate('submit')}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
              >
                Submit Complaint
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 text-xs font-semibold text-slate-600 dark:text-slate-300">
                    <th className="py-3 px-5">Reference</th>
                    <th className="py-3 px-4">Complaint & Location</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Priority</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-5 text-right">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-sm">
                  {complaints.map((item) => (
                    <tr
                      key={item.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3.5 px-5 font-mono text-xs font-medium text-slate-700 dark:text-slate-300 tabular-nums whitespace-nowrap">
                        {item.referenceCode}
                      </td>
                      <td className="py-3.5 px-4 max-w-md">
                        <p className="font-medium text-slate-900 dark:text-slate-100 truncate">
                          {item.title}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                          {item.address} · {item.ward}
                        </p>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-600 dark:text-slate-300 whitespace-nowrap">
                        {item.category}
                      </td>
                      <td className="py-3.5 px-4 text-xs font-medium text-slate-700 dark:text-slate-300 whitespace-nowrap">
                        {item.priority}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className={`text-xs font-semibold ${STATUS_STYLE[item.status]}`}>
                          {item.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-5 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => openInspector(item)}
                          aria-label={`Inspect ${item.referenceCode}`}
                          className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md transition-colors"
                        >
                          Inspect
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Card List */}
            <div className="md:hidden divide-y divide-slate-200 dark:divide-slate-800">
              {complaints.map((item) => (
                <div key={item.id} className="p-4 space-y-2.5">
                  <div className="flex items-center justify-between gap-2 text-xs">
                    <span className="font-mono font-medium text-slate-700 dark:text-slate-300 tabular-nums">
                      {item.referenceCode}
                    </span>
                    <span className={`font-semibold ${STATUS_STYLE[item.status]}`}>
                      {item.status}
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                    {item.title}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {item.category} · {item.priority} Priority · {item.ward}
                  </p>
                  <button
                    type="button"
                    onClick={() => openInspector(item)}
                    className="w-full py-2.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg"
                  >
                    Inspect Complaint Details
                  </button>
                </div>
              ))}
            </div>
          </>
        )}
      </section>

      {/* Complaint Detail & Admin Triage Modal */}
      {selectedComplaint && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="complaint-dialog-title"
          className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4"
        >
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-5">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <p className="font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                  {selectedComplaint.referenceCode} · Filed{' '}
                  {new Date(selectedComplaint.createdAt).toLocaleDateString()}
                </p>
                <h3
                  id="complaint-dialog-title"
                  className="font-display text-lg font-bold text-slate-900 dark:text-slate-100 mt-1"
                >
                  {selectedComplaint.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedComplaint(null)}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">Category & Priority</p>
                <p className="font-medium text-slate-900 dark:text-slate-100 mt-0.5">
                  {selectedComplaint.category} · {selectedComplaint.priority}
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">Ward & Street Address</p>
                <p className="font-medium text-slate-900 dark:text-slate-100 mt-0.5">
                  {selectedComplaint.address} · {selectedComplaint.ward}
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">Assigned Municipal Unit</p>
                <p className="font-medium text-slate-900 dark:text-slate-100 mt-0.5">
                  {selectedComplaint.assignedDepartment}
                </p>
              </div>
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">Reported By</p>
                <p className="font-medium text-slate-900 dark:text-slate-100 mt-0.5">
                  {selectedComplaint.reporterName}
                </p>
              </div>
            </div>

            <div className="space-y-1.5">
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Citizen Description
              </p>
              <p className="text-sm text-slate-700 dark:text-slate-200 leading-relaxed bg-slate-50 dark:bg-slate-950 p-4 rounded-lg border border-slate-200 dark:border-slate-800">
                {selectedComplaint.description}
              </p>
            </div>

            {selectedComplaint.resolutionNotes && (
              <div className="space-y-1.5">
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                  Official Resolution Notes
                </p>
                <p className="text-sm text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-slate-950 p-4 rounded-lg border border-slate-200 dark:border-slate-800">
                  {selectedComplaint.resolutionNotes}
                </p>
              </div>
            )}

            {/* Admin RBAC Triage Controls */}
            {user?.role === 'admin' ? (
              <form
                onSubmit={handleSaveTriage}
                className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h4 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                    Administrator Triage Controls
                  </h4>
                  <span className="text-xs text-slate-500 dark:text-slate-400">
                    Role verified: admin
                  </span>
                </div>

                {triageMessage && (
                  <p className="text-xs font-medium text-blue-800 dark:text-blue-200 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 rounded-lg px-3 py-2">
                    {triageMessage}
                  </p>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label
                      htmlFor="triage-status"
                      className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
                    >
                      Workflow Status
                    </label>
                    <select
                      id="triage-status"
                      value={triageStatus}
                      onChange={(e) => setTriageStatus(e.target.value as ComplaintStatus)}
                      className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg"
                    >
                      {COMPLAINT_STATUSES.map((st) => (
                        <option key={st} value={st}>
                          {st}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="triage-dept"
                      className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
                    >
                      Assigned Department
                    </label>
                    <input
                      id="triage-dept"
                      type="text"
                      value={triageDept}
                      onChange={(e) => setTriageDept(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg"
                    />
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="triage-notes"
                    className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Official Resolution Notes
                  </label>
                  <textarea
                    id="triage-notes"
                    rows={3}
                    value={triageNotes}
                    onChange={(e) => setTriageNotes(e.target.value)}
                    placeholder="Record inspection findings or dispatch status..."
                    className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg"
                  />
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    disabled={triageBusy}
                    onClick={() => handleDeleteRecord(selectedComplaint.id)}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/60 hover:bg-red-100 dark:hover:bg-red-900/60 rounded-lg"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete Record
                  </button>

                  <button
                    type="submit"
                    disabled={triageBusy}
                    className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg disabled:opacity-60"
                  >
                    {triageBusy ? 'Saving...' : 'Save Triage Update'}
                  </button>
                </div>
              </form>
            ) : (
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between gap-2">
                <span>
                  Status updates and crew dispatch are restricted to authenticated Administrator accounts.
                </span>
                {!user && (
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedComplaint(null);
                      onNavigate('auth');
                    }}
                    className="text-blue-700 dark:text-blue-400 font-medium hover:underline whitespace-nowrap"
                  >
                    Sign In
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
