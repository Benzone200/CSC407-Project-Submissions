import React, { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import { MUNICIPAL_WARDS } from '../shared/types.ts';
import type { PublicUser } from '../shared/types.ts';
import {
  calculatePasswordStrength,
  validateLogin,
  validateRegistration,
} from '../shared/validation.ts';
import { api, ApiError } from '../services/api.ts';

interface AuthViewProps {
  onAuthenticated: (user: PublicUser) => void;
}

export function AuthView({ onAuthenticated }: AuthViewProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [ward, setWard] = useState<string>(MUNICIPAL_WARDS[0]);
  const [phone, setPhone] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const strength = calculatePasswordStrength(password);

  const switchMode = (nextMode: 'login' | 'register') => {
    setMode(nextMode);
    setFieldErrors({});
    setServerError(null);
  };

  const applyDemoAccount = (role: 'resident' | 'admin') => {
    setMode('login');
    setFieldErrors({});
    setServerError(null);
    if (role === 'admin') {
      setEmail('edache.enenche@civicledger.gov');
      setPassword('AdminCivic#2026');
    } else {
      setEmail('ada.okafor@civicledger.gov');
      setPassword('Resident#2026');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setServerError(null);

    if (mode === 'login') {
      const validation = validateLogin({ email, password });
      if (!validation.ok || !validation.data) {
        setFieldErrors(validation.errors);
        return;
      }
      setFieldErrors({});
      setBusy(true);
      try {
        const res = await api.login(validation.data);
        onAuthenticated(res.user);
      } catch (err) {
        if (err instanceof ApiError) {
          setServerError(err.message);
          if (err.fieldErrors) setFieldErrors(err.fieldErrors);
        } else {
          setServerError('Login failed. Please try again.');
        }
      } finally {
        setBusy(false);
      }
      return;
    }

    const validation = validateRegistration({ fullName, email, password, ward, phone });
    if (!validation.ok || !validation.data) {
      setFieldErrors(validation.errors);
      return;
    }
    setFieldErrors({});
    setBusy(true);
    try {
      const res = await api.register(validation.data);
      onAuthenticated(res.user);
    } catch (err) {
      if (err instanceof ApiError) {
        setServerError(err.message);
        if (err.fieldErrors) setFieldErrors(err.fieldErrors);
      } else {
        setServerError('Registration failed. Please try again.');
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-12 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
      {/* Left Context Panel */}
      <div className="lg:col-span-5 bg-slate-900 dark:bg-slate-950 text-white p-6 sm:p-8 flex flex-col justify-between gap-6 border-b lg:border-b-0 lg:border-r border-slate-800">
        <div className="space-y-4">
          <p className="text-xs font-medium text-slate-300">
            scrypt Hashing · Signed HttpOnly Sessions
          </p>
          <h1 className="font-display text-2xl font-bold tracking-tight text-balance">
            Authenticated Municipal Access
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed">
            Sign in or register a citizen account to file municipal complaints, inspect your active
            session, or evaluate role-based administrative triage controls.
          </p>
        </div>

        <div className="space-y-3 border-t border-slate-800 pt-5">
          <p className="text-xs font-semibold text-slate-300">Municipal Staff &amp; Resident Accounts</p>
          <div className="space-y-2">
            <button
              type="button"
              onClick={() => applyDemoAccount('resident')}
              className="w-full text-left p-3 rounded-lg bg-slate-800 hover:bg-slate-700/80 transition-colors border border-slate-700"
            >
              <div className="flex items-center justify-between text-xs font-semibold text-white">
                <span>Fill Resident Account</span>
                <span className="font-mono text-slate-300">role: resident</span>
              </div>
              <p className="font-mono text-xs text-slate-300 mt-1 truncate">
                ada.okafor@civicledger.gov
              </p>
            </button>

            <button
              type="button"
              onClick={() => applyDemoAccount('admin')}
              className="w-full text-left p-3 rounded-lg bg-slate-800 hover:bg-slate-700/80 transition-colors border border-slate-700"
            >
              <div className="flex items-center justify-between text-xs font-semibold text-white">
                <span>Fill Municipal Admin</span>
                <span className="font-mono text-blue-300">role: admin</span>
              </div>
              <p className="font-mono text-xs text-slate-300 mt-1 truncate">
                edache.enenche@civicledger.gov
              </p>
            </button>
          </div>
        </div>
      </div>

      {/* Right Form Panel */}
      <div className="lg:col-span-7 p-6 sm:p-8 space-y-6">
        <div
          role="tablist"
          aria-label="Authentication mode"
          className="inline-flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg"
        >
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'login'}
            onClick={() => switchMode('login')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors ${
              mode === 'login'
                ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'register'}
            onClick={() => switchMode('register')}
            className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-colors ${
              mode === 'register'
                ? 'bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Create Account
          </button>
        </div>

        <form onSubmit={handleSubmit} noValidate className="space-y-4">
          {serverError && (
            <div
              role="alert"
              className="p-3 text-sm text-red-800 dark:text-red-300 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 rounded-lg"
            >
              {serverError}
            </div>
          )}

          {mode === 'register' && (
            <div>
              <label
                htmlFor="auth-fullname"
                className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1"
              >
                Full Name
              </label>
              <input
                id="auth-fullname"
                type="text"
                autoComplete="name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g., Chinedu Eze"
                className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
              {fieldErrors.fullName && (
                <p className="mt-1 text-xs text-red-700 dark:text-red-400">{fieldErrors.fullName}</p>
              )}
            </div>
          )}

          <div>
            <label
              htmlFor="auth-email"
              className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1"
            >
              Email Address
            </label>
            <input
              id="auth-email"
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@civicledger.gov"
              className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
            {fieldErrors.email && (
              <p className="mt-1 text-xs text-red-700 dark:text-red-400">{fieldErrors.email}</p>
            )}
          </div>

          <div>
            <label
              htmlFor="auth-password"
              className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1"
            >
              Password
            </label>
            <div className="relative">
              <input
                id="auth-password"
                type={showPassword ? 'text' : 'password'}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={
                  mode === 'register' ? 'Min. 8 chars, 1 uppercase, 1 number' : 'Enter your password'
                }
                className="w-full pl-3.5 pr-11 py-2.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 rounded"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {fieldErrors.password && (
              <p className="mt-1 text-xs text-red-700 dark:text-red-400">{fieldErrors.password}</p>
            )}

            {mode === 'register' && password.length > 0 && (
              <div className="mt-2 flex items-center justify-between text-xs">
                <span className="text-slate-500 dark:text-slate-400">Password strength</span>
                <span
                  className={`font-semibold ${
                    strength.label === 'Strong'
                      ? 'text-emerald-700 dark:text-emerald-400'
                      : strength.label === 'Fair'
                        ? 'text-amber-700 dark:text-amber-400'
                        : 'text-red-700 dark:text-red-400'
                  }`}
                >
                  {strength.label}
                </span>
              </div>
            )}
          </div>

          {mode === 'register' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="auth-ward"
                  className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1"
                >
                  Municipal Ward
                </label>
                <select
                  id="auth-ward"
                  value={ward}
                  onChange={(e) => setWard(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  {MUNICIPAL_WARDS.map((w) => (
                    <option key={w} value={w}>
                      {w}
                    </option>
                  ))}
                </select>
                {fieldErrors.ward && (
                  <p className="mt-1 text-xs text-red-700 dark:text-red-400">{fieldErrors.ward}</p>
                )}
              </div>

              <div>
                <label
                  htmlFor="auth-phone"
                  className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1"
                >
                  Phone Number (Optional)
                </label>
                <input
                  id="auth-phone"
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+234 800 000 0000"
                  className="w-full px-3.5 py-2.5 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                {fieldErrors.phone && (
                  <p className="mt-1 text-xs text-red-700 dark:text-red-400">{fieldErrors.phone}</p>
                )}
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full mt-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors disabled:opacity-60"
          >
            {busy
              ? 'Authenticating...'
              : mode === 'login'
                ? 'Sign In to CivicLedger'
                : 'Register Citizen Account'}
          </button>
        </form>
      </div>
    </div>
  );
}
