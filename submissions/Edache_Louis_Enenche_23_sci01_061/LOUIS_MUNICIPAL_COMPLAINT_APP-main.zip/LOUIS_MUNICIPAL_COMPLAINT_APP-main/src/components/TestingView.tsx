import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Play } from 'lucide-react';
import type { LiveTestCheckResult } from '../shared/types.ts';
import { api } from '../services/api.ts';

const CATEGORIES = [
  'All',
  'Functional',
  'Login & Registration',
  'Form Validation',
  'Security',
  'Usability',
  'Responsive & Mobile',
  'Error Handling',
  'Database',
] as const;

export function TestingView() {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [liveResults, setLiveResults] = useState<LiveTestCheckResult[]>([]);
  const [lastRunAt, setLastRunAt] = useState<string | null>(null);
  const [running, setRunning] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const handleRunLiveSuite = useCallback(async () => {
    setRunning(true);
    setError(null);
    try {
      const response = await api.runLiveVerificationSuite();

      // Real live DOM usability & accessibility landmark check
      const tUx = performance.now();
      const hasMain = Boolean(document.querySelector('main'));
      const hasNav = Boolean(document.querySelector('nav'));
      const interactiveButtons = document.querySelectorAll('button').length;
      const unlabeledInputs = Array.from(
        document.querySelectorAll('input, select, textarea'),
      ).filter((el) => {
        const id = el.getAttribute('id');
        const hasFor = id ? Boolean(document.querySelector(`label[for="${id}"]`)) : false;
        const hasAria = Boolean(el.getAttribute('aria-label') || el.getAttribute('aria-labelledby'));
        return !hasFor && !hasAria;
      }).length;
      const uxCheck: LiveTestCheckResult = {
        id: 'UX-01',
        category: 'Usability',
        name: 'Live DOM accessibility landmarks & labeled form controls',
        expectedResult: 'Semantic <main>/<nav> landmarks present and 0 unlabeled form inputs',
        actualResult: `Main=${hasMain}, Nav=${hasNav}, Buttons=${interactiveButtons}, UnlabeledInputs=${unlabeledInputs}`,
        status: hasMain && hasNav && unlabeledInputs === 0 ? 'Pass' : 'Fail',
        durationMs: Math.max(1, Math.round(performance.now() - tUx)),
        automated: true,
      };

      // Real viewport overflow & responsive layout check
      const tMob = performance.now();
      const clientMobileCheck: LiveTestCheckResult = {
        id: 'MOB-01',
        category: 'Responsive & Mobile',
        name: 'Live viewport overflow & responsive layout check',
        expectedResult: 'Document scrollWidth <= innerWidth without horizontal overflow',
        actualResult: `Viewport=${window.innerWidth}px, ScrollWidth=${document.documentElement.scrollWidth}px`,
        status: document.documentElement.scrollWidth <= window.innerWidth + 1 ? 'Pass' : 'Fail',
        durationMs: Math.max(1, Math.round(performance.now() - tMob)),
        automated: true,
      };

      setLiveResults([...response.results, uxCheck, clientMobileCheck]);
      setLastRunAt(response.executedAt);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to execute live verification suite.');
    } finally {
      setRunning(false);
    }
  }, []);

  useEffect(() => {
    handleRunLiveSuite();
  }, [handleRunLiveSuite]);

  const filteredRows = useMemo(() => {
    if (selectedCategory === 'All') return liveResults;
    return liveResults.filter((row) => row.category === selectedCategory);
  }, [liveResults, selectedCategory]);

  const passCount = filteredRows.filter((r) => r.status === 'Pass').length;

  return (
    <div className="space-y-8">
      <section className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div className="space-y-1.5">
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100">
            Testing & Quality Assurance Matrix
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300 max-w-2xl">
            Executes real server-side SQLite transactions, scrypt checks, RBAC probes, input
            validation assertions, and live browser DOM audits across all 8 required testing
            disciplines.
          </p>
        </div>

        <button
          type="button"
          onClick={handleRunLiveSuite}
          disabled={running}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-60"
        >
          <Play className="w-4 h-4" />
          {running ? 'Running Live Probes...' : 'Re-run Live Verification Suite'}
        </button>
      </section>

      {/* Summary Strip */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Live Checks Executed
          </p>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
            {filteredRows.length}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Passing Assertions
          </p>
          <p className="mt-2 font-mono text-2xl font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
            {passCount} / {filteredRows.length}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Test Execution</p>
          <p className="mt-2 font-mono text-sm font-semibold text-slate-900 dark:text-slate-100">
            Live API + node:test
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Last Live Execution
          </p>
          <p className="mt-2 font-mono text-xs font-semibold text-slate-700 dark:text-slate-300 tabular-nums">
            {lastRunAt ? new Date(lastRunAt).toLocaleTimeString() : 'Executing...'}
          </p>
        </div>
      </section>

      {error && (
        <div
          role="alert"
          className="p-4 text-sm text-red-800 dark:text-red-300 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 rounded-xl"
        >
          {error}
        </div>
      )}

      {/* Category Filter Bar + Table */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-1.5">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {running && liveResults.length === 0 ? (
          <div className="p-6 space-y-3" aria-busy="true">
            {[1, 2, 3, 4].map((row) => (
              <div key={row} className="h-10 bg-slate-100 dark:bg-slate-800 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 text-xs font-semibold text-slate-600 dark:text-slate-300">
                  <th className="py-3 px-4">ID</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Test Case</th>
                  <th className="py-3 px-4">Expected Result</th>
                  <th className="py-3 px-4">Actual Result (Live)</th>
                  <th className="py-3 px-4 text-right">Duration</th>
                  <th className="py-3 px-4 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 text-xs sm:text-sm">
                {filteredRows.map((row) => (
                  <tr key={row.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                    <td className="py-3.5 px-4 font-mono text-xs font-semibold text-slate-700 dark:text-slate-300 whitespace-nowrap">
                      {row.id}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-600 dark:text-slate-300 whitespace-nowrap">
                      {row.category}
                    </td>
                    <td className="py-3.5 px-4 font-medium text-slate-900 dark:text-slate-100 min-w-[200px]">
                      {row.name}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-600 dark:text-slate-300 min-w-[180px]">
                      {row.expectedResult}
                    </td>
                    <td className="py-3.5 px-4 text-xs font-mono text-slate-700 dark:text-slate-200 min-w-[200px]">
                      {row.actualResult}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-xs text-slate-600 dark:text-slate-300 tabular-nums whitespace-nowrap">
                      {row.durationMs} ms
                    </td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <span
                        className={`text-xs font-semibold ${
                          row.status === 'Pass'
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : 'text-red-700 dark:text-red-400'
                        }`}
                      >
                        {row.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
