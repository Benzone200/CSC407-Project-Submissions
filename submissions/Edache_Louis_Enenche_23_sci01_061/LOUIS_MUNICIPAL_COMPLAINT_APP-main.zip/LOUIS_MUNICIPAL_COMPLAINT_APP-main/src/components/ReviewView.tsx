import React, { useEffect, useState } from 'react';
import type { Complaint, HealthReport } from '../shared/types.ts';
import { api } from '../services/api.ts';

interface ReviewViewProps {
  complaints: Complaint[];
}

export function ReviewView({ complaints }: ReviewViewProps) {
  const [health, setHealth] = useState<HealthReport | null>(null);

  useEffect(() => {
    api.getHealth().then(setHealth).catch(() => setHealth(null));
  }, []);

  const totalTickets = health?.complaintCount ?? complaints.length;
  const resolvedCount =
    health?.resolvedCount ?? complaints.filter((c) => c.status === 'Resolved').length;

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header Summary */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 space-y-3">
        <p className="text-xs font-semibold text-blue-700 dark:text-blue-400">
          Semi-Project Evaluation Report · Prepared for Edache Louis Enenche
        </p>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-slate-100 text-balance">
          Building Web Applications: Web Application Security, Testing, Deployment and Review
        </h1>
        <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
          This review evaluates the CivicLedger Municipal Complaint Management System across its
          functional capabilities, implemented defensive security architecture, live verification
          test results, deployment readiness, encountered challenges, and roadmap for scaling.
        </p>
      </section>

      {/* 1 & 2: Purpose & Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            01. What the Application Does
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            CivicLedger digitizes municipal service delivery by enabling residents to report civic
            infrastructure issues (potholes, streetlights, stormwater drainage, sanitation, and
            public safety) and track resolution progress in real time, while municipal
            administrators triage tickets by priority and assign maintenance departments.
          </p>
        </section>

        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            02. Features Implemented
          </h2>
          <ul className="text-sm text-slate-600 dark:text-slate-300 space-y-1.5 list-disc pl-4">
            <li>Responsive dashboard with live KPI counters, keyword search, and multi-facet filters.</li>
            <li>Authenticated citizen registration, login, logout, and user profile management.</li>
            <li>Structured municipal complaint submission form with inline and server validation.</li>
            <li>Role-based admin triage workflow, Security Lab, live Testing Matrix, and Deployment monitor.</li>
          </ul>
        </section>
      </div>

      {/* 3 & 4: Security & Testing Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            03. Security Measures Summary
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            Security is implemented as real server-side enforcement rather than UI-only checks:
            salted <span className="font-mono text-xs">scrypt</span> password hashing, HMAC-signed{' '}
            <span className="font-mono text-xs">HttpOnly</span> cookies, strict role middleware (
            <span className="font-mono text-xs">requireAuth</span> /{' '}
            <span className="font-mono text-xs">requireAdmin</span>), 100% parameterized SQLite
            queries preventing SQL injection, HTML entity escaping + CSP headers mitigating XSS, and
            audit logging of denied requests.
          </p>
        </section>

        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            04. Testing Results & Live System Snapshot
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            Automated <span className="font-mono text-xs">node:test</span> unit assertions, live
            server-side SQLite/crypto probes, and live browser DOM checks verify all 8 testing
            disciplines: Functional, Login/Registration, Form Validation, Security, Usability,
            Responsive/Mobile, Error Handling, and Database Persistence.
          </p>
          <p className="font-mono text-xs text-slate-800 dark:text-slate-200 pt-1 tabular-nums">
            Live DB Snapshot: {totalTickets} tickets ({resolvedCount} resolved) ·{' '}
            {health ? `${health.userCount} users · ${health.auditLogCount} audit events` : 'loading telemetry...'}
          </p>
        </section>
      </div>

      {/* 5, 6, 7, 8: Performance, Problems, Limitations, Future Improvements */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-200 dark:divide-slate-800">
        <div className="p-6 space-y-2">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            05. Performance Observations
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            Enabling SQLite Write-Ahead Logging (<span className="font-mono text-xs">WAL</span>{' '}
            status: {health?.walEnabled ? 'ACTIVE' : 'Checking'}) allows concurrent dashboard reads
            alongside complaint writes without table-level read stalls. Vite production bundling
            emits a single minified SPA payload served directly by Express in production mode.
          </p>
        </div>

        <div className="p-6 space-y-2">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            06. Problems Encountered
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            Balancing strict <span className="font-mono text-xs">Content-Security-Policy</span>{' '}
            framing rules and cross-site <span className="font-mono text-xs">SameSite</span> cookie
            policies inside embedded HTTPS preview iframes required migrating from{' '}
            <span className="font-mono text-xs">X-Frame-Options: DENY</span> to an explicit{' '}
            <span className="font-mono text-xs">frame-ancestors</span> allowlist and inspecting{' '}
            <span className="font-mono text-xs">X-Forwarded-Proto</span> behind TLS proxies.
          </p>
        </div>

        <div className="p-6 space-y-2">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            07. Current System Limitations
          </h2>
          <ul className="text-sm text-slate-600 dark:text-slate-300 space-y-1.5 list-disc pl-4">
            <li>
              Single-node SQLite storage is ideal for municipal pilot scale but does not support
              multi-region horizontal write replication without migrating to PostgreSQL.
            </li>
            <li>
              Failed login attempts are logged in the audit trail, though distributed IP-level
              lockout throttling across multiple container replicas is not yet enabled.
            </li>
            <li>
              Citizen submissions currently accept structured text and street addresses without
              image file uploads or GPS coordinate map pins.
            </li>
          </ul>
        </div>

        <div className="p-6 space-y-2">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            08. Possible Future Improvements
          </h2>
          <ul className="text-sm text-slate-600 dark:text-slate-300 space-y-1.5 list-disc pl-4">
            <li>Migrate persistence layer to managed Cloud SQL (PostgreSQL) with automated read replicas.</li>
            <li>Add interactive geospatial ward maps and verified photo evidence uploads with EXIF stripping.</li>
            <li>Integrate SMS/email status notifications when municipal crews transition a ticket to Resolved.</li>
            <li>Implement MFA (TOTP) and automated brute-force throttling for administrator accounts.</li>
          </ul>
        </div>
      </section>

      <section className="bg-slate-900 dark:bg-slate-800 text-white rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="font-display text-sm font-semibold">
            CivicLedger Semi-Project Deliverable Complete
          </p>
          <p className="text-xs text-slate-300">
            Author: Edache Louis Enenche · Municipal Complaint Management System
          </p>
        </div>
        <span className="font-mono text-xs text-slate-300">
          Security · Testing · Deployment · Review
        </span>
      </section>
    </div>
  );
}
