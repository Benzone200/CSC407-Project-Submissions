import React, { useEffect, useState } from 'react';
import type {
  PublicUser,
  SecurityHeaderReport,
  SecurityLabSqlResult,
} from '../shared/types.ts';
import { api, ApiError } from '../services/api.ts';

interface SecurityViewProps {
  user: PublicUser | null;
}

const SECURITY_CONTROLS = [
  {
    title: 'User Authentication & Logout',
    mechanism: 'POST /api/auth/register, /login, /logout with timing-safe verification',
    detail:
      'Credentials are validated server-side; logout deletes the SHA-256 session digest from SQLite and clears the cookie.',
  },
  {
    title: 'Password Hashing (scrypt)',
    mechanism: 'crypto.scryptSync(password, random16ByteSalt, 64) + timingSafeEqual',
    detail:
      'Plaintext passwords are never persisted or logged. Each user receives a unique 16-byte cryptographic salt.',
  },
  {
    title: 'Role-Based Access Control (RBAC)',
    mechanism: 'requireAuth & requireAdmin middleware enforcing resident vs admin roles',
    detail:
      'Complaint triage, record deletion, and audit-log endpoints enforce server-side role checks returning HTTP 401/403.',
  },
  {
    title: 'Input Validation & Sanitization',
    mechanism: 'Shared schema validators in src/shared/validation.ts',
    detail:
      'Control characters are stripped, lengths are bounded, and emails, wards, categories, and priorities are strictly checked.',
  },
  {
    title: 'SQL Injection Protection',
    mechanism: '100% parameterized SQLite prepared statements (? placeholders)',
    detail:
      'User inputs are bound as literal parameters rather than interpolated into SQL strings, neutralizing tautologies and DDL attacks.',
  },
  {
    title: 'Cross-Site Scripting (XSS) Defense',
    mechanism: 'React JSX escaping, HTML entity encoding, and Content-Security-Policy',
    detail:
      'No dangerouslySetInnerHTML is used anywhere; CSP restricts script execution and framing.',
  },
  {
    title: 'Session Management',
    mechanism: '32-byte random token, HMAC-SHA256 signed HttpOnly cookie',
    detail:
      'Cookies cannot be read by JavaScript (HttpOnly), use SameSite=None; Secure over HTTPS previews, and expire after 7 days.',
  },
  {
    title: 'Access-Control & Ownership Checks',
    mechanism: 'Server-derived identity (req.currentUser.id) rather than client-supplied IDs',
    detail:
      'Profile edits and personal complaint queries always read the user ID from the verified server-side session record.',
  },
  {
    title: 'Sensitive Information Protection',
    mechanism: 'Explicit DTO column projections excluding password_hash & raw tokens',
    detail:
      'API responses never serialize password_hash; operational logs mask user email addresses.',
  },
  {
    title: 'HTTPS & HTTP Security Headers',
    mechanism: 'CSP frame-ancestors, nosniff, Referrer-Policy, Permissions-Policy, HSTS',
    detail:
      'Express sets defense-in-depth headers on every HTTP response while permitting trusted preview framing.',
  },
];

export function SecurityView({ user }: SecurityViewProps) {
  const [sqliInput, setSqliInput] = useState("' OR '1'='1'; DROP TABLE complaints;--");
  const [sqliResult, setSqliResult] = useState<SecurityLabSqlResult | null>(null);
  const [sqliBusy, setSqliBusy] = useState(false);

  const [xssInput, setXssInput] = useState('<script>alert("XSS")</script><img src=x onerror=alert(1)>');
  const [xssResult, setXssResult] = useState<{
    payload: string;
    rawLength: number;
    escapedOutput: string;
    detectedVectors: string[];
  } | null>(null);
  const [xssBusy, setXssBusy] = useState(false);

  const [rbacStatus, setRbacStatus] = useState<{
    httpStatus: number;
    outcome: string;
    detail: string;
    users?: PublicUser[];
  } | null>(null);
  const [rbacBusy, setRbacBusy] = useState(false);

  const [headerReport, setHeaderReport] = useState<SecurityHeaderReport | null>(null);

  useEffect(() => {
    api
      .getSecurityHeaders()
      .then(setHeaderReport)
      .catch(() => setHeaderReport(null));
  }, []);

  const runSqliProbe = async (payloadOverride?: string) => {
    const target = payloadOverride ?? sqliInput;
    if (payloadOverride !== undefined) setSqliInput(payloadOverride);
    setSqliBusy(true);
    try {
      const res = await api.testSqlInjection(target);
      setSqliResult(res);
    } finally {
      setSqliBusy(false);
    }
  };

  const runXssProbe = async (payloadOverride?: string) => {
    const target = payloadOverride ?? xssInput;
    if (payloadOverride !== undefined) setXssInput(payloadOverride);
    setXssBusy(true);
    try {
      const res = await api.testXssNeutralizer(target);
      setXssResult(res);
    } finally {
      setXssBusy(false);
    }
  };

  const runRbacCheck = async () => {
    setRbacBusy(true);
    try {
      const data = await api.getAdminAudit();
      setRbacStatus({
        httpStatus: 200,
        outcome: 'Authorized (Admin)',
        detail: `Server returned HTTP 200 OK with ${data.logs.length} audit events and ${data.users.length} user records.`,
        users: data.users,
      });
    } catch (err) {
      if (err instanceof ApiError) {
        setRbacStatus({
          httpStatus: err.status,
          outcome: err.status === 401 ? 'Blocked (Unauthenticated 401)' : 'Blocked (Forbidden 403)',
          detail: err.message,
        });
      }
    } finally {
      setRbacBusy(false);
    }
  };

  return (
    <div className="space-y-8">
      <section className="space-y-2">
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100">
          Web Application Security Architecture & Interactive Lab
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300 max-w-3xl leading-relaxed">
          Every security control documented below is actively enforced in the Express backend,
          SQLite data layer, and React frontend. Use the interactive probes to test SQL injection
          parameterization, XSS neutralization, and role-based access enforcement live.
        </p>
      </section>

      {/* 10 Implemented Security Controls Matrix */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-200 dark:border-slate-800">
          <h2 className="font-display text-lg font-semibold text-slate-900 dark:text-slate-100">
            Implemented Security Controls (10 Core Pillars)
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:gap-px bg-slate-200 dark:bg-slate-800">
          {SECURITY_CONTROLS.map((ctrl, idx) => (
            <div key={ctrl.title} className="bg-white dark:bg-slate-900 p-5 space-y-1.5">
              <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                {String(idx + 1).padStart(2, '0')}. {ctrl.title}
              </h3>
              <p className="font-mono text-xs text-blue-700 dark:text-blue-400">{ctrl.mechanism}</p>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {ctrl.detail}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Interactive Security Probes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* SQL Injection Parameterization Simulator */}
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Live SQL Injection Neutralization Lab
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Sends your payload to <span className="font-mono">POST /api/security/test-sqli</span>{' '}
            and executes a real SQLite prepared statement against the live database.
          </p>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => runSqliProbe("' OR '1'='1")}
              className="px-2.5 py-1 text-xs font-mono bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded text-slate-700 dark:text-slate-200"
            >
              &apos; OR &apos;1&apos;=&apos;1
            </button>
            <button
              type="button"
              onClick={() => runSqliProbe("'; DROP TABLE complaints;--")}
              className="px-2.5 py-1 text-xs font-mono bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded text-slate-700 dark:text-slate-200"
            >
              &apos;; DROP TABLE complaints;--
            </button>
            <button
              type="button"
              onClick={() => runSqliProbe('Streetlight')}
              className="px-2.5 py-1 text-xs font-mono bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded text-slate-700 dark:text-slate-200"
            >
              Streetlight (Benign)
            </button>
          </div>

          <div className="flex gap-2">
            <label htmlFor="sqli-probe-input" className="sr-only">
              SQL injection test payload
            </label>
            <input
              id="sqli-probe-input"
              type="text"
              value={sqliInput}
              onChange={(e) => setSqliInput(e.target.value)}
              className="flex-1 min-w-0 px-3 py-2 text-xs font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg"
            />
            <button
              type="button"
              disabled={sqliBusy}
              onClick={() => runSqliProbe()}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
            >
              {sqliBusy ? 'Testing...' : 'Test SQLi'}
            </button>
          </div>

          {sqliResult && (
            <div className="space-y-2.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg p-4">
              <div>
                <p className="font-semibold text-red-700 dark:text-red-400">
                  Vulnerable Concatenation (Avoided)
                </p>
                <pre className="mt-1 font-mono text-slate-700 dark:text-slate-300 whitespace-pre-wrap break-all">
                  {sqliResult.vulnerableQueryPreview}
                </pre>
              </div>
              <div>
                <p className="font-semibold text-emerald-700 dark:text-emerald-400">
                  Actual Parameterized Query Executed
                </p>
                <pre className="mt-1 font-mono text-slate-900 dark:text-slate-100 whitespace-pre-wrap break-all">
                  {sqliResult.parameterizedQueryPreview}
                </pre>
                <p className="mt-1 font-mono text-slate-600 dark:text-slate-400 break-all">
                  Bound param: &quot;{sqliResult.boundParameter}&quot; · Rows matched:{' '}
                  <span className="tabular-nums font-semibold">
                    {sqliResult.matchedRowsInSafeQuery}
                  </span>
                </p>
              </div>
              <p className="text-slate-700 dark:text-slate-300 leading-relaxed">
                {sqliResult.explanation}
              </p>
            </div>
          )}
        </section>

        {/* XSS Neutralizer Sandbox */}
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Live Cross-Site Scripting (XSS) Neutralizer
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Tests <span className="font-mono">POST /api/security/test-xss</span> to inspect how
            executable HTML tags and inline event handlers are entity-encoded prior to rendering.
          </p>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => runXssProbe('<script>alert("XSS")</script>')}
              className="px-2.5 py-1 text-xs font-mono bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded text-slate-700 dark:text-slate-200"
            >
              &lt;script&gt;alert()&lt;/script&gt;
            </button>
            <button
              type="button"
              onClick={() => runXssProbe('<img src=x onerror=alert(document.cookie)>')}
              className="px-2.5 py-1 text-xs font-mono bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded text-slate-700 dark:text-slate-200"
            >
              onerror=alert()
            </button>
          </div>

          <div className="flex gap-2">
            <label htmlFor="xss-probe-input" className="sr-only">
              XSS test payload
            </label>
            <input
              id="xss-probe-input"
              type="text"
              value={xssInput}
              onChange={(e) => setXssInput(e.target.value)}
              className="flex-1 min-w-0 px-3 py-2 text-xs font-mono bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg"
            />
            <button
              type="button"
              disabled={xssBusy}
              onClick={() => runXssProbe()}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg whitespace-nowrap shrink-0"
            >
              {xssBusy ? 'Testing...' : 'Test XSS'}
            </button>
          </div>

          {xssResult && (
            <div className="space-y-2.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg p-4">
              <div>
                <p className="font-semibold text-slate-700 dark:text-slate-200">
                  Detected Attack Vectors
                </p>
                <p className="mt-1 text-slate-600 dark:text-slate-300">
                  {xssResult.detectedVectors.length > 0
                    ? xssResult.detectedVectors.join(' · ')
                    : 'No executable HTML vectors detected'}
                </p>
              </div>
              <div>
                <p className="font-semibold text-emerald-700 dark:text-emerald-400">
                  Neutralized Output (Escaped Entities)
                </p>
                <pre className="mt-1 font-mono text-slate-900 dark:text-slate-100 whitespace-pre-wrap break-all">
                  {xssResult.escapedOutput}
                </pre>
              </div>
            </div>
          )}
        </section>
      </div>

      {/* Live RBAC Access-Control Probe & HTTP Security Headers */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <section className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Live Access-Control Verification
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            Calls the restricted <span className="font-mono">GET /api/admin/audit</span> endpoint
            using your current session (
            {user ? `${user.email} · role: ${user.role}` : 'Unauthenticated'}).
          </p>

          <button
            type="button"
            disabled={rbacBusy}
            onClick={runRbacCheck}
            className="w-full px-4 py-2.5 text-xs font-semibold text-white bg-slate-900 dark:bg-slate-100 dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-200 rounded-lg"
          >
            {rbacBusy ? 'Probing Endpoint...' : 'Probe Restricted Admin Endpoint'}
          </button>

          {rbacStatus && (
            <div
              className={`p-4 rounded-lg border text-xs space-y-2 ${
                rbacStatus.httpStatus === 200
                  ? 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                  : 'bg-amber-50 dark:bg-amber-950/50 border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200'
              }`}
            >
              <p className="font-mono font-semibold">
                HTTP {rbacStatus.httpStatus} — {rbacStatus.outcome}
              </p>
              <p>{rbacStatus.detail}</p>
              {rbacStatus.users && rbacStatus.users.length > 0 && (
                <div className="pt-2 border-t border-emerald-200 dark:border-emerald-800 space-y-1">
                  {rbacStatus.users.map((u) => (
                    <p key={u.id} className="font-mono text-[11px] truncate">
                      {u.fullName} · {u.role} · {u.email}
                    </p>
                  ))}
                </div>
              )}
            </div>
          )}
        </section>

        <section className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
          <div className="space-y-1">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Active HTTP & Cookie Security Headers
            </h2>
            {headerReport && (
              <p className="text-xs font-mono text-slate-500 dark:text-slate-400">
                Transport: {headerReport.transportMode}
              </p>
            )}
          </div>

          {headerReport ? (
            <div className="divide-y divide-slate-200 dark:divide-slate-800 text-xs">
              {headerReport.headers.map((h) => (
                <div key={h.name} className="py-3 space-y-1">
                  <p className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                    {h.name}
                  </p>
                  <p className="text-slate-500 dark:text-slate-400">{h.purpose}</p>
                  <p className="font-mono text-slate-700 dark:text-slate-300 break-all">{h.value}</p>
                </div>
              ))}
              <div className="pt-3 text-slate-600 dark:text-slate-300">
                Session Cookie Policy:{' '}
                <span className="font-mono text-slate-900 dark:text-slate-100">
                  {headerReport.cookiePolicy}
                </span>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Inspecting live response headers...
            </p>
          )}
        </section>
      </div>
    </div>
  );
}
