import React, { useEffect, useState } from 'react';
import { Download } from 'lucide-react';
import type { AuditLogEntry, HealthReport, PublicUser } from '../shared/types.ts';
import { api, ApiError } from '../services/api.ts';

interface DeploymentViewProps {
  user: PublicUser | null;
}

const DEPLOYMENT_SECTIONS = [
  {
    title: '01. Database Configuration',
    summary: 'SQLite in Write-Ahead Logging (WAL) mode with Foreign Key enforcement',
    details: [
      'PRAGMA journal_mode = WAL enables concurrent reads during municipal ticket writes.',
      'PRAGMA foreign_keys = ON guarantees referential integrity between complaints, users, and sessions.',
      'Database file location is parameterized via DATABASE_PATH (default ./data/civicledger.db).',
    ],
  },
  {
    title: '02. Environment Variables',
    summary: 'Zero hardcoded secrets; externalized configuration via .env & Cloud Secrets',
    details: [
      'PORT=3000 configures the Express HTTP listener for containerized reverse proxies.',
      'SESSION_SECRET injects a 256-bit cryptographic HMAC key used to sign session cookies.',
      'NODE_ENV=production switches Express from Vite dev middleware to compiled dist/ static assets.',
    ],
  },
  {
    title: '03. Server Configuration',
    summary: 'Unified Express 4 Node.js server serving API routes + static SPA bundle',
    details: [
      'app.disable("x-powered-by") conceals framework fingerprinting headers.',
      'app.set("trust proxy", 1) respects X-Forwarded-Proto behind TLS load balancers.',
      'JSON body parser is capped at 64kb to mitigate oversized payload denial-of-service attempts.',
    ],
  },
  {
    title: '04. Domain & Hosting Architecture',
    summary: 'Containerized Node.js runtime deployed to Cloud Run / managed Linux host',
    details: [
      'Development runs via tsx server.ts with Vite middleware; production builds with npm run build.',
      'Production starts cleanly via node server.ts serving pre-bundled assets from /dist.',
      'Persistent storage paths or Cloud SQL volumes preserve state across container revisions.',
    ],
  },
  {
    title: '05. HTTPS / SSL & Transport Hardening',
    summary: 'TLS termination at reverse proxy + HSTS & Secure cookie flags',
    details: [
      'Strict-Transport-Security enforces HTTPS for 1 year across subdomains in production.',
      'Session cookies automatically toggle Secure=true whenever X-Forwarded-Proto is https.',
      'Content-Security-Policy restricts script execution and limits framing to trusted preview origins.',
    ],
  },
  {
    title: '06. Backup & Disaster Recovery',
    summary: 'WAL checkpointing & on-demand Admin database snapshot export',
    details: [
      'GET /api/admin/backup runs PRAGMA wal_checkpoint(PASSIVE) before exporting records.',
      'User password hashes and raw session tokens are excluded from exported JSON snapshots.',
      'Every backup export action is recorded in audit_logs for administrative accountability.',
    ],
  },
];

export function DeploymentView({ user }: DeploymentViewProps) {
  const [health, setHealth] = useState<HealthReport | null>(null);
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [backupMessage, setBackupMessage] = useState<string | null>(null);
  const [backupBusy, setBackupBusy] = useState(false);

  const loadTelemetry = () => {
    api.getHealth().then(setHealth).catch(() => setHealth(null));
    api
      .getOperationalLogs()
      .then((res) => setLogs(res.logs))
      .catch(() => setLogs([]));
  };

  useEffect(() => {
    loadTelemetry();
  }, []);

  const handleBackupDownload = async () => {
    setBackupBusy(true);
    setBackupMessage(null);
    try {
      const { filename, content } = await api.downloadAdminBackup();
      const blob = new Blob([content], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = filename;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
      setBackupMessage(`Downloaded ${filename} after SQLite WAL checkpoint.`);
      loadTelemetry();
    } catch (err) {
      setBackupMessage(
        err instanceof ApiError ? err.message : 'Only signed-in Administrators can export backups.',
      );
    } finally {
      setBackupBusy(false);
    }
  };

  const dbSizeKb = health ? (health.dbSizeBytes / 1024).toFixed(1) : '—';

  return (
    <div className="space-y-8">
      <section className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div className="space-y-1.5">
          <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-slate-100">
            Deployment Architecture & Live Operations
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300 max-w-3xl">
            Documents how CivicLedger transitions from local development to a hardened production
            environment, paired with live SQLite diagnostics, admin backup export, and real audit logs.
          </p>
        </div>

        {user?.role === 'admin' && (
          <button
            type="button"
            disabled={backupBusy}
            onClick={handleBackupDownload}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-60"
          >
            <Download className="w-4 h-4" />
            {backupBusy ? 'Exporting Snapshot...' : 'Export SQLite Backup (JSON)'}
          </button>
        )}
      </section>

      {backupMessage && (
        <p className="text-xs font-medium text-blue-800 dark:text-blue-200 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 rounded-lg px-4 py-2.5">
          {backupMessage}
        </p>
      )}

      {/* Live Health & Runtime Telemetry Strip */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Server Runtime</p>
          <p className="mt-2 font-mono text-base font-semibold text-emerald-700 dark:text-emerald-400">
            {health ? `${health.status.toUpperCase()} (${health.nodeVersion})` : 'Checking...'}
          </p>
          <p className="mt-1 font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            Uptime: {health ? `${health.uptimeSeconds}s` : '—'} · Mode: {health?.environment ?? '—'}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">SQLite Engine</p>
          <p className="mt-2 font-mono text-base font-semibold text-slate-900 dark:text-slate-100">
            {health ? `${health.database} · ${dbSizeKb} KB` : 'Checking...'}
          </p>
          <p className="mt-1 font-mono text-xs text-slate-500 dark:text-slate-400">
            WAL: {health?.walEnabled ? 'ON' : '—'} · FK: {health?.foreignKeysEnabled ? 'ON' : '—'}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Persisted Tickets
          </p>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
            {health?.complaintCount ?? '—'}
          </p>
          <p className="mt-1 font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            Resolved: {health?.resolvedCount ?? '—'} · Users: {health?.userCount ?? '—'}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Sessions & Audit Trail
          </p>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
            {health?.auditLogCount ?? '—'}
          </p>
          <p className="mt-1 font-mono text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            Active sessions: {health?.activeSessionCount ?? '—'}
          </p>
        </div>
      </section>

      {/* Deployment Process Steps */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4">
        <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
          Development-to-Production Release Pipeline
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
          {[
            { step: '1. Install', cmd: 'npm ci', desc: 'Lockfile-verified clean install' },
            { step: '2. Unit Test', cmd: 'npx tsx --test', desc: 'Validation, XSS & RBAC tests' },
            { step: '3. Type Check', cmd: 'npm run lint', desc: 'TypeScript strict verification' },
            { step: '4. Build SPA', cmd: 'npm run build', desc: 'Minified Vite bundle to dist/' },
            {
              step: '5. Launch',
              cmd: 'NODE_ENV=production node server.ts',
              desc: 'Serve API + HTTPS headers',
            },
          ].map((item) => (
            <div
              key={item.step}
              className="p-3.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg space-y-1"
            >
              <p className="font-semibold text-slate-900 dark:text-slate-100">{item.step}</p>
              <p className="font-mono text-blue-700 dark:text-blue-400 break-all">{item.cmd}</p>
              <p className="text-slate-500 dark:text-slate-400">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 6 Operational Pillars */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {DEPLOYMENT_SECTIONS.map((sec) => (
          <div
            key={sec.title}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3"
          >
            <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              {sec.title}
            </h3>
            <p className="text-xs font-medium text-slate-700 dark:text-slate-200">{sec.summary}</p>
            <ul className="space-y-1.5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 list-disc pl-4">
              {sec.details.map((line) => (
                <li key={line}>{line}</li>
              ))}
            </ul>
          </div>
        ))}
      </section>

      {/* Live Error & Security Audit Log Stream */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-200 dark:border-slate-800">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            Error & Security Event Monitoring (Live SQLite Audit Feed)
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Recent authentication, RBAC enforcement, backup, and SQLi probe events with masked PII emails.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 font-semibold text-slate-600 dark:text-slate-300">
                <th className="py-2.5 px-4">Timestamp</th>
                <th className="py-2.5 px-4">Event</th>
                <th className="py-2.5 px-4">Actor (Masked)</th>
                <th className="py-2.5 px-4">Outcome</th>
                <th className="py-2.5 px-4">Detail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-2.5 px-4 font-mono text-slate-500 dark:text-slate-400 tabular-nums whitespace-nowrap">
                    {new Date(log.createdAt).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-4 font-mono font-semibold text-slate-800 dark:text-slate-200 whitespace-nowrap">
                    {log.eventType}
                  </td>
                  <td className="py-2.5 px-4 font-mono text-slate-600 dark:text-slate-300 whitespace-nowrap">
                    {log.actorEmail} ({log.actorRole})
                  </td>
                  <td
                    className={`py-2.5 px-4 font-mono font-semibold whitespace-nowrap ${
                      log.outcome === 'SUCCESS'
                        ? 'text-emerald-700 dark:text-emerald-400'
                        : log.outcome === 'BLOCKED'
                          ? 'text-blue-700 dark:text-blue-400'
                          : 'text-red-700 dark:text-red-400'
                    }`}
                  >
                    {log.outcome}
                  </td>
                  <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300 min-w-[240px]">
                    {log.detail}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
