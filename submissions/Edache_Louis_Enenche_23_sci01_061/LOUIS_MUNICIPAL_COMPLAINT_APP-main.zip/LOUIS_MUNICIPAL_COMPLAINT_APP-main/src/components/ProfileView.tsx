import React, { useEffect, useState } from 'react';
import { MUNICIPAL_WARDS } from '../shared/types.ts';
import type { AppSection, Complaint, PublicUser, SessionInfo } from '../shared/types.ts';
import { validateProfileUpdate } from '../shared/validation.ts';
import { api, ApiError } from '../services/api.ts';

interface ProfileViewProps {
  user: PublicUser | null;
  session: SessionInfo | null;
  onUserUpdated: (user: PublicUser) => void;
  onNavigate: (section: AppSection) => void;
}

export function ProfileView({
  user,
  session,
  onUserUpdated,
  onNavigate,
}: ProfileViewProps) {
  const [fullName, setFullName] = useState(user?.fullName ?? '');
  const [ward, setWard] = useState(user?.ward ?? MUNICIPAL_WARDS[0]);
  const [phone, setPhone] = useState(user?.phone ?? '');
  const [profileErrors, setProfileErrors] = useState<Record<string, string>>({});
  const [profileStatus, setProfileStatus] = useState<string | null>(null);
  const [profileBusy, setProfileBusy] = useState(false);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [passwordStatus, setPasswordStatus] = useState<{ ok: boolean; text: string } | null>(null);
  const [passwordBusy, setPasswordBusy] = useState(false);

  const [myComplaints, setMyComplaints] = useState<Complaint[]>([]);

  useEffect(() => {
    if (!user) return;
    setFullName(user.fullName);
    setWard(user.ward);
    setPhone(user.phone);
    api
      .listComplaints({ mine: true })
      .then((res) => setMyComplaints(res.complaints))
      .catch(() => setMyComplaints([]));
  }, [user]);

  if (!user) {
    return (
      <section className="max-w-xl mx-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center space-y-4">
        <h1 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">
          Sign In to View Profile
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300">
          Your profile, active cryptographic session metadata, and complaint history are protected
          behind authentication.
        </p>
        <button
          type="button"
          onClick={() => onNavigate('auth')}
          className="px-5 py-2.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg"
        >
          Go to Sign In
        </button>
      </section>
    );
  }

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileStatus(null);
    const validation = validateProfileUpdate({ fullName, ward, phone });
    if (!validation.ok || !validation.data) {
      setProfileErrors(validation.errors);
      return;
    }

    setProfileErrors({});
    setProfileBusy(true);
    try {
      const res = await api.updateProfile(validation.data);
      onUserUpdated(res.user);
      setProfileStatus('Profile updated and persisted in SQLite.');
    } catch (err) {
      setProfileStatus(err instanceof ApiError ? err.message : 'Unable to update profile.');
    } finally {
      setProfileBusy(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordStatus(null);
    setPasswordBusy(true);
    try {
      await api.changePassword(currentPassword, newPassword);
      setCurrentPassword('');
      setNewPassword('');
      setPasswordStatus({
        ok: true,
        text: 'Password re-hashed with a fresh 16-byte random salt.',
      });
    } catch (err) {
      setPasswordStatus({
        ok: false,
        text: err instanceof ApiError ? err.message : 'Password update failed.',
      });
    } finally {
      setPasswordBusy(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Account Summary Header */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <img
            src={user.avatarUrl || '/src/assets/images/avatar_citizen_1794860881512.jpg'}
            alt={user.fullName}
            referrerPolicy="no-referrer"
            className="w-16 h-16 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
          />
          <div>
            <h1 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100">
              {user.fullName}
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-300 mt-0.5">
              {user.email} · {user.role === 'admin' ? 'Municipal Administrator' : 'Verified Resident'} ·{' '}
              {user.ward}
            </p>
          </div>
        </div>

        <div className="text-xs text-slate-500 dark:text-slate-400 space-y-1 font-mono tabular-nums">
          <p>Member since: {new Date(user.createdAt).toLocaleDateString()}</p>
          {session && <p>Session digest: {session.sessionIdMasked}</p>}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Edit Profile Details */}
        <form
          onSubmit={handleProfileSave}
          className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
        >
          <div className="border-b border-slate-200 dark:border-slate-800 pb-3">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
              Account Profile Details
            </h2>
          </div>

          {profileStatus && (
            <p className="text-xs font-medium text-blue-800 dark:text-blue-200 bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 rounded-lg px-3 py-2">
              {profileStatus}
            </p>
          )}

          <div>
            <label
              htmlFor="profile-name"
              className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1"
            >
              Full Name
            </label>
            <input
              id="profile-name"
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full px-3.5 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg"
            />
            {profileErrors.fullName && (
              <p className="mt-1 text-xs text-red-700 dark:text-red-400">{profileErrors.fullName}</p>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="profile-ward"
                className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1"
              >
                Primary Ward
              </label>
              <select
                id="profile-ward"
                value={ward}
                onChange={(e) => setWard(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg"
              >
                {MUNICIPAL_WARDS.map((w) => (
                  <option key={w} value={w}>
                    {w}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="profile-phone"
                className="block text-sm font-medium text-slate-800 dark:text-slate-200 mb-1"
              >
                Contact Phone
              </label>
              <input
                id="profile-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg"
              />
              {profileErrors.phone && (
                <p className="mt-1 text-xs text-red-700 dark:text-red-400">{profileErrors.phone}</p>
              )}
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              disabled={profileBusy}
              className="px-4 py-2 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg disabled:opacity-60"
            >
              {profileBusy ? 'Saving...' : 'Save Profile Changes'}
            </button>
          </div>
        </form>

        {/* Password Rotation & Session Metadata */}
        <div className="lg:col-span-5 space-y-6">
          <form
            onSubmit={handlePasswordChange}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4"
          >
            <div className="border-b border-slate-200 dark:border-slate-800 pb-3">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                Change Password
              </h2>
            </div>

            {passwordStatus && (
              <p
                className={`text-xs font-medium rounded-lg px-3 py-2 border ${
                  passwordStatus.ok
                    ? 'text-emerald-800 dark:text-emerald-200 bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800'
                    : 'text-red-800 dark:text-red-200 bg-red-50 dark:bg-red-950/60 border-red-200 dark:border-red-800'
                }`}
              >
                {passwordStatus.text}
              </p>
            )}

            <div>
              <label
                htmlFor="current-password"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
              >
                Current Password
              </label>
              <input
                id="current-password"
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg"
              />
            </div>

            <div>
              <label
                htmlFor="new-password"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1"
              >
                New Password
              </label>
              <input
                id="new-password"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Min. 8 chars, 1 uppercase, 1 number"
                className="w-full px-3 py-2 text-sm bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border border-slate-300 dark:border-slate-700 rounded-lg"
              />
            </div>

            <button
              type="submit"
              disabled={passwordBusy}
              className="w-full px-4 py-2 text-xs font-semibold text-white bg-slate-900 dark:bg-slate-100 dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-200 rounded-lg disabled:opacity-60"
            >
              {passwordBusy ? 'Updating...' : 'Rotate Password Hash'}
            </button>
          </form>

          {session && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-2 text-xs">
              <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100">
                Active Server Session
              </h3>
              <p className="text-slate-600 dark:text-slate-300">
                Token Digest:{' '}
                <span className="font-mono text-slate-900 dark:text-slate-100">
                  {session.sessionIdMasked}
                </span>
              </p>
              <p className="text-slate-600 dark:text-slate-300">
                Expires:{' '}
                <span className="font-mono text-slate-900 dark:text-slate-100 tabular-nums">
                  {new Date(session.expiresAt).toLocaleString()}
                </span>
              </p>
              <p className="text-slate-500 dark:text-slate-400 truncate">Client: {session.userAgent}</p>
            </div>
          )}
        </div>
      </div>

      {/* User's Submitted Complaints */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
            My Submitted Complaints ({myComplaints.length})
          </h2>
          <button
            type="button"
            onClick={() => onNavigate('submit')}
            className="text-xs font-semibold text-blue-700 dark:text-blue-400 hover:underline"
          >
            + File New Issue
          </button>
        </div>

        {myComplaints.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500 dark:text-slate-400">
            You have not submitted any complaints under this account yet.
          </div>
        ) : (
          <div className="divide-y divide-slate-200 dark:divide-slate-800">
            {myComplaints.map((c) => (
              <div
                key={c.id}
                className="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <p className="text-sm font-medium text-slate-900 dark:text-slate-100">{c.title}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    <span className="font-mono">{c.referenceCode}</span> · {c.category} · {c.ward}
                  </p>
                </div>
                <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 whitespace-nowrap">
                  {c.status}
                </span>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
