import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { hashPassword } from './security.ts';
import type {
  AuditLogEntry,
  Complaint,
  ComplaintCategory,
  ComplaintPriority,
  ComplaintStatus,
  PublicUser,
  UserRole,
} from '../shared/types.ts';

let dbInstance: DatabaseSync | null = null;
let activeDbPath: string | null = null;

function resolveDbPath(): string {
  const configured = process.env.DATABASE_PATH || './data/civicledger.db';
  return path.resolve(process.cwd(), configured);
}

export function getActiveDbPath(): string {
  if (activeDbPath) return activeDbPath;
  getDb();
  return activeDbPath ?? resolveDbPath();
}

export function getDb(): DatabaseSync {
  if (dbInstance) return dbInstance;

  let dbPath = resolveDbPath();
  const dir = path.dirname(dbPath);
  try {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.accessSync(dir, fs.constants.W_OK);
  } catch {
    dbPath = path.join(os.tmpdir(), 'civicledger.db');
  }

  const db = new DatabaseSync(dbPath);
  activeDbPath = dbPath;
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('resident', 'admin')),
      ward TEXT NOT NULL,
      phone TEXT NOT NULL DEFAULT '',
      avatar_url TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL,
      user_agent TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS complaints (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reference_code TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      priority TEXT NOT NULL,
      status TEXT NOT NULL,
      ward TEXT NOT NULL,
      address TEXT NOT NULL,
      description TEXT NOT NULL,
      reporter_id INTEGER NOT NULL,
      assigned_department TEXT NOT NULL DEFAULT 'Central Triage Desk',
      resolution_notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_type TEXT NOT NULL,
      actor_email TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      target_resource TEXT NOT NULL,
      outcome TEXT NOT NULL,
      detail TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);

  seedInitialData(db);
  dbInstance = db;
  return dbInstance;
}

function seedInitialData(db: DatabaseSync): void {
  const userCountRow = db.prepare('SELECT COUNT(*) AS count FROM users').get() as { count: number };
  if (userCountRow.count > 0) return;

  const now = new Date();
  const daysAgo = (days: number): string =>
    new Date(now.getTime() - days * 86400_000).toISOString();

  const insertUser = db.prepare(`
    INSERT INTO users (full_name, email, password_hash, role, ward, phone, avatar_url, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const adminPass = hashPassword('AdminCivic#2026');
  const citizenPass = hashPassword('Resident#2026');

  const adminResult = insertUser.run(
    'Edache Louis Enenche',
    'edache.enenche@civicledger.gov',
    adminPass,
    'admin',
    'Ward 1 — Central Business District',
    '+234 800 100 2026',
    '/src/assets/images/avatar_admin_1794860881589.jpg',
    daysAgo(30),
  );

  const citizenResult = insertUser.run(
    'Adaeze Okafor',
    'ada.okafor@civicledger.gov',
    citizenPass,
    'resident',
    'Ward 2 — Garki Area 11',
    '+234 803 442 1980',
    '/src/assets/images/avatar_citizen_1794860881512.jpg',
    daysAgo(21),
  );

  const adminId = Number(adminResult.lastInsertRowid);
  const citizenId = Number(citizenResult.lastInsertRowid);

  const insertComplaint = db.prepare(`
    INSERT INTO complaints (
      reference_code, title, category, priority, status, ward, address,
      description, reporter_id, assigned_department, resolution_notes, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const seedComplaints: Array<{
    ref: string;
    title: string;
    category: ComplaintCategory;
    priority: ComplaintPriority;
    status: ComplaintStatus;
    ward: string;
    address: string;
    description: string;
    reporterId: number;
    dept: string;
    notes: string;
    createdDaysAgo: number;
    updatedDaysAgo: number;
  }> = [
    {
      ref: 'CL-2026-1042',
      title: 'Solar streetlight feeder outage along Ahmadu Bello Way',
      category: 'Street Lighting',
      priority: 'High',
      status: 'In Progress',
      ward: 'Ward 2 — Garki Area 11',
      address: '214 Ahmadu Bello Way, Garki',
      description:
        'Four consecutive LED streetlamp poles between Area 11 Junction and the transit bay have remained unlit since Monday evening, reducing pedestrian visibility.',
      reporterId: citizenId,
      dept: 'Electrical Maintenance Unit',
      notes: 'Bucket truck crew dispatched to inspect underground feeder relay box.',
      createdDaysAgo: 6,
      updatedDaysAgo: 1,
    },
    {
      ref: 'CL-2026-1041',
      title: 'Collapsed storm drain grate at Wuse Market Intersection',
      category: 'Water & Drainage',
      priority: 'Critical',
      status: 'Open',
      ward: 'Ward 3 — Wuse Zone 4',
      address: '88 Herbert Macaulay Way, Wuse Zone 4',
      description:
        'Heavy rainfall dislodged the cast-iron stormwater grate on the eastbound lane, leaving an exposed 45cm drop hazardous to bicycles and commuters.',
      reporterId: citizenId,
      dept: 'Stormwater & Water Utility',
      notes: 'Safety cones placed on site; structural replacement grate queued for dispatch.',
      createdDaysAgo: 2,
      updatedDaysAgo: 2,
    },
    {
      ref: 'CL-2026-1040',
      title: 'Deep roadway pothole cluster outside Central Primary School',
      category: 'Roads & Potholes',
      priority: 'High',
      status: 'In Review',
      ward: 'Ward 1 — Central Business District',
      address: '15 Tafawa Balewa Road, CBD',
      description:
        'Three interconnected asphalt potholes near the school pedestrian crossing are pooling rainwater and forcing buses to swerve toward the curb.',
      reporterId: adminId,
      dept: 'Roads & Civil Works',
      notes: 'Civil inspector scheduled site measurement for cold-patch resurfacing.',
      createdDaysAgo: 5,
      updatedDaysAgo: 3,
    },
    {
      ref: 'CL-2026-1039',
      title: 'Delayed commercial refuse evacuation at Gwarinpa 3rd Avenue',
      category: 'Waste & Sanitation',
      priority: 'Medium',
      status: 'Resolved',
      ward: 'Ward 5 — Gwarinpa Estate',
      address: '309 3rd Avenue, Gwarinpa',
      description:
        'Scheduled Tuesday municipal compactor pickup was skipped due to temporary utility trench barriers blocking service lane entry.',
      reporterId: citizenId,
      dept: 'Municipal Sanitation Fleet',
      notes: 'Special sweep crew cleared all bins and verified unobstructed access.',
      createdDaysAgo: 10,
      updatedDaysAgo: 4,
    },
    {
      ref: 'CL-2026-1038',
      title: 'Malfunctioning pedestrian crosswalk signal at Nyanya Link Road',
      category: 'Public Safety',
      priority: 'Critical',
      status: 'In Progress',
      ward: 'Ward 6 — Nyanya Transit Corridor',
      address: '501 Nyanya-Karu Expressway',
      description:
        'Walk indicator remains dark during green cycles while audible countdown signal sounds intermittently during peak commuter hours.',
      reporterId: adminId,
      dept: 'Traffic & Civic Safety Ops',
      notes: 'Controller firmware diagnostic completed; replacement pedestrian signal head queued.',
      createdDaysAgo: 4,
      updatedDaysAgo: 1,
    },
    {
      ref: 'CL-2026-1037',
      title: 'Fallen tree limb obstructing Maitama Greenbelt Walkway',
      category: 'Parks & Trees',
      priority: 'Low',
      status: 'Resolved',
      ward: 'Ward 4 — Maitama North',
      address: '19 Aguiyi Ironsi Street, Maitama',
      description:
        'High winds snapped a large limb across the paved pedestrian path near the neighborhood park footbridge.',
      reporterId: citizenId,
      dept: 'Urban Forestry & Parks',
      notes: 'Arborist team sectioned and cleared the limb; walkway fully reopened.',
      createdDaysAgo: 12,
      updatedDaysAgo: 7,
    },
    {
      ref: 'CL-2026-1036',
      title: 'Water main pressure drop and sediment tint on Shehu Shagari Way',
      category: 'Water & Drainage',
      priority: 'High',
      status: 'Open',
      ward: 'Ward 4 — Maitama North',
      address: '42 Shehu Shagari Way, Maitama',
      description:
        'Residents along the 40-block report noticeably low tap pressure and slight sediment tint following overnight valve maintenance.',
      reporterId: citizenId,
      dept: 'Stormwater & Water Utility',
      notes: 'Hydrant flushing notice queued pending pressure gauge reading.',
      createdDaysAgo: 1,
      updatedDaysAgo: 1,
    },
  ];

  for (const c of seedComplaints) {
    insertComplaint.run(
      c.ref,
      c.title,
      c.category,
      c.priority,
      c.status,
      c.ward,
      c.address,
      c.description,
      c.reporterId,
      c.dept,
      c.notes,
      daysAgo(c.createdDaysAgo),
      daysAgo(c.updatedDaysAgo),
    );
  }

  const insertAudit = db.prepare(`
    INSERT INTO audit_logs (event_type, actor_email, actor_role, target_resource, outcome, detail, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  insertAudit.run(
    'SYSTEM_INIT',
    'system@civicledger.gov',
    'system',
    'sqlite://civicledger.db',
    'SUCCESS',
    'Initialized WAL-mode SQLite schema with scrypt-hashed municipal accounts and baseline incident records.',
    daysAgo(7),
  );
  insertAudit.run(
    'COMPLAINT_TRIAGE',
    'edache.enenche@civicledger.gov',
    'admin',
    'complaint:CL-2026-1042',
    'SUCCESS',
    'Assigned ticket to Electrical Maintenance Unit and updated status to In Progress.',
    daysAgo(1),
  );
  insertAudit.run(
    'RBAC_ENFORCEMENT',
    'ada.okafor@civicledger.gov',
    'resident',
    'GET /api/admin/audit',
    'DENIED',
    'Blocked non-admin session from accessing restricted municipal audit trail (HTTP 403).',
    daysAgo(1),
  );
}

export function mapUserRow(row: Record<string, unknown>): PublicUser {
  return {
    id: Number(row.id),
    fullName: String(row.full_name),
    email: String(row.email),
    role: row.role as UserRole,
    ward: String(row.ward),
    phone: String(row.phone ?? ''),
    avatarUrl: String(row.avatar_url ?? ''),
    createdAt: String(row.created_at),
  };
}

export function mapComplaintRow(row: Record<string, unknown>): Complaint {
  return {
    id: Number(row.id),
    referenceCode: String(row.reference_code),
    title: String(row.title),
    category: row.category as ComplaintCategory,
    priority: row.priority as ComplaintPriority,
    status: row.status as ComplaintStatus,
    ward: String(row.ward),
    address: String(row.address),
    description: String(row.description),
    reporterId: Number(row.reporter_id),
    reporterName: String(row.reporter_name ?? 'Municipal Resident'),
    assignedDepartment: String(row.assigned_department),
    resolutionNotes: String(row.resolution_notes ?? ''),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export function mapAuditRow(row: Record<string, unknown>): AuditLogEntry {
  return {
    id: Number(row.id),
    eventType: String(row.event_type),
    actorEmail: String(row.actor_email),
    actorRole: String(row.actor_role),
    targetResource: String(row.target_resource),
    outcome: row.outcome as AuditLogEntry['outcome'],
    detail: String(row.detail),
    createdAt: String(row.created_at),
  };
}

export function recordAuditEvent(params: {
  eventType: string;
  actorEmail: string;
  actorRole: string;
  targetResource: string;
  outcome: AuditLogEntry['outcome'];
  detail: string;
}): void {
  const db = getDb();
  db.prepare(
    `INSERT INTO audit_logs (event_type, actor_email, actor_role, target_resource, outcome, detail, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    params.eventType,
    params.actorEmail,
    params.actorRole,
    params.targetResource,
    params.outcome,
    params.detail,
    new Date().toISOString(),
  );
}
