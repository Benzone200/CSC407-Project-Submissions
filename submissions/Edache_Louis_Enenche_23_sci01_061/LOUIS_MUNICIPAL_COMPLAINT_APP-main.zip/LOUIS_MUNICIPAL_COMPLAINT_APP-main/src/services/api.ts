import type {
  AuditLogEntry,
  Complaint,
  ComplaintInput,
  HealthReport,
  LiveTestCheckResult,
  LoginInput,
  ProfileUpdateInput,
  PublicUser,
  RegistrationInput,
  SecurityHeaderReport,
  SecurityLabSqlResult,
  SessionInfo,
} from '../shared/types.ts';

export class ApiError extends Error {
  status: number;
  fieldErrors?: Record<string, string>;

  constructor(message: string, status: number, fieldErrors?: Record<string, string>) {
    super(message);
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

async function requestJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
    ...init,
  });

  const payload = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ApiError(
      typeof payload.error === 'string' ? payload.error : `Request failed (${res.status})`,
      res.status,
      payload.fieldErrors,
    );
  }
  return payload as T;
}

export const api = {
  getSession: () =>
    requestJson<{ user: PublicUser | null; session: SessionInfo | null }>('/api/auth/me'),

  register: (input: RegistrationInput) =>
    requestJson<{ user: PublicUser }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(input),
    }),

  login: (input: LoginInput) =>
    requestJson<{ user: PublicUser }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(input),
    }),

  logout: () =>
    requestJson<{ ok: boolean }>('/api/auth/logout', {
      method: 'POST',
    }),

  updateProfile: (input: ProfileUpdateInput) =>
    requestJson<{ user: PublicUser }>('/api/profile', {
      method: 'PATCH',
      body: JSON.stringify(input),
    }),

  changePassword: (currentPassword: string, newPassword: string) =>
    requestJson<{ ok: boolean }>('/api/profile/password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, newPassword }),
    }),

  listComplaints: (filters?: {
    q?: string;
    status?: string;
    category?: string;
    priority?: string;
    mine?: boolean;
  }) => {
    const params = new URLSearchParams();
    if (filters?.q) params.set('q', filters.q);
    if (filters?.status && filters.status !== 'All') params.set('status', filters.status);
    if (filters?.category && filters.category !== 'All') params.set('category', filters.category);
    if (filters?.priority && filters?.priority !== 'All') params.set('priority', filters.priority);
    if (filters?.mine) params.set('mine', 'true');
    const qs = params.toString();
    return requestJson<{ complaints: Complaint[] }>(`/api/complaints${qs ? `?${qs}` : ''}`);
  },

  createComplaint: (input: ComplaintInput) =>
    requestJson<{ complaint: Complaint }>('/api/complaints', {
      method: 'POST',
      body: JSON.stringify(input),
    }),

  updateComplaintAdmin: (
    id: number,
    input: { status: string; assignedDepartment: string; resolutionNotes: string },
  ) =>
    requestJson<{ complaint: Complaint }>(`/api/complaints/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(input),
    }),

  deleteComplaintAdmin: (id: number) =>
    requestJson<{ ok: boolean }>(`/api/complaints/${id}`, {
      method: 'DELETE',
    }),

  getAdminAudit: () =>
    requestJson<{ logs: AuditLogEntry[]; users: PublicUser[] }>('/api/admin/audit'),

  downloadAdminBackup: async (): Promise<{ filename: string; content: string }> => {
    const res = await fetch('/api/admin/backup', { credentials: 'include' });
    if (!res.ok) {
      const payload = await res.json().catch(() => ({}));
      throw new ApiError(
        typeof payload.error === 'string' ? payload.error : `Backup failed (${res.status})`,
        res.status,
      );
    }
    const content = await res.text();
    const disposition = res.headers.get('Content-Disposition') ?? '';
    const match = /filename="([^"]+)"/.exec(disposition);
    return {
      filename: match?.[1] ?? `civicledger-backup-${new Date().toISOString().slice(0, 10)}.json`,
      content,
    };
  },

  getOperationalLogs: () =>
    requestJson<{ logs: AuditLogEntry[] }>('/api/operations/logs'),

  testSqlInjection: (payload: string) =>
    requestJson<SecurityLabSqlResult>('/api/security/test-sqli', {
      method: 'POST',
      body: JSON.stringify({ payload }),
    }),

  testXssNeutralizer: (payload: string) =>
    requestJson<{
      payload: string;
      rawLength: number;
      escapedOutput: string;
      detectedVectors: string[];
    }>('/api/security/test-xss', {
      method: 'POST',
      body: JSON.stringify({ payload }),
    }),

  getSecurityHeaders: () => requestJson<SecurityHeaderReport>('/api/security/headers'),

  runLiveVerificationSuite: () =>
    requestJson<{ executedAt: string; results: LiveTestCheckResult[] }>('/api/testing/run-live', {
      method: 'POST',
    }),

  getHealth: () => requestJson<HealthReport>('/api/health'),
};
