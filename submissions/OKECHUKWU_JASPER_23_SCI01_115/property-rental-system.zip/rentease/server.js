require('dotenv').config();
const express = require('express'), session = require('express-session'), helmet = require('helmet'),
  bcrypt = require('bcryptjs'), crypto = require('crypto'), rateLimit = require('express-rate-limit'),
  Database = require('better-sqlite3'), path = require('path');

const prod = process.env.NODE_ENV === 'production';
if (prod && !process.env.SESSION_SECRET) throw new Error('SESSION_SECRET required in production');
const app = express(), db = new Database(process.env.DB_FILE || 'rental.db');
db.pragma('journal_mode = WAL'); db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
  hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', created DATETIME DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS properties(id INTEGER PRIMARY KEY, owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, city TEXT NOT NULL, type TEXT NOT NULL, bedrooms INTEGER NOT NULL, price INTEGER NOT NULL,
  description TEXT, created DATETIME DEFAULT CURRENT_TIMESTAMP);`);

// Seed admin from environment (never hard-code credentials)
if (!db.prepare("SELECT 1 FROM users WHERE role='admin'").get() && process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD)
  db.prepare("INSERT INTO users(name,email,hash,role) VALUES('Admin',?,?, 'admin')")
    .run(process.env.ADMIN_EMAIL.toLowerCase(), bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12));

const DUMMY = bcrypt.hashSync('dummy-password', 12); // equalises timing for unknown emails
const TYPES = ['Apartment', 'House', 'Studio', 'Duplex', 'Room'];

app.set('view engine', 'ejs'); app.set('views', path.join(__dirname, 'views'));
if (prod) app.set('trust proxy', 1);
app.use(helmet());                       // CSP, X-Frame-Options, nosniff, HSTS (over HTTPS), etc.
app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  name: 'sid', secret: process.env.SESSION_SECRET || 'dev-only-secret', resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: prod, maxAge: 30 * 60 * 1000 } // 30-min idle expiry
}));

// Per-request locals, CSRF token and flash messages
app.use((req, res, next) => {
  if (!req.session.csrf) req.session.csrf = crypto.randomBytes(24).toString('hex');
  res.locals.csrf = req.session.csrf; res.locals.user = req.session.user || null;
  res.locals.flash = req.session.flash || null; delete req.session.flash; res.locals.title = 'RentEase';
  next();
});
app.use((req, res, next) => {            // CSRF check on every state-changing request
  if (req.method === 'POST' && req.body._csrf !== req.session.csrf) return res.status(403).render('error', { title: 'Forbidden', code: 403, msg: 'Invalid CSRF token.' });
  next();
});

const requireLogin = (req, res, next) => req.session.user ? next() : (req.session.flash = { type: 'err', msg: 'Please log in first.' }, res.redirect('/login'));
const requireAdmin = (req, res, next) => req.session.user?.role === 'admin' ? next() : res.status(403).render('error', { title: 'Denied', code: 403, msg: 'Access denied.' });
const flash = (req, type, msg) => req.session.flash = { type, msg };
const clean = s => String(s ?? '').trim();
const strongPw = p => p.length >= 8 && /[A-Za-z]/.test(p) && /\d/.test(p);
const emailOk = e => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e) && e.length <= 120;

// ---------- Dashboard + search/filter (parameterised SQL only) ----------
app.get('/', (req, res) => {
  const q = clean(req.query.q), city = clean(req.query.city), type = clean(req.query.type);
  const min = parseInt(req.query.min, 10), max = parseInt(req.query.max, 10), beds = parseInt(req.query.beds, 10);
  const where = [], args = [];
  if (q) { where.push('(p.title LIKE ? OR p.description LIKE ?)'); args.push(`%${q}%`, `%${q}%`); }
  if (city) { where.push('p.city LIKE ?'); args.push(`%${city}%`); }
  if (TYPES.includes(type)) { where.push('p.type = ?'); args.push(type); }
  if (!isNaN(min)) { where.push('p.price >= ?'); args.push(min); }
  if (!isNaN(max)) { where.push('p.price <= ?'); args.push(max); }
  if (!isNaN(beds)) { where.push('p.bedrooms >= ?'); args.push(beds); }
  const sql = `SELECT p.*, u.name AS owner FROM properties p JOIN users u ON u.id=p.owner_id
    ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY p.created DESC LIMIT 100`;
  const stats = db.prepare('SELECT COUNT(*) n, COALESCE(ROUND(AVG(price)),0) avg FROM properties').get();
  res.render('index', { title: 'Dashboard', props: db.prepare(sql).all(...args), f: { q, city, type, min: req.query.min || '', max: req.query.max || '', beds: req.query.beds || '' }, TYPES, stats });
});

// ---------- Auth ----------
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false,
  handler: (req, res) => res.status(429).render('error', { title: 'Slow down', code: 429, msg: 'Too many attempts. Try again in 15 minutes.' }) });

app.get('/register', (req, res) => res.render('register', { title: 'Register', v: {} }));
app.post('/register', authLimiter, (req, res) => {
  const name = clean(req.body.name), email = clean(req.body.email).toLowerCase(), pw = String(req.body.password || '');
  const errs = [];
  if (name.length < 2 || name.length > 60) errs.push('Name must be 2–60 characters.');
  if (!emailOk(email)) errs.push('Enter a valid email address.');
  if (!strongPw(pw)) errs.push('Password needs 8+ characters with letters and numbers.');
  if (pw !== req.body.confirm) errs.push('Passwords do not match.');
  if (errs.length) return res.status(400).render('register', { title: 'Register', v: { name, email }, errs });
  try {
    db.prepare("INSERT INTO users(name,email,hash) VALUES(?,?,?)").run(name, email, bcrypt.hashSync(pw, 12)); // role is never taken from the form
  } catch { return res.status(400).render('register', { title: 'Register', v: { name, email }, errs: ['Could not register with those details.'] }); }
  flash(req, 'ok', 'Account created. Please log in.'); res.redirect('/login');
});

app.get('/login', (req, res) => res.render('login', { title: 'Login' }));
app.post('/login', authLimiter, (req, res) => {
  const email = clean(req.body.email).toLowerCase(), pw = String(req.body.password || '');
  const u = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  const ok = bcrypt.compareSync(pw, u ? u.hash : DUMMY) && u;
  if (!ok) return res.status(401).render('login', { title: 'Login', err: 'Invalid email or password.' }); // generic message
  req.session.regenerate(() => {            // new session ID on login prevents session fixation
    req.session.user = { id: u.id, name: u.name, role: u.role };
    req.session.csrf = crypto.randomBytes(24).toString('hex');
    flash(req, 'ok', `Welcome back, ${u.name}.`); res.redirect('/');
  });
});
app.post('/logout', (req, res) => req.session.destroy(() => { res.clearCookie('sid'); res.redirect('/login'); }));

// ---------- Profile ----------
app.get('/profile', requireLogin, (req, res) => {
  const me = db.prepare('SELECT id,name,email,role,created FROM users WHERE id=?').get(req.session.user.id);
  const mine = db.prepare('SELECT * FROM properties WHERE owner_id=? ORDER BY created DESC').all(me.id);
  res.render('profile', { title: 'Profile', me, mine });
});
app.post('/profile', requireLogin, (req, res) => {
  const name = clean(req.body.name), cur = String(req.body.current || ''), pw = String(req.body.password || '');
  if (name.length < 2 || name.length > 60) { flash(req, 'err', 'Name must be 2–60 characters.'); return res.redirect('/profile'); }
  db.prepare('UPDATE users SET name=? WHERE id=?').run(name, req.session.user.id); req.session.user.name = name;
  if (pw) {
    const u = db.prepare('SELECT hash FROM users WHERE id=?').get(req.session.user.id);
    if (!bcrypt.compareSync(cur, u.hash) || !strongPw(pw)) { flash(req, 'err', 'Password not changed: wrong current password or weak new password.'); return res.redirect('/profile'); }
    db.prepare('UPDATE users SET hash=? WHERE id=?').run(bcrypt.hashSync(pw, 12), req.session.user.id);
  }
  flash(req, 'ok', 'Profile updated.'); res.redirect('/profile');
});

// ---------- Properties ----------
app.get('/properties/new', requireLogin, (req, res) => res.render('property-new', { title: 'Add property', TYPES, v: {} }));
app.post('/properties', requireLogin, (req, res) => {
  const v = { title: clean(req.body.title), city: clean(req.body.city), type: clean(req.body.type), bedrooms: parseInt(req.body.bedrooms, 10),
    price: parseInt(req.body.price, 10), description: clean(req.body.description) };
  const errs = [];
  if (v.title.length < 3 || v.title.length > 100) errs.push('Title must be 3–100 characters.');
  if (v.city.length < 2 || v.city.length > 60) errs.push('City must be 2–60 characters.');
  if (!TYPES.includes(v.type)) errs.push('Choose a valid property type.');
  if (!(v.bedrooms >= 0 && v.bedrooms <= 20)) errs.push('Bedrooms must be 0–20.');
  if (!(v.price > 0 && v.price <= 1e9)) errs.push('Price must be a positive number.');
  if (v.description.length > 1000) errs.push('Description max 1000 characters.');
  if (errs.length) return res.status(400).render('property-new', { title: 'Add property', TYPES, v, errs });
  db.prepare('INSERT INTO properties(owner_id,title,city,type,bedrooms,price,description) VALUES(?,?,?,?,?,?,?)')
    .run(req.session.user.id, v.title, v.city, v.type, v.bedrooms, v.price, v.description);
  flash(req, 'ok', 'Property listed.'); res.redirect('/');
});
app.post('/properties/:id/delete', requireLogin, (req, res) => {
  const p = db.prepare('SELECT * FROM properties WHERE id=?').get(parseInt(req.params.id, 10));
  if (!p) return res.status(404).render('error', { title: 'Not found', code: 404, msg: 'Property not found.' });
  if (p.owner_id !== req.session.user.id && req.session.user.role !== 'admin')   // object-level access control
    return res.status(403).render('error', { title: 'Denied', code: 403, msg: 'You can only delete your own listings.' });
  db.prepare('DELETE FROM properties WHERE id=?').run(p.id); flash(req, 'ok', 'Listing deleted.'); res.redirect(req.get('referer') ? '/profile' : '/');
});

// ---------- Admin ----------
app.get('/admin', requireLogin, requireAdmin, (req, res) => res.render('admin', { title: 'Admin',
  users: db.prepare('SELECT id,name,email,role,created FROM users ORDER BY id').all(),
  props: db.prepare('SELECT p.id,p.title,p.city,u.name owner FROM properties p JOIN users u ON u.id=p.owner_id ORDER BY p.id DESC').all() }));
app.post('/admin/users/:id/delete', requireLogin, requireAdmin, (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (id === req.session.user.id) { flash(req, 'err', 'You cannot delete yourself.'); return res.redirect('/admin'); }
  db.prepare('DELETE FROM users WHERE id=?').run(id); flash(req, 'ok', 'User deleted.'); res.redirect('/admin');
});

app.get('/security', (req, res) => res.render('security', { title: 'Security' }));
app.use((req, res) => res.status(404).render('error', { title: 'Not found', code: 404, msg: 'Page not found.' }));
app.use((err, req, res, next) => {          // error handling: log details server-side, show nothing sensitive
  console.error(new Date().toISOString(), req.method, req.url, err);
  res.status(500).render('error', { title: 'Error', code: 500, msg: 'Something went wrong.' });
});
if (require.main === module) app.listen(process.env.PORT || 3000, () => console.log('RentEase on http://localhost:' + (process.env.PORT || 3000)));
module.exports = app;
