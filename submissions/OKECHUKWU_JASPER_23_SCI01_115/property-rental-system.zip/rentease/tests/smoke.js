const B = 'http://localhost:3000';
const tok = h => /name="_csrf" value="(\w+)"/.exec(h)?.[1];
const jar = {}; // minimal cookie jar
const call = async (p, o = {}) => { const r = await fetch(B + p, { redirect: 'manual', ...o, headers: { cookie: jar.c || '', 'content-type': 'application/x-www-form-urlencoded' } });
const sc = r.headers.get('set-cookie'); if (sc) jar.c = sc.split(';')[0]; return { s: r.status, t: await r.text() }; };
const post = (p, d) => call(p, { method: 'POST', body: new URLSearchParams(d) });
(async () => {
    const rows = [], t = (n, ok) => rows.push([n, ok ? 'Pass' : 'FAIL']);
    let r = await call('/login'); const c = tok(r.t);
    t('Wrong password rejected', (await post('/login', { _csrf: c, email: 'admin@rentease.local', password: 'wrong' })).s === 401);
    t('POST without CSRF blocked', (await post('/login', { email: 'a@b.c', password: 'x' })).s === 403);
    t('Valid login redirects', [302].includes((await post('/login', { _csrf: c, email: 'admin@rentease.local', password: 'Admin12345' })).s));
    t('Admin page reachable for admin', (await call('/admin')).s === 200);
    jar.c = ''; t('Admin page blocked when logged out', (await call('/admin')).s === 302);
    t('SQLi in search is harmless', (await call("/?q=' OR 1=1 --")).s === 200);
    t('XSS payload not echoed raw', !(await call('/?q=<script>alert(1)</script>')).t.includes('<script>alert(1)'));
    console.table(rows);
})();
