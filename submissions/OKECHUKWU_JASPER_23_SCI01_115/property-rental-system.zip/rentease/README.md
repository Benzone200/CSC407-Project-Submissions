# RentEase – Property Rental System

A secure, responsive property rental web application built with **Node.js, Express, EJS and SQLite**. Users register, list rental properties and search them; admins moderate users and listings. The project demonstrates core web application security practices.

---

## 1. Features

**Frontend**
- Dashboard with listing statistics and property cards
- Registration and login pages
- User profile (edit name, change password, view own listings)
- Responsive navigation (hamburger menu on phones)
- Forms: register, login, profile, add property
- Search and filter: keyword, city, type, minimum bedrooms, price range

**Security**
- Login and logout with session management
- Password hashing (bcrypt, cost 12)
- Role-based access (`user`, `admin`)
- Object-level access control (only owners or admins can delete a listing)
- Server-side input validation
- SQL injection protection (prepared statements only)
- XSS protection (EJS output escaping and Content-Security-Policy via Helmet)
- CSRF tokens on every POST, SameSite cookies
- Rate limiting on login and registration
- Secrets in environment variables, errors logged server-side only
- A built-in **Security** page (`/security`) explaining all measures

---

## 2. Requirements

| Requirement | Version |
|---|---|
| Node.js | 18 or newer (includes npm) |
| Editor | VS Code (recommended) |
| Optional | `sqlite3` CLI for inspecting the database |

No separate database server is needed. SQLite creates a local file automatically.

### Dependencies (installed via npm)
`express`, `ejs`, `better-sqlite3`, `bcryptjs`, `express-session`, `helmet`, `express-rate-limit`, `dotenv`

---

## 3. Project structure

```
rentease/
├─ server.js              # App, routes, security middleware, database setup
├─ .env                   # Environment variables (never commit)
├─ .gitignore             # Should contain: node_modules, .env, *.db
├─ package.json
├─ public/
│  └─ style.css           # Responsive styles
├─ tests/
│  └─ smoke.js            # Automated security/functional smoke tests
└─ views/
   ├─ partials/head.ejs   # Header + navigation + flash messages
   ├─ partials/foot.ejs
   ├─ index.ejs           # Dashboard + search/filter
   ├─ register.ejs
   ├─ login.ejs
   ├─ profile.ejs
   ├─ property-new.ejs
   ├─ admin.ejs
   ├─ security.ejs
   └─ error.ejs
```

---

## 4. Installation and running locally

```bash
# 1. Create the project folder and open it in VS Code
mkdir rentease && cd rentease
code .

# 2. Initialise and install dependencies
npm init -y
npm i express ejs better-sqlite3 bcryptjs express-session helmet express-rate-limit dotenv

# 3. Add all project files (server.js, .env, public/, views/, tests/)

# 4. Start the server
node server.js
```

Open **http://localhost:3000**.

Optional: add `"start": "node server.js"` and `"test": "node tests/smoke.js"` to the `scripts` section of `package.json`, then use `npm start` and `npm test`.

### Default admin account
Created automatically on first run from `.env`:

| Field | Default |
|---|---|
| Email | `admin@rentease.local` |
| Password | `Admin12345` |

**Change these values in `.env` before first run** (or before deploying). The admin is only seeded when no admin exists yet; to re-seed, delete `rental.db`.

---

## 5. Environment variables (`.env`)

```
PORT=3000
NODE_ENV=development
SESSION_SECRET=change-this-to-a-long-random-string
ADMIN_EMAIL=admin@rentease.local
ADMIN_PASSWORD=Admin12345
DB_FILE=rental.db
```

| Variable | Purpose |
|---|---|
| `PORT` | Port the server listens on |
| `NODE_ENV` | `production` enables Secure cookies and proxy trust; the app refuses to start without `SESSION_SECRET` |
| `SESSION_SECRET` | Signs session cookies. Generate with `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | Seeds the first admin account |
| `DB_FILE` | Path of the SQLite database file |

---

## 6. Database

SQLite, created automatically on first run.

**users**: `id`, `name`, `email` (unique), `hash`, `role` (`user`/`admin`), `created`

**properties**: `id`, `owner_id` (FK to users, cascade delete), `title`, `city`, `type`, `bedrooms`, `price`, `description`, `created`

Inspect it:
```bash
sqlite3 rental.db "select id,email,role,hash from users;"
```
Password hashes should start with `$2a$` or `$2b$`.

---

## 7. Routes

| Method | Route | Access | Purpose |
|---|---|---|---|
| GET | `/` | Public | Dashboard, search and filter |
| GET/POST | `/register` | Public | Create account |
| GET/POST | `/login` | Public | Log in |
| POST | `/logout` | Logged in | Destroy session |
| GET/POST | `/profile` | Logged in | View/update profile, change password |
| GET | `/properties/new` | Logged in | Add-property form |
| POST | `/properties` | Logged in | Create listing |
| POST | `/properties/:id/delete` | Owner or admin | Delete listing |
| GET | `/admin` | Admin | Users and all listings |
| POST | `/admin/users/:id/delete` | Admin | Delete a user |
| GET | `/security` | Public | Security measures page |

---

## 8. Security measures

| Measure | Implementation |
|---|---|
| Authentication | Email and password; logout destroys the session and clears the cookie |
| Password hashing | bcrypt, salted, cost 12; plain-text passwords are never stored |
| Roles | `requireAdmin` guards `/admin`; role is never read from forms |
| Access control | Ownership check before deleting listings, enforced server-side |
| Input validation | Length, type, range and whitelist checks on the server (plus HTML5 checks) |
| SQL injection | Prepared statements with bound parameters everywhere |
| XSS | EJS `<%= %>` escaping; Helmet CSP |
| CSRF | Per-session token on every POST; SameSite=Lax cookies |
| Sessions | HttpOnly, Secure in production, 30-minute expiry, ID regenerated on login |
| Brute force | 10 login/register attempts per 15 minutes per IP; generic error messages; timing equalised for unknown emails |
| Sensitive data | Secrets in `.env`; hashes never sent to views; errors logged server-side only |
| HTTPS | Terminated at Nginx with Let's Encrypt; HSTS via Helmet |

---

## 9. Testing

### Automated smoke tests
Start the server in one terminal, then in another:
```bash
node tests/smoke.js
```
Checks: wrong password rejected, missing CSRF blocked, valid admin login, admin page access (logged in and out), SQL injection string in search, XSS payload not echoed.
The tests assume the default admin credentials from section 4.

### Manual test table (fill in "Actual Result" and "Status" yourself)

| Category | Test | Expected Result | Actual Result | Status |
|---|---|---|---|---|
| Login | Valid login | Redirect to dashboard | | |
| Login | Wrong password | Generic "Invalid email or password" | | |
| Registration | Empty field | Validation message | | |
| Registration | Weak password (`abc`) | Rejected with message | | |
| Registration | Duplicate email | Generic error, no account created | | |
| Form validation | Price `-5`, bedrooms `99` | Errors shown, nothing saved | | |
| Security | Open `/admin` as normal user | 403 Access denied | | |
| Security | Search `' OR 1=1 --` | No error, no extra data | | |
| Security | Title `<script>alert(1)</script>` | Shown as plain text, no popup | | |
| Security | POST without CSRF token | 403 Forbidden | | |
| Security | Delete another user's listing | 403 Denied | | |
| Security | 11+ rapid logins | 429 Too many attempts | | |
| Session | Logout, then Back and reload | Redirected to login | | |
| Responsive | DevTools at 375px | Hamburger menu, single-column cards | | |
| Error handling | Visit `/nope` | Friendly 404 page | | |
| Database | Register, inspect `rental.db` | Hash column starts with `$2a$`/`$2b$` | | |
| Usability | 2–3 classmates list a property | Done without help | | |

---

## 10. Deployment (development to production)

1. **Environment:** set `NODE_ENV=production`, a long random `SESSION_SECRET`, and strong admin credentials. Keep `.env` and `*.db` out of Git.
2. **Server:** Linux VPS or a platform such as Render or Railway. Install with `npm ci --omit=dev`.
3. **Process manager:** `pm2 start server.js --name rentease`, then `pm2 save` and `pm2 startup`.
4. **Reverse proxy:** Nginx forwards ports 80/443 to `localhost:3000`, passing `X-Forwarded-Proto`.
5. **HTTPS:** `certbot --nginx -d yourdomain.com` for a free Let's Encrypt certificate with auto-renewal.
6. **Domain:** point an A record to the server IP.
7. **Database:** the SQLite file is set by `DB_FILE`. For larger scale, migrate to PostgreSQL or MySQL and keep the prepared statements.
8. **Backups:** nightly cron, e.g. `sqlite3 rental.db ".backup /backups/rental-$(date +%F).db"`; copy backups off the server and test a restore.
9. **Logs and monitoring:** `pm2 logs` for application errors, Nginx access/error logs, and an uptime monitor such as UptimeRobot.

For a demonstration, running locally with `node server.js` is enough.

---

## 11. Project review

- **What it does:** lets users register, list rental properties and search them; admins moderate users and listings.
- **Features implemented:** see section 1.
- **Security measures:** see section 8.
- **Testing results:** summarise your table (e.g. "X of Y tests passed").
- **Performance observations:** record your own measurements (page load in DevTools, behaviour with ~1,000 listings). SQLite suits small to medium traffic.
- **Problems encountered:** write your real experience (examples: adding CSRF tokens to every form, regenerating the session on login).
- **Limitations:** in-memory session store (sessions lost on restart, not shareable across servers); no image uploads; no booking or payments; no email verification or password reset; SQLite is single-server.
- **Future improvements:** Redis or SQLite session store, email verification and password reset, two-factor authentication, image uploads with type and size checks, booking and payment flow, audit logging, automated tests in CI, PostgreSQL migration.

---

## 12. Troubleshooting

| Problem | Fix |
|---|---|
| `Cannot find module ...` | Run the `npm i ...` command from section 4 inside the project folder |
| `better-sqlite3` install fails | Use Node 18 or 20 LTS; on Windows install the "Desktop development with C++" build tools if no prebuilt binary is available |
| Port already in use | Change `PORT` in `.env` |
| Cannot log in as admin | Admin is seeded only if none exists; delete `rental.db` and restart |
| "Invalid CSRF token" | Reload the page to get a fresh form; don't submit forms from cached pages |
| Login fails behind HTTPS proxy | Ensure `NODE_ENV=production` and Nginx sends `X-Forwarded-Proto $scheme` |
