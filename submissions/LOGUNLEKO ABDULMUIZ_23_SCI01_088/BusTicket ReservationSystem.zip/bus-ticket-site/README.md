Ajo Coaches - Bus Ticket Reservation System (no server needed)

Open index.html by double-clicking it. That's all.
Admin page: open admin.html (or the same link is not shown to customers).

Files
- index.html   Customer website (search, seat map, booking, find/cancel booking)
- style.css    All the styling and the sunrise bus animation
- data.js      The "backend": trips, bookings, rules, saved in the browser (localStorage)
- script.js    Customer page logic
- admin.html, admin.js   Add/delete trips, see and cancel bookings, reset data

Notes
- Bookings are saved in the browser you use, on that device only.
- Sample trips for the next 7 days are added automatically.


