// ============================================================
//  script.js  -  the customer side of the website.
//  It calls the functions in data.js (searchTrips, createBooking, ...).
// ============================================================
const MAX_SEATS = 6;
let currentTrip = null;   // the trip the customer is booking
let chosenSeats = [];     // seat numbers the customer tapped

const $ = id => document.getElementById(id);
const naira = n => '\u20A6' + Number(n).toLocaleString('en-NG');

// Escape text before putting it in HTML (stops people injecting code through names)
function esc(text) {
  const d = document.createElement('div');
  d.textContent = text;
  return d.innerHTML;
}
function formatDate(dateStr) {
  return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-NG', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}
function formatTime(t) {
  const [h, m] = t.split(':').map(Number);
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
}

// ---------- Switching between "pages" ----------
const views = ['viewSearch', 'viewSeats', 'viewTicket', 'viewManage'];
function show(viewId) {
  views.forEach(v => { $(v).hidden = v !== viewId; });
  $('hero').hidden = viewId !== 'viewSearch'; // the sunrise banner only shows on the search page
  window.scrollTo(0, 0);
}
$('navBook').onclick = e => { e.preventDefault(); show('viewSearch'); };
$('navManage').onclick = e => { e.preventDefault(); show('viewManage'); };
$('bookAnother').onclick = () => { show('viewSearch'); runSearch(); };
$('backToResults').onclick = () => show('viewSearch');

// ---------- 1. Search ----------
function loadCities() {
  $('cityList').innerHTML = getCities().map(c => `<option value="${esc(c)}">`).join('');
}

// Popular route buttons: fill in the form and search
function loadPopular() {
  const picks = [ROUTES[0], ROUTES[2], ROUTES[4], ROUTES[6], ROUTES[7]];
  $('popularRoutes').innerHTML = picks.map(([from, to, , price]) =>
    `<button type="button" class="chip" data-from="${esc(from)}" data-to="${esc(to)}">${esc(from)} to ${esc(to)}<small>from ${naira(price)}</small></button>`).join('');
}
$('popularRoutes').onclick = e => {
  const chip = e.target.closest('.chip');
  if (!chip) return;
  $('from').value = chip.dataset.from;
  $('to').value = chip.dataset.to;
  runSearch();
};

function runSearch() {
  const trips = searchTrips({ from: $('from').value, to: $('to').value, date: $('date').value });
  $('searchMsg').textContent = '';
  renderResults(trips);
}

function renderResults(trips) {
  if (!trips.length) {
    $('results').innerHTML = '<p class="empty">No buses found for that search. Try another date or route.</p>';
    return;
  }
  $('results').innerHTML = trips.map(t => `
    <article class="ticket">
      <div class="main">
        <div class="route">${esc(t.from)} to ${esc(t.to)}</div>
        <div class="when">${formatDate(t.date)} at ${formatTime(t.time)} &middot; ${esc(t.busType)}</div>
      </div>
      <div class="stub">
        <div class="price">${naira(t.price)}</div>
        <div class="left ${t.seatsLeft <= 5 ? 'low' : ''}">${t.seatsLeft ? t.seatsLeft + ' seats left' : 'Sold out'}</div>
        <button class="btn primary" data-trip="${t.id}" ${t.seatsLeft ? '' : 'disabled'}>Choose seats</button>
      </div>
    </article>`).join('');
}

$('searchForm').onsubmit = e => { e.preventDefault(); runSearch(); };
$('results').onclick = e => {
  const btn = e.target.closest('[data-trip]');
  if (btn) openSeats(Number(btn.dataset.trip));
};

// ---------- 2. Seat map ----------
function openSeats(tripId) {
  try {
    currentTrip = getTrip(tripId); // fresh seat data every time
  } catch (err) { alert(err.message); return; }
  chosenSeats = [];
  $('bookMsg').textContent = '';
  $('tripTitle').textContent = `${currentTrip.from} to ${currentTrip.to}`;
  $('tripMeta').textContent = `${formatDate(currentTrip.date)} at ${formatTime(currentTrip.time)} \u00B7 ${naira(currentTrip.price)} per seat`;
  drawSeatMap();
  updateSummary();
  show('viewSeats');
}

function drawSeatMap() {
  let html = '';
  for (let n = 1; n <= currentTrip.totalSeats; n++) {
    const taken = currentTrip.takenSeats.includes(n);
    const state = taken ? 'taken' : chosenSeats.includes(n) ? 'chosen' : 'free';
    html += `<button type="button" class="seat-btn ${state}" data-seat="${n}" ${taken ? 'disabled' : ''}
              aria-label="Seat ${n}, ${state === 'taken' ? 'taken' : state === 'chosen' ? 'selected' : 'free'}">${n}</button>`;
    if (n % 4 === 2) html += '<span class="aisle"></span>'; // gap between left and right seats
  }
  $('seatMap').innerHTML = html;
}

$('seatMap').onclick = e => {
  const btn = e.target.closest('[data-seat]');
  if (!btn) return;
  const n = Number(btn.dataset.seat);
  if (chosenSeats.includes(n)) chosenSeats = chosenSeats.filter(s => s !== n);
  else if (chosenSeats.length < MAX_SEATS) chosenSeats.push(n);
  else { $('bookMsg').textContent = `You can book up to ${MAX_SEATS} seats at once.`; return; }
  $('bookMsg').textContent = '';
  drawSeatMap();
  updateSummary();
};

function updateSummary() {
  const sorted = [...chosenSeats].sort((a, b) => a - b);
  $('selectedInfo').textContent = sorted.length ? `Seats: ${sorted.join(', ')}` : 'Tap seats on the bus to choose (up to 6).';
  $('totalPrice').textContent = naira(sorted.length * (currentTrip ? currentTrip.price : 0));
  $('bookBtn').disabled = sorted.length === 0;
}

// ---------- 3. Confirm booking ----------
$('bookForm').onsubmit = e => {
  e.preventDefault();
  try {
    const { booking, trip } = createBooking({
      tripId: currentTrip.id, seats: chosenSeats,
      name: $('pName').value, phone: $('pPhone').value, email: $('pEmail').value,
    });
    $('ticketBox').innerHTML = ticketHtml(booking, trip);
    $('bookForm').reset();
    show('viewTicket');
  } catch (err) {
    $('bookMsg').textContent = err.message;
    // A seat may have just been taken (for example in another tab), so reload the map
    currentTrip = getTrip(currentTrip.id);
    chosenSeats = chosenSeats.filter(s => !currentTrip.takenSeats.includes(s));
    drawSeatMap();
    updateSummary();
  }
};

function ticketHtml(b, t) {
  return `
    <div class="big-ticket">
      <div class="head"><span>Ajo Coaches</span><span class="ref">${esc(b.ref)}</span></div>
      <dl class="body">
        <div><dt>Route</dt><dd>${esc(t.from)} to ${esc(t.to)}</dd></div>
        <div><dt>Status</dt><dd><span class="badge ${b.status}">${b.status === 'confirmed' ? 'Confirmed' : 'Cancelled'}</span></dd></div>
        <div><dt>Date</dt><dd>${formatDate(t.date)}</dd></div>
        <div><dt>Departure</dt><dd>${formatTime(t.time)}</dd></div>
        <div><dt>Passenger</dt><dd>${esc(b.name)}</dd></div>
        <div><dt>Phone</dt><dd>${esc(b.phone)}</dd></div>
        <div><dt>Seats</dt><dd>${b.seats.join(', ')}</dd></div>
        <div><dt>Total</dt><dd>${naira(b.total)}</dd></div>
      </dl>
      <div class="code" aria-hidden="true"></div>
    </div>`;
}

// ---------- 4. Find / cancel a booking ----------
$('lookupForm').onsubmit = e => {
  e.preventDefault();
  $('lookupMsg').textContent = '';
  $('lookupResult').innerHTML = '';
  try {
    const { booking, trip } = findBooking($('lRef').value, $('lPhone').value);
    renderLookup(booking, trip);
  } catch (err) {
    $('lookupMsg').textContent = err.message;
  }
};

function renderLookup(booking, trip) {
  const canCancel = booking.status === 'confirmed';
  $('lookupResult').innerHTML = ticketHtml(booking, trip) +
    (canCancel ? '<button class="btn danger" id="cancelBtn">Cancel this booking</button>' : '');
  if (canCancel) {
    $('cancelBtn').onclick = () => {
      if (!confirm('Cancel this booking? Your seats will be released.')) return;
      try {
        const res = cancelBooking(booking.ref, $('lPhone').value);
        renderLookup(res.booking, res.trip);
      } catch (err) { $('lookupMsg').textContent = err.message; }
    };
  }
}

// ---------- Start ----------
$('date').min = dateString(0);
loadCities();
loadPopular();
runSearch();
