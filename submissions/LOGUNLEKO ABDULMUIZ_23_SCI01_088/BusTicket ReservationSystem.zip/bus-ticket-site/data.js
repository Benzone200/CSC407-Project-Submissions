// ============================================================
//  data.js  -  the "backend" of the bus system, now living in the browser.
//  All trips and bookings are saved in localStorage (no server needed).
//  Both index.html and admin.html use these functions.
// ============================================================
const DB_KEY = 'ajo_coaches_db';

// Sample routes: [from, to, time, price]
const ROUTES = [
  ['Lagos', 'Ibadan', '07:00', 3500],
  ['Ibadan', 'Lagos', '15:00', 3500],
  ['Lagos', 'Ado-Ekiti', '08:00', 9000],
  ['Ado-Ekiti', 'Lagos', '09:00', 9000],
  ['Lagos', 'Abuja', '06:00', 18000],
  ['Abuja', 'Lagos', '18:00', 18000],
  ['Lagos', 'Benin City', '07:30', 8000],
  ['Abuja', 'Kano', '09:30', 12000],
];

// ---------- Saving and loading ----------
let memoryBackup = null; // used only if the browser blocks localStorage

function dateString(offsetDays) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function loadDB() {
  let db = null;
  try { db = JSON.parse(localStorage.getItem(DB_KEY)); } catch (e) { db = memoryBackup; }
  if (!db) db = { nextTripId: 1, trips: [], bookings: [], seededDates: [] };
  // Make sure the next 7 days always have sample trips (each day is added only once)
  let changed = false;
  for (let i = 0; i < 7; i++) {
    const date = dateString(i);
    if (db.seededDates.includes(date)) continue;
    ROUTES.forEach(([from, to, time, price]) => {
      db.trips.push({ id: db.nextTripId++, from, to, date, time, price, totalSeats: 30, busType: 'Luxury coach' });
    });
    db.seededDates.push(date);
    changed = true;
  }
  if (changed) saveDB(db);
  return db;
}

function saveDB(db) {
  memoryBackup = db;
  try { localStorage.setItem(DB_KEY, JSON.stringify(db)); } catch (e) { /* storage blocked: memory only */ }
}

// ---------- Helpers ----------
function takenSeats(db, tripId) {
  return db.bookings.filter(b => b.tripId === tripId && b.status === 'confirmed').flatMap(b => b.seats);
}
function withSeats(db, trip) {
  const taken = takenSeats(db, trip.id);
  return { ...trip, seatsLeft: trip.totalSeats - taken.length, takenSeats: taken };
}
function departureTime(trip) { return new Date(`${trip.date}T${trip.time}:00`); }
function digits(phone) { return String(phone).replace(/\D/g, '').slice(-10); }
function makeRef() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let ref = 'BT';
  for (let i = 0; i < 6; i++) ref += chars[Math.floor(Math.random() * chars.length)];
  return ref;
}

// ---------- Customer functions ----------
function getCities() {
  const db = loadDB();
  const set = new Set();
  db.trips.forEach(t => { set.add(t.from); set.add(t.to); });
  return [...set].sort();
}

function searchTrips({ from = '', to = '', date = '' }) {
  const db = loadDB();
  from = from.trim().toLowerCase();
  to = to.trim().toLowerCase();
  const now = new Date();
  return db.trips
    .filter(t => !from || t.from.toLowerCase() === from)
    .filter(t => !to || t.to.toLowerCase() === to)
    .filter(t => !date || t.date === date)
    .filter(t => departureTime(t) > now)
    .sort((a, b) => departureTime(a) - departureTime(b))
    .map(t => withSeats(db, t));
}

function getTrip(id) {
  const db = loadDB();
  const trip = db.trips.find(t => t.id === Number(id));
  if (!trip) throw new Error('Trip not found.');
  return withSeats(db, trip);
}

function createBooking({ tripId, seats, name, phone, email }) {
  const db = loadDB(); // always the freshest data, so seats taken in another tab are respected
  const trip = db.trips.find(t => t.id === Number(tripId));
  if (!trip) throw new Error('Trip not found.');
  if (departureTime(trip) <= new Date()) throw new Error('This bus has already left.');

  name = String(name || '').trim();
  phone = String(phone || '').trim();
  email = String(email || '').trim();
  if (name.length < 2 || name.length > 80) throw new Error('Enter your full name.');
  if (!/^[0-9+\s-]{7,15}$/.test(phone)) throw new Error('Enter a valid phone number.');
  if (email && !/^\S+@\S+\.\S+$/.test(email)) throw new Error('Enter a valid email or leave it empty.');

  seats = (seats || []).map(Number);
  if (seats.length < 1 || seats.length > 6) throw new Error('Choose between 1 and 6 seats.');
  const valid = seats.every(s => Number.isInteger(s) && s >= 1 && s <= trip.totalSeats);
  if (!valid || new Set(seats).size !== seats.length) throw new Error('Invalid seat selection.');

  const taken = takenSeats(db, trip.id);
  const clash = seats.filter(s => taken.includes(s));
  if (clash.length) throw new Error(`Seat ${clash.join(', ')} was just taken. Pick another seat.`);

  let ref = makeRef();
  while (db.bookings.some(b => b.ref === ref)) ref = makeRef();
  const booking = {
    ref, tripId: trip.id, seats: seats.sort((a, b) => a - b), name, phone, email,
    total: seats.length * trip.price, status: 'confirmed', createdAt: new Date().toISOString(),
  };
  db.bookings.push(booking);
  saveDB(db);
  return { booking, trip };
}

function findBooking(ref, phone) {
  const db = loadDB();
  const booking = db.bookings.find(b => b.ref === String(ref).trim().toUpperCase());
  if (!booking || digits(booking.phone) !== digits(phone)) {
    throw new Error('No booking found. Check the reference and phone number.');
  }
  return { booking, trip: db.trips.find(t => t.id === booking.tripId) };
}

function cancelBooking(ref, phone) {
  const { booking, trip } = findBooking(ref, phone);
  if (booking.status === 'cancelled') throw new Error('This booking is already cancelled.');
  if (trip && departureTime(trip) <= new Date()) throw new Error('This bus has already left.');
  const db = loadDB();
  db.bookings.find(b => b.ref === booking.ref).status = 'cancelled';
  saveDB(db);
  return { booking: { ...booking, status: 'cancelled' }, trip };
}

// ---------- Admin functions ----------
function adminTrips() {
  const db = loadDB();
  return [...db.trips].sort((a, b) => departureTime(a) - departureTime(b)).map(t => withSeats(db, t));
}

function adminBookings() {
  const db = loadDB();
  return db.bookings
    .map(b => ({ ...b, trip: db.trips.find(t => t.id === b.tripId) }))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

function adminAddTrip(b) {
  const db = loadDB();
  const trip = {
    id: db.nextTripId, from: String(b.from || '').trim(), to: String(b.to || '').trim(),
    date: String(b.date || ''), time: String(b.time || ''), price: Number(b.price),
    totalSeats: Number(b.totalSeats) || 30, busType: 'Luxury coach',
  };
  if (!trip.from || !trip.to || trip.from.toLowerCase() === trip.to.toLowerCase()) throw new Error('Enter two different cities.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(trip.date) || !/^\d{2}:\d{2}$/.test(trip.time)) throw new Error('Enter a valid date and time.');
  if (!(trip.price > 0)) throw new Error('Enter a price above 0.');
  if (trip.totalSeats < 4 || trip.totalSeats > 80) throw new Error('Seats must be between 4 and 80.');
  db.nextTripId++;
  db.trips.push(trip);
  saveDB(db);
  return trip;
}

function adminDeleteTrip(id) {
  const db = loadDB();
  id = Number(id);
  if (!db.trips.some(t => t.id === id)) throw new Error('Trip not found.');
  db.bookings.forEach(b => { if (b.tripId === id) b.status = 'cancelled'; });
  db.trips = db.trips.filter(t => t.id !== id);
  saveDB(db);
}

function adminCancelBooking(ref) {
  const db = loadDB();
  const booking = db.bookings.find(b => b.ref === ref);
  if (!booking) throw new Error('Booking not found.');
  booking.status = 'cancelled';
  saveDB(db);
}
