// ============================================================
//  admin.js  -  add/delete trips, see and cancel bookings.
//  Uses the same functions in data.js as the customer pages.
// ============================================================
const $ = id => document.getElementById(id);
const naira = n => '\u20A6' + Number(n).toLocaleString('en-NG');
function esc(text) { const d = document.createElement('div'); d.textContent = text; return d.innerHTML; }

function draw() {
  $('tripRows').innerHTML = adminTrips().map(t => `
    <tr><td>${esc(t.from)} to ${esc(t.to)}</td><td>${t.date}</td><td>${t.time}</td>
    <td>${naira(t.price)}</td><td>${t.seatsLeft} / ${t.totalSeats}</td>
    <td><button class="btn danger" data-del="${t.id}">Delete</button></td></tr>`).join('') || '<tr><td colspan="6">No trips yet.</td></tr>';

  $('bookingRows').innerHTML = adminBookings().map(b => `
    <tr><td>${esc(b.ref)}</td><td>${esc(b.name)}</td><td>${esc(b.phone)}</td>
    <td>${b.trip ? esc(b.trip.from) + ' to ' + esc(b.trip.to) + ', ' + b.trip.date : 'Trip removed'}</td>
    <td>${b.seats.join(', ')}</td><td>${naira(b.total)}</td>
    <td><span class="badge ${b.status}">${b.status}</span></td>
    <td>${b.status === 'confirmed' ? `<button class="btn danger" data-cancel="${esc(b.ref)}">Cancel</button>` : ''}</td></tr>`).join('') || '<tr><td colspan="8">No bookings yet.</td></tr>';
}

$('tripForm').onsubmit = e => {
  e.preventDefault();
  try {
    adminAddTrip({
      from: $('tFrom').value, to: $('tTo').value, date: $('tDate').value, time: $('tTime').value,
      price: $('tPrice').value, totalSeats: $('tSeats').value,
    });
    $('adminMsg').textContent = '';
    $('tripForm').reset();
    $('tSeats').value = 30;
    draw();
  } catch (err) { $('adminMsg').textContent = err.message; }
};

document.querySelector('main').onclick = e => {
  const del = e.target.closest('[data-del]');
  const cancel = e.target.closest('[data-cancel]');
  try {
    if (del && confirm('Delete this trip? Passengers booked on it will be cancelled.')) {
      adminDeleteTrip(del.dataset.del);
      draw();
    }
    if (cancel && confirm('Cancel this booking?')) {
      adminCancelBooking(cancel.dataset.cancel);
      draw();
    }
  } catch (err) { $('adminMsg').textContent = err.message; }
};

$('resetBtn').onclick = () => {
  if (confirm('Delete ALL trips and bookings and start fresh with sample trips?')) {
    try { localStorage.removeItem(DB_KEY); } catch (e) {}
    memoryBackup = null;
    draw();
  }
};

draw();
