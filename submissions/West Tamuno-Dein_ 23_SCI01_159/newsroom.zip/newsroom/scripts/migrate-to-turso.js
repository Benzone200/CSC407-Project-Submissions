const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { createClient } = require('@libsql/client');
const { looksLikeImage, saveImage, UPLOAD_DIR } = require('../src/storage');

const ROOT = path.join(__dirname, '..');
const DEFAULT_SOURCE = path.join(ROOT, 'data', 'newsroom.db');
const BODY_UPLOAD_RE = /(^|["'(=\s])\/uploads\/([^"'()\s?#]+)/g;
const MIME_TYPES = {
  '.gif': 'image/gif',
  '.jpeg': 'image/jpeg',
  '.jpg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
};

function loadEnvFile() {
  const file = path.join(ROOT, '.env');
  if (!fs.existsSync(file)) return;

  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!match || process.env[match[1]] !== undefined) continue;
    const value = match[2].replace(/^(['"])(.*)\1$/, '$2');
    process.env[match[1]] = value;
  }
}

function rowsAsObjects(result) {
  return result.rows.map((row) =>
    Object.fromEntries(result.columns.map((column, index) => [column, row[index]]))
  );
}

async function selectRows(client, sql) {
  return rowsAsObjects(await client.execute(sql));
}

function fileDatabaseUrl(file) {
  return `file:${path.resolve(file).replace(/\\/g, '/')}`;
}

async function readSource(client) {
  const users = await selectRows(client, 'SELECT id, name, email, created_at FROM users');
  const categories = await selectRows(client, 'SELECT id, name, slug, description, sort_order FROM categories');
  const articles = await selectRows(client, `SELECT id, title, slug, summary, body, cover_image, cover_caption,
    category_id, author_id, status, featured, views, published_at, created_at, updated_at
    FROM articles`);
  return { users, categories, articles };
}

async function readTarget(client) {
  const users = await selectRows(client, 'SELECT id, name, email, role, active FROM users');
  const categories = await selectRows(client, 'SELECT id, name, slug FROM categories');
  const articles = await selectRows(client, 'SELECT id, slug FROM articles');
  return { users, categories, articles };
}

function makePlan(source, target) {
  if (!target.users.some((user) => user.role === 'admin' && Number(user.active) === 1)) {
    throw new Error('Turso needs an active admin before migration. Open the deployed site once to initialize it.');
  }

  const targetUsers = new Map(target.users.map((user) => [user.email.trim().toLowerCase(), user]));
  const sourceUsers = new Map(source.users.map((user) => [Number(user.id), user]));
  const userIds = new Set(source.articles.map((article) => article.author_id).filter((id) => id != null).map(Number));
  const usersToAdd = [];
  const userIdsBySourceId = new Map();

  for (const id of userIds) {
    const user = sourceUsers.get(id);
    if (!user) throw new Error(`Local article refers to missing author id ${id}.`);
    const existing = targetUsers.get(user.email.trim().toLowerCase());
    if (existing) userIdsBySourceId.set(id, Number(existing.id));
    else usersToAdd.push(user);
  }

  const targetCategoriesBySlug = new Map(target.categories.map((category) => [category.slug, category]));
  const targetCategoriesByName = new Map(target.categories.map((category) => [category.name.toLowerCase(), category]));
  const categoryIdsBySourceId = new Map();
  const categoriesToAdd = [];

  for (const category of source.categories) {
    const bySlug = targetCategoriesBySlug.get(category.slug);
    const byName = targetCategoriesByName.get(category.name.toLowerCase());
    if (bySlug || byName) {
      const existing = bySlug || byName;
      if (bySlug && byName && Number(bySlug.id) !== Number(byName.id)) {
        throw new Error(`A Turso category conflicts with local category "${category.name}".`);
      }
      if (existing.slug !== category.slug || existing.name !== category.name) {
        throw new Error(`A Turso category conflicts with local category "${category.name}".`);
      }
      categoryIdsBySourceId.set(Number(category.id), Number(existing.id));
    } else {
      categoriesToAdd.push(category);
    }
  }

  const targetSlugs = new Set(target.articles.map((article) => article.slug));
  const conflicts = source.articles.filter((article) => targetSlugs.has(article.slug));
  if (conflicts.length) {
    throw new Error(`${conflicts.length} local article slug(s) already exist in Turso; no records were changed.`);
  }

  for (const article of source.articles) {
    if (article.category_id != null && !source.categories.some((category) => Number(category.id) === Number(article.category_id))) {
      throw new Error(`Local article "${article.slug}" refers to a missing category.`);
    }
  }

  return { usersToAdd, userIdsBySourceId, categoriesToAdd, categoryIdsBySourceId };
}

function collectUploadNames(articles) {
  const names = new Set();
  for (const article of articles) {
    if (article.cover_image && article.cover_image.startsWith('/uploads/')) {
      names.add(article.cover_image.slice('/uploads/'.length).split(/[?#]/, 1)[0]);
    }
    for (const match of article.body.matchAll(BODY_UPLOAD_RE)) names.add(match[2]);
  }
  return names;
}

function getLocalImage(name) {
  if (!name || path.basename(name) !== name) throw new Error('Invalid local upload path in an article.');
  const file = path.join(UPLOAD_DIR, name);
  if (!fs.existsSync(file)) throw new Error(`Article references a missing local upload: ${name}`);

  const ext = path.extname(name).toLowerCase();
  const contentType = MIME_TYPES[ext];
  if (!contentType) throw new Error(`Unsupported local upload type: ${ext || '(no extension)'}`);

  const buffer = fs.readFileSync(file);
  if (!looksLikeImage(buffer)) throw new Error(`Local upload is not a recognized image: ${name}`);
  return { buffer, ext, contentType };
}

function rewriteCover(value, imageUrls) {
  if (!value || !value.startsWith('/uploads/')) return value || '';
  const name = value.slice('/uploads/'.length).split(/[?#]/, 1)[0];
  const url = imageUrls.get(name);
  if (!url) throw new Error(`No Blob URL was prepared for local upload: ${name}`);
  return url;
}

function rewriteBody(value, imageUrls) {
  return String(value || '').replace(BODY_UPLOAD_RE, (_match, prefix, name) => {
    const url = imageUrls.get(name);
    if (!url) throw new Error(`No Blob URL was prepared for local upload: ${name}`);
    return `${prefix}${url}`;
  });
}

async function uploadLocalImages(names) {
  const urls = new Map();
  for (const name of names) {
    const { buffer, ext, contentType } = getLocalImage(name);
    const url = await saveImage(buffer, ext, contentType);
    if (!url.startsWith('https://')) {
      throw new Error('Image migration did not return a Blob URL; check BLOB_READ_WRITE_TOKEN.');
    }
    urls.set(name, url);
  }
  return urls;
}

async function applyPlan(target, source, imageUrls) {
  const tx = await target.transaction('write');
  try {
    const plan = makePlan(source, await readTarget(tx));
    const userIds = new Map(plan.userIdsBySourceId);
    const categoryIds = new Map(plan.categoryIdsBySourceId);

    for (const user of plan.usersToAdd) {
      const passwordHash = bcrypt.hashSync(crypto.randomBytes(32).toString('hex'), 11);
      const result = await tx.execute({
        sql: `INSERT INTO users (name, email, password_hash, role, active, created_at)
          VALUES (?, ?, ?, 'editor', 0, ?)`,
        args: [user.name, user.email, passwordHash, user.created_at],
      });
      userIds.set(Number(user.id), Number(result.lastInsertRowid));
    }

    for (const category of plan.categoriesToAdd) {
      const result = await tx.execute({
        sql: `INSERT INTO categories (name, slug, description, sort_order) VALUES (?, ?, ?, ?)`,
        args: [category.name, category.slug, category.description, category.sort_order],
      });
      categoryIds.set(Number(category.id), Number(result.lastInsertRowid));
    }

    for (const article of source.articles) {
      await tx.execute({
        sql: `INSERT INTO articles (
          title, slug, summary, body, cover_image, cover_caption, category_id, author_id,
          status, featured, views, published_at, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        args: [
          article.title,
          article.slug,
          article.summary,
          rewriteBody(article.body, imageUrls),
          rewriteCover(article.cover_image, imageUrls),
          article.cover_caption,
          article.category_id == null ? null : categoryIds.get(Number(article.category_id)),
          article.author_id == null ? null : userIds.get(Number(article.author_id)),
          article.status,
          article.featured,
          article.views,
          article.published_at,
          article.created_at,
          article.updated_at,
        ],
      });
    }

    await tx.commit();
    return { usersAdded: plan.usersToAdd.length, categoriesAdded: plan.categoriesToAdd.length };
  } catch (error) {
    try {
      await tx.rollback();
    } catch (rollbackError) {
      console.error(`Database rollback failed: ${rollbackError.message}`);
    }
    throw error;
  }
}

async function main() {
  loadEnvFile();

  const args = process.argv.slice(2);
  if (args.some((arg) => !['--apply', '--dry-run'].includes(arg)) || (args.includes('--apply') && args.includes('--dry-run'))) {
    throw new Error('Use no option (dry run) or exactly one of --dry-run / --apply.');
  }
  const apply = args.includes('--apply');
  const sourceFile = path.resolve(process.env.MIGRATION_SOURCE_DB || DEFAULT_SOURCE);

  if (!process.env.TURSO_DATABASE_URL || !process.env.TURSO_AUTH_TOKEN) {
    throw new Error('Set TURSO_DATABASE_URL and TURSO_AUTH_TOKEN in the environment or local .env file.');
  }
  if (!process.env.TURSO_DATABASE_URL.startsWith('libsql://')) {
    throw new Error('TURSO_DATABASE_URL must point to a libsql:// Turso database.');
  }
  if (!fs.existsSync(sourceFile)) throw new Error(`Local SQLite database not found: ${sourceFile}`);

  const sourceClient = createClient({ url: fileDatabaseUrl(sourceFile) });
  const targetClient = createClient({
    url: process.env.TURSO_DATABASE_URL,
    authToken: process.env.TURSO_AUTH_TOKEN,
  });

  try {
    const source = await readSource(sourceClient);
    const target = await readTarget(targetClient);
    const plan = makePlan(source, target);
    const uploadNames = collectUploadNames(source.articles);
    for (const name of uploadNames) getLocalImage(name);

    const statusCounts = source.articles.reduce((counts, article) => {
      counts[article.status] = (counts[article.status] || 0) + 1;
      return counts;
    }, {});
    const statuses = Object.entries(statusCounts).map(([status, count]) => `${count} ${status}`).join(', ');
    console.log(`Local database: ${source.articles.length} article(s) (${statuses}), ${source.categories.length} categories.`);
    console.log(`Turso database: ${target.articles.length} existing article(s).`);
    console.log(`Planned import: ${source.articles.length} article(s), ${plan.categoriesToAdd.length} new categories, ${plan.usersToAdd.length} inactive author account(s), ${uploadNames.size} image(s).`);

    if (!apply) {
      console.log('Dry run only; no data was changed. Run with --apply to import.');
      return;
    }
    if (uploadNames.size && !process.env.BLOB_READ_WRITE_TOKEN) {
      throw new Error('BLOB_READ_WRITE_TOKEN is required to migrate local article images.');
    }

    const imageUrls = await uploadLocalImages(uploadNames);
    let result;
    try {
      result = await applyPlan(targetClient, source, imageUrls);
    } catch (error) {
      if (imageUrls.size) {
        console.error(`${imageUrls.size} image(s) may remain unused in Blob because the database transaction failed.`);
      }
      throw error;
    }
    console.log(`Imported ${source.articles.length} article(s), ${result.categoriesAdded} category(ies), and ${result.usersAdded} inactive author account(s).`);
    console.log(`Uploaded ${imageUrls.size} local image(s) to Vercel Blob. Local files were not changed.`);
  } finally {
    sourceClient.close();
    targetClient.close();
  }
}

if (require.main === module) {
  main().catch((error) => {
    console.error(`Migration failed: ${error.message}`);
    process.exitCode = 1;
  });
}

module.exports = { collectUploadNames, makePlan, rewriteBody, rewriteCover };
