const { Database } = require("node:sqlite");
const path = require("path");

const db = new Database(path.join(__dirname, "seminar.db"));

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL COLLATE NOCASE UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'participant'
      CHECK (role IN ('admin', 'organizer', 'participant')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

db.close();

console.log("Users table is ready.");