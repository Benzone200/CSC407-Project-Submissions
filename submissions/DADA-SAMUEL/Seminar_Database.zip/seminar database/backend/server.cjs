const express = require("express");
const bcrypt = require("bcryptjs");
const session = require("express-session");
const crypto = require("node:crypto");
const path = require("path");
const { Database } = require("node:sqlite");

const app = express();
const PORT = 5000;

const db = new Database("seminar.db");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'student',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS seminars (
    seminar_id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    venue TEXT NOT NULL,
    capacity INTEGER NOT NULL,
    created_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id)
  );
`);

app.use(express.json());

app.use(session({
  name: "seminar.sid",
  secret: crypto.randomBytes(32).toString("hex"),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: false,
    maxAge: 60 * 60 * 1000
  }
}));

function requireLogin(req, res, next) {
  if (!req.session.userId) {
    return res.status(401).json({
      message: "You must log in to create a seminar."
    });
  }

  next();
}

app.use(express.static(path.join(__dirname, "public")));

app.post("/api/auth/register", async (req, res) => {
  const { full_name, email, password } = req.body || {};

  if (
    typeof full_name !== "string" ||
    full_name.trim().length === 0 ||
    full_name.trim().length > 100 ||
    typeof email !== "string" ||
    email.trim().length === 0 ||
    email.length > 254 ||
    !email.includes("@") ||
    typeof password !== "string" ||
    password.length < 8 ||
    password.length > 72
  ) {
    return res.status(400).json({
      message: "Please provide a valid full name, email, and password of at least 8 characters."
    });
  }

  try {
    const checkStatement = db.prepare(`
      SELECT user_id
      FROM users
      WHERE email = ?
    `);

    const existingUser = checkStatement.get(email.trim().toLowerCase());
    checkStatement.close();

    if (existingUser) {
      return res.status(409).json({
        message: "An account with this email already exists."
      });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const insertStatement = db.prepare(`
      INSERT INTO users (full_name, email, password_hash)
      VALUES (?, ?, ?)
    `);

    const result = insertStatement.run(
      full_name.trim(),
      email.trim().toLowerCase(),
      passwordHash
    );

    insertStatement.close();

    return res.status(201).json({
      message: "Account created successfully.",
      user_id: result.lastInsertRowid
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      message: "Unable to create your account."
    });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { email, password } = req.body || {};

  if (
    typeof email !== "string" ||
    email.trim().length === 0 ||
    email.length > 254 ||
    typeof password !== "string" ||
    password.length === 0 ||
    password.length > 72
  ) {
    return res.status(400).json({
      message: "Please enter a valid email and password."
    });
  }

  try {
    const statement = db.prepare(`
      SELECT user_id, full_name, email, password_hash, role
      FROM users
      WHERE email = ?
    `);

    const user = statement.get(email.trim().toLowerCase());
    statement.close();

    if (!user) {
      return res.status(401).json({
        message: "Invalid email or password."
      });
    }

    const passwordMatches = await bcrypt.compare(
      password,
      user.password_hash
    );

    if (!passwordMatches) {
      return res.status(401).json({
        message: "Invalid email or password."
      });
    }

    req.session.regenerate((error) => {
      if (error) {
        console.error(error);

        return res.status(500).json({
          message: "Unable to log in."
        });
      }

      req.session.userId = user.user_id;
      req.session.fullName = user.full_name;

      req.session.save((error) => {
        if (error) {
          console.error(error);

          return res.status(500).json({
            message: "Unable to save your login session."
          });
        }

        return res.json({
          message: "Login successful.",
          user: {
            user_id: user.user_id,
            full_name: user.full_name,
            email: user.email,
            role: user.role
          }
        });
      });
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      message: "Unable to log in."
    });
  }
});

app.get("/api/auth/me", (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({
      message: "You are not logged in."
    });
  }

  return res.json({
    user_id: req.session.userId,
    full_name: req.session.fullName
  });
});

app.post("/api/auth/logout", (req, res) => {
  req.session.destroy((error) => {
    if (error) {
      console.error(error);

      return res.status(500).json({
        message: "Unable to log out."
      });
    }

    res.clearCookie("seminar.sid");

    return res.json({
      message: "Logged out successfully."
    });
  });
});

app.get("/api/seminars", (req, res) => {
  try {
    const statement = db.prepare(`
      SELECT
        seminars.seminar_id AS seminar_id,
        seminars.title AS title,
        seminars.description AS description,
        seminars.date AS date,
        seminars.time AS time,
        seminars.venue AS venue,
        seminars.capacity AS capacity,
        users.full_name AS created_by_name
      FROM seminars
      JOIN users ON seminars.created_by = users.user_id
      ORDER BY seminars.created_at DESC
    `);

    const seminars = statement.all();
    statement.close();

    return res.json(seminars);
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      message: "Unable to load seminars."
    });
  }
});

app.post("/api/seminars", requireLogin, async (req, res) => {
  const { title, description, date, time, venue, capacity } = req.body || {};

  const capacityNumber = Number(capacity);

  if (
    typeof title !== "string" ||
    title.trim().length === 0 ||
    title.trim().length > 150 ||
    typeof description !== "string" ||
    description.trim().length === 0 ||
    description.trim().length > 1000 ||
    typeof date !== "string" ||
    date.length === 0 ||
    typeof time !== "string" ||
    time.length === 0 ||
    typeof venue !== "string" ||
    venue.trim().length === 0 ||
    venue.trim().length > 150 ||
    !Number.isInteger(capacityNumber) ||
    capacityNumber < 1 ||
    capacityNumber > 10000
  ) {
    return res.status(400).json({
      message: "Please provide valid seminar details."
    });
  }

  try {
    const statement = db.prepare(`
      INSERT INTO seminars (
        title,
        description,
        date,
        time,
        venue,
        capacity,
        created_by
      )
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    const result = statement.run(
      title.trim(),
      description.trim(),
      date,
      time,
      venue.trim(),
      capacityNumber,
      req.session.userId
    );

    statement.close();

    return res.status(201).json({
      message: "Seminar created successfully.",
      seminar_id: result.lastInsertRowid
    });
  } catch (error) {
    console.error(error);

    return res.status(500).json({
      message: "Unable to create the seminar."
    });
  }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});