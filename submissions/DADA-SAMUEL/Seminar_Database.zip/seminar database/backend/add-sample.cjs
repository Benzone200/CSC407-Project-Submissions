const { Database } = require("node:sqlite");
const path = require("path");

const db = new Database(path.join(__dirname, "seminar.db"));

const statement = db.prepare(`
  INSERT INTO seminars (
    title,
    description,
    start_datetime,
    venue,
    capacity
  )
  VALUES (?, ?, ?, ?, ?)
`);

statement.run(
  "Introduction to Web Development",
  "Learn the basics of building websites.",
  "2026-12-10T10:00",
  "Main Hall",
  50
);

statement.close();
db.close();

console.log("Sample seminar added successfully.");