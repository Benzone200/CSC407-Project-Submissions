const registerForm = document.getElementById("register-form");
const registerMessage = document.getElementById("register-message");

registerForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const fullName = document.getElementById("full-name").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  registerMessage.textContent = "Creating your account...";
  registerMessage.className = "message";

  try {
    const response = await fetch("/api/auth/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        full_name: fullName,
        email,
        password
      })
    });

    const data = await response.json();

    if (!response.ok) {
      registerMessage.textContent = data.message || "Unable to create your account.";
      registerMessage.className = "message error";

      return;
    }

    registerMessage.textContent = data.message;
    registerMessage.className = "message success";

    setTimeout(() => {
      window.location.href = "login.html";
    }, 1500);
  } catch (error) {
    registerMessage.textContent = "Unable to connect to the server.";
    registerMessage.className = "message error";
  }
});