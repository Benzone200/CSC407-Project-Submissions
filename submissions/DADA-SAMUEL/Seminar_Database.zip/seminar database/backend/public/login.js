const loginForm = document.getElementById("login-form");
const loginMessage = document.getElementById("login-message");

loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  loginMessage.textContent = "Logging in...";
  loginMessage.className = "message";

  try {
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      credentials: "include",
      body: JSON.stringify({
        email,
        password
      })
    });

    const data = await response.json();

    if (!response.ok) {
      loginMessage.textContent = data.message || "Unable to log in.";
      loginMessage.className = "message error";

      return;
    }

    loginMessage.textContent = data.message;
    loginMessage.className = "message success";

    setTimeout(() => {
      window.location.href = "index.html";
    }, 1000);
  } catch (error) {
    loginMessage.textContent = "Unable to connect to the server.";
    loginMessage.className = "message error";
  }
});