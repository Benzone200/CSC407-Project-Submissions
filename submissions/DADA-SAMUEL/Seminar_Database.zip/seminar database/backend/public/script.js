const welcomeMessage = document.getElementById("welcome-message");
const seminarForm = document.getElementById("seminar-form");
const formMessage = document.getElementById("form-message");
const seminarsList = document.getElementById("seminars-list");
const logoutButton = document.getElementById("logout-button");

async function loadCurrentUser() {
  if (!welcomeMessage) {
    return;
  }

  try {
    const response = await fetch("/api/auth/me", {
      credentials: "include"
    });

    if (!response.ok) {
      welcomeMessage.textContent = "You are not logged in.";
      return;
    }

    const user = await response.json();

    welcomeMessage.textContent = "Welcome, " + user.full_name;
  } catch (error) {
    welcomeMessage.textContent = "";
  }
}

async function loadSeminars() {
  if (!seminarsList) {
    return;
  }

  try {
    const response = await fetch("/api/seminars");
    const data = await response.json();

    if (!response.ok) {
      seminarsList.textContent = data.message || "Unable to load seminars.";
      return;
    }

    displaySeminars(data);
  } catch (error) {
    seminarsList.textContent = "Unable to connect to the server.";
  }
}

function displaySeminars(seminars) {
  seminarsList.textContent = "";

  if (!Array.isArray(seminars) || seminars.length === 0) {
    const emptyMessage = document.createElement("p");
    emptyMessage.textContent = "No seminars available yet.";
    seminarsList.appendChild(emptyMessage);

    return;
  }

  seminars.forEach((seminar) => {
    const seminarCard = document.createElement("div");
    seminarCard.className = "seminar-card";

    const title = document.createElement("h3");
    title.textContent = seminar.title;

    const description = document.createElement("p");
    description.textContent = seminar.description;

    const details = document.createElement("p");
    details.textContent =
      (seminar.date || "No date") + " at " +
      (seminar.time || "No time") + " — " +
      (seminar.venue || "No venue") + " — Capacity: " +
      (seminar.capacity || "Not specified");

    const createdBy = document.createElement("p");
    createdBy.textContent = "Created by: " + (seminar.created_by_name || "Unknown user");

    seminarCard.appendChild(title);
    seminarCard.appendChild(description);
    seminarCard.appendChild(details);
    seminarCard.appendChild(createdBy);

    seminarsList.appendChild(seminarCard);
  });
}

if (seminarForm) {
  seminarForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const title = document.getElementById("title").value.trim();
    const description = document.getElementById("description").value.trim();
    const date = document.getElementById("date").value;
    const time = document.getElementById("time").value;
    const venue = document.getElementById("venue").value.trim();
    const capacity = document.getElementById("capacity").value;

    formMessage.textContent = "Creating seminar...";
    formMessage.className = "message";

    try {
      const response = await fetch("/api/seminars", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        credentials: "include",
        body: JSON.stringify({
          title,
          description,
          date,
          time,
          venue,
          capacity: Number(capacity)
        })
      });

      const data = await response.json();

      if (!response.ok) {
        if (response.status === 401) {
          formMessage.textContent = "You must log in to create a seminar.";
        } else {
          formMessage.textContent = data.message || "Unable to create seminar.";
        }

        formMessage.className = "message error";

        return;
      }

      formMessage.textContent = data.message || "Seminar created successfully.";
      formMessage.className = "message success";

      seminarForm.reset();

      await loadSeminars();
    } catch (error) {
      formMessage.textContent = "Unable to connect to the server.";
      formMessage.className = "message error";
    }
  });
}

if (logoutButton) {
  logoutButton.addEventListener("click", async () => {
    try {
      const response = await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include"
      });

      const data = await response.json();

      if (!response.ok) {
        alert(data.message || "Unable to log out.");
        return;
      }

      window.location.href = "login.html";
    } catch (error) {
      alert("Unable to connect to the server.");
    }
  });
}

loadCurrentUser();
loadSeminars();