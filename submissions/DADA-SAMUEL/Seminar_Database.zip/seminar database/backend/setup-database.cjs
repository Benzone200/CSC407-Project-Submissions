const { Database } = require("node:sqlite");
const path = require("path");

const databasePath = path.join(__dirname, "seminar.db");
const db = new Database(databasePath);

db.exec(`
  CREATE TABLE IF NOT EXISTS seminars (
    seminar_id INTEGER PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    start_datetime TEXT NOT NULL,
    venue TEXT NOT NULL,
    capacity INTEGER NOT NULL CHECK (capacity > 0)
  );
`);

console.log("Database created successfully.");
console.log("The seminars table is ready.");

db.close();