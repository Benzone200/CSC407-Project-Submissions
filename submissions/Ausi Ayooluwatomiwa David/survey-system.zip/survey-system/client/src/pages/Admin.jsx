import { useEffect, useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { api } from '../api';
import Navbar from '../components/Navbar';
import { lazy, Suspense } from 'react';

import { PageLoading } from '../components/Spinner';



 const AdminCharts = lazy(() => import('../components/AdminCharts'));
export default function Admin() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [surveys, setSurveys] = useState([]);

 

  const isAdmin = user && user.role === 'admin';

  function handleError(err) {
    if (err.status === 401) navigate('/login');
    else if (err.status === 403) navigate('/dashboard');
    else setError(err.message);
  }

  useEffect(() => {
    if (!isAdmin) return;
    api('/api/admin/stats')
      .then((d) => setStats(d.stats))
      .catch(handleError);
  }, [isAdmin]);

  useEffect(() => {
    if (!isAdmin) return;
    const timer = setTimeout(() => {
      api(`/api/admin/users?search=${encodeURIComponent(search)}`)
        .then((d) => setUsers(d.users))
        .catch(handleError)
        .finally(() => setLoading(false));
    }, 300);
    return () => clearTimeout(timer);
  }, [search, isAdmin]);
  useEffect(() => {
  if (!isAdmin) return;
  api('/api/admin/surveys')
    .then((d) => setSurveys(d.surveys))
    .catch(handleError);
}, [isAdmin]);
async function closeSurvey(s) {
  if (!window.confirm(`Close "${s.title}"? Nobody will be able to respond to it.`)) return;
  setError('');
  try {
    await api(`/api/admin/surveys/${s.id}/close`, { method: 'POST' });
    setSurveys(surveys.map((x) => (x.id === s.id ? { ...x, status: 'closed' } : x)));
  } catch (err) {
    handleError(err);
  }
}

async function deleteSurvey(s) {
  const warning = `Permanently delete "${s.title}" and its ${s.response_count} responses? This cannot be undone.`;
  if (!window.confirm(warning)) return;
  setError('');
  try {
    await api(`/api/admin/surveys/${s.id}`, { method: 'DELETE' });
    setSurveys(surveys.filter((x) => x.id !== s.id));
    setStats((prev) =>
      prev
        ? { ...prev, surveys: prev.surveys - 1, responses: prev.responses - s.response_count }
        : prev
    );
  } catch (err) {
    handleError(err);
  }
}

  async function toggleActive(u) {
    const action = u.is_active ? 'Deactivate' : 'Reactivate';
    if (!window.confirm(`${action} ${u.email}?`)) return;
    setError('');
    try {
      const data = await api(`/api/admin/users/${u.id}`, {
        method: 'PATCH',
        body: { is_active: !u.is_active },
      });
      setUsers(users.map((x) => (x.id === u.id ? { ...x, is_active: data.user.is_active } : x)));
    } catch (err) {
      handleError(err);
    }
  }

  if (authLoading) return <PageLoading />;
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== 'admin') return <Navigate to="/dashboard" replace />;

  return (
    <>
      <Navbar />
      <main className="app-page admin-page">
      <div className="app-page__content admin-page__content">
        <header className="app-page__heading">
          <p className="app-page__eyebrow">SurveyApp overview</p>
          <h1>Admin workspace</h1>
          <p>Monitor activity and manage accounts and surveys.</p>
        </header>

       {stats && (
  <div className="admin-stats mb-8 grid grid-cols-3 gap-3">
    {[
      ['Users', stats.users, stats.users_7d],
      ['Surveys', stats.surveys, stats.surveys_7d],
      ['Responses', stats.responses, stats.responses_7d],
    ].map(([label, value, week]) => (
      <div key={label} className="admin-stat-card app-panel p-4 text-center">
        <p className="text-2xl font-semibold text-gray-900">{value}</p>
        <p className="text-sm text-gray-500">{label}</p>
        <p className="mt-1 text-xs text-green-700">+{week} this week</p>
      </div>
    ))}
  </div>
)}
        <Suspense fallback={<PageLoading text="Loading charts..." />}>
  <AdminCharts />
</Suspense>

        <div className="admin-section-heading">
          <p className="app-page__eyebrow">People</p>
          <h2>Users</h2>
        </div>
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name or email"
          aria-label="Search users"
          className="mb-4 w-full rounded border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

        {error && (
          <p role="alert" className="mb-3 rounded bg-red-50 px-3 py-2 text-red-700">
            {error}
          </p>
        )}
        {loading && <PageLoading text="Loading users..." />}
        {!loading && users.length === 0 && <p className="text-gray-500">No users found.</p>}

        {users.length > 0 && (
          <div className="admin-table-wrap overflow-x-auto app-panel">
            <table className="w-full text-left text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="px-3 py-2">Name</th>
                  <th className="px-3 py-2">Email</th>
                  <th className="px-3 py-2">Role</th>
                  <th className="px-3 py-2">Surveys</th>
                  <th className="px-3 py-2">Status</th>
                  <th className="px-3 py-2"></th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id} className="border-t border-gray-100">
                    <td className="px-3 py-2">{u.name}</td>
                    <td className="px-3 py-2 break-all">{u.email}</td>
                    <td className="px-3 py-2">{u.role}</td>
                    <td className="px-3 py-2">{u.survey_count}</td>
                    <td className="px-3 py-2">
                      <span
                        className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                          u.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {u.is_active ? 'active' : 'deactivated'}
                      </span>
                    </td>
                    <td className="px-3 py-2">
                      {u.role === 'user' && (
                        <button
                          onClick={() => toggleActive(u)}
                          className="rounded border border-gray-400 px-2 py-1 text-xs font-medium text-gray-700 hover:bg-gray-50"
                        >
                          {u.is_active ? 'Deactivate' : 'Reactivate'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <div className="admin-section-heading admin-section-heading--spaced">
          <p className="app-page__eyebrow">Survey activity</p>
          <h2>All surveys</h2>
        </div>
{surveys.length === 0 ? (
  <p className="text-gray-500">No surveys yet.</p>
) : (
  <div className="admin-table-wrap overflow-x-auto app-panel">
    <table className="w-full text-left text-sm">
      <thead className="bg-gray-50 text-gray-600">
        <tr>
          <th className="px-3 py-2">Title</th>
          <th className="px-3 py-2">Owner</th>
          <th className="px-3 py-2">Status</th>
          <th className="px-3 py-2">Responses</th>
          <th className="px-3 py-2"></th>
        </tr>
      </thead>
      <tbody>
        {surveys.map((s) => (
          <tr key={s.id} className="border-t border-gray-100">
            <td className="px-3 py-2">{s.title}</td>
            <td className="px-3 py-2 break-all">{s.owner_email}</td>
            <td className="px-3 py-2">{s.status}</td>
            <td className="px-3 py-2">{s.response_count}</td>
            <td className="px-3 py-2">
              <div className="flex gap-2">
                {s.status !== 'closed' && (
                  <button
                    onClick={() => closeSurvey(s)}
                    className="rounded border border-gray-400 px-2 py-1 text-xs font-medium text-gray-700 hover:bg-gray-50"
                  >
                    Close
                  </button>
                )}
                <button
                  onClick={() => deleteSurvey(s)}
                  className="rounded border border-red-600 px-2 py-1 text-xs font-medium text-red-700 hover:bg-red-50"
                >
                  Delete
                </button>
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
)}
      </div>
      </main>
    </>
  );
}