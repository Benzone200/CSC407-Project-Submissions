import { openDatabase } from './lib/database.js';
import { createApp } from './app.js';
const codespaces=process.env.CODESPACES==='true';
const production=codespaces||process.env.NODE_ENV==='production';
const port=Number(process.env.PORT||3000);
const host=codespaces?'0.0.0.0':process.env.HOST||'127.0.0.1';
const forwardedDomain=process.env.GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN||'app.github.dev';
const origin=codespaces
  ? `https://${process.env.CODESPACE_NAME}-${port}.${forwardedDomain}`
  : process.env.APP_ORIGIN||`http://localhost:${port}`;
const db=openDatabase(process.env.DATABASE_PATH||'./data/jobify.sqlite');
const app=createApp({db,secret:process.env.SESSION_SECRET,origin,production,trustProxy:codespaces||process.env.TRUST_PROXY==='1',allowSetup:true});
const server=app.listen(port,host,()=>console.log(`Jobify is ready at ${origin}`));
function stop(){server.close(()=>{db.close();process.exit(0);});}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
