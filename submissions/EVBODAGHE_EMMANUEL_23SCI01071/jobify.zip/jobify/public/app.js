const menu=document.querySelector('[data-menu]');
menu?.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')==='true';menu.setAttribute('aria-expanded',String(!open));document.getElementById('main-nav').classList.toggle('open',!open);});
for(const form of document.querySelectorAll('[data-confirm]'))form.addEventListener('submit',event=>{if(!window.confirm(form.dataset.confirm))event.preventDefault();});
for(const form of document.querySelectorAll('[data-validate-passwords]')){
  const password=form.querySelector('[name="password"]'),confirm=form.querySelector('[name="confirm_password"]');
  function check(){if(!password)return;const bytes=new TextEncoder().encode(password.value).length;password.setCustomValidity(bytes>72?'Use no more than 72 UTF-8 bytes.':'');if(confirm)confirm.setCustomValidity(password.value===confirm.value?'':'Passwords must match.');}
  password?.addEventListener('input',check);confirm?.addEventListener('input',check);
}
const minSalary=document.getElementById('salary_min'),maxSalary=document.getElementById('salary_max');
function checkSalary(){if(minSalary&&maxSalary)maxSalary.setCustomValidity(Number(maxSalary.value)<Number(minSalary.value)?'Maximum salary must be at least the minimum.':'');}
minSalary?.addEventListener('input',checkSalary);maxSalary?.addEventListener('input',checkSalary);
const cvForm=document.querySelector('[data-cv-upload]');
cvForm?.addEventListener('submit',async event=>{
  event.preventDefault();const file=cvForm.querySelector('input[type="file"]').files[0],message=cvForm.querySelector('[data-upload-message]'),button=cvForm.querySelector('button');
  if(!file||file.size>2*1024*1024||!file.name.toLowerCase().endsWith('.pdf')){message.textContent='Select a PDF file no larger than 2 MB.';return;}
  const header=await file.slice(0,5).text();if(header!=='%PDF-'){message.textContent='The selected file must be a PDF.';return;}
  button.disabled=true;message.textContent='Uploading your CV…';
  try{
    const data=new FormData();data.append('cv',file);
    const response=await fetch('/profile/cv',{method:'POST',headers:{'X-CSRF-Token':document.querySelector('meta[name="csrf-token"]').content,'Accept':'application/json'},body:data,credentials:'same-origin',redirect:'error'});
    const result=await response.json().catch(()=>({error:'Your session may have expired. Refresh the page and try again.'}));
    if(!response.ok)throw new Error(result.error||'Unable to upload your CV.');
    location.assign('/profile');
  }catch(error){message.textContent=error.message||'Upload failed. Please try again.';button.disabled=false;}
});
