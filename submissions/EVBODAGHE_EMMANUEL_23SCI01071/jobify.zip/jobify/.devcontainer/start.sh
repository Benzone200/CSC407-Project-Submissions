#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p data
if [ -f data/server.pid ]; then
  running_pid=$(cat data/server.pid)
  if [[ "$running_pid" =~ ^[0-9]+$ ]] && kill -0 "$running_pid" 2>/dev/null; then
    echo "Jobify is already running. Open port 3000 in the Ports panel."
    exit 0
  fi
fi
nohup node scripts/start-browser.js >data/server.log 2>&1 &
echo "$!" >data/server.pid
echo "Starting Jobify. The website will open through port 3000."
