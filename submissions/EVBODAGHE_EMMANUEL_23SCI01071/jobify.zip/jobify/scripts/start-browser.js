import { existsSync, writeFileSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
// This runs automatically inside Codespaces; no password is stored in the source.
if(!existsSync('.env'))writeFileSync('.env','SESSION_SECRET='+randomBytes(48).toString('hex')+'\n',{mode:0o600,flag:'wx'});
process.loadEnvFile('.env');
await import('../server.js');
