import bcrypt from 'bcryptjs';
import { pathToFileURL } from 'node:url';
import { openDatabase } from '../lib/database.js';
import { seedListings } from '../lib/seed-data.js';
import { passwordValid, emailValid } from '../lib/validation.js';
import { askHidden } from './password-prompt.js';
export async function seed(db) {
  let admin=db.prepare("SELECT id FROM users WHERE role='admin' LIMIT 1").get();
  if(!admin){
    const email=(process.env.ADMIN_EMAIL||'admin@jobify.local').trim().toLowerCase();
    if(!emailValid(email))throw new Error('ADMIN_EMAIL must be a valid email address.');
    let password=process.env.ADMIN_PASSWORD;
    if(!password){password=await askHidden('Choose an administrator password (12+ characters, uppercase, lowercase and number): ');const confirm=await askHidden('Confirm administrator password: ');if(password!==confirm)throw new Error('Passwords do not match. Run setup again.');}
    if(!passwordValid(password))throw new Error('Use 12+ characters with uppercase, lowercase and a number; maximum 72 UTF-8 bytes.');
    if(db.prepare('SELECT 1 FROM users WHERE email=?').get(email))throw new Error('The administrator email is already used by another account. Choose another ADMIN_EMAIL.');
    const hash=await bcrypt.hash(password,12);
    admin={id:Number(db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')").run('Jobify Administrator',email,hash).lastInsertRowid)};
    console.log('Administrator created. Sign in with '+email+' and the password you chose.');
  }
  seedListings(db,admin.id);
  console.log('Job listings and database are ready.');
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){const db=openDatabase(process.env.DATABASE_PATH||'./data/jobify.sqlite');try{await seed(db);}catch(error){console.error(error.message);process.exitCode=1;}finally{db.close();}}
