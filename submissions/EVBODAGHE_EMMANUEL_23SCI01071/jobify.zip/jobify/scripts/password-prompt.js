import { stdin, stdout } from 'node:process';
export function askHidden(label) {
  if(!stdin.isTTY)throw new Error('Use an interactive terminal, or set ADMIN_PASSWORD for the seed command.');
  return new Promise((resolve,reject)=>{
    stdout.write(label);let value='';stdin.setRawMode(true);stdin.resume();stdin.setEncoding('utf8');
    const finish=()=>{stdin.off('data',onData);stdin.setRawMode(false);stdin.pause();stdout.write('\n');};
    function onData(chunk){for(const char of chunk){if(char==='\u0003'){finish();reject(new Error('Setup cancelled.'));return;}if(char==='\r'||char==='\n'){finish();resolve(value);return;}if(char==='\u007f'||char==='\b'){if(value.length){value=value.slice(0,-1);stdout.write('\b \b');}}else if(char.charCodeAt(0)>=32){value+=char;stdout.write('*');}}}
    stdin.on('data',onData);
  });
}
