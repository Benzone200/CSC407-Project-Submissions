import { openDatabase } from '../lib/database.js';
const db=openDatabase(process.env.DATABASE_PATH||'./data/jobify.sqlite');
console.log('Database migrations complete.');db.close();
