import { mkdirSync, chmodSync } from 'node:fs';
import path from 'node:path';
import { openDatabase } from '../lib/database.js';
export function createBackup(db,destination){
  // VACUUM INTO produces a consistent snapshot, including CV blobs, even with WAL enabled.
  mkdirSync(path.dirname(destination),{recursive:true,mode:0o700});
  db.prepare('VACUUM INTO ?').run(destination);chmodSync(destination,0o600);
  const copy=openDatabase(destination);copy.exec('DELETE FROM sessions; DELETE FROM login_attempts; PRAGMA wal_checkpoint(TRUNCATE);');copy.close();
  return destination;
}
if(process.argv[1]?.endsWith('/backup.js')){
  const db=openDatabase(process.env.DATABASE_PATH||'./data/jobify.sqlite');
  const target=path.resolve('backups','jobify-'+new Date().toISOString().replace(/[:.]/g,'-')+'.sqlite');
  try{createBackup(db,target);console.log('Backup created: '+target);}finally{db.close();}
}
