import { randomBytes } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync, chmodSync } from 'node:fs';
import { openDatabase } from '../lib/database.js';
import { seed } from './seed.js';
try {
  if(!existsSync('.env')){
    const secret=randomBytes(48).toString('hex');
    writeFileSync('.env',`NODE_ENV=development\nHOST=127.0.0.1\nPORT=3000\nAPP_ORIGIN=http://localhost:3000\nSESSION_SECRET=${secret}\nDATABASE_PATH=./data/jobify.sqlite\nTRUST_PROXY=0\n`,{mode:0o600,flag:'wx'});
    console.log('Local configuration created. Keep .env private.');
  }else{
    let config=readFileSync('.env','utf8');
    if(/^SESSION_SECRET=replace-.*$/m.test(config)){config=config.replace(/^SESSION_SECRET=.*$/m,'SESSION_SECRET='+randomBytes(48).toString('hex'));writeFileSync('.env',config,{mode:0o600});}
    chmodSync('.env',0o600);
  }
  const db=openDatabase(process.env.DATABASE_PATH||'./data/jobify.sqlite');
  try{await seed(db);}finally{db.close();}
  console.log('Setup complete. Run npm start, then open http://localhost:3000.');
}catch(error){console.error(error.message);process.exitCode=1;}
