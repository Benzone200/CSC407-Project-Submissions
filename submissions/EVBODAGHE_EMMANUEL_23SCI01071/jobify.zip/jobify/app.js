import express from 'express';
import helmet from 'helmet';
import session from 'express-session';
import { rateLimit } from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import multer from 'multer';
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SQLiteSessionStore } from './lib/session-store.js';
import { csrfProtection, regenerate, saveSession, flash } from './lib/security.js';
import * as validate from './lib/validation.js';
import { icon } from './lib/icons.js';
import { seedListings } from './lib/seed-data.js';

const root=path.dirname(fileURLToPath(import.meta.url));
const dummyHash=await bcrypt.hash(randomBytes(24).toString('hex'),12);
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:2*1024*1024,files:1,fields:1,parts:3}});
const money=n=>'₦'+Number(n).toLocaleString('en-NG');

export function createApp({db,secret,origin='http://localhost:3000',production=false,trustProxy=false,loginLimit=15,registrationLimit=15,allowSetup=false}) {
  if(!secret || secret.length<32 || secret.startsWith('replace-')) throw new Error('Configure a random SESSION_SECRET with at least 32 characters.');
  const app=express();
  app.disable('x-powered-by');
  if(trustProxy) app.set('trust proxy',1);
  app.set('view engine','ejs'); app.set('views',path.join(root,'views'));
  app.use((req,res,next)=>{res.locals.requestId=randomUUID();res.locals.user=null;res.locals.flash=null;res.locals.csrf='';res.locals.title='Jobify';res.locals.path=req.path;res.locals.icon=icon;res.locals.money=money;res.locals.URLSearchParams=URLSearchParams;res.locals.jobTypes=validate.jobTypes;res.locals.workplaces=validate.workplaces;res.locals.categories=validate.categories;next();});
  // No inline scripts, remote fonts, frames or plugin content are needed.
  app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],scriptSrc:["'self'"],styleSrc:["'self'"],imgSrc:["'self'",'data:'],objectSrc:["'none'"],frameAncestors:["'none'"],baseUri:["'self'"],formAction:["'self'"],upgradeInsecureRequests:production?[]:null}},strictTransportSecurity:production?{maxAge:31536000,includeSubDomains:true}:false,referrerPolicy:{policy:'no-referrer'}}));
  app.use(express.static(path.join(root,'public'),{index:false,maxAge:production?'1h':0}));
  app.use(express.urlencoded({extended:false,limit:'48kb',parameterLimit:40}));
  app.use(session({name:'jobify.sid',secret,store:new SQLiteSessionStore(db),resave:false,saveUninitialized:false,rolling:true,cookie:{httpOnly:true,secure:production,sameSite:'lax',maxAge:30*60*1000}}));
  app.use((req,res,next)=>{
    // Session version invalidates sessions after a password or privilege change.
    if(req.session.userId){
      const user=db.prepare('SELECT id,name,email,role,headline,location,bio,cv_id,session_version FROM users WHERE id=?').get(req.session.userId);
      if(!user || user.session_version!==req.session.version || Date.now()-(req.session.started||0)>8*60*60*1000){return req.session.destroy(error=>{if(error)return next(error);res.clearCookie('jobify.sid',{path:'/',httpOnly:true,sameSite:'lax',secure:production});res.redirect('/login');});}
      req.user=user;res.locals.user=user;
    }
    res.set('Cache-Control','no-store');
    res.locals.flash=req.session.flash||null;delete req.session.flash;
    next();
  });
  app.use(csrfProtection(origin,production));
  const errorPage=(res,code,title,message)=>res.status(code).render('error',{code,title,message});
  const auth=(req,res,next)=>req.user?next():res.redirect('/login');
  const admin=(req,res,next)=>req.user?.role==='admin'?next():errorPage(res,403,'Access denied','You do not have permission to open this page.');
  const applicant=(req,res,next)=>req.user?.role==='applicant'?next():errorPage(res,403,'Applicant access required','This action is available to applicant accounts.');
  const id=(req,res,next)=>validate.idValid(req.params.id)?next():errorPage(res,404,'Not found','The requested record could not be found.');
  const limiter=(max)=>rateLimit({windowMs:15*60*1000,limit:max,standardHeaders:'draft-8',legacyHeaders:false,handler:(req,res)=>errorPage(res,429,'Please try again later','Too many attempts. Wait 15 minutes before trying again.')});
  const signIn=async(req,user)=>{await regenerate(req);req.session.userId=user.id;req.session.version=user.session_version;req.session.started=Date.now();await saveSession(req);};
  // First-run setup is available only until the first administrator exists.
  // Codespaces keeps the forwarded port private; local use binds to loopback.
  const hasAdmin=()=>!!db.prepare("SELECT 1 FROM users WHERE role='admin' LIMIT 1").get();
  app.use((req,res,next)=>{if(allowSetup&&!hasAdmin()&&req.path!=='/setup')return res.redirect('/setup');next();});
  app.get('/setup',(req,res)=>{
    if(!allowSetup||hasAdmin())return res.redirect('/login');
    res.render('setup',{title:'Set up Jobify',errors:[],values:{name:'Administrator',email:''}});
  });
  app.post('/setup',limiter(10),async(req,res)=>{
    if(!allowSetup||hasAdmin())return errorPage(res,409,'Setup already completed','Sign in with your administrator account.');
    const {errors,values}=validate.registration(req.body);
    if(db.prepare('SELECT 1 FROM users WHERE email=?').get(values.email))errors.push('Choose a different administrator email address.');
    if(errors.length)return res.status(422).render('setup',{title:'Set up Jobify',errors,values});
    const hash=await bcrypt.hash(req.body.password,12);
    // Recheck after hashing so concurrent setup submissions cannot create two administrators.
    if(hasAdmin())return errorPage(res,409,'Setup already completed','Sign in with your administrator account.');
    const result=db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')").run(values.name,values.email,hash);
    const adminId=Number(result.lastInsertRowid);
    seedListings(db,adminId);
    await signIn(req,{id:adminId,session_version:1});
    flash(req,'success','Your administrator account is ready.');
    res.redirect('/admin');
  });
  const jobById=jobId=>db.prepare('SELECT * FROM jobs WHERE id=?').get(jobId);
  const active=job=>job&&job.status==='open'&&job.deadline>=new Date().toISOString().slice(0,10);

  app.get('/',(req,res)=>{
    const jobs=db.prepare("SELECT * FROM jobs WHERE status='open' AND deadline>=date('now') ORDER BY id DESC LIMIT 4").all();
    const stats={jobs:db.prepare("SELECT count(*) AS n FROM jobs WHERE status='open' AND deadline>=date('now')").get().n,companies:db.prepare("SELECT count(DISTINCT company) AS n FROM jobs WHERE status='open' AND deadline>=date('now')").get().n};
    const saved=req.user?db.prepare('SELECT job_id FROM saved_jobs WHERE user_id=?').all(req.user.id).map(r=>r.job_id):[];
    res.render('home',{title:'Find jobs',jobs,stats,saved});
  });
  app.get('/jobs',(req,res)=>{
    const filters={q:validate.field(req.query,'q').slice(0,120),location:validate.field(req.query,'location').slice(0,100),type:validate.field(req.query,'type'),category:validate.field(req.query,'category'),workplace:validate.field(req.query,'workplace')};
    const where=["status='open'","deadline>=date('now')"],params=[];
    if(filters.q){where.push('(title LIKE ? OR company LIKE ? OR description LIKE ?)');params.push(...Array(3).fill('%'+filters.q+'%'));}
    if(filters.location){where.push('location LIKE ?');params.push('%'+filters.location+'%');}
    for(const k of ['type','category','workplace'])if(filters[k]){where.push(k+'=?');params.push(filters[k]);} // k comes from this fixed allowlist.
    const count=db.prepare('SELECT count(*) AS n FROM jobs WHERE '+where.join(' AND ')).get(...params).n;
    const page=Math.max(1,Math.min(Math.ceil(count/8)||1,parseInt(req.query.page,10)||1));
    const jobs=db.prepare('SELECT * FROM jobs WHERE '+where.join(' AND ')+' ORDER BY id DESC LIMIT 8 OFFSET ?').all(...params,(page-1)*8);
    const saved=req.user?db.prepare('SELECT job_id FROM saved_jobs WHERE user_id=?').all(req.user.id).map(r=>r.job_id):[];
    const pages=Math.ceil(count/8);const base=new URLSearchParams(filters);
    res.render('jobs',{title:'Find jobs',jobs,saved,filters,count,page,pages,base});
  });
  app.get('/jobs/:id',id,(req,res)=>{
    const job=jobById(req.params.id);if(!job)return errorPage(res,404,'Job not found','This job listing could not be found.');
    const application=req.user?db.prepare('SELECT id,status FROM applications WHERE job_id=? AND user_id=?').get(job.id,req.user.id):null;
    const saved=req.user?!!db.prepare('SELECT 1 FROM saved_jobs WHERE user_id=? AND job_id=?').get(req.user.id,job.id):false;
    res.render('job',{title:job.title,job,application,saved,isActive:active(job),errors:[],cover:''});
  });
  app.get('/register',(req,res)=>req.user?res.redirect('/dashboard'):res.render('auth',{title:'Create an account',mode:'register',errors:[],values:{}}));
  app.post('/register',limiter(registrationLimit),async(req,res)=>{
    if(req.user)return res.redirect('/dashboard');
    const {errors,values}=validate.registration(req.body);
    if(db.prepare('SELECT 1 FROM users WHERE email=?').get(values.email))errors.push('Unable to create an account with these details. Try signing in.');
    if(errors.length)return res.status(422).render('auth',{title:'Create an account',mode:'register',errors,values});
    const hash=await bcrypt.hash(req.body.password,12);
    const result=db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'applicant')").run(values.name,values.email,hash);
    await signIn(req,{id:Number(result.lastInsertRowid),session_version:1});flash(req,'success','Your account has been created. Complete your profile to start applying.');res.redirect('/profile');
  });
  app.get('/login',(req,res)=>req.user?res.redirect('/dashboard'):res.render('auth',{title:'Sign in',mode:'login',errors:[],values:{}}));
  app.post('/login',limiter(loginLimit),async(req,res)=>{
    const email=validate.field(req.body,'email').toLowerCase(),password=typeof req.body.password==='string'?req.body.password:'';
    const key=createHash('sha256').update(email).digest('hex');
    const prior=db.prepare('SELECT * FROM login_attempts WHERE key=?').get(key);
    const user=email.length<=120?db.prepare('SELECT id,password_hash,session_version FROM users WHERE email=?').get(email):null;
    const matches=await bcrypt.compare(password.length<=200?password:'',user?.password_hash||dummyHash);
    if(!validate.emailValid(email)||!matches||!user||(prior&&prior.locked_until>Date.now())){
      const failures=(prior&&prior.locked_until>Date.now()-15*60*1000?prior.failures:0)+1;
      db.prepare('INSERT OR REPLACE INTO login_attempts(key,failures,locked_until) VALUES(?,?,?)').run(key,failures,failures>=5?Date.now()+15*60*1000:Date.now());
      db.prepare('DELETE FROM login_attempts WHERE locked_until<?').run(Date.now()-86400000);
      return res.status(401).render('auth',{title:'Sign in',mode:'login',errors:['Unable to sign in. Check your details or try again later.'],values:{email}});
    }
    db.prepare('DELETE FROM login_attempts WHERE key=?').run(key);await signIn(req,user);res.redirect('/dashboard');
  });
  app.post('/logout',auth,(req,res,next)=>req.session.destroy(error=>{if(error)return next(error);res.clearCookie('jobify.sid',{httpOnly:true,secure:production,sameSite:'lax',path:'/'});res.redirect('/');}));

  app.get('/dashboard',auth,(req,res)=>{
    if(req.user.role==='admin')return res.redirect('/admin');
    const counts=db.prepare("SELECT count(*) AS total,sum(CASE WHEN status='shortlisted' THEN 1 ELSE 0 END) AS shortlisted,sum(CASE WHEN status IN ('submitted','reviewing') THEN 1 ELSE 0 END) AS active FROM applications WHERE user_id=?").get(req.user.id);
    counts.saved=db.prepare('SELECT count(*) AS n FROM saved_jobs WHERE user_id=?').get(req.user.id).n;
    const applications=db.prepare('SELECT a.*,j.title,j.company,j.location FROM applications a JOIN jobs j ON j.id=a.job_id WHERE a.user_id=? ORDER BY a.id DESC LIMIT 5').all(req.user.id);
    res.render('dashboard',{title:'Dashboard',counts,applications});
  });
  app.post('/jobs/:id/save',auth,applicant,id,(req,res)=>{
    if(!jobById(req.params.id))return errorPage(res,404,'Job not found','This listing could not be found.');
    const exists=db.prepare('SELECT 1 FROM saved_jobs WHERE user_id=? AND job_id=?').get(req.user.id,req.params.id);
    if(exists)db.prepare('DELETE FROM saved_jobs WHERE user_id=? AND job_id=?').run(req.user.id,req.params.id);
    else db.prepare('INSERT INTO saved_jobs(user_id,job_id) VALUES(?,?)').run(req.user.id,req.params.id);
    flash(req,'success',exists?'Job removed from saved jobs.':'Job saved.');res.redirect('/jobs/'+req.params.id);
  });
  app.get('/saved',auth,applicant,(req,res)=>{
    const jobs=db.prepare('SELECT j.* FROM jobs j JOIN saved_jobs s ON s.job_id=j.id WHERE s.user_id=? ORDER BY j.id DESC').all(req.user.id);
    res.render('saved',{title:'Saved jobs',jobs,saved:jobs.map(j=>j.id)});
  });
  app.post('/jobs/:id/apply',auth,applicant,id,(req,res)=>{
    const job=jobById(req.params.id);if(!job)return errorPage(res,404,'Job not found','This listing could not be found.');
    if(!active(job))return errorPage(res,409,'Applications closed','This role is no longer accepting applications.');
    if(db.prepare('SELECT 1 FROM applications WHERE user_id=? AND job_id=?').get(req.user.id,job.id))return errorPage(res,409,'Already applied','You already have an application for this job.');
    const cover=validate.field(req.body,'cover_letter'),errors=[];
    if(!req.user.cv_id)errors.push('Upload your CV in Profile before applying.');
    if(cover.length<40||cover.length>5000)errors.push('Your cover letter must contain 40–5,000 characters.');
    if(errors.length)return res.status(422).render('job',{title:job.title,job,application:null,saved:false,isActive:true,errors,cover});
    db.prepare('INSERT INTO applications(user_id,job_id,cv_id,cover_letter) VALUES(?,?,?,?)').run(req.user.id,job.id,req.user.cv_id,cover);
    flash(req,'success','Your application has been submitted.');res.redirect('/applications');
  });
  app.get('/applications',auth,applicant,(req,res)=>{
    const applications=db.prepare('SELECT a.*,j.title,j.company,j.location FROM applications a JOIN jobs j ON j.id=a.job_id WHERE a.user_id=? ORDER BY a.id DESC').all(req.user.id);
    res.render('applications',{title:'My applications',applications});
  });
  app.get('/applications/:id',auth,applicant,id,(req,res)=>{
    const application=db.prepare('SELECT a.*,j.title,j.company FROM applications a JOIN jobs j ON j.id=a.job_id WHERE a.id=? AND a.user_id=?').get(req.params.id,req.user.id);
    if(!application)return errorPage(res,404,'Application not found','This application could not be found.');
    res.render('application',{title:'Application details',application,errors:[]});
  });
  app.post('/applications/:id/edit',auth,applicant,id,(req,res)=>{
    const a=db.prepare('SELECT a.*,j.title,j.company FROM applications a JOIN jobs j ON j.id=a.job_id WHERE a.id=? AND a.user_id=?').get(req.params.id,req.user.id);
    if(!a)return errorPage(res,404,'Application not found','This application could not be found.');
    if(!['submitted','reviewing'].includes(a.status))return errorPage(res,409,'Application cannot be edited','Only submitted applications or applications under review can be edited.');
    const cover=validate.field(req.body,'cover_letter');
    if(cover.length<40||cover.length>5000)return res.status(422).render('application',{title:'Application details',application:{...a,cover_letter:cover},errors:['Use 40–5,000 characters for your cover letter.']});
    db.prepare('UPDATE applications SET cover_letter=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?').run(cover,a.id,req.user.id);flash(req,'success','Application updated.');res.redirect('/applications/'+a.id);
  });
  app.post('/applications/:id/withdraw',auth,applicant,id,(req,res)=>{
    const a=db.prepare('SELECT status FROM applications WHERE id=? AND user_id=?').get(req.params.id,req.user.id);
    if(!a)return errorPage(res,404,'Application not found','This application could not be found.');
    if(['withdrawn','hired','rejected'].includes(a.status))return errorPage(res,409,'Application cannot be withdrawn','This application is already closed.');
    db.prepare("UPDATE applications SET status='withdrawn',updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?").run(req.params.id,req.user.id);flash(req,'success','Application withdrawn.');res.redirect('/applications');
  });
  app.post('/applications/:id/delete',auth,applicant,id,(req,res)=>{
    const result=db.prepare("DELETE FROM applications WHERE id=? AND user_id=? AND status='withdrawn'").run(req.params.id,req.user.id);
    if(!result.changes)return errorPage(res,409,'Application cannot be removed','Withdraw your application before deleting it.');
    flash(req,'success','Application removed.');res.redirect('/applications');
  });

  function profilePage(req,res,errors=[],values=null,status=200){const cv=req.user.cv_id?db.prepare('SELECT id,original_name,created_at FROM cvs WHERE id=? AND user_id=?').get(req.user.cv_id,req.user.id):null;return res.status(status).render('profile',{title:'My profile',values:values||req.user,cv,errors});}
  app.get('/profile',auth,(req,res)=>profilePage(req,res));
  app.post('/profile',auth,async(req,res)=>{
    const {errors,values}=validate.profile(req.body);
    const existing=db.prepare('SELECT id FROM users WHERE email=? AND id<>?').get(values.email,req.user.id);
    if(existing)errors.push('Unable to use these account details.');
    const emailChanged=values.email!==req.user.email;
    if(emailChanged){const row=db.prepare('SELECT password_hash FROM users WHERE id=?').get(req.user.id);if(!await bcrypt.compare(typeof req.body.current_password==='string'?req.body.current_password:'',row.password_hash))errors.push('Enter your current password to change your email address.');}
    if(errors.length)return profilePage(req,res,errors,values,422);
    db.prepare('UPDATE users SET name=?,email=?,headline=?,location=?,bio=? WHERE id=?').run(values.name,values.email,values.headline,values.location,values.bio,req.user.id);
    flash(req,'success','Your profile has been updated.');res.redirect('/profile');
  });
  app.post('/profile/password',auth,async(req,res)=>{
    const errors=[];const row=db.prepare('SELECT password_hash,session_version FROM users WHERE id=?').get(req.user.id);
    if(!await bcrypt.compare(typeof req.body.current_password==='string'?req.body.current_password:'',row.password_hash))errors.push('Your current password is incorrect.');
    if(!validate.passwordValid(req.body.password))errors.push('Use at least 12 characters with uppercase, lowercase and a number (maximum 72 UTF-8 bytes).');
    if(req.body.password!==req.body.confirm_password)errors.push('New passwords must match.');
    if(errors.length)return profilePage(req,res,errors,null,422);
    const hash=await bcrypt.hash(req.body.password,12);
    db.prepare('UPDATE users SET password_hash=?,session_version=session_version+1 WHERE id=?').run(hash,req.user.id);
    await signIn(req,{id:req.user.id,session_version:row.session_version+1});flash(req,'success','Password changed. Other sessions have been signed out.');res.redirect('/profile');
  });
  // CSRF is checked before multipart data is accepted. The upload client sends the token in a header.
  app.post('/profile/cv',auth,applicant,upload.single('cv'),(req,res)=>{
    const file=req.file;
    if(!file||file.mimetype!=='application/pdf'||!file.originalname.toLowerCase().endsWith('.pdf')||file.buffer.subarray(0,5).toString()!=='%PDF-'||!file.buffer.subarray(-1024).toString().includes('%%EOF')||/\/(JavaScript|JS|Launch|EmbeddedFile|OpenAction|RichMedia|AA)\b/i.test(file.buffer.toString('latin1')))return res.status(422).json({error:'Upload a PDF CV without scripts or attachments, up to 2 MB.'});
    const filename=path.basename(file.originalname).replace(/[^a-zA-Z0-9 ._-]/g,'_').slice(0,120)||'CV.pdf';
    db.exec('BEGIN');
    try {
      const prior=req.user.cv_id;
      const result=db.prepare('INSERT INTO cvs(user_id,original_name,data) VALUES(?,?,?)').run(req.user.id,filename,file.buffer);
      db.prepare('UPDATE users SET cv_id=? WHERE id=?').run(Number(result.lastInsertRowid),req.user.id);
      if(prior)db.prepare('DELETE FROM cvs WHERE id=? AND NOT EXISTS(SELECT 1 FROM applications WHERE cv_id=?)').run(prior,prior);
      db.exec('COMMIT');
    }catch(error){db.exec('ROLLBACK');throw error;}
    res.json({success:true});
  });
  app.post('/profile/cv/delete',auth,applicant,(req,res)=>{
    const prior=req.user.cv_id;
    if(prior){db.exec('BEGIN');try{db.prepare('UPDATE users SET cv_id=NULL WHERE id=?').run(req.user.id);db.prepare('DELETE FROM cvs WHERE id=? AND NOT EXISTS(SELECT 1 FROM applications WHERE cv_id=?)').run(prior,prior);db.exec('COMMIT');}catch(error){db.exec('ROLLBACK');throw error;}}
    flash(req,'success','CV removed from your profile. Copies already attached to applications are retained with those applications.');res.redirect('/profile');
  });
  app.get('/cv/:id',auth,id,(req,res)=>{
    // CVs are never in the public directory; every download has an ownership/review check.
    const cv=db.prepare('SELECT * FROM cvs WHERE id=?').get(req.params.id);
    const reviewing=req.user.role==='admin'&&db.prepare('SELECT 1 FROM applications WHERE cv_id=?').get(req.params.id);
    if(!cv||(cv.user_id!==req.user.id&&!reviewing))return errorPage(res,404,'CV not found','This CV could not be found.');
    res.set({'Content-Type':'application/pdf','Content-Disposition':'attachment; filename="CV.pdf"','Content-Security-Policy':"default-src 'none'; sandbox",'Cache-Control':'no-store'});res.send(Buffer.from(cv.data));
  });

  app.get('/admin',auth,admin,(req,res)=>{
    const counts={jobs:db.prepare('SELECT count(*) AS n FROM jobs').get().n,applications:db.prepare('SELECT count(*) AS n FROM applications').get().n,applicants:db.prepare("SELECT count(*) AS n FROM users WHERE role='applicant'").get().n,reviewing:db.prepare("SELECT count(*) AS n FROM applications WHERE status IN ('submitted','reviewing')").get().n};
    const jobs=db.prepare('SELECT j.*,(SELECT count(*) FROM applications a WHERE a.job_id=j.id) AS application_count FROM jobs j ORDER BY j.id DESC').all();
    res.render('admin',{title:'Admin dashboard',counts,jobs});
  });
  const jobForm=(res,values={},errors=[],editing=false,code=200)=>res.status(code).render('job-form',{title:editing?'Edit job':'Post a job',values,errors,editing});
  app.get('/admin/jobs/new',auth,admin,(req,res)=>jobForm(res));
  app.post('/admin/jobs',auth,admin,(req,res)=>{
    const {errors,values:v}=validate.job(req.body);if(errors.length)return jobForm(res,v,errors,false,422);
    const columns=['title','company','location','workplace','type','category','salary_min','salary_max','description','requirements','deadline','status'];
    db.prepare('INSERT INTO jobs('+columns.join(',')+',created_by) VALUES('+columns.map(()=>'?').join(',')+',?)').run(...columns.map(k=>v[k]),req.user.id);
    flash(req,'success','Job listing published.');res.redirect('/admin');
  });
  app.get('/admin/jobs/:id/edit',auth,admin,id,(req,res)=>{const job=jobById(req.params.id);if(!job)return errorPage(res,404,'Job not found','This job listing could not be found.');jobForm(res,job,[],true);});
  app.post('/admin/jobs/:id/edit',auth,admin,id,(req,res)=>{
    if(!jobById(req.params.id))return errorPage(res,404,'Job not found','This job listing could not be found.');
    const {errors,values:v}=validate.job(req.body);if(errors.length)return jobForm(res,{...v,id:req.params.id},errors,true,422);
    db.prepare('UPDATE jobs SET title=?,company=?,location=?,workplace=?,type=?,category=?,salary_min=?,salary_max=?,description=?,requirements=?,deadline=?,status=? WHERE id=?').run(v.title,v.company,v.location,v.workplace,v.type,v.category,v.salary_min,v.salary_max,v.description,v.requirements,v.deadline,v.status,req.params.id);
    flash(req,'success','Job listing updated.');res.redirect('/admin');
  });
  app.post('/admin/jobs/:id/delete',auth,admin,id,(req,res)=>{
    if(db.prepare('SELECT 1 FROM applications WHERE job_id=?').get(req.params.id))return errorPage(res,409,'Listing has applications','Close this job instead of deleting it to preserve application records.');
    const result=db.prepare('DELETE FROM jobs WHERE id=?').run(req.params.id);if(!result.changes)return errorPage(res,404,'Job not found','This job listing could not be found.');flash(req,'success','Job listing deleted.');res.redirect('/admin');
  });
  app.get('/admin/applications',auth,admin,(req,res)=>{
    const status=validate.field(req.query,'status'),q=validate.field(req.query,'q').slice(0,120);
    const params=[],where=[];
    if(status&&[...validate.reviewStatuses,'withdrawn'].includes(status)){where.push('a.status=?');params.push(status);}
    if(q){where.push('(j.title LIKE ? OR u.name LIKE ?)');params.push('%'+q+'%','%'+q+'%');}
    const applications=db.prepare('SELECT a.*,j.title,j.company,u.name,u.email,u.headline FROM applications a JOIN jobs j ON j.id=a.job_id JOIN users u ON u.id=a.user_id'+(where.length?' WHERE '+where.join(' AND '):'')+' ORDER BY a.id DESC').all(...params);
    res.render('admin-applications',{title:'Review applications',applications,status,q,reviewStatuses:validate.reviewStatuses});
  });
  app.post('/admin/applications/:id/status',auth,admin,id,(req,res)=>{
    const status=validate.field(req.body,'status');if(!validate.reviewStatuses.includes(status))return errorPage(res,422,'Invalid status','Choose a valid application status.');
    const a=db.prepare('SELECT status FROM applications WHERE id=?').get(req.params.id);
    if(!a)return errorPage(res,404,'Application not found','This application could not be found.');
    if(a.status==='withdrawn')return errorPage(res,409,'Application withdrawn','A withdrawn application cannot be reopened by an administrator.');
    db.prepare('UPDATE applications SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,req.params.id);
    flash(req,'success','Application status updated.');res.redirect('/admin/applications');
  });
  app.get('/security',(req,res)=>res.render('security',{title:'Security'}));
  app.get('/help',(req,res)=>res.render('help',{title:'Help Center'}));
  app.use((req,res)=>errorPage(res,404,'Page not found','The page you requested could not be found.'));
  app.use((error,req,res,next)=>{
    if(res.headersSent)return next(error);
    if(req.path==='/profile/cv'&&(error instanceof multer.MulterError||error.status===413))return res.status(422).json({error:'Upload one PDF file, up to 2 MB.'});
    const status=error.status>=400&&error.status<500?error.status:500;
    // Log only a correlation ID and error class, never bodies, passwords, CVs or SQL values.
    if(status===500&&process.env.NODE_ENV!=='test')console.error(JSON.stringify({requestId:res.locals.requestId,event:'request_failed',errorType:error.name}));
    errorPage(res,status,status===500?'Something went wrong':'Invalid request',status===500?'Please try again. If the issue continues, use the reference '+res.locals.requestId+'.':'Check your request and try again.');
  });
  return app;
}
