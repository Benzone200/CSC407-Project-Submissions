#!/bin/bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Install Node.js 24 LTS from https://nodejs.org, then reopen this file."
  read -r -p "Press Enter to close."
  exit 1
fi
NODE_MAJOR=$(node -p 'Number(process.versions.node.split(".")[0])')
if [ "$NODE_MAJOR" -lt 24 ]; then
  echo "Jobify needs Node.js 24 or newer. Install Node.js 24 LTS from https://nodejs.org."
  read -r -p "Press Enter to close."
  exit 1
fi
if [ ! -d node_modules ]; then
  echo "Installing packages. Internet is needed for this first setup only."
  npm ci --no-fund
fi
npm run setup
(sleep 3; open "http://localhost:3000") &
echo "Keep this window open while using Jobify. Press Control+C to stop."
npm start
