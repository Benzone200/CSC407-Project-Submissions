// Small progressive enhancements. The site works fully without JavaScript.
// Kept in a separate file (no inline scripts) so the Content Security Policy can block injected code.

// Lets the CSS hide things that only matter without JavaScript (e.g. the mobile menu
// stays open and "Filter" buttons stay visible when scripts are off).
document.documentElement.classList.add('js');

document.addEventListener('DOMContentLoaded', () => {
  // Mobile menu toggle
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('site-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
    });
  }

  // Account menu: opens on hover (CSS) and on click/tap; Escape or clicking elsewhere closes it.
  const accountMenu = document.querySelector('[data-account-menu]');
  if (accountMenu) {
    const trigger = accountMenu.querySelector('.account-trigger');
    const setOpen = (open) => {
      accountMenu.classList.toggle('open', open);
      trigger.setAttribute('aria-expanded', String(open));
    };
    trigger.addEventListener('click', (event) => {
      event.stopPropagation();
      setOpen(!accountMenu.classList.contains('open'));
    });
    document.addEventListener('click', (event) => {
      if (!accountMenu.contains(event.target)) setOpen(false);
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && accountMenu.classList.contains('open')) {
        setOpen(false);
        trigger.focus();
      }
    });
    accountMenu.addEventListener('mouseenter', () => trigger.setAttribute('aria-expanded', 'true'));
    accountMenu.addEventListener('mouseleave', () => {
      if (!accountMenu.classList.contains('open')) trigger.setAttribute('aria-expanded', 'false');
    });
  }

  // Ask before destructive actions, e.g. deleting a product
  document.querySelectorAll('form[data-confirm]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      if (!window.confirm(form.dataset.confirm)) event.preventDefault();
    });
  });

  // Apply filters as soon as a dropdown or checkbox changes
  document.querySelectorAll('form[data-autosubmit]').forEach((form) => {
    form.querySelectorAll('select, input[type="checkbox"]').forEach((input) => {
      input.addEventListener('change', () => form.requestSubmit());
    });
  });

  // Quantity steppers (−/+ buttons around a number field)
  document.querySelectorAll('.qty-stepper').forEach((stepper) => {
    const input = stepper.querySelector('input');
    stepper.querySelectorAll('.qty-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const min = Number(input.min || 0);
        const max = Number(input.max || 99);
        const next = Math.min(max, Math.max(min, (Number(input.value) || 0) + Number(btn.dataset.step)));
        if (next === Number(input.value)) return;
        input.value = next;
        input.dispatchEvent(new Event('change', { bubbles: true }));
      });
    });
  });

  // Cart: save quantity changes automatically (short delay so several clicks count as one)
  document.querySelectorAll('form[data-autoupdate]').forEach((form) => {
    let timer;
    form.addEventListener('change', () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        form.classList.add('is-updating');
        form.requestSubmit();
      }, 500);
    });
  });

  // Product form: preview an uploaded photo or the library photo picked
  const photoInput = document.querySelector('[data-photo-input]');
  const preview = document.querySelector('[data-photo-preview]');
  const showPreview = (src) => {
    if (!preview) return;
    const img = document.createElement('img');
    img.src = src;
    img.alt = 'Selected photo';
    preview.replaceChildren(img);
  };
  if (photoInput) {
    const nameLine = document.querySelector('[data-photo-name]');
    photoInput.addEventListener('change', () => {
      const file = photoInput.files[0];
      if (!file) return;
      if (nameLine) nameLine.textContent = `${file.name} · ${(file.size / 1024 / 1024).toFixed(1)} MB`;
      const reader = new FileReader();
      reader.onload = () => showPreview(reader.result);
      reader.readAsDataURL(file);
      document.querySelectorAll('.image-option input').forEach((r) => { r.checked = false; });
    });
  }
  document.querySelectorAll('.image-option input').forEach((radio) => {
    radio.addEventListener('change', () => {
      if (photoInput) photoInput.value = '';
      showPreview(radio.nextElementSibling.src);
    });
  });

  // Loading state: disable the submit button while the form is sending,
  // so a double click cannot, for example, place the same order twice.
  document.querySelectorAll('button[data-loading]').forEach((button) => {
    const form = button.form;
    if (!form) return;
    button.dataset.label = button.textContent;
    form.addEventListener('submit', (event) => {
      if (event.defaultPrevented) return;
      if (form.dataset.submitting) {
        event.preventDefault();
        return;
      }
      form.dataset.submitting = '1';
      button.disabled = true;
      button.setAttribute('aria-busy', 'true');
      button.textContent = button.dataset.loading;
    });
  });
});

// Restore buttons when the browser shows a cached page (e.g. after pressing Back).
window.addEventListener('pageshow', (event) => {
  if (!event.persisted) return;
  document.querySelectorAll('button[data-loading][aria-busy]').forEach((button) => {
    button.disabled = false;
    button.removeAttribute('aria-busy');
    button.textContent = button.dataset.label;
    delete button.form.dataset.submitting;
  });
});
