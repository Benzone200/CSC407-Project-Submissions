'use strict';
// Builds the Express application. Kept separate from server.js so the tests
// can create an app with an in-memory database.

const path = require('node:path');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');

const { openDatabase } = require('./db');
const { seedIfEmpty } = require('./seed');
const SqliteSessionStore = require('./session-store');
const { csrfProtection } = require('./middleware/csrf');
const { createKoraClient } = require('./payments/kora');
const { createPaymentService } = require('./payments/service');
const { paymentRoutes, paymentWebhookRouter } = require('./routes/payments');
const { loadUser, requireAdmin } = require('./middleware/auth');
const {
  formatNaira, formatDate, formatDateTime, cartCount, paymentLabel, DELIVERY_FEE_KOBO, FREE_DELIVERY_FROM_KOBO,
} = require('./helpers');

function createApp(options = {}) {
  const config = {
    dbFile: ':memory:',
    sessionSecret: 'dev-only-secret',
    isProduction: false,
    trustProxy: false,
    bcryptRounds: 12,
    loginRateLimit: 10,
    appUrl: 'http://localhost:3000',
    koraSecretKey: '',
    demoLogin: true,
    ...options,
  };

  const db = openDatabase(config.dbFile);
  seedIfEmpty(db, { bcryptRounds: config.bcryptRounds });

  // Payments: real Kora when a secret key is set (or a client is injected by tests),
  // otherwise the local simulator outside production.
  let kora = config.kora || null;
  if (!kora && config.koraSecretKey) {
    kora = createKoraClient({ secretKey: config.koraSecretKey });
    kora.testMode = config.koraSecretKey.startsWith('sk_test');
  }
  const payments = createPaymentService(db, {
    kora,
    simulatorEnabled: config.paymentSimulator ?? !config.isProduction,
    appUrl: config.appUrl,
  });

  const app = express();
  app.locals.db = db;
  app.locals.payments = payments;
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, '..', 'views'));
  app.disable('x-powered-by');
  if (config.trustProxy) app.set('trust proxy', 1);

  // Security headers, including a strict Content Security Policy: scripts and
  // styles may only come from this site, which blocks most injected-script (XSS) attacks.
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'"],
        imgSrc: ["'self'", 'data:'],
        // Checkout forms redirect to Kora's hosted payment page.
        formAction: ["'self'", 'https://checkout.korapay.com'],
        frameAncestors: ["'none'"],
        objectSrc: ["'none'"],
        upgradeInsecureRequests: config.isProduction ? [] : null,
      },
    },
  }));

  app.use(express.static(path.join(__dirname, '..', 'public'), { maxAge: config.isProduction ? '7d' : 0 }));

  // Kora webhooks are signed server-to-server calls: no session, no CSRF token.
  app.use(paymentWebhookRouter(payments));
  app.use(express.urlencoded({ extended: false, limit: '20kb' }));

  app.use(session({
    name: 'papernest.sid',
    secret: config.sessionSecret,
    store: new SqliteSessionStore(db),
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: {
      httpOnly: true, // JavaScript cannot read the cookie
      sameSite: 'lax', // not sent on cross-site form posts
      secure: config.isProduction, // HTTPS only in production
      maxAge: 2 * 60 * 60 * 1000, // 2 hours of inactivity
    },
  }));

  app.use(loadUser(db));

  // Values every page template can use. Set before the CSRF check so the
  // error page can still render if that check fails.
  app.use((req, res, next) => {
    res.locals.formatNaira = formatNaira;
    res.locals.paymentLabel = paymentLabel;
    res.locals.onlinePayments = payments.onlineAvailable;
    res.locals.paymentsTestMode = payments.isTestMode;
    res.locals.formatDate = formatDate;
    res.locals.formatDateTime = formatDateTime;
    res.locals.deliveryFee = DELIVERY_FEE_KOBO;
    res.locals.freeDeliveryFrom = FREE_DELIVERY_FROM_KOBO;
    res.locals.cartCount = cartCount(req.session);
    res.locals.currentPath = req.path;
    res.locals.currentUrl = req.originalUrl;
    res.locals.searchQuery = typeof req.query.q === 'string' ? req.query.q : '';
    // One-time messages ("Item added to cart") shown on the next page.
    res.locals.flash = req.session.flash || null;
    delete req.session.flash;
    next();
  });

  app.use(csrfProtection);

  app.use(require('./routes/shop')(db));
  app.use(require('./routes/cart')(db, payments));
  app.use(paymentRoutes(db, payments));
  app.use(require('./routes/auth')(db, config));
  app.use('/admin', requireAdmin, require('./routes/admin')(db, payments));

  app.get('/healthz', (req, res) => res.type('text').send('ok'));

  // 404 handler
  app.use((req, res) => {
    res.status(404).render('error', {
      title: 'Page not found', status: 404, message: 'We could not find the page you were looking for.',
    });
  });

  // Error handler. Details are logged on the server, never shown to the visitor.
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    const status = err.status || err.statusCode || 500;
    if (status >= 500) console.error(err);
    const message = status < 500 ? err.message : 'An unexpected error occurred. Please try again.';
    res.status(status).render('error', {
      title: status === 403 ? 'Not allowed' : 'Something went wrong', status, message,
    }, (renderErr, html) => {
      if (renderErr) {
        // Last resort if the error page itself fails: plain text, no details.
        console.error(renderErr);
        return res.type('text').send(message);
      }
      res.send(html);
    });
  });

  return app;
}

module.exports = { createApp };
