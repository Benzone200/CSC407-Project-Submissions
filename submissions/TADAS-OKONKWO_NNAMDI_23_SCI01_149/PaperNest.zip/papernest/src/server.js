'use strict';
// Entry point: `npm start`

const config = require('./config');
const { createApp } = require('./app');

const app = createApp(config);

app.listen(config.port, () => {
  console.log(`PaperNest is running at http://localhost:${config.port}`);
});
