'use strict';
// Reads settings from environment variables (see .env.example).

const path = require('node:path');
const crypto = require('node:crypto');

const isProduction = process.env.NODE_ENV === 'production';

let sessionSecret = process.env.SESSION_SECRET;
if (!sessionSecret) {
  if (isProduction) {
    throw new Error('SESSION_SECRET must be set in production.');
  }
  // Development only: a random secret means sessions reset when the server restarts.
  sessionSecret = crypto.randomBytes(32).toString('hex');
}

const port = Number(process.env.PORT) || 3000;

module.exports = {
  isProduction,
  port,
  // Public address of the site. Kora sends customers back here after paying.
  appUrl: (process.env.APP_URL || `http://localhost:${port}`).replace(/\/+$/, ''),
  // Kora secret key (sk_test_... for the sandbox). Without it, a local payment
  // simulator is used in development so the checkout can still be demonstrated.
  koraSecretKey: process.env.KORA_SECRET_KEY || '',
  // One-click demo logins on the login page (for assessment). Set DEMO_LOGIN=0 to turn off.
  demoLogin: process.env.DEMO_LOGIN !== '0',
  dbFile: process.env.DATABASE_FILE || path.join(__dirname, '..', 'data', 'papernest.db'),
  sessionSecret,
  bcryptRounds: Number(process.env.BCRYPT_ROUNDS) || 12,
  // Set TRUST_PROXY=1 when running behind a host's HTTPS proxy (Render, Railway, etc.).
  trustProxy: process.env.TRUST_PROXY === '1',
};
