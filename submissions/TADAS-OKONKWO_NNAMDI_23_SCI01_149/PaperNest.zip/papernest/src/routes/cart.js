'use strict';
// Shopping cart (add, update quantity, remove) and checkout.

const crypto = require('node:crypto');
const express = require('express');
const { transaction } = require('../db');
const { requireLogin } = require('../middleware/auth');
const {
  str, parseIntInRange, getCart, buildCart, PHONE_RE, MAX_QTY_PER_ITEM, safeRedirectPath, setFlash: flash,
} = require('../helpers');

const NIGERIAN_STATES = [
  'Abia', 'Adamawa', 'Akwa Ibom', 'Anambra', 'Bauchi', 'Bayelsa', 'Benue', 'Borno', 'Cross River',
  'Delta', 'Ebonyi', 'Edo', 'Ekiti', 'Enugu', 'FCT - Abuja', 'Gombe', 'Imo', 'Jigawa', 'Kaduna',
  'Kano', 'Katsina', 'Kebbi', 'Kogi', 'Kwara', 'Lagos', 'Nasarawa', 'Niger', 'Ogun', 'Ondo', 'Osun',
  'Oyo', 'Plateau', 'Rivers', 'Sokoto', 'Taraba', 'Yobe', 'Zamfara',
];

class StockError extends Error {}

module.exports = function cartRoutes(db, payments) {
  const router = express.Router();
  const productStmt = db.prepare('SELECT id, name, stock FROM products WHERE id = ?');

  router.get('/cart', (req, res) => {
    const cart = buildCart(db, req.session);
    if (cart.adjusted) {
      res.locals.flash = {
        type: 'info',
        message: 'Some items in your cart changed because of stock levels. Please review your cart.',
      };
    }
    res.render('cart', { title: 'Your cart', cart });
  });

  router.post('/cart/add', (req, res) => {
    const productId = parseIntInRange(req.body.product_id, 1, Number.MAX_SAFE_INTEGER);
    const qty = parseIntInRange(req.body.quantity ?? '1', 1, MAX_QTY_PER_ITEM);
    const back = safeRedirectPath(req.body.return_to, '/cart');
    const product = productId && productStmt.get(productId);

    if (!product || !qty) {
      flash(req, 'error', 'That product could not be added.');
      return res.redirect(back);
    }
    const cart = getCart(req.session);
    const wanted = (cart[product.id] || 0) + qty;
    const allowed = Math.min(wanted, product.stock, MAX_QTY_PER_ITEM);
    if (allowed <= 0) {
      flash(req, 'error', `${product.name} is out of stock.`);
    } else {
      cart[product.id] = allowed;
      flash(req, allowed < wanted ? 'info' : 'success', allowed < wanted
        ? `Only ${allowed} of ${product.name} can be added (limited stock).`
        : `${product.name} was added to your cart.`);
    }
    res.redirect(back);
  });

  router.post('/cart/update', (req, res) => {
    const productId = parseIntInRange(req.body.product_id, 1, Number.MAX_SAFE_INTEGER);
    const qty = parseIntInRange(req.body.quantity, 0, MAX_QTY_PER_ITEM);
    const cart = getCart(req.session);
    if (!productId || qty === null || !(productId in cart)) {
      flash(req, 'error', 'Enter a quantity between 0 and 99.');
      return res.redirect('/cart');
    }
    if (qty === 0) {
      delete cart[productId];
      flash(req, 'success', 'Item removed from your cart.');
    } else {
      const product = productStmt.get(productId);
      cart[productId] = Math.min(qty, product ? product.stock : 0);
      if (cart[productId] < qty) {
        flash(req, 'info', `Only ${cart[productId]} left in stock, so your quantity was reduced.`);
      } else {
        flash(req, 'success', 'Cart updated.');
      }
      if (cart[productId] === 0) delete cart[productId];
    }
    res.redirect('/cart');
  });

  router.post('/cart/remove', (req, res) => {
    const productId = parseIntInRange(req.body.product_id, 1, Number.MAX_SAFE_INTEGER);
    const cart = getCart(req.session);
    if (productId && productId in cart) {
      delete cart[productId];
      flash(req, 'success', 'Item removed from your cart.');
    }
    res.redirect('/cart');
  });

  // ---- Checkout ----

  router.get('/checkout', requireLogin, (req, res) => {
    const cart = buildCart(db, req.session);
    if (cart.items.length === 0) {
      flash(req, 'info', 'Your cart is empty.');
      return res.redirect('/cart');
    }
    res.render('checkout', {
      title: 'Checkout',
      cart,
      states: NIGERIAN_STATES,
      values: { full_name: req.user.name, payment_method: payments.onlineAvailable ? 'online' : 'cod' },
      errors: {},
    });
  });

  const updateStock = db.prepare('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?');
  const insertOrder = db.prepare(`
    INSERT INTO orders (reference, user_id, full_name, phone, address, city, state, notes,
                        subtotal_kobo, delivery_kobo, total_kobo, payment_method, payment_status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  const insertItem = db.prepare(`
    INSERT INTO order_items (order_id, product_id, product_name, unit_price_kobo, quantity)
    VALUES (?, ?, ?, ?, ?)`);

  router.post('/checkout', requireLogin, async (req, res, next) => {
    const values = {
      full_name: str(req.body.full_name),
      phone: str(req.body.phone),
      address: str(req.body.address),
      city: str(req.body.city),
      state: str(req.body.state),
      notes: str(req.body.notes),
      // Older clients that don't send a choice get pay on delivery.
      payment_method: str(req.body.payment_method) || 'cod',
    };
    const errors = {};
    const methods = payments.onlineAvailable ? ['online', 'cod'] : ['cod'];
    if (!methods.includes(values.payment_method)) errors.payment_method = 'Choose how you want to pay.';
    if (values.full_name.length < 2 || values.full_name.length > 100) errors.full_name = 'Enter your full name.';
    if (!PHONE_RE.test(values.phone)) errors.phone = 'Enter a valid phone number, e.g. 0803 123 4567.';
    if (values.address.length < 5 || values.address.length > 200) errors.address = 'Enter your street address.';
    if (values.city.length < 2 || values.city.length > 60) errors.city = 'Enter your city or town.';
    if (!NIGERIAN_STATES.includes(values.state)) errors.state = 'Choose your state.';
    if (values.notes.length > 300) errors.notes = 'Delivery notes must be 300 characters or fewer.';

    const cart = buildCart(db, req.session);
    if (cart.items.length === 0) {
      flash(req, 'info', 'Your cart is empty.');
      return res.redirect('/cart');
    }
    if (cart.adjusted) {
      flash(req, 'info', 'Some items changed because of stock levels. Please review your cart before paying.');
      return res.redirect('/cart');
    }
    if (Object.keys(errors).length > 0) {
      return res.status(422).render('checkout', {
        title: 'Checkout', cart, states: NIGERIAN_STATES, values, errors,
      });
    }

    const reference = `PN-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    try {
      // All-or-nothing: stock is reduced and the order is saved together.
      transaction(db, () => {
        for (const item of cart.items) {
          const { changes } = updateStock.run(item.quantity, item.id, item.quantity);
          if (changes !== 1) throw new StockError(item.name);
        }
        const orderId = insertOrder.run(
          reference, req.user.id, values.full_name, values.phone, values.address, values.city,
          values.state, values.notes, cart.subtotal, cart.delivery, cart.total,
          values.payment_method, values.payment_method === 'online' ? 'pending' : 'unpaid',
        ).lastInsertRowid;
        for (const item of cart.items) {
          insertItem.run(orderId, item.id, item.name, item.price_kobo, item.quantity);
        }
      });
    } catch (err) {
      if (err instanceof StockError) {
        flash(req, 'error', `Sorry, ${err.message} just sold out. Please review your cart.`);
        return res.redirect('/cart');
      }
      return next(err);
    }

    req.session.cart = {};
    if (values.payment_method === 'cod') {
      flash(req, 'success', 'Thank you! Your order has been placed. You will pay when it arrives.');
      return res.redirect(`/orders/${reference}`);
    }

    // Online payment: send the customer to the payment page.
    const order = db.prepare('SELECT * FROM orders WHERE reference = ?').get(reference);
    try {
      res.redirect(await payments.startPayment(order, req.user));
    } catch (err) {
      console.error('Could not start payment:', err.message);
      flash(req, 'error', 'Your order was saved, but we could not open the payment page. Please use "Pay now" to try again.');
      res.redirect(`/orders/${reference}`);
    }
  });

  return router;
};

