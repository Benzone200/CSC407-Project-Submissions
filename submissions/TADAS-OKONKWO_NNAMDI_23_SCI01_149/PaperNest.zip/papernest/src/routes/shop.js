'use strict';
// Public pages: homepage, product catalogue with search/filter, product details.

const express = require('express');
const { str, parseIntInRange, parseNairaToKobo, likePattern } = require('../helpers');

const PAGE_SIZE = 12;

// Whitelisted sort options. User input picks a key; it never reaches the SQL directly.
const SORTS = {
  newest: 'p.created_at DESC, p.id DESC',
  price_asc: 'p.price_kobo ASC, p.id',
  price_desc: 'p.price_kobo DESC, p.id',
  name: 'p.name COLLATE NOCASE ASC',
};

module.exports = function shopRoutes(db) {
  const router = express.Router();

  const featuredStmt = db.prepare(`
    SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id = p.category_id
    WHERE p.featured = 1 AND p.stock > 0 ORDER BY p.id`);
  const onSaleStmt = db.prepare(`
    SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id = p.category_id
    WHERE p.old_price_kobo IS NOT NULL AND p.stock > 0
    ORDER BY (p.old_price_kobo - p.price_kobo) * 1.0 / p.old_price_kobo DESC LIMIT 4`);
  const categoriesStmt = db.prepare(`
    SELECT c.*, COUNT(p.id) AS product_count FROM categories c
    LEFT JOIN products p ON p.category_id = c.id GROUP BY c.id ORDER BY c.id`);
  const productStmt = db.prepare(`
    SELECT p.*, c.name AS category_name, c.slug AS category_slug
    FROM products p JOIN categories c ON c.id = p.category_id WHERE p.id = ?`);
  const relatedStmt = db.prepare(`
    SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id = p.category_id
    WHERE p.category_id = ? AND p.id != ? ORDER BY p.featured DESC, p.id LIMIT 4`);

  const HOME_ROW = 4; // products per homepage row

  router.get('/', (req, res) => {
    const onSale = onSaleStmt.all();
    // Don't show the same product twice on the homepage.
    const dealIds = new Set(onSale.map((p) => p.id));
    const featured = featuredStmt.all().filter((p) => !dealIds.has(p.id)).slice(0, HOME_ROW);
    res.render('home', {
      title: 'Stationery for students and offices',
      featured,
      onSale,
      categories: categoriesStmt.all(),
    });
  });

  router.get('/products', (req, res) => {
    const categories = categoriesStmt.all();
    const filters = {
      q: str(req.query.q).slice(0, 100),
      category: str(req.query.category),
      min: str(req.query.min),
      max: str(req.query.max),
      inStock: req.query.in_stock === '1',
      sort: Object.hasOwn(SORTS, req.query.sort) ? req.query.sort : 'newest',
    };
    const page = parseIntInRange(req.query.page, 1, 10_000) || 1;

    const where = [];
    const params = [];
    if (filters.q) {
      where.push("(p.name LIKE ? ESCAPE '\\' OR p.description LIKE ? ESCAPE '\\')");
      params.push(likePattern(filters.q), likePattern(filters.q));
    }
    const category = categories.find((c) => c.slug === filters.category);
    if (category) {
      where.push('p.category_id = ?');
      params.push(category.id);
    } else {
      filters.category = '';
    }
    const minKobo = filters.min ? parseNairaToKobo(filters.min) : null;
    const maxKobo = filters.max ? parseNairaToKobo(filters.max) : null;
    if (minKobo !== null) {
      where.push('p.price_kobo >= ?');
      params.push(minKobo);
    } else {
      filters.min = '';
    }
    if (maxKobo !== null) {
      where.push('p.price_kobo <= ?');
      params.push(maxKobo);
    } else {
      filters.max = '';
    }
    if (filters.inStock) where.push('p.stock > 0');

    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const { total } = db.prepare(`SELECT COUNT(*) AS total FROM products p ${whereSql}`).get(...params);
    const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    const currentPage = Math.min(page, pages);
    const products = db.prepare(`
      SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id = p.category_id
      ${whereSql} ORDER BY ${SORTS[filters.sort]} LIMIT ? OFFSET ?`,
    ).all(...params, PAGE_SIZE, (currentPage - 1) * PAGE_SIZE);

    // Builds a link to another page of results while keeping the filters.
    const pageLink = (n) => {
      const qs = new URLSearchParams();
      if (filters.q) qs.set('q', filters.q);
      if (filters.category) qs.set('category', filters.category);
      if (filters.min) qs.set('min', filters.min);
      if (filters.max) qs.set('max', filters.max);
      if (filters.inStock) qs.set('in_stock', '1');
      if (filters.sort !== 'newest') qs.set('sort', filters.sort);
      qs.set('page', String(n));
      return `/products?${qs}`;
    };

    res.render('products', {
      title: category ? category.name : filters.q ? `Search: ${filters.q}` : 'All products',
      heading: category ? category.name : filters.q ? 'Search results' : 'All products',
      products,
      categories,
      filters,
      total,
      page: currentPage,
      pages,
      pageLink,
    });
  });

  // Photo credits (licences require attribution). Only http(s) links are shown.
  const isWebLink = (u) => typeof u === 'string' && /^https?:\/\//.test(u);
  const credits = Object.entries(require('../photo-credits.json')).map(([slug, c]) => ({
    file: slug === 'hero' ? 'hero.jpg' : `products/${slug}.jpg`,
    title: String(c.title || '').replace(/^File:/, '').replace(/\.jpe?g$/i, ''),
    artist: c.artist,
    license: c.license,
    license_url: isWebLink(c.license_url) ? c.license_url : '',
    page: isWebLink(c.page) ? c.page : '#',
  }));
  router.get('/credits', (req, res) => {
    res.render('credits', { title: 'Photo credits', credits });
  });

  router.get('/products/:id', (req, res, next) => {
    const id = parseIntInRange(req.params.id, 1, Number.MAX_SAFE_INTEGER);
    const product = id && productStmt.get(id);
    if (!product) return next(); // falls through to the 404 handler
    res.render('product', {
      title: product.name,
      product,
      related: relatedStmt.all(product.category_id, product.id),
    });
  });

  return router;
};
