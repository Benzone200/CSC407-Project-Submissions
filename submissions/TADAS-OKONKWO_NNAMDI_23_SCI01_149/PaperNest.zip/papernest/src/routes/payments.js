'use strict';
// Online payment routes: Kora callback + webhook, "Pay now" for unpaid orders,
// and the local payment simulator (only when Kora keys are not configured).

const express = require('express');
const { requireLogin } = require('../middleware/auth');
const { setFlash: flash } = require('../helpers');

const RESULT_MESSAGES = {
  paid: ['success', 'Payment received. Thank you! Your order is being processed.'],
  failed: ['error', 'The payment was not completed. You can try again below.'],
  pending: ['info', 'Your payment is still being confirmed. This page will show the result once it is complete.'],
  unchanged: ['info', 'We could not find that payment.'],
};

// Webhook: Kora calls this server-to-server. It has no session or CSRF token;
// it is authenticated by the HMAC signature instead. Mounted before CSRF checks.
function paymentWebhookRouter(payments) {
  const router = express.Router();
  router.post('/payments/kora/webhook', express.json({ limit: '100kb' }), async (req, res) => {
    if (!payments.verifyWebhookSignature(req.body, req.get('x-korapay-signature'))) {
      return res.status(401).json({ ok: false });
    }
    const reference = req.body.data && req.body.data.reference;
    try {
      // Re-check with Kora's API rather than trusting the webhook body alone.
      if (typeof reference === 'string') await payments.verify(reference);
    } catch (err) {
      console.error('Kora webhook verification failed:', err.message);
      return res.status(502).json({ ok: false }); // Kora will retry later
    }
    res.json({ ok: true });
  });
  return router;
}

function paymentRoutes(db, payments) {
  const router = express.Router();
  const orderById = db.prepare('SELECT * FROM orders WHERE id = ?');
  const orderByRef = db.prepare('SELECT * FROM orders WHERE reference = ?');

  const ownsOrder = (req, order) => order && (order.user_id === req.user.id || req.user.role === 'admin');

  // Kora sends the customer back here with ?reference=...
  router.get('/payments/kora/callback', async (req, res, next) => {
    const reference = typeof req.query.reference === 'string' ? req.query.reference : '';
    const payment = reference && payments.findByReference(reference);
    if (!payment) return next(); // 404
    try {
      const outcome = await payments.verify(reference);
      const [type, message] = RESULT_MESSAGES[outcome] || RESULT_MESSAGES.pending;
      flash(req, type, message);
    } catch (err) {
      console.error('Kora verification failed:', err.message);
      flash(req, 'error', 'We could not confirm your payment with Kora yet. Please refresh this page in a minute.');
    }
    res.redirect(`/orders/${orderById.get(payment.order_id).reference}`);
  });

  // Start (or retry) an online payment for an unpaid order.
  router.post('/orders/:reference/pay', requireLogin, async (req, res, next) => {
    const order = orderByRef.get(String(req.params.reference));
    if (!ownsOrder(req, order) || order.user_id !== req.user.id) return next();
    if (order.payment_method !== 'online' || order.payment_status === 'paid' || order.status === 'cancelled') {
      return res.redirect(`/orders/${order.reference}`);
    }
    try {
      res.redirect(await payments.startPayment(order, req.user));
    } catch (err) {
      console.error('Could not start payment:', err.message);
      flash(req, 'error', 'We could not start the payment right now. Please try again in a moment.');
      res.redirect(`/orders/${order.reference}`);
    }
  });

  // ---- Local payment simulator (no Kora keys configured) ----
  if (payments.provider === 'simulator') {
    const loadSimulated = (req, res, next) => {
      const payment = payments.findByReference(String(req.params.reference));
      const order = payment && orderById.get(payment.order_id);
      if (!payment || payment.provider !== 'simulator' || !order || order.user_id !== req.user.id) return next('route');
      req.payment = payment;
      req.order = order;
      next();
    };

    router.get('/payments/simulator/:reference', requireLogin, loadSimulated, (req, res) => {
      if (req.payment.status !== 'pending') return res.redirect(`/orders/${req.order.reference}`);
      res.render('payment-simulator', { title: 'Test payment', payment: req.payment, order: req.order });
    });

    router.post('/payments/simulator/:reference', requireLogin, loadSimulated, (req, res) => {
      const succeed = req.body.outcome === 'success';
      const outcome = payments.applyResult(req.payment.reference, {
        status: succeed ? 'success' : 'failed',
        amountKobo: req.payment.amount_kobo,
        currency: 'NGN',
        channel: succeed ? 'card' : null,
        feeKobo: null,
        raw: { simulated: true, outcome: succeed ? 'success' : 'failed' },
      });
      const [type, message] = RESULT_MESSAGES[outcome];
      flash(req, type, message);
      res.redirect(`/orders/${req.order.reference}`);
    });
  }

  return router;
}

module.exports = { paymentRoutes, paymentWebhookRouter };
