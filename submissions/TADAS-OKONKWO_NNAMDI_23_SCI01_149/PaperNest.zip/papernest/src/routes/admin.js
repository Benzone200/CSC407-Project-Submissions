'use strict';
// Admin dashboard: sales monitoring, transactions, products (add/edit/delete,
// restock, photo upload) and orders. Every route is protected by requireAdmin (see app.js).

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const express = require('express');
const multer = require('multer');
const { transaction } = require('../db');
const { verifyDeferredCsrf } = require('../middleware/csrf');
const { str, parseIntInRange, parseNairaToKobo, safeRedirectPath, setFlash: flash } = require('../helpers');

const IMG_DIR = path.join(__dirname, '..', '..', 'public', 'img');
const LIBRARY_DIR = path.join(IMG_DIR, 'products'); // built-in photo library
const UPLOAD_DIR = path.join(IMG_DIR, 'uploads'); // photos uploaded by admins
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const ORDER_STATUSES = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
const PAYMENT_STATUSES = ['pending', 'success', 'failed'];
const PROVIDERS = ['kora', 'simulator', 'cash'];
const LOW_STOCK = 10;
const CHART_DAYS = 14;
const MAX_PHOTO_BYTES = 3 * 1024 * 1024;

// All photos an admin can pick: uploads first (newest first), then the library.
function listImages() {
  const read = (dir, prefix) => fs.readdirSync(dir)
    .filter((f) => /^[a-z0-9-]+\.(jpg|png|webp)$/.test(f))
    .map((f) => ({ path: `${prefix}/${f}`, time: fs.statSync(path.join(dir, f)).mtimeMs }));
  const uploads = read(UPLOAD_DIR, 'uploads').sort((a, b) => b.time - a.time);
  const library = read(LIBRARY_DIR, 'products').sort((a, b) => a.path.localeCompare(b.path));
  return [...uploads, ...library].map((i) => i.path);
}

// Detects the real file type from its first bytes (the browser-supplied type can lie).
function detectImageType(buffer) {
  if (buffer.length > 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return 'jpg';
  if (buffer.length > 8 && buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buffer.length > 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  return null;
}

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_PHOTO_BYTES, files: 1, fields: 20 },
});

// Parses a multipart product form (with an optional photo), then checks the CSRF token.
function productFormParser(req, res, next) {
  upload.single('photo')(req, res, (err) => {
    if (err) {
      req.uploadError = err.code === 'LIMIT_FILE_SIZE' ? 'The photo must be 3 MB or smaller.' : 'The photo could not be uploaded.';
    }
    verifyDeferredCsrf(req, res, next);
  });
}

// "2026-11-17" for today in Lagos time, minus `daysAgo` days.
function lagosDay(daysAgo) {
  const d = new Date(Date.now() + 60 * 60 * 1000 - daysAgo * 86400000);
  return d.toISOString().slice(0, 10);
}

module.exports = function adminRoutes(db, payments) {
  const router = express.Router();

  const categoriesStmt = db.prepare('SELECT * FROM categories ORDER BY name');
  const productStmt = db.prepare('SELECT * FROM products WHERE id = ?');

  // ---- Dashboard ----

  router.get('/', (req, res) => {
    const stats = db.prepare(`
      SELECT
        (SELECT COALESCE(SUM(amount_kobo), 0) FROM payments WHERE status = 'success') AS revenue,
        (SELECT COALESCE(SUM(amount_kobo), 0) FROM payments WHERE status = 'success'
           AND updated_at >= datetime('now', '-7 days')) AS revenue7,
        (SELECT COUNT(*) FROM orders WHERE date(created_at, '+1 hour') = date('now', '+1 hour')) AS ordersToday,
        (SELECT COUNT(*) FROM orders WHERE status IN ('pending', 'processing')) AS toFulfil,
        (SELECT COUNT(*) FROM orders WHERE payment_method = 'online' AND payment_status IN ('pending', 'failed')
           AND status != 'cancelled') AS awaitingPayment,
        (SELECT COUNT(*) FROM products WHERE stock <= ?) AS lowStock,
        (SELECT COUNT(*) FROM products) AS products,
        (SELECT COUNT(*) FROM users WHERE role = 'customer') AS customers`).get(LOW_STOCK);

    // Revenue per day (Lagos time) for the chart.
    const rows = db.prepare(`
      SELECT date(updated_at, '+1 hour') AS day, SUM(amount_kobo) AS total, COUNT(*) AS count
      FROM payments WHERE status = 'success' AND updated_at >= datetime('now', ?)
      GROUP BY day`).all(`-${CHART_DAYS + 1} days`);
    const byDay = new Map(rows.map((r) => [r.day, r]));
    const chart = [];
    for (let i = CHART_DAYS - 1; i >= 0; i--) {
      const day = lagosDay(i);
      const r = byDay.get(day);
      chart.push({ day, total: r ? r.total : 0, count: r ? r.count : 0 });
    }
    const chartMax = Math.max(...chart.map((d) => d.total), 1);

    const lowStock = db.prepare(
      'SELECT id, name, stock FROM products WHERE stock <= ? ORDER BY stock, name LIMIT 8').all(LOW_STOCK);
    const recentPayments = db.prepare(`
      SELECT p.*, o.reference AS order_reference, u.email FROM payments p
      JOIN orders o ON o.id = p.order_id JOIN users u ON u.id = o.user_id
      ORDER BY p.id DESC LIMIT 6`).all();
    const topProducts = db.prepare(`
      SELECT oi.product_name AS name, SUM(oi.quantity) AS qty, SUM(oi.quantity * oi.unit_price_kobo) AS total
      FROM order_items oi JOIN orders o ON o.id = oi.order_id
      WHERE o.status != 'cancelled' AND o.created_at >= datetime('now', '-30 days')
      GROUP BY oi.product_name ORDER BY qty DESC LIMIT 5`).all();

    res.render('admin/dashboard', {
      title: 'Admin dashboard', stats, chart, chartMax, lowStock, recentPayments, topProducts,
      lowStockLevel: LOW_STOCK, paymentProvider: payments.provider, paymentsTestMode: payments.isTestMode,
    });
  });

  // ---- Transactions ----

  router.get('/transactions', (req, res) => {
    const filters = {
      status: PAYMENT_STATUSES.includes(req.query.status) ? req.query.status : '',
      provider: PROVIDERS.includes(req.query.provider) ? req.query.provider : '',
      q: str(req.query.q).slice(0, 60),
    };
    const where = [];
    const params = [];
    if (filters.status) { where.push('p.status = ?'); params.push(filters.status); }
    if (filters.provider) { where.push('p.provider = ?'); params.push(filters.provider); }
    if (filters.q) {
      where.push("(p.reference LIKE ? ESCAPE '\\' OR o.reference LIKE ? ESCAPE '\\' OR u.email LIKE ? ESCAPE '\\')");
      const like = `%${filters.q.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
      params.push(like, like, like);
    }
    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const transactions = db.prepare(`
      SELECT p.*, o.reference AS order_reference, o.full_name, u.email FROM payments p
      JOIN orders o ON o.id = p.order_id JOIN users u ON u.id = o.user_id
      ${whereSql} ORDER BY p.id DESC LIMIT 200`).all(...params);
    const summary = db.prepare(`
      SELECT
        COALESCE(SUM(CASE WHEN status = 'success' THEN amount_kobo END), 0) AS received,
        COALESCE(SUM(CASE WHEN status = 'success' THEN fee_kobo END), 0) AS fees,
        SUM(status = 'success') AS successful, SUM(status = 'pending') AS pending, SUM(status = 'failed') AS failed
      FROM payments`).get();
    res.render('admin/transactions', {
      title: 'Transactions', transactions, summary, filters,
      statuses: PAYMENT_STATUSES, providers: PROVIDERS, koraConnected: payments.provider === 'kora',
    });
  });

  router.post('/transactions/:id/verify', async (req, res, next) => {
    const id = parseIntInRange(req.params.id, 1, Number.MAX_SAFE_INTEGER);
    const payment = id && db.prepare('SELECT * FROM payments WHERE id = ?').get(id);
    if (!payment) return next();
    try {
      const outcome = await payments.verify(payment.reference);
      flash(req, 'success', `Checked with Kora: ${payment.reference} is ${outcome === 'paid' ? 'paid' : outcome}.`);
    } catch (err) {
      flash(req, 'error', `Could not reach Kora: ${err.message}`);
    }
    res.redirect('/admin/transactions');
  });

  // ---- Products ----

  router.get('/products', (req, res) => {
    const products = db.prepare(`
      SELECT p.*, c.name AS category_name FROM products p JOIN categories c ON c.id = p.category_id
      ORDER BY p.id DESC`).all();
    res.render('admin/products', { title: 'Manage products', products, lowStockLevel: LOW_STOCK });
  });

  function emptyProductForm() {
    return { name: '', category_id: '', description: '', price: '', old_price: '', stock: '0', image: '', featured: false };
  }

  // Validates the product form (and uploaded photo). Returns { values, errors, data, photo }.
  function readProductForm(req, categories) {
    const body = req.body || {};
    const values = {
      name: str(body.name),
      category_id: str(body.category_id),
      description: str(body.description),
      price: str(body.price),
      old_price: str(body.old_price),
      stock: str(body.stock),
      image: str(body.image),
      featured: body.featured === '1',
    };
    const errors = {};
    const categoryId = parseIntInRange(values.category_id, 1, Number.MAX_SAFE_INTEGER);
    const price = parseNairaToKobo(values.price);
    const oldPrice = values.old_price ? parseNairaToKobo(values.old_price) : null;
    const stock = parseIntInRange(values.stock, 0, 100_000);

    if (values.name.length < 2 || values.name.length > 120) errors.name = 'Name must be 2-120 characters.';
    if (!categories.some((c) => c.id === categoryId)) errors.category_id = 'Choose a category.';
    if (values.description.length < 10 || values.description.length > 1000) {
      errors.description = 'Description must be 10-1000 characters.';
    }
    if (!price) errors.price = 'Enter a price greater than zero, e.g. 1500 or 1500.50.';
    if (values.old_price && (oldPrice === null || (price && oldPrice <= price))) {
      errors.old_price = 'The old price must be higher than the current price (or left empty).';
    }
    if (stock === null) errors.stock = 'Stock must be a whole number from 0 to 100000.';

    // Photo: a new upload wins; otherwise one picked from the library.
    let photo = null;
    if (req.uploadError) {
      errors.image = req.uploadError;
    } else if (req.file && req.file.size > 0) {
      const ext = detectImageType(req.file.buffer);
      if (!ext) errors.image = 'The photo must be a JPG, PNG or WebP image.';
      else photo = { buffer: req.file.buffer, ext };
    } else if (!listImages().includes(values.image)) {
      errors.image = 'Upload a photo or choose one below.';
    }

    const data = {
      name: values.name, category_id: categoryId, description: values.description,
      price_kobo: price, old_price_kobo: oldPrice, stock, image: values.image, featured: values.featured ? 1 : 0,
    };
    return { values, errors, data, photo };
  }

  // Saves an uploaded photo under a random name and returns its image path.
  function savePhoto(photo) {
    const name = `${crypto.randomBytes(8).toString('hex')}.${photo.ext}`;
    fs.writeFileSync(path.join(UPLOAD_DIR, name), photo.buffer, { flag: 'wx' });
    return `uploads/${name}`;
  }

  const renderForm = (res, status, locals) => res.status(status).render('admin/product-form', {
    categories: categoriesStmt.all(), images: listImages(), errors: {}, ...locals,
  });

  router.get('/products/new', (req, res) => {
    renderForm(res, 200, { title: 'Add product', product: null, values: emptyProductForm() });
  });

  router.post('/products', productFormParser, (req, res) => {
    const { values, errors, data, photo } = readProductForm(req, categoriesStmt.all());
    if (Object.keys(errors).length > 0) {
      return renderForm(res, 422, { title: 'Add product', product: null, values, errors });
    }
    if (photo) data.image = savePhoto(photo);
    db.prepare(`
      INSERT INTO products (name, category_id, description, price_kobo, old_price_kobo, stock, image, featured)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(
      data.name, data.category_id, data.description, data.price_kobo, data.old_price_kobo,
      data.stock, data.image, data.featured,
    );
    flash(req, 'success', `"${data.name}" was added.`);
    res.redirect('/admin/products');
  });

  // Loads the product for /products/:id routes, or 404s.
  function findProduct(req, res, next) {
    const id = parseIntInRange(req.params.id, 1, Number.MAX_SAFE_INTEGER);
    req.product = id && productStmt.get(id);
    if (!req.product) return next('route');
    next();
  }

  router.get('/products/:id/edit', findProduct, (req, res) => {
    const p = req.product;
    const values = {
      name: p.name, category_id: String(p.category_id), description: p.description,
      price: String(p.price_kobo / 100), old_price: p.old_price_kobo ? String(p.old_price_kobo / 100) : '',
      stock: String(p.stock), image: p.image, featured: p.featured === 1,
    };
    renderForm(res, 200, { title: `Edit ${p.name}`, product: p, values });
  });

  router.post('/products/:id', findProduct, productFormParser, (req, res) => {
    const { values, errors, data, photo } = readProductForm(req, categoriesStmt.all());
    if (Object.keys(errors).length > 0) {
      return renderForm(res, 422, { title: `Edit ${req.product.name}`, product: req.product, values, errors });
    }
    if (photo) data.image = savePhoto(photo);
    db.prepare(`
      UPDATE products SET name = ?, category_id = ?, description = ?, price_kobo = ?, old_price_kobo = ?,
        stock = ?, image = ?, featured = ?, updated_at = datetime('now')
      WHERE id = ?`).run(
      data.name, data.category_id, data.description, data.price_kobo, data.old_price_kobo,
      data.stock, data.image, data.featured, req.product.id,
    );
    flash(req, 'success', `"${data.name}" was updated.`);
    res.redirect('/admin/products');
  });

  // Receive new goods: add to the current stock.
  router.post('/products/:id/restock', findProduct, (req, res) => {
    const qty = parseIntInRange(req.body.quantity, 1, 10_000);
    const back = safeRedirectPath(req.body.return_to, '/admin/products');
    if (!qty) {
      flash(req, 'error', 'Enter how many units arrived (1 to 10000).');
      return res.redirect(back);
    }
    db.prepare("UPDATE products SET stock = stock + ?, updated_at = datetime('now') WHERE id = ?").run(qty, req.product.id);
    flash(req, 'success', `Added ${qty} to "${req.product.name}". New stock: ${req.product.stock + qty}.`);
    res.redirect(back);
  });

  router.post('/products/:id/delete', findProduct, (req, res) => {
    // Past orders keep their own copy of the product name and price,
    // so deleting a product does not change order history.
    db.prepare('DELETE FROM products WHERE id = ?').run(req.product.id);
    flash(req, 'success', `"${req.product.name}" was deleted.`);
    res.redirect('/admin/products');
  });

  // ---- Orders ----

  router.get('/orders', (req, res) => {
    const status = ORDER_STATUSES.includes(req.query.status) ? req.query.status : '';
    const orders = db.prepare(`
      SELECT o.*, u.email FROM orders o JOIN users u ON u.id = o.user_id
      ${status ? 'WHERE o.status = ?' : ''} ORDER BY o.id DESC`).all(...(status ? [status] : []));
    res.render('admin/orders', { title: 'Manage orders', orders, statuses: ORDER_STATUSES, status });
  });

  router.post('/orders/:id/status', (req, res, next) => {
    const id = parseIntInRange(req.params.id, 1, Number.MAX_SAFE_INTEGER);
    const status = str(req.body.status);
    if (!id || !ORDER_STATUSES.includes(status)) {
      flash(req, 'error', 'Invalid order status.');
      return res.redirect('/admin/orders');
    }
    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
    if (!order) return next();
    if (order.status === 'cancelled' && status !== 'cancelled') {
      flash(req, 'error', `Order ${order.reference} is cancelled and cannot be reopened.`);
      return res.redirect('/admin/orders');
    }
    transaction(db, () => {
      db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(status, id);
      // Cancelling an order puts its items back in stock.
      if (status === 'cancelled' && order.status !== 'cancelled') {
        db.prepare(`
          UPDATE products SET stock = stock + (
            SELECT SUM(quantity) FROM order_items WHERE order_id = ? AND product_id = products.id)
          WHERE id IN (SELECT product_id FROM order_items WHERE order_id = ?)`).run(id, id);
      }
      // Pay on delivery: the cash is collected when the order is delivered.
      if (status === 'delivered') payments.recordCashPayment(order);
    });
    let message = `Order ${order.reference} marked as ${status}.`;
    if (status === 'cancelled' && order.payment_status === 'paid') {
      message += ' It was already paid, so remember to refund the customer.';
    }
    flash(req, 'success', message);
    res.redirect('/admin/orders');
  });

  return router;
};
