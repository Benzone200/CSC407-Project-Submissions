'use strict';
// Registration, login, logout and the customer's order history.

const express = require('express');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const { requireLogin } = require('../middleware/auth');
const { str, EMAIL_RE, safeRedirectPath } = require('../helpers');

// A real hash of a random password. Comparing against it when the email does not
// exist makes failed logins take the same time either way, so attackers cannot
// tell which emails are registered.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password-' + Math.random(), 10);

function checkPasswordStrength(password) {
  if (password.length < 8) return 'Password must be at least 8 characters.';
  if (password.length > 72) return 'Password must be 72 characters or fewer.';
  if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    return 'Password must contain at least one letter and one number.';
  }
  return null;
}

const { DEMO_ADMIN, DEMO_CUSTOMER } = require('../seed');

module.exports = function authRoutes(db, { bcryptRounds, loginRateLimit = 10, demoLogin = false }) {
  const router = express.Router();
  const findByEmail = db.prepare('SELECT * FROM users WHERE email = ?');
  const insertUser = db.prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)');

  // Slows down password guessing: at most `loginRateLimit` attempts per IP every 15 minutes.
  const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: loginRateLimit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (req, res) => {
      res.status(429).render('login', {
        title: 'Log in',
        values: { email: str(req.body.email) },
        error: 'Too many login attempts. Please wait 15 minutes and try again.',
        next: safeRedirectPath(req.body.next, '/'),
        demoAccounts: null,
      });
    },
  });

  // Starts a fresh session on login so an attacker cannot fix the session ID in
  // advance (session fixation). The cart is carried over.
  function logIn(req, userId, done) {
    const cart = req.session.cart;
    req.session.regenerate((err) => {
      if (err) return done(err);
      req.session.userId = userId;
      req.session.cart = cart || {};
      done();
    });
  }

  router.get('/register', (req, res) => {
    if (req.user) return res.redirect('/');
    res.render('register', { title: 'Create an account', values: {}, errors: {} });
  });

  router.post('/register', async (req, res, next) => {
    try {
      const values = { name: str(req.body.name), email: str(req.body.email).toLowerCase() };
      const password = typeof req.body.password === 'string' ? req.body.password : '';
      const confirm = typeof req.body.confirm_password === 'string' ? req.body.confirm_password : '';

      const errors = {};
      if (values.name.length < 2 || values.name.length > 80) errors.name = 'Enter your name (2-80 characters).';
      if (!EMAIL_RE.test(values.email) || values.email.length > 254) errors.email = 'Enter a valid email address.';
      const passwordProblem = checkPasswordStrength(password);
      if (passwordProblem) errors.password = passwordProblem;
      else if (password !== confirm) errors.confirm_password = 'Passwords do not match.';
      if (!errors.email && findByEmail.get(values.email)) {
        errors.email = 'An account with this email already exists. Try logging in instead.';
      }
      if (Object.keys(errors).length > 0) {
        return res.status(422).render('register', { title: 'Create an account', values, errors });
      }

      const hash = await bcrypt.hash(password, bcryptRounds);
      const userId = Number(insertUser.run(values.name, values.email, hash).lastInsertRowid);
      logIn(req, userId, (err) => {
        if (err) return next(err);
        req.session.flash = { type: 'success', message: `Welcome to PaperNest, ${values.name}!` };
        res.redirect('/');
      });
    } catch (err) {
      next(err);
    }
  });

  // Demo accounts shown on the login page so the project can be assessed quickly.
  // Turned off with DEMO_LOGIN=0 (a real shop must never offer one-click logins).
  const demoAccounts = demoLogin ? {
    admin: { label: 'Admin', email: process.env.ADMIN_EMAIL || DEMO_ADMIN.email,
      password: process.env.ADMIN_PASSWORD ? null : DEMO_ADMIN.password },
    customer: { label: 'Customer', email: DEMO_CUSTOMER.email, password: DEMO_CUSTOMER.password },
  } : null;

  router.get('/login', (req, res) => {
    if (req.user) return res.redirect('/');
    res.render('login', {
      title: 'Log in', values: {}, error: null, next: safeRedirectPath(req.query.next, '/'), demoAccounts,
    });
  });

  // One-click login as a demo account (still a POST with a CSRF token).
  router.post('/login/demo', (req, res, next) => {
    if (!demoAccounts || !Object.hasOwn(demoAccounts, req.body.role)) return next();
    const user = findByEmail.get(demoAccounts[req.body.role].email);
    if (!user) {
      req.session.flash = { type: 'error', message: 'That demo account does not exist. Run "npm run seed" to recreate it.' };
      return res.redirect('/login');
    }
    logIn(req, user.id, (err) => {
      if (err) return next(err);
      req.session.flash = { type: 'success', message: `Signed in as the demo ${req.body.role}, ${user.name}.` };
      res.redirect(user.role === 'admin' ? '/admin' : '/');
    });
  });

  router.post('/login', loginLimiter, async (req, res, next) => {
    try {
      const email = str(req.body.email).toLowerCase();
      const password = typeof req.body.password === 'string' ? req.body.password : '';
      const target = safeRedirectPath(req.body.next, '/');

      const user = findByEmail.get(email);
      const ok = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);
      if (!user || !ok) {
        // Same message whether the email or the password was wrong.
        return res.status(401).render('login', {
          title: 'Log in', values: { email }, error: 'Incorrect email or password.', next: target, demoAccounts,
        });
      }
      logIn(req, user.id, (err) => {
        if (err) return next(err);
        req.session.flash = { type: 'success', message: `Welcome back, ${user.name}!` };
        res.redirect(user.role === 'admin' && target === '/' ? '/admin' : target);
      });
    } catch (err) {
      next(err);
    }
  });

  router.post('/logout', (req, res, next) => {
    req.session.destroy((err) => {
      if (err) return next(err);
      res.clearCookie('papernest.sid');
      res.redirect('/');
    });
  });

  // ---- Profile ----

  const profileStmt = db.prepare(`
    SELECT u.id, u.name, u.email, u.role, u.created_at,
      (SELECT COUNT(*) FROM orders WHERE user_id = u.id) AS order_count,
      (SELECT COALESCE(SUM(total_kobo), 0) FROM orders WHERE user_id = u.id AND payment_status = 'paid') AS total_paid,
      (SELECT COUNT(*) FROM orders WHERE user_id = u.id AND status IN ('pending', 'processing', 'shipped')) AS open_orders
    FROM users u WHERE u.id = ?`);
  const recentOrdersStmt = db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC LIMIT 3');

  function renderProfile(req, res, status = 200, extra = {}) {
    res.status(status).render('account', {
      title: 'My profile',
      profile: profileStmt.get(req.user.id),
      recentOrders: recentOrdersStmt.all(req.user.id),
      nameValue: req.user.name,
      nameError: null,
      passwordErrors: {},
      ...extra,
    });
  }

  router.get('/account', requireLogin, (req, res) => renderProfile(req, res));

  router.post('/account/profile', requireLogin, (req, res) => {
    const name = str(req.body.name);
    if (name.length < 2 || name.length > 80) {
      return renderProfile(req, res, 422, { nameValue: name, nameError: 'Enter your name (2-80 characters).' });
    }
    db.prepare('UPDATE users SET name = ? WHERE id = ?').run(name, req.user.id);
    req.session.flash = { type: 'success', message: 'Your name was updated.' };
    res.redirect('/account');
  });

  router.post('/account/password', requireLogin, async (req, res, next) => {
    try {
      const current = typeof req.body.current_password === 'string' ? req.body.current_password : '';
      const password = typeof req.body.new_password === 'string' ? req.body.new_password : '';
      const confirm = typeof req.body.confirm_password === 'string' ? req.body.confirm_password : '';
      const { password_hash: hash } = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(req.user.id);

      const errors = {};
      if (!(await bcrypt.compare(current, hash))) errors.current_password = 'Your current password is not correct.';
      const problem = checkPasswordStrength(password);
      if (problem) errors.new_password = problem;
      else if (password !== confirm) errors.confirm_password = 'Passwords do not match.';
      if (Object.keys(errors).length) return renderProfile(req, res, 422, { passwordErrors: errors });

      db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(await bcrypt.hash(password, bcryptRounds), req.user.id);
      // Sign out other devices: drop every other session belonging to this user.
      db.prepare("DELETE FROM sessions WHERE sid != ? AND json_extract(sess, '$.userId') = ?").run(req.sessionID, req.user.id);
      req.session.flash = { type: 'success', message: 'Your password was changed.' };
      res.redirect('/account');
    } catch (err) {
      next(err);
    }
  });

  // ---- Order history ----

  const ordersForUser = db.prepare(`
    SELECT o.*, (SELECT SUM(quantity) FROM order_items WHERE order_id = o.id) AS item_count
    FROM orders o WHERE o.user_id = ? ORDER BY o.id DESC`);
  const orderByRef = db.prepare('SELECT * FROM orders WHERE reference = ?');
  const orderItems = db.prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY id');

  router.get('/orders', requireLogin, (req, res) => {
    res.render('orders', { title: 'My orders', orders: ordersForUser.all(req.user.id) });
  });

  router.get('/orders/:reference', requireLogin, (req, res, next) => {
    const order = orderByRef.get(String(req.params.reference));
    // Customers may only see their own orders. Someone else's order gives a 404
    // (not a 403), so its existence is not revealed.
    if (!order || (order.user_id !== req.user.id && req.user.role !== 'admin')) return next();
    res.render('order', { title: `Order ${order.reference}`, order, items: orderItems.all(order.id) });
  });

  return router;
};
