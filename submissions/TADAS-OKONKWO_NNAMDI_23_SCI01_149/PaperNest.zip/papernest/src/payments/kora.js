'use strict';
// Kora (Korapay) Checkout Redirect client.
// Docs: https://developers.korapay.com/docs/checkout-redirect
//       https://developers.korapay.com/docs/webhooks
//
// Flow: the server initialises a charge with the SECRET key, sends the customer to
// Kora's hosted checkout page, Kora sends them back to our redirect_url with
// ?reference=..., and the server verifies the charge before marking the order paid.
// The secret key is only ever used here, on the server.

const crypto = require('node:crypto');

const API_BASE = 'https://api.korapay.com/merchant/api/v1';
const TIMEOUT_MS = 15000;

class KoraError extends Error {}

function createKoraClient({ secretKey, fetchImpl = fetch } = {}) {
  if (!secretKey) throw new Error('A Kora secret key is required.');

  async function request(method, path, body) {
    let res;
    try {
      res = await fetchImpl(`${API_BASE}${path}`, {
        method,
        headers: {
          Authorization: `Bearer ${secretKey}`,
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: body ? JSON.stringify(body) : undefined,
        signal: AbortSignal.timeout(TIMEOUT_MS),
      });
    } catch (err) {
      throw new KoraError(`Could not reach Kora: ${err.message}`);
    }
    const json = await res.json().catch(() => null);
    if (!res.ok || !json || json.status !== true) {
      throw new KoraError((json && json.message) || `Kora returned HTTP ${res.status}`);
    }
    return json.data;
  }

  return {
    provider: 'kora',

    // Amounts are passed to Kora in naira (major units).
    async initializeCharge({ reference, amountKobo, customer, redirectUrl, notificationUrl, narration }) {
      const data = await request('POST', '/charges/initialize', {
        reference,
        amount: amountKobo / 100,
        currency: 'NGN',
        customer: { name: customer.name, email: customer.email },
        redirect_url: redirectUrl,
        notification_url: notificationUrl,
        narration,
        merchant_bears_cost: true,
      });
      if (!data || typeof data.checkout_url !== 'string' || !/^https:\/\//.test(data.checkout_url)) {
        throw new KoraError('Kora did not return a checkout link.');
      }
      return { checkoutUrl: data.checkout_url };
    },

    // Asks Kora for the real status of a charge. Never trust the redirect alone.
    async verifyCharge(reference) {
      const data = await request('GET', `/charges/${encodeURIComponent(reference)}`);
      return normalise(data);
    },

    // Webhook signature: HMAC-SHA256 of JSON.stringify(body.data), keyed with the secret key.
    verifyWebhookSignature(body, signature) {
      if (!body || typeof body.data !== 'object' || typeof signature !== 'string') return false;
      const expected = crypto.createHmac('sha256', secretKey).update(JSON.stringify(body.data)).digest('hex');
      const a = Buffer.from(expected);
      const b = Buffer.from(signature);
      return a.length === b.length && crypto.timingSafeEqual(a, b);
    },

    normalise,
  };
}

// Converts Kora's charge data into our own shape.
function normalise(data = {}) {
  const status = String(data.status || '').toLowerCase();
  const amount = data.amount_paid ?? data.amount;
  return {
    reference: data.reference,
    status: status === 'success' ? 'success' : status === 'failed' ? 'failed' : 'pending',
    amountKobo: amount === undefined || amount === null ? null : Math.round(Number(amount) * 100),
    currency: data.currency || null,
    feeKobo: data.fee === undefined || data.fee === null ? null : Math.round(Number(data.fee) * 100),
    channel: data.payment_method || data.channel || null,
    raw: data,
  };
}

module.exports = { createKoraClient, KoraError };
