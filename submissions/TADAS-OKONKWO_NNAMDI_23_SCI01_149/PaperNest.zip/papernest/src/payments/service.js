'use strict';
// Payment logic shared by checkout, the Kora callback/webhook and the admin dashboard.
//
// Providers:
//   kora       real Kora checkout (test or live, depending on the secret key)
//   simulator  a local stand-in used ONLY when no Kora key is set and not in production,
//              so the project can be demonstrated without an account
//   cash       pay on delivery, recorded when the admin marks the order as delivered

const crypto = require('node:crypto');
const { transaction } = require('../db');

function createPaymentService(db, { kora = null, simulatorEnabled = false, appUrl }) {
  const provider = kora ? 'kora' : simulatorEnabled ? 'simulator' : null;

  const insertPayment = db.prepare(`
    INSERT INTO payments (order_id, provider, reference, amount_kobo, currency, status)
    VALUES (?, ?, ?, ?, 'NGN', ?)`);
  const findByReference = db.prepare('SELECT * FROM payments WHERE reference = ?');
  const markOrderPending = db.prepare(
    "UPDATE orders SET payment_status = 'pending' WHERE id = ? AND payment_status != 'paid'");

  const newReference = (order) => `${order.reference}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;

  // Starts an online payment for an order. Returns the URL to send the customer to.
  async function startPayment(order, customer) {
    if (!provider) throw new Error('Online payment is not available.');
    const reference = newReference(order);
    insertPayment.run(order.id, provider, reference, order.total_kobo, 'pending');
    markOrderPending.run(order.id);

    if (provider === 'simulator') return `/payments/simulator/${reference}`;

    try {
      const { checkoutUrl } = await kora.initializeCharge({
        reference,
        amountKobo: order.total_kobo,
        customer: { name: customer.name, email: customer.email },
        redirectUrl: `${appUrl}/payments/kora/callback`,
        notificationUrl: `${appUrl}/payments/kora/webhook`,
        narration: `PaperNest order ${order.reference}`,
      });
      db.prepare("UPDATE payments SET checkout_url = ?, updated_at = datetime('now') WHERE reference = ?")
        .run(checkoutUrl, reference);
      return checkoutUrl;
    } catch (err) {
      db.prepare(`UPDATE payments SET status = 'failed', provider_response = ?, updated_at = datetime('now')
                  WHERE reference = ?`).run(JSON.stringify({ error: err.message }), reference);
      throw err;
    }
  }

  // Applies a verified result from the provider. Safe to call more than once for the
  // same payment (Kora retries webhooks, customers refresh pages).
  // Returns 'paid', 'failed', 'pending' or 'unchanged'.
  function applyResult(reference, result) {
    return transaction(db, () => {
      const payment = findByReference.get(reference);
      if (!payment) return 'unchanged';
      if (payment.status === 'success') return 'paid';

      const raw = JSON.stringify(result.raw ?? null);
      const amountOk = result.amountKobo !== null && result.amountKobo >= payment.amount_kobo
        && (result.currency || 'NGN') === payment.currency;

      if (result.status === 'success' && amountOk) {
        db.prepare(`UPDATE payments SET status = 'success', channel = ?, fee_kobo = ?, provider_response = ?,
                    updated_at = datetime('now') WHERE id = ?`)
          .run(result.channel, result.feeKobo, raw, payment.id);
        db.prepare(`UPDATE orders SET payment_status = 'paid', paid_at = datetime('now'),
                    status = CASE WHEN status = 'pending' THEN 'processing' ELSE status END
                    WHERE id = ?`).run(payment.order_id);
        return 'paid';
      }

      if (result.status === 'failed' || (result.status === 'success' && !amountOk)) {
        db.prepare(`UPDATE payments SET status = 'failed', provider_response = ?, updated_at = datetime('now')
                    WHERE id = ?`).run(result.status === 'success' ? JSON.stringify({ error: 'Amount or currency mismatch', raw: result.raw }) : raw, payment.id);
        db.prepare("UPDATE orders SET payment_status = 'failed' WHERE id = ? AND payment_status != 'paid'")
          .run(payment.order_id);
        return 'failed';
      }

      db.prepare("UPDATE payments SET provider_response = ?, updated_at = datetime('now') WHERE id = ?")
        .run(raw, payment.id);
      return 'pending';
    });
  }

  // Asks Kora for the latest status of a payment and applies it.
  async function verify(reference) {
    const payment = findByReference.get(reference);
    if (!payment || payment.provider !== 'kora' || !kora) return 'unchanged';
    const result = await kora.verifyCharge(reference);
    return applyResult(reference, result);
  }

  // Pay on delivery: record the cash once the order is delivered.
  function recordCashPayment(order) {
    if (order.payment_method !== 'cod' || order.payment_status === 'paid') return;
    insertPayment.run(order.id, 'cash', `${order.reference}-CASH`, order.total_kobo, 'success');
    db.prepare("UPDATE orders SET payment_status = 'paid', paid_at = datetime('now') WHERE id = ?").run(order.id);
  }

  return {
    provider,
    onlineAvailable: provider !== null,
    isTestMode: provider === 'simulator' || Boolean(kora && kora.testMode),
    startPayment,
    applyResult,
    verify,
    recordCashPayment,
    findByReference: (reference) => findByReference.get(reference),
    verifyWebhookSignature: (body, signature) => Boolean(kora && kora.verifyWebhookSignature(body, signature)),
  };
}

module.exports = { createPaymentService };
