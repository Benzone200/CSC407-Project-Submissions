'use strict';
// Demo data: categories, products and two accounts (admin + customer).
// Runs automatically on first start when the database is empty.
// `npm run seed` wipes the database and reseeds it.

const bcrypt = require('bcryptjs');

const CATEGORIES = [
  { slug: 'notebooks', name: 'Notebooks & Jotters', image: 'products/a4-hardcover-notebook.jpg' },
  { slug: 'pens-pencils', name: 'Pens & Pencils', image: 'products/ballpoint-pens.jpg' },
  { slug: 'highlighters-markers', name: 'Highlighters & Markers', image: 'products/highlighters.jpg' },
  { slug: 'sticky-notes', name: 'Sticky Notes', image: 'products/sticky-notes.jpg' },
  { slug: 'files-folders', name: 'Files & Folders', image: 'products/spring-file.jpg' },
  { slug: 'staplers', name: 'Staplers', image: 'products/desktop-stapler.jpg' },
  { slug: 'art-supplies', name: 'Art Supplies', image: 'products/colour-pencils.jpg' },
  { slug: 'diaries-planners', name: 'Diaries & Planners', image: 'products/weekly-planner.jpg' },
];

// [category slug, name, description, price (naira), old price (naira) | null, stock, featured, photo]
// Photos are in public/img/products/ (credits: src/photo-credits.json, shown at /credits).
const PRODUCTS = [
  ['notebooks', 'A4 Hardcover Notebook (200 pages)', 'Ruled A4 notebook with a sturdy hardcover, ideal for lecture notes.', 1800, 2200, 120, 1, 'a4-hardcover-notebook'],
  ['notebooks', '40-Leaves Exercise Book (Pack of 10)', 'Standard ruled exercise books for everyday class work.', 2500, null, 300, 0, 'exercise-books'],
  ['notebooks', 'Pocket Jotter (A6)', 'Small spiral jotter that fits in a shirt pocket. 80 sheets.', 450, null, 250, 0, 'pocket-jotter'],
  ['pens-pencils', 'Blue Ballpoint Pens (Box of 50)', 'Smooth-writing 1.0mm ballpoint pens. A whole semester of writing.', 3500, 4000, 80, 1, 'ballpoint-pens'],
  ['pens-pencils', 'HB Pencils with Eraser (Pack of 12)', 'Pre-sharpened HB pencils with rubber tips.', 1200, null, 150, 0, 'hb-pencils'],
  ['pens-pencils', 'Gel Pen Set (6 colours)', 'Quick-dry gel pens in black, blue, red, green, purple and pink.', 1900, null, 90, 1, 'gel-pens'],
  ['highlighters-markers', 'Highlighter Pack (5 colours)', 'Chisel-tip highlighters that do not bleed through paper.', 1500, 1800, 110, 1, 'highlighters'],
  ['highlighters-markers', 'Permanent Markers (Pack of 4)', 'Bold permanent markers for labels, cartons and posters.', 1400, null, 70, 0, 'permanent-markers'],
  ['highlighters-markers', 'Whiteboard Markers (Pack of 4)', 'Low-odour dry-erase markers with a bullet tip.', 1600, null, 65, 0, 'whiteboard-markers'],
  ['sticky-notes', 'Sticky Notes 3x3 (12 pads)', 'Classic yellow sticky notes, 100 sheets per pad.', 2100, null, 140, 0, 'sticky-notes'],
  ['sticky-notes', 'Neon Page Markers (5 colours)', 'Thin sticky flags for marking pages in textbooks.', 800, 1000, 200, 1, 'page-markers'],
  ['files-folders', 'Spring File (Pack of 5)', 'Plastic spring files for keeping assignments and handouts tidy.', 1750, null, 95, 1, 'spring-file'],
  ['files-folders', 'Box File with Lever Arch', 'Strong box file for office documents and records.', 2800, null, 40, 0, 'box-file'],
  ['files-folders', 'Document Wallet with Button (Pack of 10)', 'Transparent A4 envelopes with a snap button.', 1300, null, 160, 0, 'document-wallet'],
  ['staplers', 'Desktop Stapler (Full Strip)', 'Metal desktop stapler that staples up to 25 sheets.', 3200, 3800, 35, 1, 'desktop-stapler'],
  ['staplers', 'Mini Stapler with Staples', 'Pocket stapler with a box of 1,000 staples included.', 900, null, 120, 0, 'mini-stapler'],
  ['staplers', 'Staple Pins 24/6 (Box of 5,000)', 'Standard staple pins that fit most desktop staplers.', 700, null, 180, 0, 'staple-pins'],
  ['art-supplies', 'Colour Pencils (Set of 24)', 'Bright, break-resistant colour pencils in a tin case.', 2600, null, 60, 1, 'colour-pencils'],
  ['art-supplies', 'Watercolour Paint Set (12 colours)', 'Student watercolour set with a brush included.', 3400, null, 30, 0, 'watercolour-set'],
  ['art-supplies', 'A3 Drawing Book (40 sheets)', 'Heavy cartridge paper for drawing and technical sketches.', 2000, null, 55, 0, 'drawing-book'],
  ['diaries-planners', '2027 Executive Diary', 'Leather-look one-day-per-page diary with a ribbon marker.', 4500, 5500, 45, 1, 'executive-diary'],
  ['diaries-planners', 'Weekly Student Planner', 'Undated weekly planner with timetable and to-do pages.', 2300, null, 75, 0, 'weekly-planner'],
  ['diaries-planners', 'Monthly Wall Planner', 'Large wall calendar planner for the whole year.', 1700, null, 50, 0, 'wall-planner'],
];

const DEMO_ADMIN = { name: 'Store Admin', email: 'admin@papernest.test', password: 'Admin@12345' };
const DEMO_CUSTOMER = { name: 'Demo Customer', email: 'customer@papernest.test', password: 'Customer@123' };

function seed(db, { bcryptRounds = 12 } = {}) {
  const insertCategory = db.prepare('INSERT INTO categories (slug, name, image) VALUES (?, ?, ?)');
  const categoryIds = {};
  for (const c of CATEGORIES) {
    categoryIds[c.slug] = Number(insertCategory.run(c.slug, c.name, c.image).lastInsertRowid);
  }

  const insertProduct = db.prepare(`
    INSERT INTO products (name, category_id, description, price_kobo, old_price_kobo, stock, image, featured)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
  // Insert one product from each category in turn, so "newest first" shows a mix.
  const byCategory = CATEGORIES.map((c) => PRODUCTS.filter((p) => p[0] === c.slug));
  const mixed = [];
  for (let i = 0; byCategory.some((list) => i < list.length); i++) {
    for (const list of byCategory) if (list[i]) mixed.push(list[i]);
  }
  for (const [slug, name, description, price, oldPrice, stock, featured, photo] of mixed) {
    const image = `products/${photo}.jpg`;
    insertProduct.run(name, categoryIds[slug], description, price * 100,
      oldPrice ? oldPrice * 100 : null, stock, image, featured);
  }

  const insertUser = db.prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
  const adminEmail = process.env.ADMIN_EMAIL || DEMO_ADMIN.email;
  const adminPassword = process.env.ADMIN_PASSWORD || DEMO_ADMIN.password;
  insertUser.run(DEMO_ADMIN.name, adminEmail, bcrypt.hashSync(adminPassword, bcryptRounds), 'admin');
  insertUser.run(DEMO_CUSTOMER.name, DEMO_CUSTOMER.email,
    bcrypt.hashSync(DEMO_CUSTOMER.password, bcryptRounds), 'customer');
}

function seedIfEmpty(db, options) {
  const { n } = db.prepare('SELECT COUNT(*) AS n FROM categories').get();
  if (n === 0) seed(db, options);
}

module.exports = { seed, seedIfEmpty, CATEGORIES, DEMO_ADMIN, DEMO_CUSTOMER };

// `node src/seed.js --reset`: wipe and reseed the configured database.
if (require.main === module) {
  const config = require('./config');
  const { openDatabase } = require('./db');
  const db = openDatabase(config.dbFile);
  if (process.argv.includes('--reset')) {
    db.exec(`DELETE FROM payments; DELETE FROM order_items; DELETE FROM orders; DELETE FROM products;
             DELETE FROM categories; DELETE FROM users; DELETE FROM sessions;
             DELETE FROM sqlite_sequence;`); // restart IDs at 1
  }
  seedIfEmpty(db, { bcryptRounds: config.bcryptRounds });
  console.log(`Database ready at ${config.dbFile}`);
}
