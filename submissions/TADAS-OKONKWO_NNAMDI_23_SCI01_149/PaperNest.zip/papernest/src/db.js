'use strict';
// Database access. Uses SQLite through Node's built-in `node:sqlite` module,
// so there is nothing native to compile. All queries use bound parameters
// (never string concatenation) to prevent SQL injection.

const { DatabaseSync } = require('node:sqlite');
const fs = require('node:fs');
const path = require('node:path');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT    NOT NULL,
  email         TEXT    NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT    NOT NULL,
  role          TEXT    NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'admin')),
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS categories (
  id    INTEGER PRIMARY KEY AUTOINCREMENT,
  slug  TEXT NOT NULL UNIQUE,
  name  TEXT NOT NULL,
  image TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  name           TEXT    NOT NULL,
  category_id    INTEGER NOT NULL REFERENCES categories(id),
  description    TEXT    NOT NULL,
  price_kobo     INTEGER NOT NULL CHECK (price_kobo > 0),
  old_price_kobo INTEGER CHECK (old_price_kobo IS NULL OR old_price_kobo > price_kobo),
  stock          INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  image          TEXT    NOT NULL,
  featured       INTEGER NOT NULL DEFAULT 0 CHECK (featured IN (0, 1)),
  created_at     TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at     TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);

CREATE TABLE IF NOT EXISTS orders (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  reference     TEXT    NOT NULL UNIQUE,
  user_id       INTEGER NOT NULL REFERENCES users(id),
  full_name     TEXT    NOT NULL,
  phone         TEXT    NOT NULL,
  address       TEXT    NOT NULL,
  city          TEXT    NOT NULL,
  state         TEXT    NOT NULL,
  notes         TEXT    NOT NULL DEFAULT '',
  subtotal_kobo INTEGER NOT NULL,
  delivery_kobo INTEGER NOT NULL,
  total_kobo    INTEGER NOT NULL,
  status        TEXT    NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending', 'processing', 'shipped', 'delivered', 'cancelled')),
  payment_method TEXT   NOT NULL DEFAULT 'cod' CHECK (payment_method IN ('cod', 'online')),
  payment_status TEXT   NOT NULL DEFAULT 'unpaid' CHECK (payment_status IN ('unpaid', 'pending', 'paid', 'failed')),
  paid_at       TEXT,
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);

CREATE TABLE IF NOT EXISTS order_items (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id        INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id      INTEGER REFERENCES products(id) ON DELETE SET NULL,
  product_name    TEXT    NOT NULL,
  unit_price_kobo INTEGER NOT NULL,
  quantity        INTEGER NOT NULL CHECK (quantity > 0)
);

-- Every payment attempt: online (Kora, or the local simulator when Kora keys are not set)
-- and cash collected on delivery. One order can have several attempts.
CREATE TABLE IF NOT EXISTS payments (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id    INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  provider    TEXT    NOT NULL CHECK (provider IN ('kora', 'simulator', 'cash')),
  reference   TEXT    NOT NULL UNIQUE,
  amount_kobo INTEGER NOT NULL,
  currency    TEXT    NOT NULL DEFAULT 'NGN',
  status      TEXT    NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'success', 'failed')),
  channel     TEXT,
  fee_kobo    INTEGER,
  checkout_url TEXT,
  provider_response TEXT,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_payments_order ON payments(order_id);
CREATE INDEX IF NOT EXISTS idx_payments_created ON payments(created_at);

CREATE TABLE IF NOT EXISTS sessions (
  sid     TEXT    PRIMARY KEY,
  sess    TEXT    NOT NULL,
  expires INTEGER NOT NULL
);
`;

function openDatabase(file) {
  if (file !== ':memory:') {
    fs.mkdirSync(path.dirname(file), { recursive: true });
  }
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys = ON;');
  if (file !== ':memory:') db.exec('PRAGMA journal_mode = WAL;');
  db.exec(SCHEMA);
  migrate(db);
  return db;
}

// Adds columns introduced after the first version to databases created earlier.
function migrate(db) {
  const orderColumns = db.prepare('PRAGMA table_info(orders)').all().map((c) => c.name);
  const add = {
    payment_method: "ALTER TABLE orders ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'cod'",
    payment_status: "ALTER TABLE orders ADD COLUMN payment_status TEXT NOT NULL DEFAULT 'unpaid'",
    paid_at: 'ALTER TABLE orders ADD COLUMN paid_at TEXT',
  };
  for (const [column, sql] of Object.entries(add)) {
    if (!orderColumns.includes(column)) db.exec(sql);
  }
}

// Run `fn` inside a transaction; roll back if it throws.
function transaction(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

module.exports = { openDatabase, transaction };
