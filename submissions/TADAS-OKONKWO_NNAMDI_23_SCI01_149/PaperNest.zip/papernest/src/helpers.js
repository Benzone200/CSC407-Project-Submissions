'use strict';
// Small shared helpers: money formatting, validation and the shopping cart.
// Money is always stored as whole kobo (integers) to avoid floating-point errors.

const nairaFormatter = new Intl.NumberFormat('en-NG', {
  style: 'currency',
  currency: 'NGN',
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});

const formatNaira = (kobo) => nairaFormatter.format(kobo / 100);

// SQLite stores datetime('now') in UTC as "YYYY-MM-DD HH:MM:SS"; show it in Nigerian time.
const dateFormatter = new Intl.DateTimeFormat('en-NG', { dateStyle: 'medium', timeZone: 'Africa/Lagos' });
const dateTimeFormatter = new Intl.DateTimeFormat('en-NG', {
  dateStyle: 'medium', timeStyle: 'short', timeZone: 'Africa/Lagos',
});
const parseDbDate = (text) => new Date(`${String(text).replace(' ', 'T')}Z`);
const formatDate = (text) => dateFormatter.format(parseDbDate(text));
const formatDateTime = (text) => dateTimeFormatter.format(parseDbDate(text));

// Human wording for an order's payment state.
function paymentLabel(order) {
  if (order.payment_status === 'paid') return 'Paid';
  if (order.payment_method === 'cod') return 'Pay on delivery';
  return { pending: 'Awaiting payment', failed: 'Payment failed' }[order.payment_status] || 'Unpaid';
}

// One-time message shown on the next page ("Item added to cart").
function setFlash(req, type, message) {
  req.session.flash = { type, message };
}

// "1,250.50" -> 125050. Returns null for anything that is not a valid amount.
function parseNairaToKobo(value) {
  const cleaned = String(value ?? '').replace(/,/g, '').trim();
  if (!/^\d{1,7}(\.\d{1,2})?$/.test(cleaned)) return null;
  const [whole, fraction = ''] = cleaned.split('.');
  return Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
}

// Whole number in [min, max], or null.
function parseIntInRange(value, min, max) {
  const text = String(value ?? '').trim();
  if (!/^-?\d+$/.test(text)) return null;
  const n = Number(text);
  return n >= min && n <= max ? n : null;
}

const str = (value) => (typeof value === 'string' ? value.trim() : '');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_RE = /^\+?[0-9][0-9 -]{6,18}[0-9]$/;

// Only allow redirects to paths on this site (blocks open-redirect attacks
// such as /login?next=https://evil.example).
function safeRedirectPath(value, fallback = '/') {
  return typeof value === 'string' && /^\/(?![/\\])/.test(value) ? value : fallback;
}

// Escape % and _ so user input is matched literally inside a LIKE pattern.
const likePattern = (text) => `%${text.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;

// ---- Cart ----
// The cart lives in the session as { productId: quantity }. Prices and stock
// are always re-read from the database, never trusted from the browser.

const MAX_QTY_PER_ITEM = 99;

function getCart(session) {
  if (!session.cart || typeof session.cart !== 'object') session.cart = {};
  return session.cart;
}

function cartCount(session) {
  return Object.values(session.cart || {}).reduce((sum, qty) => sum + qty, 0);
}

const DELIVERY_FEE_KOBO = 1500_00;
const FREE_DELIVERY_FROM_KOBO = 20000_00;

// Builds the cart summary from current database prices. Drops products that
// no longer exist and caps quantities at the available stock.
function buildCart(db, session) {
  const cart = getCart(session);
  const ids = Object.keys(cart).map(Number).filter(Number.isInteger);
  if (ids.length === 0) {
    return { items: [], subtotal: 0, delivery: 0, total: 0, adjusted: false };
  }

  const placeholders = ids.map(() => '?').join(',');
  const products = db.prepare(
    `SELECT id, name, price_kobo, stock, image FROM products WHERE id IN (${placeholders})`,
  ).all(...ids);

  let adjusted = false;
  const items = [];
  const found = new Set();
  for (const p of products) {
    found.add(String(p.id));
    let qty = cart[p.id];
    if (p.stock === 0) {
      delete cart[p.id];
      adjusted = true;
      continue;
    }
    if (qty > p.stock) {
      qty = p.stock;
      cart[p.id] = qty;
      adjusted = true;
    }
    items.push({ ...p, quantity: qty, line_total: p.price_kobo * qty });
  }
  for (const id of Object.keys(cart)) {
    if (!found.has(id)) {
      delete cart[id];
      adjusted = true;
    }
  }

  const subtotal = items.reduce((sum, item) => sum + item.line_total, 0);
  const delivery = subtotal === 0 || subtotal >= FREE_DELIVERY_FROM_KOBO ? 0 : DELIVERY_FEE_KOBO;
  return { items, subtotal, delivery, total: subtotal + delivery, adjusted };
}

module.exports = {
  formatNaira,
  formatDate,
  formatDateTime,
  setFlash,
  paymentLabel,
  parseNairaToKobo,
  parseIntInRange,
  str,
  EMAIL_RE,
  PHONE_RE,
  safeRedirectPath,
  likePattern,
  MAX_QTY_PER_ITEM,
  DELIVERY_FEE_KOBO,
  FREE_DELIVERY_FROM_KOBO,
  getCart,
  cartCount,
  buildCart,
};
