'use strict';
// Access control. Checks run on the server for every protected route;
// hiding links in the page is not relied on for security.

function loadUser(db) {
  const findUser = db.prepare('SELECT id, name, email, role FROM users WHERE id = ?');
  return (req, res, next) => {
    req.user = null;
    if (req.session.userId) {
      req.user = findUser.get(req.session.userId) || null;
      // The account was deleted: drop the stale login.
      if (!req.user) delete req.session.userId;
    }
    res.locals.user = req.user;
    next();
  };
}

function requireLogin(req, res, next) {
  if (req.user) return next();
  req.session.flash = { type: 'info', message: 'Please log in to continue.' };
  const target = req.method === 'GET' ? req.originalUrl : '/cart';
  res.redirect(`/login?next=${encodeURIComponent(target)}`);
}

function requireAdmin(req, res, next) {
  if (!req.user) return requireLogin(req, res, next);
  if (req.user.role !== 'admin') {
    const err = new Error('You do not have permission to view this page.');
    err.status = 403;
    return next(err);
  }
  next();
}

module.exports = { loadUser, requireLogin, requireAdmin };
