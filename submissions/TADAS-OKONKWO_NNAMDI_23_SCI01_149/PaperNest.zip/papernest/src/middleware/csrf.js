'use strict';
// CSRF protection (synchronizer token pattern).
// Each session gets a random token. Every form includes it as a hidden `_csrf`
// field, and every state-changing request must send it back. A malicious site
// cannot read the token, so it cannot forge a valid request.

const crypto = require('node:crypto');

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

// Forms that upload a photo are sent as multipart/form-data, which is only parsed
// inside those routes. For these exact paths the token check runs after parsing
// (see verifyDeferredCsrf). Every other request is checked here.
const UPLOAD_PATHS = /^\/admin\/products(\/\d+)?$/;

function tokensMatch(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  return bufA.length === bufB.length && crypto.timingSafeEqual(bufA, bufB);
}

function csrfProtection(req, res, next) {
  if (!req.session.csrfToken) {
    req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  }
  res.locals.csrfToken = req.session.csrfToken;

  if (SAFE_METHODS.has(req.method)) return next();
  if (req.method === 'POST' && UPLOAD_PATHS.test(req.path) && req.is('multipart/form-data')) {
    req.csrfDeferred = true;
    return next();
  }

  const sent = (req.body && req.body._csrf) || req.get('x-csrf-token');
  if (!tokensMatch(sent, req.session.csrfToken)) {
    const err = new Error('Invalid or missing CSRF token. Please refresh the page and try again.');
    err.status = 403;
    return next(err);
  }
  next();
}

// Runs after a multipart body has been parsed. Requests that were already checked pass straight through.
function verifyDeferredCsrf(req, res, next) {
  if (!req.csrfDeferred) return next();
  if (!tokensMatch(req.body && req.body._csrf, req.session.csrfToken)) {
    const err = new Error('Invalid or missing CSRF token. Please refresh the page and try again.');
    err.status = 403;
    return next(err);
  }
  next();
}

module.exports = { csrfProtection, verifyDeferredCsrf };
