'use strict';
// Automated tests: `npm test`
// Each test builds a fresh app with an in-memory database, so tests never touch real data.

const { test, describe } = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');
const { createApp } = require('../src/app');
const { DEMO_ADMIN, DEMO_CUSTOMER } = require('../src/seed');
const { parseNairaToKobo, safeRedirectPath, formatNaira } = require('../src/helpers');

// Low bcrypt cost keeps the tests fast. Production uses 12.
const newApp = (opts = {}) => createApp({ bcryptRounds: 4, loginRateLimit: 1000, ...opts });

// Reads the CSRF token out of a page's form.
async function csrfFrom(agent, url = '/login') {
  const res = await agent.get(url);
  const match = res.text.match(/name="_csrf" value="([a-f0-9]+)"/);
  assert.ok(match, `no CSRF token found on ${url}`);
  return match[1];
}

async function login(agent, { email, password }) {
  const _csrf = await csrfFrom(agent);
  return agent.post('/login').type('form').send({ _csrf, email, password, next: '/' });
}

async function addToCart(agent, productId, quantity = 1) {
  const _csrf = await csrfFrom(agent, '/products');
  return agent.post('/cart/add').type('form').send({ _csrf, product_id: productId, quantity });
}

const validDelivery = {
  full_name: 'Ada Obi', phone: '0803 123 4567', address: '12 Unity Road, Bodija',
  city: 'Ibadan', state: 'Oyo', notes: '',
};

describe('helpers', () => {
  test('parseNairaToKobo accepts valid amounts and rejects junk', () => {
    assert.equal(parseNairaToKobo('1500'), 150000);
    assert.equal(parseNairaToKobo('1,250.5'), 125050);
    assert.equal(parseNairaToKobo('-5'), null);
    assert.equal(parseNairaToKobo('abc'), null);
    assert.equal(parseNairaToKobo('1.234'), null);
  });

  test('safeRedirectPath only allows local paths', () => {
    assert.equal(safeRedirectPath('/cart'), '/cart');
    assert.equal(safeRedirectPath('https://evil.example'), '/');
    assert.equal(safeRedirectPath('//evil.example'), '/');
    assert.equal(safeRedirectPath('/\\evil.example'), '/');
  });

  test('formatNaira formats kobo as naira', () => {
    assert.match(formatNaira(150000), /1,500/);
  });
});

describe('homepage and catalogue', () => {
  test('homepage shows featured products and promotions', async () => {
    const res = await request(newApp()).get('/');
    assert.equal(res.status, 200);
    assert.match(res.text, /Popular picks/);
    assert.match(res.text, /A4 Hardcover Notebook/);
    assert.match(res.text, /Today's deals/);
  });

  test('catalogue lists products with prices', async () => {
    const res = await request(newApp()).get('/products');
    assert.equal(res.status, 200);
    assert.match(res.text, /23 products/);
    assert.match(res.text, /₦/);
  });

  test('search finds matching products only', async () => {
    const res = await request(newApp()).get('/products?q=stapler');
    assert.match(res.text, /Desktop Stapler/);
    assert.doesNotMatch(res.text, /Watercolour Paint Set/);
  });

  test('category and price filters work together', async () => {
    const res = await request(newApp()).get('/products?category=staplers&max=1000');
    assert.match(res.text, /Mini Stapler/);
    assert.doesNotMatch(res.text, /Desktop Stapler \(Full Strip\)/);
  });

  test('SQL wildcard characters in search are treated literally', async () => {
    const res = await request(newApp()).get('/products?q=%25');
    assert.match(res.text, /No products found/);
  });

  test('product page shows details; unknown product is 404', async () => {
    const app = newApp();
    const ok = await request(app).get('/products/1');
    assert.equal(ok.status, 200);
    assert.match(ok.text, /Add to cart/);
    assert.equal((await request(app).get('/products/9999')).status, 404);
    assert.equal((await request(app).get('/products/abc')).status, 404);
  });
});

describe('shopping cart', () => {
  test('add, update and remove items', async () => {
    const agent = request.agent(newApp());
    await addToCart(agent, 1, 2);
    let cart = await agent.get('/cart');
    assert.match(cart.text, /A4 Hardcover Notebook/);
    assert.match(cart.text, /value="2"/);

    let _csrf = await csrfFrom(agent, '/cart');
    await agent.post('/cart/update').type('form').send({ _csrf, product_id: 1, quantity: 5 });
    cart = await agent.get('/cart');
    assert.match(cart.text, /value="5"/);

    _csrf = await csrfFrom(agent, '/cart');
    await agent.post('/cart/remove').type('form').send({ _csrf, product_id: 1 });
    cart = await agent.get('/cart');
    assert.match(cart.text, /Your cart is empty/);
  });

  test('quantity cannot exceed stock', async () => {
    const app = newApp();
    app.locals.db.prepare('UPDATE products SET stock = 3 WHERE id = 1').run();
    const agent = request.agent(app);
    await addToCart(agent, 1, 10);
    const cart = await agent.get('/cart');
    assert.match(cart.text, /value="3"/);
  });

  test('out-of-stock products cannot be added', async () => {
    const app = newApp();
    app.locals.db.prepare('UPDATE products SET stock = 0 WHERE id = 1').run();
    const agent = request.agent(app);
    await addToCart(agent, 1, 1);
    assert.match((await agent.get('/cart')).text, /Your cart is empty/);
  });
});

describe('registration and login', () => {
  test('a new customer can register and is logged in', async () => {
    const agent = request.agent(newApp());
    const _csrf = await csrfFrom(agent, '/register');
    const res = await agent.post('/register').type('form').send({
      _csrf, name: 'Ada Obi', email: 'ada@example.com', password: 'Secret123', confirm_password: 'Secret123',
    });
    assert.equal(res.status, 302);
    const home = await agent.get('/');
    assert.match(home.text, /Log out/);
  });

  test('registration rejects weak passwords and duplicate emails', async () => {
    const agent = request.agent(newApp());
    let _csrf = await csrfFrom(agent, '/register');
    let res = await agent.post('/register').type('form').send({
      _csrf, name: 'Ada', email: 'ada@example.com', password: 'short', confirm_password: 'short',
    });
    assert.equal(res.status, 422);
    assert.match(res.text, /at least 8 characters/);

    _csrf = await csrfFrom(agent, '/register');
    res = await agent.post('/register').type('form').send({
      _csrf, name: 'Ada', email: DEMO_CUSTOMER.email, password: 'Secret123', confirm_password: 'Secret123',
    });
    assert.equal(res.status, 422);
    assert.match(res.text, /already exists/);
  });

  test('passwords are stored hashed, never in plain text', async () => {
    const app = newApp();
    const row = app.locals.db.prepare('SELECT password_hash FROM users WHERE email = ?').get(DEMO_CUSTOMER.email);
    assert.notEqual(row.password_hash, DEMO_CUSTOMER.password);
    assert.match(row.password_hash, /^\$2[aby]\$/);
  });

  test('wrong password gives a generic error', async () => {
    const agent = request.agent(newApp());
    const res = await login(agent, { email: DEMO_CUSTOMER.email, password: 'wrong-password1' });
    assert.equal(res.status, 401);
    assert.match(res.text, /Incorrect email or password/);
  });

  test('login changes the session ID (prevents session fixation)', async () => {
    const agent = request.agent(newApp());
    const before = await agent.get('/login');
    const cookieBefore = before.headers['set-cookie'][0].split(';')[0];
    const res = await login(agent, DEMO_CUSTOMER);
    const cookieAfter = res.headers['set-cookie'][0].split(';')[0];
    assert.notEqual(cookieBefore, cookieAfter);
  });

  test('too many login attempts are rate limited', async () => {
    const agent = request.agent(newApp({ loginRateLimit: 3 }));
    let res;
    for (let i = 0; i < 4; i++) {
      res = await login(agent, { email: DEMO_CUSTOMER.email, password: 'wrong-password1' });
    }
    assert.equal(res.status, 429);
  });

  test('login refuses to redirect to another website', async () => {
    const agent = request.agent(newApp());
    const _csrf = await csrfFrom(agent);
    const res = await agent.post('/login').type('form').send({
      _csrf, ...DEMO_CUSTOMER, next: 'https://evil.example/phish',
    });
    assert.equal(res.status, 302);
    assert.equal(res.headers.location, '/');
  });
});

describe('checkout and orders', () => {
  test('checkout requires login', async () => {
    const res = await request(newApp()).get('/checkout');
    assert.equal(res.status, 302);
    assert.match(res.headers.location, /^\/login\?next=%2Fcheckout/);
  });

  test('placing an order saves it, reduces stock and empties the cart', async () => {
    const app = newApp();
    const db = app.locals.db;
    const stockBefore = db.prepare('SELECT stock FROM products WHERE id = 1').get().stock;
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    await addToCart(agent, 1, 2);

    const _csrf = await csrfFrom(agent, '/checkout');
    const res = await agent.post('/checkout').type('form').send({ _csrf, ...validDelivery });
    assert.equal(res.status, 302);
    assert.match(res.headers.location, /^\/orders\/PN-[0-9A-F]{8}$/);

    const order = await agent.get(res.headers.location);
    assert.equal(order.status, 200);
    assert.match(order.text, /Ada Obi/);
    assert.match(order.text, /Ibadan, Oyo/);

    assert.equal(db.prepare('SELECT stock FROM products WHERE id = 1').get().stock, stockBefore - 2);
    assert.match((await agent.get('/cart')).text, /Your cart is empty/);
    assert.match((await agent.get('/orders')).text, /PN-/);
  });

  test('order total is computed on the server from database prices', async () => {
    const app = newApp();
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    await addToCart(agent, 1, 1); // A4 notebook: ₦1,800 + ₦1,500 delivery
    const _csrf = await csrfFrom(agent, '/checkout');
    await agent.post('/checkout').type('form').send({ _csrf, ...validDelivery, total_kobo: 1 });
    const order = app.locals.db.prepare('SELECT * FROM orders').get();
    assert.equal(order.subtotal_kobo, 180000);
    assert.equal(order.delivery_kobo, 150000);
    assert.equal(order.total_kobo, 330000);
  });

  test('invalid delivery details are rejected', async () => {
    const agent = request.agent(newApp());
    await login(agent, DEMO_CUSTOMER);
    await addToCart(agent, 1, 1);
    const _csrf = await csrfFrom(agent, '/checkout');
    const res = await agent.post('/checkout').type('form').send({
      _csrf, ...validDelivery, phone: 'call me', state: 'Atlantis',
    });
    assert.equal(res.status, 422);
    assert.match(res.text, /valid phone number/);
    assert.match(res.text, /Choose your state/);
  });

  test('if stock runs out before checkout, no order is created', async () => {
    const app = newApp();
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    await addToCart(agent, 1, 2);
    const _csrf = await csrfFrom(agent, '/checkout');
    app.locals.db.prepare('UPDATE products SET stock = 1 WHERE id = 1').run();
    const res = await agent.post('/checkout').type('form').send({ _csrf, ...validDelivery });
    assert.equal(res.headers.location, '/cart');
    assert.equal(app.locals.db.prepare('SELECT COUNT(*) AS n FROM orders').get().n, 0);
  });

  test("customers cannot see other customers' orders", async () => {
    const app = newApp();
    const owner = request.agent(app);
    await login(owner, DEMO_CUSTOMER);
    await addToCart(owner, 1, 1);
    const _csrf = await csrfFrom(owner, '/checkout');
    const placed = await owner.post('/checkout').type('form').send({ _csrf, ...validDelivery });

    const other = request.agent(app);
    const csrf2 = await csrfFrom(other, '/register');
    await other.post('/register').type('form').send({
      _csrf: csrf2, name: 'Eve', email: 'eve@example.com', password: 'Secret123', confirm_password: 'Secret123',
    });
    const res = await other.get(placed.headers.location);
    assert.equal(res.status, 404);
  });
});

describe('admin dashboard', () => {
  test('guests are sent to login and customers are refused', async () => {
    const app = newApp();
    const guest = await request(app).get('/admin');
    assert.equal(guest.status, 302);

    const customer = request.agent(app);
    await login(customer, DEMO_CUSTOMER);
    assert.equal((await customer.get('/admin')).status, 403);
    assert.equal((await customer.get('/admin/products')).status, 403);
  });

  test('a customer cannot create products even with a valid CSRF token', async () => {
    const app = newApp();
    const customer = request.agent(app);
    await login(customer, DEMO_CUSTOMER);
    const _csrf = await csrfFrom(customer, '/');
    const res = await customer.post('/admin/products').type('form').send({
      _csrf, name: 'Hacked', category_id: 1, description: 'Should not exist', price: '1', stock: '1', image: 'products/ballpoint-pens.jpg',
    });
    assert.equal(res.status, 403);
    assert.equal(app.locals.db.prepare("SELECT COUNT(*) AS n FROM products WHERE name = 'Hacked'").get().n, 0);
  });

  test('admin can add, edit and delete a product', async () => {
    const app = newApp();
    const db = app.locals.db;
    const admin = request.agent(app);
    await login(admin, DEMO_ADMIN);
    assert.equal((await admin.get('/admin')).status, 200);

    let _csrf = await csrfFrom(admin, '/admin/products/new');
    let res = await admin.post('/admin/products').type('form').send({
      _csrf, name: 'Glue Stick (Pack of 3)', category_id: 7, description: 'Non-toxic washable glue sticks.',
      price: '750', old_price: '', stock: '40', image: 'products/colour-pencils.jpg', featured: '1',
    });
    assert.equal(res.status, 302);
    const created = db.prepare("SELECT * FROM products WHERE name = 'Glue Stick (Pack of 3)'").get();
    assert.equal(created.price_kobo, 75000);
    assert.equal(created.featured, 1);

    _csrf = await csrfFrom(admin, `/admin/products/${created.id}/edit`);
    res = await admin.post(`/admin/products/${created.id}`).type('form').send({
      _csrf, name: 'Glue Stick (Pack of 3)', category_id: 7, description: 'Non-toxic washable glue sticks.',
      price: '700', old_price: '900', stock: '35', image: 'products/colour-pencils.jpg',
    });
    assert.equal(res.status, 302);
    const updated = db.prepare('SELECT * FROM products WHERE id = ?').get(created.id);
    assert.equal(updated.price_kobo, 70000);
    assert.equal(updated.old_price_kobo, 90000);
    assert.equal(updated.featured, 0);

    _csrf = await csrfFrom(admin, '/admin/products');
    res = await admin.post(`/admin/products/${created.id}/delete`).type('form').send({ _csrf });
    assert.equal(res.status, 302);
    assert.equal(db.prepare('SELECT * FROM products WHERE id = ?').get(created.id), undefined);
  });

  test('product form validates input', async () => {
    const admin = request.agent(newApp());
    await login(admin, DEMO_ADMIN);
    const _csrf = await csrfFrom(admin, '/admin/products/new');
    const res = await admin.post('/admin/products').type('form').send({
      _csrf, name: '', category_id: 999, description: 'short', price: '-4', stock: 'lots', image: '../../etc/passwd',
    });
    assert.equal(res.status, 422);
    assert.match(res.text, /Choose a category/);
    assert.match(res.text, /Upload a photo or choose one/);
  });

  test('deleting a product keeps past orders intact', async () => {
    const app = newApp();
    const customer = request.agent(app);
    await login(customer, DEMO_CUSTOMER);
    await addToCart(customer, 2, 1);
    let _csrf = await csrfFrom(customer, '/checkout');
    const placed = await customer.post('/checkout').type('form').send({ _csrf, ...validDelivery });

    const admin = request.agent(app);
    await login(admin, DEMO_ADMIN);
    _csrf = await csrfFrom(admin, '/admin/products');
    await admin.post('/admin/products/2/delete').type('form').send({ _csrf });

    const order = await customer.get(placed.headers.location);
    assert.match(order.text, /Blue Ballpoint Pens/);
  });

  test('cancelling an order returns its items to stock', async () => {
    const app = newApp();
    const db = app.locals.db;
    const stockBefore = db.prepare('SELECT stock FROM products WHERE id = 1').get().stock;
    const customer = request.agent(app);
    await login(customer, DEMO_CUSTOMER);
    await addToCart(customer, 1, 3);
    let _csrf = await csrfFrom(customer, '/checkout');
    await customer.post('/checkout').type('form').send({ _csrf, ...validDelivery });
    const orderId = db.prepare('SELECT id FROM orders').get().id;

    const admin = request.agent(app);
    await login(admin, DEMO_ADMIN);
    _csrf = await csrfFrom(admin, '/admin/orders');
    await admin.post(`/admin/orders/${orderId}/status`).type('form').send({ _csrf, status: 'cancelled' });
    assert.equal(db.prepare('SELECT stock FROM products WHERE id = 1').get().stock, stockBefore);
    assert.equal(db.prepare('SELECT status FROM orders WHERE id = ?').get(orderId).status, 'cancelled');
  });
});

describe('security', () => {
  test('POST requests without a CSRF token are rejected', async () => {
    const agent = request.agent(newApp());
    await agent.get('/');
    const res = await agent.post('/cart/add').type('form').send({ product_id: 1, quantity: 1 });
    assert.equal(res.status, 403);
    assert.match(res.text, /CSRF/);
  });

  test('security headers are set', async () => {
    const res = await request(newApp()).get('/');
    assert.match(res.headers['content-security-policy'], /script-src 'self'/);
    assert.equal(res.headers['x-content-type-options'], 'nosniff');
    assert.ok(res.headers['x-frame-options']);
    assert.equal(res.headers['x-powered-by'], undefined);
  });

  test('session cookie is HttpOnly and SameSite', async () => {
    const res = await request(newApp()).get('/');
    const cookie = res.headers['set-cookie'][0];
    assert.match(cookie, /HttpOnly/);
    assert.match(cookie, /SameSite=Lax/);
  });

  test('user input is HTML-escaped (no XSS)', async () => {
    const res = await request(newApp()).get('/products?q=%3Cscript%3Ealert(1)%3C%2Fscript%3E');
    assert.doesNotMatch(res.text, /<script>alert\(1\)<\/script>/);
    assert.match(res.text, /&lt;script&gt;/);
  });

  test('errors do not leak stack traces', async () => {
    const res = await request(newApp()).get('/does-not-exist');
    assert.equal(res.status, 404);
    assert.doesNotMatch(res.text, /at .*\.js:\d+/);
  });
});

describe('account menu and profile', () => {
  test('header shows "Not signed in" for guests and the user\'s name when signed in', async () => {
    const agent = request.agent(newApp());
    let home = await agent.get('/');
    assert.match(home.text, /Not signed in/);
    assert.match(home.text, /href="\/login"/);
    await login(agent, DEMO_CUSTOMER);
    home = await agent.get('/');
    assert.match(home.text, /Signed in/);
    assert.match(home.text, /customer@papernest\.test/);
    assert.match(home.text, />DC</); // initials
    assert.doesNotMatch(home.text, /Admin dashboard/);
  });

  test('profile page requires login and shows the user\'s details', async () => {
    const app = newApp();
    assert.equal((await request(app).get('/account')).status, 302);
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    const res = await agent.get('/account');
    assert.equal(res.status, 200);
    assert.match(res.text, /Member since/);
    assert.match(res.text, /Demo Customer/);
  });

  test('user can change their name', async () => {
    const app = newApp();
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    const _csrf = await csrfFrom(agent, '/account');
    await agent.post('/account/profile').type('form').send({ _csrf, name: 'Ada Obi' });
    assert.equal(app.locals.db.prepare('SELECT name FROM users WHERE email = ?').get(DEMO_CUSTOMER.email).name, 'Ada Obi');
  });

  test('changing password needs the current password', async () => {
    const app = newApp();
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    let _csrf = await csrfFrom(agent, '/account');
    let res = await agent.post('/account/password').type('form')
      .send({ _csrf, current_password: 'wrong-password1', new_password: 'NewSecret99', confirm_password: 'NewSecret99' });
    assert.equal(res.status, 422);
    assert.match(res.text, /current password is not correct/);

    _csrf = await csrfFrom(agent, '/account');
    res = await agent.post('/account/password').type('form')
      .send({ _csrf, current_password: DEMO_CUSTOMER.password, new_password: 'NewSecret99', confirm_password: 'NewSecret99' });
    assert.equal(res.status, 302);

    const fresh = request.agent(app);
    const ok = await login(fresh, { email: DEMO_CUSTOMER.email, password: 'NewSecret99' });
    assert.equal(ok.status, 302);
  });
});

describe('demo logins', () => {
  test('login page lists the demo accounts and one-click buttons', async () => {
    const res = await request(newApp()).get('/login');
    assert.match(res.text, /Demo accounts/);
    assert.match(res.text, /admin@papernest\.test/);
    assert.match(res.text, /Log in as admin/);
    assert.match(res.text, /Log in as customer/);
  });

  test('one-click demo login signs in as the chosen role', async () => {
    const agent = request.agent(newApp());
    const _csrf = await csrfFrom(agent, '/login');
    const res = await agent.post('/login/demo').type('form').send({ _csrf, role: 'admin' });
    assert.equal(res.headers.location, '/admin');
    assert.equal((await agent.get('/admin')).status, 200);
  });

  test('demo login can be switched off and still needs a CSRF token', async () => {
    const off = request.agent(newApp({ demoLogin: false }));
    assert.doesNotMatch((await off.get('/login')).text, /Demo accounts/);
    const _csrf = await csrfFrom(off, '/login');
    assert.equal((await off.post('/login/demo').type('form').send({ _csrf, role: 'admin' })).status, 404);

    const on = request.agent(newApp());
    await on.get('/login');
    assert.equal((await on.post('/login/demo').type('form').send({ role: 'admin' })).status, 403);
  });
});
