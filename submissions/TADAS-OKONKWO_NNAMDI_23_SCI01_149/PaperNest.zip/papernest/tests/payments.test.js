'use strict';
// Tests for online payments (Kora + simulator) and the admin dashboard features.
// Kora itself is replaced by a fake client, so no network calls are made.

const { test, describe } = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const request = require('supertest');
const { createApp } = require('../src/app');
const { createKoraClient } = require('../src/payments/kora');
const { DEMO_ADMIN, DEMO_CUSTOMER } = require('../src/seed');

const SECRET = 'sk_test_fake_secret_for_tests';

// A stand-in for Kora: records charges and lets each test decide the verify result.
function fakeKora() {
  const real = createKoraClient({ secretKey: SECRET, fetchImpl: () => { throw new Error('no network in tests'); } });
  const fake = {
    provider: 'kora',
    testMode: true,
    charges: [],
    nextVerify: null,
    async initializeCharge(args) {
      fake.charges.push(args);
      return { checkoutUrl: `https://checkout.korapay.com/${args.reference}/pay` };
    },
    async verifyCharge(reference) {
      const charge = fake.charges.find((c) => c.reference === reference);
      return {
        reference, status: 'success', amountKobo: charge.amountKobo, currency: 'NGN',
        feeKobo: 5000, channel: 'card', raw: { reference }, ...(fake.nextVerify || {}),
      };
    },
    verifyWebhookSignature: real.verifyWebhookSignature,
  };
  return fake;
}

const newApp = (opts = {}) => createApp({ bcryptRounds: 4, loginRateLimit: 1000, ...opts });

async function csrfFrom(agent, url) {
  const res = await agent.get(url);
  const match = res.text.match(/name="_csrf" value="([a-f0-9]+)"/);
  assert.ok(match, `no CSRF token on ${url}`);
  return match[1];
}
async function post(agent, url, from, body) {
  const _csrf = await csrfFrom(agent, from);
  return agent.post(url).type('form').send({ _csrf, ...body });
}
const login = (agent, user) => post(agent, '/login', '/login', { email: user.email, password: user.password, next: '/' });

const delivery = {
  full_name: 'Ada Obi', phone: '0803 123 4567', address: '12 Unity Road, Bodija', city: 'Ibadan', state: 'Oyo',
};

async function placeOrder(agent, paymentMethod) {
  await post(agent, '/cart/add', '/products', { product_id: 1, quantity: 2 }); // 2 × ₦1,800 + ₦1,500 delivery
  return post(agent, '/checkout', '/checkout', { ...delivery, payment_method: paymentMethod });
}

describe('Kora checkout', () => {
  test('online checkout creates a pending order and redirects to Kora', async () => {
    const kora = fakeKora();
    const app = newApp({ kora });
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    const res = await placeOrder(agent, 'online');

    assert.equal(res.status, 302);
    assert.match(res.headers.location, /^https:\/\/checkout\.korapay\.com\//);
    assert.equal(kora.charges.length, 1);
    assert.equal(kora.charges[0].amountKobo, 510000);
    assert.equal(kora.charges[0].customer.email, DEMO_CUSTOMER.email);
    assert.match(kora.charges[0].redirectUrl, /\/payments\/kora\/callback$/);

    const order = app.locals.db.prepare('SELECT * FROM orders').get();
    assert.equal(order.payment_method, 'online');
    assert.equal(order.payment_status, 'pending');
  });

  test('callback verifies with Kora and marks the order paid', async () => {
    const kora = fakeKora();
    const app = newApp({ kora });
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    await placeOrder(agent, 'online');
    const { reference } = kora.charges[0];

    const res = await agent.get(`/payments/kora/callback?reference=${reference}`);
    assert.equal(res.status, 302);
    const order = app.locals.db.prepare('SELECT * FROM orders').get();
    assert.equal(order.payment_status, 'paid');
    assert.equal(order.status, 'processing');
    const page = await agent.get(res.headers.location);
    assert.match(page.text, /Payment received/);

    // Visiting the callback again does not double-count.
    await agent.get(`/payments/kora/callback?reference=${reference}`);
    assert.equal(app.locals.db.prepare("SELECT COUNT(*) AS n FROM payments WHERE status = 'success'").get().n, 1);
  });

  test('a payment for less than the order total is not accepted', async () => {
    const kora = fakeKora();
    kora.nextVerify = { amountKobo: 100 };
    const app = newApp({ kora });
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    await placeOrder(agent, 'online');
    await agent.get(`/payments/kora/callback?reference=${kora.charges[0].reference}`);
    const order = app.locals.db.prepare('SELECT * FROM orders').get();
    assert.notEqual(order.payment_status, 'paid');
  });

  test('a failed payment can be retried with "Pay now"', async () => {
    const kora = fakeKora();
    kora.nextVerify = { status: 'failed' };
    const app = newApp({ kora });
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    await placeOrder(agent, 'online');
    await agent.get(`/payments/kora/callback?reference=${kora.charges[0].reference}`);
    const order = app.locals.db.prepare('SELECT * FROM orders').get();
    assert.equal(order.payment_status, 'failed');

    const page = await agent.get(`/orders/${order.reference}`);
    assert.match(page.text, /Pay now/);
    const retry = await post(agent, `/orders/${order.reference}/pay`, `/orders/${order.reference}`, {});
    assert.match(retry.headers.location, /checkout\.korapay\.com/);
    assert.equal(kora.charges.length, 2);
    assert.notEqual(kora.charges[0].reference, kora.charges[1].reference);
  });

  test('webhook with a valid signature marks the order paid', async () => {
    const kora = fakeKora();
    const app = newApp({ kora });
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    await placeOrder(agent, 'online');
    const body = { event: 'charge.success', data: { reference: kora.charges[0].reference, status: 'success', amount: 5100, currency: 'NGN' } };
    const signature = crypto.createHmac('sha256', SECRET).update(JSON.stringify(body.data)).digest('hex');

    const res = await request(app).post('/payments/kora/webhook').set('x-korapay-signature', signature).send(body);
    assert.equal(res.status, 200);
    assert.equal(app.locals.db.prepare('SELECT payment_status FROM orders').get().payment_status, 'paid');
  });

  test('webhook with a wrong signature is rejected', async () => {
    const kora = fakeKora();
    const app = newApp({ kora });
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    await placeOrder(agent, 'online');
    const body = { event: 'charge.success', data: { reference: kora.charges[0].reference, status: 'success' } };
    const res = await request(app).post('/payments/kora/webhook').set('x-korapay-signature', 'forged').send(body);
    assert.equal(res.status, 401);
    assert.equal(app.locals.db.prepare('SELECT payment_status FROM orders').get().payment_status, 'pending');
  });

  test('another customer cannot pay for or view someone else\'s order', async () => {
    const kora = fakeKora();
    const app = newApp({ kora });
    const owner = request.agent(app);
    await login(owner, DEMO_CUSTOMER);
    await placeOrder(owner, 'online');
    const order = app.locals.db.prepare('SELECT * FROM orders').get();

    const other = request.agent(app);
    await post(other, '/register', '/register', { name: 'Eve', email: 'eve@example.com', password: 'Secret123', confirm_password: 'Secret123' });
    const res = await post(other, `/orders/${order.reference}/pay`, '/', {});
    assert.equal(res.status, 404);
  });

  test('pay on delivery still works', async () => {
    const app = newApp({ kora: fakeKora() });
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    const res = await placeOrder(agent, 'cod');
    assert.match(res.headers.location, /^\/orders\/PN-/);
    const order = app.locals.db.prepare('SELECT * FROM orders').get();
    assert.equal(order.payment_method, 'cod');
    assert.equal(order.payment_status, 'unpaid');
  });
});

describe('payment simulator (no Kora keys)', () => {
  test('simulated success marks the order paid', async () => {
    const app = newApp();
    const agent = request.agent(app);
    await login(agent, DEMO_CUSTOMER);
    const res = await placeOrder(agent, 'online');
    assert.match(res.headers.location, /^\/payments\/simulator\//);

    const page = await agent.get(res.headers.location);
    assert.match(page.text, /Test mode/);
    await post(agent, res.headers.location, res.headers.location, { outcome: 'success' });
    assert.equal(app.locals.db.prepare('SELECT payment_status FROM orders').get().payment_status, 'paid');
  });

  test('simulator is off in production without keys, so only pay on delivery is offered', async () => {
    const app = newApp({ isProduction: true, sessionSecret: 'x'.repeat(32) });
    assert.equal(app.locals.payments.onlineAvailable, false);
    assert.equal(app.locals.payments.provider, null);
  });
});

describe('admin dashboard', () => {
  async function adminAgent(app) {
    const admin = request.agent(app);
    await login(admin, DEMO_ADMIN);
    return admin;
  }

  test('dashboard shows revenue chart and transactions', async () => {
    const app = newApp();
    const customer = request.agent(app);
    await login(customer, DEMO_CUSTOMER);
    const res = await placeOrder(customer, 'online');
    await post(customer, res.headers.location, res.headers.location, { outcome: 'success' });

    const admin = await adminAgent(app);
    const dash = await admin.get('/admin');
    assert.equal(dash.status, 200);
    assert.match(dash.text, /Revenue received/);
    assert.match(dash.text, /class="chart-bar"/);
    assert.match(dash.text, /₦5,100/);

    const txns = await admin.get('/admin/transactions');
    assert.equal(txns.status, 200);
    assert.match(txns.text, /Test payment/);
    const filtered = await admin.get('/admin/transactions?status=failed');
    assert.match(filtered.text, /No transactions found/);
  });

  test('customers cannot see transactions', async () => {
    const app = newApp();
    const customer = request.agent(app);
    await login(customer, DEMO_CUSTOMER);
    assert.equal((await customer.get('/admin/transactions')).status, 403);
  });

  test('delivering a pay-on-delivery order records the cash payment', async () => {
    const app = newApp();
    const customer = request.agent(app);
    await login(customer, DEMO_CUSTOMER);
    await placeOrder(customer, 'cod');
    const order = app.locals.db.prepare('SELECT * FROM orders').get();

    const admin = await adminAgent(app);
    await post(admin, `/admin/orders/${order.id}/status`, '/admin/orders', { status: 'delivered' });
    const payment = app.locals.db.prepare('SELECT * FROM payments').get();
    assert.equal(payment.provider, 'cash');
    assert.equal(payment.status, 'success');
    assert.equal(app.locals.db.prepare('SELECT payment_status FROM orders').get().payment_status, 'paid');
  });

  test('receiving goods adds to stock', async () => {
    const app = newApp();
    const before = app.locals.db.prepare('SELECT stock FROM products WHERE id = 3').get().stock;
    const admin = await adminAgent(app);
    await post(admin, '/admin/products/3/restock', '/admin/products', { quantity: 25 });
    assert.equal(app.locals.db.prepare('SELECT stock FROM products WHERE id = 3').get().stock, before + 25);

    await post(admin, '/admin/products/3/restock', '/admin/products', { quantity: -5 });
    assert.equal(app.locals.db.prepare('SELECT stock FROM products WHERE id = 3').get().stock, before + 25);
  });

  // 1×1 PNG
  const PNG = Buffer.from('89504e470d0a1a0a0000000d4948445200000001000000010806000000'
    + '1f15c4890000000d49444154789c6360000002000154a24f5d0000000049454e44ae426082', 'hex');

  test('admin can add a product with an uploaded photo', async () => {
    const app = newApp();
    const admin = await adminAgent(app);
    const _csrf = await csrfFrom(admin, '/admin/products/new');
    const res = await admin.post('/admin/products')
      .field('_csrf', _csrf).field('name', 'Glue Stick').field('category_id', '7')
      .field('description', 'Washable glue stick for school projects.').field('price', '650').field('stock', '30')
      .attach('photo', PNG, { filename: 'glue.png', contentType: 'image/png' });
    assert.equal(res.status, 302);
    const product = app.locals.db.prepare("SELECT * FROM products WHERE name = 'Glue Stick'").get();
    assert.match(product.image, /^uploads\/[0-9a-f]{16}\.png$/);
    const img = await admin.get(`/img/${product.image}`);
    assert.equal(img.status, 200);
    require('node:fs').unlinkSync(require('node:path').join(__dirname, '..', 'public', 'img', product.image));
  });

  test('uploads that are not images are rejected', async () => {
    const app = newApp();
    const admin = await adminAgent(app);
    const _csrf = await csrfFrom(admin, '/admin/products/new');
    const res = await admin.post('/admin/products')
      .field('_csrf', _csrf).field('name', 'Bad File').field('category_id', '7')
      .field('description', 'This upload is not a picture at all.').field('price', '650').field('stock', '30')
      .attach('photo', Buffer.from('<script>alert(1)</script>'), { filename: 'evil.png', contentType: 'image/png' });
    assert.equal(res.status, 422);
    assert.match(res.text, /must be a JPG, PNG or WebP/);
  });

  test('photo upload form still requires a CSRF token', async () => {
    const app = newApp();
    const admin = await adminAgent(app);
    const res = await admin.post('/admin/products')
      .field('name', 'No Token').field('category_id', '7')
      .field('description', 'Submitted without a CSRF token.').field('price', '650').field('stock', '30')
      .attach('photo', PNG, { filename: 'x.png', contentType: 'image/png' });
    assert.equal(res.status, 403);
  });
});
