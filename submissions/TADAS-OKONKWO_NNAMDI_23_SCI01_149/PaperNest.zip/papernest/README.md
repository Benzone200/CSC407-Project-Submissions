# PaperNest – Online Stationery Store

An e-commerce website where students and office workers can buy stationery: notebooks and jotters, pens and pencils, highlighters and markers, sticky notes, files and folders, staplers, art supplies, and diaries and planners.

| | |
|---|---|
| **Name** | Tadas-Okonkwo Nnamdi |
| **Matric number** | 23/SCI01/149 |
| **Course** | CSC 407 |
| **Project** | PaperNest – Online Stationery Store |

## Features

1. **Homepage.** Featured products, today's deals (items with a reduced price), promotions and shop-by-category links.
2. **Product catalogue.** Every product has a picture, price, description and stock level, with a details page for each product.
3. **Search and filter.** Search by keyword, then filter by category, price range and "in stock only". Results can be sorted by newest, price or name, and are split into pages.
4. **Shopping cart.** Add, update and remove products. Quantities are limited to the stock available. Delivery is ₦1,500, or free on orders of ₦20,000 and above.
5. **Checkout and payment.** Logged-in customers enter their delivery details and choose how to pay:
   - **Pay now with Kora**: card, bank transfer or pay-with-bank through Kora's hosted checkout (test mode, see below).
   - **Pay on delivery**: cash or transfer when the order arrives.

   Customers can see their order history, the payment status of each order and a **Pay now** button if an online payment did not go through.
6. **User authentication.** Customers can register, log in and log out.
7. **Admin dashboard.**
   - **Monitor:** revenue received, orders today, orders awaiting payment, low stock, a 14-day revenue chart, recent transactions and best sellers.
   - **Transactions:** every payment (Kora, test payments and cash on delivery) with search, status and method filters, Kora fees and a "Check status" button that asks Kora for the latest result.
   - **Products:** add, edit and delete products, **upload a product photo** (or pick one from the photo library) and **receive goods**, which adds new stock to a product in one step.
   - **Orders:** update the status (pending → processing → shipped → delivered, or cancelled). Cancelling puts items back in stock, and delivering a pay-on-delivery order records the cash payment.

## Technology

- **Backend:** Node.js and Express
- **Views:** EJS templates (rendered on the server), plain CSS and a little JavaScript
- **Database:** SQLite through Node's built-in `node:sqlite` module, so there is nothing extra to install
- **Payments:** Kora (Korapay) Checkout Redirect, in test mode
- **Security:** helmet, express-session, bcryptjs and express-rate-limit
- **Uploads:** multer (product photos)
- **Tests:** Node's built-in test runner and Supertest

## How to run

**Requirements:** Node.js **22.13 or newer** (`node -v` to check). Download it from https://nodejs.org if needed.

```bash
npm install
npm start
```

Then open **http://localhost:3000**.

On the first run the app creates the database at `data/papernest.db` and fills it with 8 categories, 23 products and two demo accounts.

### Demo accounts (for the supervisor)

The **login page has one-click buttons**, **Log in as admin** and **Log in as customer**, so no typing is needed. The details are also shown there:

| Role | Email | Password | What to try |
|---|---|---|---|
| Admin | `admin@papernest.test` | `Admin@12345` | Dashboard, transactions, add/edit products, upload photos, receive goods, update orders |
| Customer | `customer@papernest.test` | `Customer@123` | Shop, cart, checkout (Kora test payment or pay on delivery), My orders, My profile |

Payments run in **test mode**: choosing "Pay now with Kora" opens a test payment page where you can approve or cancel the payment. No real money is involved.

For a real shop, set `DEMO_LOGIN=0` in `.env` to remove the demo buttons.

You can also create your own customer account with **Sign up**.

### Other commands

| Command | What it does |
|---|---|
| `npm start` | Start the website |
| `npm run dev` | Start and restart automatically when files change |
| `npm test` | Run the automated tests |
| `npm run seed` | Wipe the database and reload the demo data |

### Settings (optional)

Copy `.env.example` to `.env` to change the port, database location, admin login and so on. The app runs without a `.env` file during development.

## Payments with Kora

PaperNest uses [Kora's Checkout Redirect](https://developers.korapay.com/docs/checkout-redirect):

1. At checkout the server creates the order, then calls Kora's *initialize charge* API with the **secret key**. Kora returns a checkout link.
2. The customer pays on Kora's hosted page, so card details never touch PaperNest.
3. Kora sends the customer back to `/payments/kora/callback?reference=...`. The server then **asks Kora for the charge status** and checks the amount and currency before marking the order paid.
4. Kora also calls the webhook `/payments/kora/webhook`. The `x-korapay-signature` header (HMAC-SHA256 of the payload's `data`, keyed with the secret key) is verified, and the charge is re-checked with Kora. Repeated webhooks are harmless: a payment can only be marked paid once.

**Turning on the Kora test checkout**

1. Create a free account at https://merchant.korapay.com and stay in **Test mode**.
2. Copy the **test secret key** (`sk_test_...`) from Settings → API Configuration.
3. Copy `.env.example` to `.env` and set `KORA_SECRET_KEY=sk_test_...` and `APP_URL` (for example `http://localhost:3000`).
4. Restart the app and pay with one of Kora's test cards from their documentation. No real money moves in test mode.
5. Optional: set the webhook URL in the Kora dashboard to `APP_URL/payments/kora/webhook`. This needs a public address, for example after deploying.

**Without a Kora key**, the app uses a clearly labelled **payment simulator** in development, so the whole flow (success, failure, retry) can still be demonstrated. The simulator is switched off in production.

## Security measures

| Threat | Protection |
|---|---|
| SQL injection | Every query uses bound parameters. Sort options are chosen from a fixed list. Search text is escaped inside `LIKE` patterns. |
| Cross-site scripting (XSS) | EJS escapes all output. A strict Content Security Policy allows scripts and styles from this site only, and the pages contain no inline scripts. |
| Cross-site request forgery (CSRF) | Every form carries a secret per-session token, checked on every POST. Cookies are also `SameSite=Lax`. |
| Stolen or weak passwords | Passwords are hashed with bcrypt (cost 12) and must be at least 8 characters with a letter and a number. |
| Password guessing | Login is rate limited to 10 attempts per IP every 15 minutes. The same error is shown for a wrong email and a wrong password, and both take the same time. |
| Session hijacking or fixation | The session cookie is `HttpOnly`, `SameSite`, `Secure` in production and expires after 2 hours idle. A new session ID is issued at login. |
| Broken access control | Admin pages are checked on the server for every request. Customers can only open their own orders, and anyone else's order returns 404. |
| Price tampering | The cart stores only product IDs and quantities. Prices and totals are always worked out on the server from the database. |
| Payment tampering | An order is only marked paid after the server verifies the charge with Kora (amount and currency included). Webhooks must carry a valid HMAC signature. The secret key never reaches the browser. |
| Malicious uploads | Product photos are limited to 3 MB, the real file type is checked from its first bytes (JPG, PNG or WebP only) and files get random names. Only admins can upload, and uploads still need the CSRF token. |
| Overselling | Checkout reduces stock and saves the order in one database transaction, and fails safely if an item sells out first. |
| Open redirect | The `?next=` redirect after login only accepts paths on this site. |
| Information leaks | Error pages never show stack traces, and the `X-Powered-By` header is removed. |

## Testing

```bash
npm test
```

There are 60 automated tests. Each one runs against a fresh in-memory database. They cover:

- the homepage, catalogue, search, filters and product pages
- adding, updating and removing cart items, and the stock limits
- registration, login, password hashing, rate limiting and session ID renewal
- checkout, server-side totals, validation, sold-out handling and order privacy
- admin access control, product add/edit/delete, form validation and order cancellation (which puts stock back)
- online payments: Kora redirect, callback verification, underpayment rejection, retry, signed and forged webhooks, and the simulator (Kora is replaced by a fake, so no network is used)
- the admin dashboard: revenue chart, transactions, receiving goods, cash on delivery recorded, photo upload and rejection of non-images
- the account menu, the profile page (edit name, change password) and the one-click demo logins
- the security checks: CSRF rejection, security headers, cookie flags, XSS escaping and no leaked stack traces

## Deployment

The app is a standard Node.js web service and can be deployed to Render, Railway or a VPS:

1. Build command: `npm install`. Start command: `npm start`.
2. Set these environment variables:
   - `NODE_ENV=production`
   - a long random `SESSION_SECRET`
   - `TRUST_PROXY=1`
   - your own `ADMIN_EMAIL` and `ADMIN_PASSWORD`
3. Point `DATABASE_FILE` at a **persistent disk** (for example `/var/data/papernest.db` on Render). Otherwise the data is lost every time the server restarts.
4. The `/healthz` endpoint returns `ok` for uptime checks.

## Project structure

```text
src/
  server.js            starts the web server
  app.js               Express setup: security headers, sessions, routes, error pages
  config.js            reads environment variables
  db.js                database tables and transactions
  seed.js              demo categories, products and accounts
  session-store.js     keeps login sessions in SQLite
  helpers.js           money formatting, validation, cart calculations
  middleware/
    auth.js            login and admin checks
    csrf.js            CSRF token protection
  routes/
    shop.js            homepage, catalogue, search/filter, product page
    cart.js            cart and checkout
    auth.js            register, login, logout, order history
    admin.js           admin dashboard, products and orders
views/                 EJS page templates (admin/ holds the admin pages)
public/                CSS, JavaScript and product images
tests/app.test.js      automated tests
```

## Known limitations

- Kora runs in **test mode** until live keys are added, and refunds are done in the Kora dashboard rather than in PaperNest.
- Uploaded photos are stored on the server's disk. On hosts with temporary disks (such as Render's free tier), use a persistent disk or move uploads to cloud storage.
- There is no password-reset email or email verification.
- SQLite suits a single server. A larger shop would move to PostgreSQL.
