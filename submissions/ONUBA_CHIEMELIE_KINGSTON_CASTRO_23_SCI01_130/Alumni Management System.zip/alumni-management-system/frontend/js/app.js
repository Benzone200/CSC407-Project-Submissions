

document.addEventListener("DOMContentLoaded", () => {
    const VIEW_METADATA = {
        dashboard: {
            title: "Dashboard Overview",
            subtitle: "Welcome back to your university alumni network"
        },
        directory: {
            title: "Alumni Directory",
            subtitle: "Search and connect with graduates across industries"
        },
        jobs: {
            title: "Career & Job Board",
            subtitle: "Explore roles posted by fellow alumni and hiring partners"
        },
        events: {
            title: "Events & Reunions",
            subtitle: "RSVP for upcoming campus reunions and networking mixers"
        },
        profile: {
            title: "My Alumni Profile",
            subtitle: "Manage your contact details and directory visibility"
        },
        admin: {
            title: "Admin Management Center",
            subtitle: "Platform administration and user database overview"
        }
    };

    // Mobile Collapsible Navigation Menu Helpers
    const mobileMenuToggle = document.getElementById("mobile-menu-toggle");
    const collapsibleMenu = document.getElementById("collapsible-sidebar-menu");
    const mobileMenuIcon = document.getElementById("mobile-menu-icon");
    const mobileMenuLabel = document.getElementById("mobile-menu-label");

    function setMobileMenuOpen(isOpen) {
        if (!collapsibleMenu || !mobileMenuToggle) return;
        if (isOpen) {
            collapsibleMenu.classList.remove("hidden");
            collapsibleMenu.classList.add("flex");
            mobileMenuToggle.setAttribute("aria-expanded", "true");
            if (mobileMenuIcon) {
                mobileMenuIcon.classList.remove("fa-bars");
                mobileMenuIcon.classList.add("fa-xmark");
            }
            if (mobileMenuLabel) mobileMenuLabel.textContent = "Close";
        } else {
            collapsibleMenu.classList.add("hidden");
            collapsibleMenu.classList.remove("flex");
            mobileMenuToggle.setAttribute("aria-expanded", "false");
            if (mobileMenuIcon) {
                mobileMenuIcon.classList.remove("fa-xmark");
                mobileMenuIcon.classList.add("fa-bars");
            }
            if (mobileMenuLabel) mobileMenuLabel.textContent = "Menu";
        }
    }

    if (mobileMenuToggle && collapsibleMenu) {
        mobileMenuToggle.addEventListener("click", () => {
            const currentlyClosed = collapsibleMenu.classList.contains("hidden");
            setMobileMenuOpen(currentlyClosed);
        });
    }

    function switchView(target, pushHistory = true) {
        document.querySelectorAll(".nav-btn").forEach(b => {
            b.classList.remove("bg-emerald-800", "text-white", "active");
            b.classList.add("text-emerald-200");
        });
        const activeBtn = document.querySelector(`.nav-btn[data-target="${target}"]`);
        if (activeBtn) {
            activeBtn.classList.add("bg-emerald-800", "text-white", "active");
            activeBtn.classList.remove("text-emerald-200");
        }

        document.querySelectorAll(".view-section").forEach(sec => sec.classList.add("hidden"));
        const targetView = document.getElementById(`view-${target}`);
        if (targetView) targetView.classList.remove("hidden");

        if (VIEW_METADATA[target]) {
            document.getElementById("page-title").textContent = VIEW_METADATA[target].title;
            document.getElementById("page-subtitle").textContent = VIEW_METADATA[target].subtitle;
        }

        // Automatically collapse mobile menu after selecting a destination
        setMobileMenuOpen(false);

        if (pushHistory) {
            const stateObj = { view: target };
            const newUrl = `#${target}`;
            history.pushState(stateObj, "", newUrl);
        }
    }

    window.addEventListener("popstate", event => {
        const state = window.store.getState();
        if (!state.currentUser) return;

        let target = "dashboard";
        if (event.state && event.state.view) {
            target = event.state.view;
        } else {
            const hash = window.location.hash.replace("#", "");
            if (VIEW_METADATA[hash]) {
                target = hash;
            }
        }
        switchView(target, false);
    });

    let renderCycle = 0;
    const refreshTableScrollProxies = [];
    const tableScrollObservers = [];

    function initializeTableScrollProxies() {
        document.querySelectorAll("[data-scroll-proxy-for]").forEach(proxy => {
            const target = document.getElementById(proxy.getAttribute("data-scroll-proxy-for"));
            const spacer = proxy.firstElementChild;
            if (!target || !spacer) return;

            let isSyncing = false;
            const refresh = () => {
                const table = target.querySelector("table");
                if (!table) return;
                const contentWidth = Math.max(table.scrollWidth, target.clientWidth);
                spacer.style.width = `${contentWidth}px`;
                proxy.classList.toggle("hidden", table.scrollWidth <= target.clientWidth + 1);
                if (Math.abs(proxy.scrollLeft - target.scrollLeft) > 1) {
                    proxy.scrollLeft = target.scrollLeft;
                }
            };

            proxy.addEventListener("scroll", () => {
                if (isSyncing) return;
                isSyncing = true;
                target.scrollLeft = proxy.scrollLeft;
                isSyncing = false;
            });
            target.addEventListener("scroll", () => {
                if (isSyncing) return;
                isSyncing = true;
                proxy.scrollLeft = target.scrollLeft;
                isSyncing = false;
            });
            target.addEventListener("wheel", event => {
                if (event.shiftKey && Math.abs(event.deltaY) > 0) {
                    target.scrollLeft += event.deltaY;
                    event.preventDefault();
                }
            }, { passive: false });

            if (typeof ResizeObserver !== "undefined") {
                const observer = new ResizeObserver(refresh);
                observer.observe(target);
                const table = target.querySelector("table");
                if (table) observer.observe(table);
                tableScrollObservers.push(observer);
            }
            refreshTableScrollProxies.push(refresh);
            refresh();
        });
    }

    function refreshAllTableScrollProxies() {
        refreshTableScrollProxies.forEach(refresh => refresh());
    }

    initializeTableScrollProxies();
    window.addEventListener("resize", refreshAllTableScrollProxies);

    async function renderAllViews() {
        const thisCycle = ++renderCycle;
        const state = window.store.getState();
        const authScreen = document.getElementById("auth-screen");

        if (!state.currentUser) {
            authScreen.classList.remove("hidden");
            return;
        }
        authScreen.classList.add("hidden");

        // Always render from the canonical alumni record so the profile, directory,
        // event registrations and admin controls show the same member values.
        const canonicalUser = state.alumni.find(alum => alum.id === state.currentUser.id) || state.currentUser;
        state.currentUser = canonicalUser;

        UI.renderUserChrome(canonicalUser);
        UI.populateProfileForm(canonicalUser);
        UI.renderDashboard(state);

        const filteredAlumni = await AlumniAPI.getAlumniDirectory({
            query: document.getElementById("directory-search").value,
            year: document.getElementById("directory-year-filter").value,
            department: document.getElementById("directory-dept-filter").value
        });
        if (thisCycle !== renderCycle) return;
        UI.renderDirectory(filteredAlumni, canonicalUser.id);

        const filteredJobs = await AlumniAPI.getJobs(document.getElementById("job-search").value);
        if (thisCycle !== renderCycle) return;
        UI.renderJobs(filteredJobs, state.applications, canonicalUser);

        UI.renderEvents(state.events, canonicalUser);
        UI.renderAdminPendingTable(state.pendingAlumni);
        UI.renderAdminTable(state.alumni, canonicalUser, document.getElementById("admin-users-search")?.value || "");
        refreshAllTableScrollProxies();
    }

    window.store.subscribe(() => {
        renderAllViews();
    });

    document.querySelectorAll(".nav-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            const target = btn.getAttribute("data-target");
            switchView(target, true);
        });
    });

    document.addEventListener("click", e => {
        const shortcut = e.target.closest(".nav-link-shortcut");
        if (shortcut) {
            const target = shortcut.getAttribute("data-target");
            if (target) {
                switchView(target, true);
            }
        }
    });

    document.querySelectorAll(".kpi-card").forEach(card => {
        card.addEventListener("click", () => {
            const target = card.getAttribute("data-kpi-target");
            if (target === "jobs") {
                const statText = card.querySelector("#stat-my-applications");
                if (statText) {
                    const state = window.store.getState();
                    UI.renderMyApplicationsModal(state.applications, state.jobs);
                    return;
                }
            }
            if (target) {
                switchView(target, true);
            }
        });
    });

    function handleLogout() {
        setMobileMenuOpen(false);
        window.store.logoutUser();
        document.getElementById("login-form").reset();
        document.getElementById("signup-form").reset();
        document.getElementById("login-error-box").classList.add("hidden");
        document.getElementById("signup-error-box").classList.add("hidden");
        document.getElementById("auth-screen").classList.remove("hidden");
    }

    document.getElementById("logout-btn").addEventListener("click", handleLogout);
    const mobileLogoutBtn = document.getElementById("mobile-logout-btn");
    if (mobileLogoutBtn) {
        mobileLogoutBtn.addEventListener("click", handleLogout);
    }

    document.getElementById("tab-login-btn").addEventListener("click", () => {
        document.getElementById("tab-login-btn").className = "flex-1 py-2 text-xs font-semibold rounded-md bg-white text-emerald-600 shadow-sm transition-all";
        document.getElementById("tab-signup-btn").className = "flex-1 py-2 text-xs font-semibold rounded-md text-slate-600 transition-all";
        document.getElementById("login-form").classList.remove("hidden");
        document.getElementById("signup-form").classList.add("hidden");
        document.getElementById("signup-error-box").classList.add("hidden");
    });

    document.getElementById("tab-signup-btn").addEventListener("click", () => {
        document.getElementById("tab-signup-btn").className = "flex-1 py-2 text-xs font-semibold rounded-md bg-white text-emerald-600 shadow-sm transition-all";
        document.getElementById("tab-login-btn").className = "flex-1 py-2 text-xs font-semibold rounded-md text-slate-600 transition-all";
        document.getElementById("signup-form").classList.remove("hidden");
        document.getElementById("login-form").classList.add("hidden");
        document.getElementById("login-error-box").classList.add("hidden");
    });

    document.getElementById("login-form").addEventListener("submit", e => {
        e.preventDefault();
        const email = document.getElementById("login-email").value.trim();
        const password = document.getElementById("login-password").value.trim();
        const errorBox = document.getElementById("login-error-box");
        errorBox.classList.add("hidden");

        try {
            window.store.loginUser(email, password);
            document.getElementById("auth-screen").classList.add("hidden");
            UI.showToast(`Welcome back, ${window.store.getState().currentUser.name}!`);
            switchView("dashboard", true);
        } catch (err) {
            errorBox.textContent = err.message;
            errorBox.classList.remove("hidden");
        }
    });

    document.getElementById("signup-form").addEventListener("submit", e => {
        e.preventDefault();
        const firstName = document.getElementById("signup-firstname").value.trim();
        const lastName = document.getElementById("signup-lastname").value.trim();
        const email = document.getElementById("signup-email").value.trim();
        const matricNumber = document.getElementById("signup-matric").value.trim();
        const password = document.getElementById("signup-password").value.trim();
        const confirmPassword = document.getElementById("signup-confirm-password").value.trim();
        const gradYear = document.getElementById("signup-year").value;
        const department = document.getElementById("signup-dept").value;
        const errorBox = document.getElementById("signup-error-box");
        errorBox.classList.add("hidden");

        if (password !== confirmPassword) {
            errorBox.textContent = "Passwords do not match. Please verify.";
            errorBox.classList.remove("hidden");
            return;
        }

        try {
            const newUser = window.store.registerUser({ 
                firstName, 
                lastName, 
                name: `${firstName} ${lastName}`, 
                email, 
                password, 
                confirmPassword, 
                matricNumber, 
                gradYear, 
                department 
            });
            document.getElementById("signup-form").reset();
            document.getElementById("auth-screen").classList.add("hidden");
            
            if (newUser.isAdmin) {
                UI.showToast(`Admin account created & signed in successfully as ${newUser.name}!`);
                switchView("dashboard", true);
            } else {
                document.getElementById("auth-screen").classList.remove("hidden");
                document.getElementById("tab-login-btn").click();
                const infoBox = document.getElementById("login-info-box");
                const infoText = document.getElementById("login-info-text");
                if (infoBox && infoText) {
                    infoText.textContent = `Please wait — your registration (${newUser.email}, Matric: ${newUser.matricNumber}) has been submitted and is pending administrator approval.`;
                    infoBox.classList.remove("hidden");
                }
                UI.showToast("Registration submitted! Please wait for admin approval.");
            }
        } catch (err) {
            errorBox.textContent = err.message;
            errorBox.classList.remove("hidden");
        }
    });

    const deleteOwnAccountBtn = document.getElementById("delete-own-account-btn");
    if (deleteOwnAccountBtn) {
        deleteOwnAccountBtn.addEventListener("click", () => {
            const currentUser = window.store.getState().currentUser;
            if (!currentUser) return;
            const confirmed = confirm("Permanently delete your AlmaConnect account and all your associated data? Your posted jobs and events, job applications, event registrations and announcements will also be removed. This cannot be undone.");
            if (!confirmed) return;
            try {
                const result = window.store.deleteAccount(currentUser.id);
                UI.closeAllModals();
                document.getElementById("auth-screen").classList.remove("hidden");
                document.getElementById("login-form").reset();
                document.getElementById("signup-form").reset();
                UI.showToast(`Your account has been deleted.`);
            } catch (err) {
                UI.showToast(err.message, "error");
            }
        });
    }

    document.getElementById("edit-alumni-form").addEventListener("submit", e => {
        e.preventDefault();
        const userId = document.getElementById("edit-alumni-id").value;
        try {
            window.store.updateAlumniUser(userId, {
                name: document.getElementById("edit-alumni-name").value.trim(),
                email: document.getElementById("edit-alumni-email").value.trim(),
                matricNumber: document.getElementById("edit-alumni-matric").value.trim(),
                gradYear: document.getElementById("edit-alumni-year").value,
                department: document.getElementById("edit-alumni-dept").value,
                location: document.getElementById("edit-alumni-location").value.trim(),
                role: document.getElementById("edit-alumni-role").value.trim(),
                company: document.getElementById("edit-alumni-company").value.trim(),
                bio: document.getElementById("edit-alumni-bio").value.trim()
            });
            UI.closeAllModals();
            UI.showToast("Alumni account updated successfully.");
        } catch (err) {
            UI.showToast(err.message, "error");
        }
    });

    document.getElementById("profile-form").addEventListener("submit", async e => {
        e.preventDefault();
        const updatedProfile = {
            name: document.getElementById("prof-name").value.trim(),
            email: document.getElementById("prof-email").value.trim(),
            gradYear: document.getElementById("prof-year").value,
            department: document.getElementById("prof-dept").value,
            location: document.getElementById("prof-location").value.trim(),
            role: document.getElementById("prof-role").value.trim(),
            company: document.getElementById("prof-company").value.trim(),
            bio: document.getElementById("prof-bio").value.trim()
        };

        await AlumniAPI.updateUserProfile(updatedProfile);
        UI.showToast("Profile updated successfully!");
    });

    ["directory-search", "directory-year-filter", "directory-dept-filter", "job-search", "admin-users-search"].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener("input", renderAllViews);
    });

    // Open Post Information Modal (from Dashboard or Admin view)
    ["dashboard-post-info-btn", "admin-post-info-btn"].forEach(btnId => {
        const btn = document.getElementById(btnId);
        if (btn) {
            btn.addEventListener("click", () => {
                document.getElementById("post-info-form").reset();
                document.getElementById("post-info-modal").classList.remove("hidden");
            });
        }
    });

    // Submit New Information / Announcement
    document.getElementById("post-info-form").addEventListener("submit", e => {
        e.preventDefault();
        try {
            window.store.addAnnouncement({
                title: document.getElementById("new-info-title").value.trim(),
                category: document.getElementById("new-info-category").value,
                content: document.getElementById("new-info-content").value.trim()
            });
            UI.closeAllModals();
            UI.showToast("Information published to the alumni notice board!");
        } catch (err) {
            UI.showToast(err.message, "error");
        }
    });

    // Submit Edited Information / Announcement
    document.getElementById("edit-info-form").addEventListener("submit", e => {
        e.preventDefault();
        const infoId = document.getElementById("edit-info-id").value;
        try {
            window.store.updateAnnouncement(infoId, {
                title: document.getElementById("edit-info-title").value.trim(),
                category: document.getElementById("edit-info-category").value,
                content: document.getElementById("edit-info-content").value.trim()
            });
            UI.closeAllModals();
            UI.showToast("Information updated successfully!");
        } catch (err) {
            UI.showToast(err.message, "error");
        }
    });

    document.addEventListener("click", async e => {
        const mailtoLink = e.target.closest('a[href^="mailto:"]');
        if (mailtoLink) {
            e.preventDefault();
            const href = mailtoLink.getAttribute("href");
            const email = href.replace("mailto:", "").trim();
            if (email) {
                try {
                    await navigator.clipboard.writeText(email);
                    UI.showToast(`Email copied to clipboard: ${email}`);
                } catch (err) {
                    UI.showToast(`Email: ${email}`);
                }
            }
            return;
        }

        // Admin Edit / Delete Information buttons
        const editInfoBtn = e.target.closest(".edit-info-btn");
        if (editInfoBtn) {
            const infoId = editInfoBtn.getAttribute("data-info-id");
            const state = window.store.getState();
            const ann = (state.announcements || []).find(a => a.id === infoId);
            if (ann) UI.openEditInfoModal(ann);
            return;
        }

        const deleteInfoBtn = e.target.closest(".delete-info-btn");
        if (deleteInfoBtn) {
            const infoId = deleteInfoBtn.getAttribute("data-info-id");
            if (confirm("Are you sure you want to delete this information post?")) {
                try {
                    window.store.deleteAnnouncement(infoId);
                    UI.showToast("Information post deleted successfully.");
                } catch (err) {
                    UI.showToast(err.message, "error");
                }
            }
            return;
        }

        const applyBtn = e.target.closest(".open-apply-btn");
        if (applyBtn) {
            UI.openApplyModal(applyBtn.getAttribute("data-job-id"), applyBtn.getAttribute("data-job-title"));
        }

        const viewApplicantsBtn = e.target.closest(".view-applicants-btn");
        if (viewApplicantsBtn) {
            const jobId = viewApplicantsBtn.getAttribute("data-job-id");
            const jobTitle = viewApplicantsBtn.getAttribute("data-job-title");
            const state = window.store.getState();
            const jobApps = state.applications.filter(a => a.jobId === jobId);
            UI.renderApplicantsModal(jobTitle, jobApps);
        }

        const editJobBtn = e.target.closest(".edit-job-btn");
        if (editJobBtn) {
            const jobId = editJobBtn.getAttribute("data-job-id");
            const state = window.store.getState();
            const job = state.jobs.find(j => j.id === jobId);
            if (job) UI.openEditJobModal(job);
        }

        const deleteJobBtn = e.target.closest(".delete-job-btn");
        if (deleteJobBtn) {
            const jobId = deleteJobBtn.getAttribute("data-job-id");
            if (confirm("Are you sure you want to delete this job posting?")) {
                try {
                    window.store.deleteJob(jobId);
                    UI.showToast("Job posting deleted successfully.");
                } catch (err) {
                    UI.showToast(err.message, "error");
                }
            }
        }

        const editEventBtn = e.target.closest(".edit-event-btn");
        if (editEventBtn) {
            const eventId = editEventBtn.getAttribute("data-event-id");
            const state = window.store.getState();
            const evt = state.events.find(ev => ev.id === eventId);
            if (evt) UI.openEditEventModal(evt);
        }

        const approveBtn = e.target.closest(".approve-user-btn");
        if (approveBtn) {
            const pendingId = approveBtn.getAttribute("data-pending-id");
            UI.closeAllModals();
            window.store.approveUserRequest(pendingId);
            UI.showToast("Alumni account approved and added to directory!");
            return;
        }

        const rejectBtn = e.target.closest(".reject-user-btn");
        if (rejectBtn) {
            const pendingId = rejectBtn.getAttribute("data-pending-id");
            UI.closeAllModals();
            window.store.rejectUserRequest(pendingId);
            UI.showToast("Registration request declined.", "error");
            return;
        }

        const viewPendingBtn = e.target.closest(".view-pending-btn");
        if (viewPendingBtn) {
            const pendingId = viewPendingBtn.getAttribute("data-pending-id");
            const state = window.store.getState();
            const pendingUser = state.pendingAlumni.find(p => p.id === pendingId);
            if (pendingUser) UI.openPendingDetailsModal(pendingUser);
            return;
        }

        const deleteEventBtn = e.target.closest(".delete-event-btn");
        if (deleteEventBtn) {
            const eventId = deleteEventBtn.getAttribute("data-event-id");
            if (confirm("Are you sure you want to delete this event?")) {
                try {
                    window.store.deleteEvent(eventId);
                    UI.showToast("Event deleted successfully.");
                } catch (err) {
                    UI.showToast(err.message, "error");
                }
            }
        }

        const removeApplicationBtn = e.target.closest(".remove-application-btn");
        if (removeApplicationBtn) {
            const applicationId = removeApplicationBtn.getAttribute("data-application-id");
            if (confirm("Withdraw this job application? The employer will no longer see it in the applicant list.")) {
                try {
                    await AlumniAPI.removeApplication(applicationId);
                    UI.showToast("Your job application has been withdrawn.");
                    if (!document.getElementById("my-applications-modal").classList.contains("hidden")) {
                        const state = window.store.getState();
                        UI.renderMyApplicationsModal(state.applications, state.jobs);
                    }
                } catch (err) {
                    UI.showToast(err.message, "error");
                }
            }
            return;
        }

        const editAlumniBtn = e.target.closest(".edit-alumni-btn");
        if (editAlumniBtn) {
            const userId = editAlumniBtn.getAttribute("data-user-id");
            const member = window.store.getState().alumni.find(alum => alum.id === userId);
            if (member) UI.openEditAlumniModal(member);
            return;
        }

        const deleteAlumniBtn = e.target.closest(".delete-alumni-btn");
        if (deleteAlumniBtn) {
            const userId = deleteAlumniBtn.getAttribute("data-user-id");
            const member = window.store.getState().alumni.find(alum => alum.id === userId);
            if (member && confirm(`Permanently delete ${member.name}'s account and all associated data? This removes their jobs, applications, events, RSVPs and announcements. This cannot be undone.`)) {
                try {
                    const result = window.store.deleteAccount(userId);
                    UI.closeAllModals();
                    if (result.deletedCurrentUser) document.getElementById("auth-screen").classList.remove("hidden");
                    else UI.showToast(`${result.deletedUserName}'s account and associated data were deleted.`);
                } catch (err) {
                    UI.showToast(err.message, "error");
                }
            }
            return;
        }

        const directoryProfileLink = e.target.closest(".directory-user-link, .attendee-directory-link");
        if (directoryProfileLink) {
            const memberId = directoryProfileLink.getAttribute("data-directory-user-id") || directoryProfileLink.getAttribute("data-attendee-id") || "";
            const memberEmail = (directoryProfileLink.getAttribute("data-directory-user-email") || directoryProfileLink.getAttribute("data-attendee-email") || "").toLowerCase();
            const memberName = directoryProfileLink.getAttribute("data-directory-user-name") || directoryProfileLink.getAttribute("data-attendee-name") || "this alumnus";

            UI.closeAllModals();
            const searchInput = document.getElementById("directory-search");
            const yearFilter = document.getElementById("directory-year-filter");
            const deptFilter = document.getElementById("directory-dept-filter");
            if (searchInput) searchInput.value = "";
            if (yearFilter) yearFilter.value = "all";
            if (deptFilter) deptFilter.value = "all";

            switchView("directory", true);
            await renderAllViews();

            const cards = Array.from(document.querySelectorAll(".alumni-directory-card"));
            const targetCard = cards.find(card =>
                (memberId && card.getAttribute("data-alumni-id") === memberId) ||
                (memberEmail && card.getAttribute("data-alumni-email") === memberEmail)
            );
            if (targetCard) {
                targetCard.scrollIntoView({ behavior: "smooth", block: "center" });
                targetCard.classList.add("ring-4", "ring-emerald-400", "bg-emerald-50/40");
                window.setTimeout(() => targetCard.classList.remove("ring-4", "ring-emerald-400", "bg-emerald-50/40"), 2600);
            } else {
                UI.showToast(`Could not find ${memberName} in the alumni directory.`, "error");
            }
            return;
        }

        const viewAttendeesBtn = e.target.closest(".view-attendees-btn");
        if (viewAttendeesBtn) {
            const eventId = viewAttendeesBtn.getAttribute("data-event-id");
            const eventTitle = viewAttendeesBtn.getAttribute("data-event-title");
            const state = window.store.getState();
            const evt = state.events.find(ev => ev.id === eventId);
            UI.renderAttendeesModal(eventTitle, evt ? (evt.attendees || []) : []);
        }

        const rsvpBtn = e.target.closest(".toggle-rsvp-btn");
        if (rsvpBtn) {
            await AlumniAPI.toggleRsvp(rsvpBtn.getAttribute("data-event-id"));
            UI.showToast("Event registration updated.");
        }

        if (e.target.closest(".close-modal")) {
            UI.closeAllModals();
        }
    });

    document.getElementById("apply-job-form").addEventListener("submit", async e => {
        e.preventDefault();
        const jobId = document.getElementById("apply-job-id").value;
        const applicantEmail = document.getElementById("apply-applicant-email").value.trim();
        const note = document.getElementById("apply-applicant-note").value.trim();

        try {
            await AlumniAPI.applyForJob(jobId, applicantEmail, note);
            UI.closeAllModals();
            UI.showToast("Job application submitted successfully!");
        } catch (err) {
            UI.showToast(err.message, "error");
        }
    });

    document.getElementById("open-post-job-modal").addEventListener("click", () => {
        document.getElementById("post-job-form").reset();
        document.getElementById("post-job-modal").classList.remove("hidden");
    });

    document.getElementById("post-job-form").addEventListener("submit", async e => {
        e.preventDefault();
        window.store.addJob({
            title: document.getElementById("new-job-title").value.trim(),
            company: document.getElementById("new-job-company").value.trim(),
            type: document.getElementById("new-job-type").value,
            location: document.getElementById("new-job-location").value.trim(),
            description: document.getElementById("new-job-desc").value.trim()
        });
        UI.closeAllModals();
        UI.showToast("Job opportunity posted successfully!");
    });

    document.getElementById("edit-job-form").addEventListener("submit", e => {
        e.preventDefault();
        const jobId = document.getElementById("edit-job-id").value;
        try {
            window.store.updateJob(jobId, {
                title: document.getElementById("edit-job-title").value.trim(),
                company: document.getElementById("edit-job-company").value.trim(),
                type: document.getElementById("edit-job-type").value,
                location: document.getElementById("edit-job-location").value.trim(),
                description: document.getElementById("edit-job-desc").value.trim()
            });
            UI.closeAllModals();
            UI.showToast("Job posting updated successfully!");
        } catch (err) {
            UI.showToast(err.message, "error");
        }
    });

    document.getElementById("open-create-event-modal").addEventListener("click", () => {
        document.getElementById("create-event-form").reset();
        document.getElementById("create-event-modal").classList.remove("hidden");
    });

    document.getElementById("create-event-form").addEventListener("submit", e => {
        e.preventDefault();
        window.store.addEvent({
            title: document.getElementById("new-evt-title").value.trim(),
            date: document.getElementById("new-evt-date").value,
            time: document.getElementById("new-evt-time").value,
            category: document.getElementById("new-evt-category").value,
            location: document.getElementById("new-evt-location").value.trim()
        });
        UI.closeAllModals();
        UI.showToast("Alumni event created successfully!");
    });

    document.getElementById("edit-event-form").addEventListener("submit", e => {
        e.preventDefault();
        const eventId = document.getElementById("edit-evt-id").value;
        try {
            window.store.updateEvent(eventId, {
                title: document.getElementById("edit-evt-title").value.trim(),
                date: document.getElementById("edit-evt-date").value,
                time: document.getElementById("edit-evt-time").value,
                category: document.getElementById("edit-evt-category").value,
                location: document.getElementById("edit-evt-location").value.trim()
            });
            UI.closeAllModals();
            UI.showToast("Alumni event updated successfully!");
        } catch (err) {
            UI.showToast(err.message, "error");
        }
    });

    document.getElementById("reset-demo-btn").addEventListener("click", () => {
        window.store.resetAll();
        UI.showToast("Demo data reset to factory defaults. Please log in again.");
    });

    const initialHash = window.location.hash.replace("#", "");
    if (VIEW_METADATA[initialHash]) {
        switchView(initialHash, false);
    }

    renderAllViews();

    // Keep event status badges and dashboard counts in sync as event times pass.
    window.setInterval(() => {
        const state = window.store.getState();
        if (!state.currentUser) return;
        UI.renderDashboard(state);
        UI.renderEvents(state.events || [], state.currentUser);
    }, 15000);
});
