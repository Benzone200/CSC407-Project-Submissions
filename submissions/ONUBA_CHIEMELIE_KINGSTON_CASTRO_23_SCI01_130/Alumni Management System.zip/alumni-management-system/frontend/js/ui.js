

const UI = {
    getInitials(name) {
        if (!name) return "AL";
        return name
            .split(" ")
            .map(part => part[0])
            .join("")
            .toUpperCase()
            .slice(0, 2);
    },

    escapeHTML(str) {
        if (str === null || str === undefined) return "";
        return String(str)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    },

    findLiveAlumniMember(userId, email) {
        const alumni = window.store.getState().alumni || [];
        const normalizedEmail = String(email || "").trim().toLowerCase();
        return (userId ? alumni.find(member => member.id === userId) : null) ||
            (normalizedEmail ? alumni.find(member => (member.email || "").trim().toLowerCase() === normalizedEmail) : null) ||
            null;
    },

    showToast(message, type = "success") {
        const container = document.getElementById("toast-container");
        const toast = document.createElement("div");
        const bgClass = type === "error" ? "bg-rose-600" : "bg-slate-900";
        const icon = type === "error" ? "fa-circle-exclamation" : "fa-circle-check text-emerald-400";

        toast.className = `toast-item ${bgClass} text-white px-4 py-3 rounded-lg shadow-lg text-sm flex items-center gap-2.5`;
        toast.innerHTML = `<i class="fa-solid ${icon}"></i><span>${this.escapeHTML(message)}</span>`;

        container.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = "0";
            toast.style.transition = "opacity 0.2s";
            setTimeout(() => toast.remove(), 200);
        }, 3000);
    },

    renderUserChrome(user) {
        const initials = this.getInitials(user.name);
        document.getElementById("sidebar-avatar").textContent = initials;
        document.getElementById("sidebar-user-name").textContent = user.name;
        document.getElementById("sidebar-user-email").textContent = user.email;

        const mobAvatar = document.getElementById("mobile-sidebar-avatar");
        const mobName = document.getElementById("mobile-sidebar-user-name");
        const mobEmail = document.getElementById("mobile-sidebar-user-email");
        if (mobAvatar) mobAvatar.textContent = initials;
        if (mobName) mobName.textContent = user.name;
        if (mobEmail) mobEmail.textContent = user.email;

        document.getElementById("profile-large-avatar").textContent = initials;

        const adminBadge = document.getElementById("admin-badge");
        const adminNavBtn = document.getElementById("admin-nav-btn");
        const dashPostInfoBtn = document.getElementById("dashboard-post-info-btn");

        if (user.isAdmin) {
            adminBadge.classList.remove("hidden");
            adminBadge.classList.add("inline-flex");
            adminNavBtn.classList.remove("hidden");
            if (dashPostInfoBtn) {
                dashPostInfoBtn.classList.remove("hidden");
                dashPostInfoBtn.classList.add("inline-flex");
            }
        } else {
            adminBadge.classList.add("hidden");
            adminBadge.classList.remove("inline-flex");
            adminNavBtn.classList.add("hidden");
            if (dashPostInfoBtn) {
                dashPostInfoBtn.classList.add("hidden");
                dashPostInfoBtn.classList.remove("inline-flex");
            }
        }
    },

    populateProfileForm(user) {
        document.getElementById("prof-name").value = user.name;
        document.getElementById("prof-email").value = user.email;
        document.getElementById("prof-year").value = user.gradYear;
        document.getElementById("prof-dept").value = user.department;
        document.getElementById("prof-location").value = user.location;
        document.getElementById("prof-role").value = user.role;
        document.getElementById("prof-company").value = user.company;
        document.getElementById("prof-bio").value = user.bio;
    },

    renderAnnouncements(announcementsList, currentUser) {
        const dashContainer = document.getElementById("dashboard-announcements-list");
        const adminContainer = document.getElementById("admin-announcements-list");
        const isAdmin = currentUser && currentUser.isAdmin;
        const list = announcementsList || [];

        if (dashContainer) {
            if (list.length === 0) {
                dashContainer.innerHTML = `<div class="col-span-full text-center py-8 text-slate-400 text-xs bg-slate-50/70 rounded-lg border border-dashed border-slate-200">No official announcements or information posted yet.</div>`;
            } else {
                dashContainer.innerHTML = list
                    .map(ann => {
                        const dateLabel = new Date(ann.createdAt).toLocaleDateString("en-US", {
                            year: "numeric",
                            month: "short",
                            day: "numeric"
                        });
                        const editedTag = ann.updatedAt ? ` <span class="text-[10px] text-slate-400 italic">(Edited)</span>` : "";
                        return `
                        <div class="p-4 rounded-xl border border-slate-200 bg-slate-50/70 hover:border-emerald-200 transition-all flex flex-col justify-between">
                            <div>
                                <div class="flex items-start justify-between gap-2 mb-1.5">
                                    <span class="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                                        ${this.escapeHTML(ann.category || "General Notice")}
                                    </span>
                                    ${
                                        isAdmin
                                            ? `<div class="flex items-center gap-1 shrink-0">
                                                 <button data-info-id="${ann.id}" class="edit-info-btn px-2 py-1 bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs rounded" title="Edit Information">
                                                   <i class="fa-solid fa-pen"></i>
                                                 </button>
                                                 <button data-info-id="${ann.id}" class="delete-info-btn px-2 py-1 bg-rose-50 border border-rose-200 text-rose-700 hover:bg-rose-100 text-xs rounded" title="Delete Information">
                                                   <i class="fa-solid fa-trash"></i>
                                                 </button>
                                               </div>`
                                            : ""
                                    }
                                </div>
                                <h4 class="font-bold text-slate-900 text-sm">${this.escapeHTML(ann.title)}</h4>
                                <p class="text-xs text-slate-600 mt-1.5 whitespace-pre-line leading-relaxed">${this.escapeHTML(ann.content)}</p>
                            </div>
                            <div class="mt-3 pt-2.5 border-t border-slate-200/70 flex items-center justify-between text-[11px] text-slate-400">
                                <span><i class="fa-solid fa-shield-halved text-emerald-500 mr-1"></i> ${this.escapeHTML(ann.postedBy || "Admin")}</span>
                                <span>${dateLabel}${editedTag}</span>
                            </div>
                        </div>
                    `;
                    })
                    .join("");
            }
        }

        if (adminContainer) {
            if (list.length === 0) {
                adminContainer.innerHTML = `<p class="text-center py-6 text-slate-400 text-xs bg-slate-50 rounded-lg border border-dashed border-slate-200">No announcements published yet. Click "Post Information" to share updates with all alumni.</p>`;
            } else {
                adminContainer.innerHTML = list
                    .map(ann => {
                        const dateLabel = new Date(ann.createdAt).toLocaleString();
                        const editedTag = ann.updatedAt ? ` • Edited ${new Date(ann.updatedAt).toLocaleString()}` : "";
                        return `
                        <div class="p-4 rounded-lg border border-slate-200 bg-slate-50/60 flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                            <div class="space-y-1 flex-1 min-w-0">
                                <div class="flex flex-wrap items-center gap-2">
                                    <span class="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800">${this.escapeHTML(ann.category || "General Notice")}</span>
                                    <h4 class="font-bold text-slate-900 text-sm">${this.escapeHTML(ann.title)}</h4>
                                </div>
                                <p class="text-xs text-slate-600 whitespace-pre-line">${this.escapeHTML(ann.content)}</p>
                                <p class="text-[11px] text-slate-400 pt-1">Posted by ${this.escapeHTML(ann.postedBy || "Admin")} on ${dateLabel}${editedTag}</p>
                            </div>
                            <div class="flex items-center gap-1.5 shrink-0">
                                <button data-info-id="${ann.id}" class="edit-info-btn px-3 py-1.5 bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold rounded-lg flex items-center gap-1">
                                    <i class="fa-solid fa-pen"></i> Edit
                                </button>
                                <button data-info-id="${ann.id}" class="delete-info-btn px-3 py-1.5 bg-rose-50 border border-rose-200 text-rose-700 hover:bg-rose-100 text-xs font-semibold rounded-lg flex items-center gap-1">
                                    <i class="fa-solid fa-trash"></i> Delete
                                </button>
                            </div>
                        </div>
                    `;
                    })
                    .join("");
            }
        }
    },

    isEventConcluded(evt, now = new Date()) {
        if (!evt || !evt.date) return false;

        const dateMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(evt.date));
        if (!dateMatch) return false;

        const year = Number(dateMatch[1]);
        const month = Number(dateMatch[2]);
        const day = Number(dateMatch[3]);
        let hours = 23;
        let minutes = 59;

        // If a legacy event has no time, treat it as running through the end of that day.
        if (evt.time) {
            const timeMatch = /^(\d{2}):(\d{2})$/.exec(String(evt.time));
            if (timeMatch) {
                hours = Number(timeMatch[1]);
                minutes = Number(timeMatch[2]);
            }
        }

        if (month < 1 || month > 12 || day < 1 || day > 31 || hours > 23 || minutes > 59) {
            return false;
        }

        const eventDateTime = new Date(year, month - 1, day, hours, minutes, 0, 0);
        // Reject invalid dates such as February 31 instead of allowing JS to roll them forward.
        if (
            eventDateTime.getFullYear() !== year ||
            eventDateTime.getMonth() !== month - 1 ||
            eventDateTime.getDate() !== day
        ) {
            return false;
        }

        return eventDateTime.getTime() <= now.getTime();
    },

    renderDashboard(state) {
        const currentUser = state.currentUser;
        document.getElementById("stat-total-alumni").textContent = state.alumni.length;
        document.getElementById("stat-total-jobs").textContent = state.jobs.length;

        const upcomingEvents = state.events.filter(evt => !this.isEventConcluded(evt));
        document.getElementById("stat-total-events").textContent = upcomingEvents.length;

        const myApplications = state.applications.filter(app => app.userId === currentUser.id ||
            (!app.userId && (app.applicantEmail || "").toLowerCase() === currentUser.email.toLowerCase()));
        document.getElementById("stat-my-applications").textContent = myApplications.length;

        this.renderAnnouncements(state.announcements || [], currentUser);

        const recentJobsEl = document.getElementById("dashboard-recent-jobs");
        recentJobsEl.innerHTML = state.jobs
            .slice(0, 3)
            .map(
                job => `
            <div data-target="jobs" class="nav-link-shortcut p-3.5 rounded-lg border border-slate-100 bg-slate-50/70 hover:bg-emerald-50/50 hover:border-emerald-200 cursor-pointer transition-all flex items-center justify-between gap-3">
                <div>
                    <h4 class="font-semibold text-sm text-slate-800">${this.escapeHTML(job.title)}</h4>
                    <p class="text-xs text-slate-500">${this.escapeHTML(job.company)} • ${this.escapeHTML(job.location)} • Posted by ${this.escapeHTML(job.postedBy)}</p>
                </div>
                <span class="px-2.5 py-1 text-xs font-medium rounded-full bg-emerald-50 text-emerald-700 shrink-0">${this.escapeHTML(job.type)}</span>
            </div>
        `
            )
            .join("");

        const upcomingEventsEl = document.getElementById("dashboard-upcoming-events");
        upcomingEventsEl.innerHTML = upcomingEvents
            .slice(0, 3)
            .map(
                evt => `
            <div data-target="events" class="nav-link-shortcut p-3.5 rounded-lg border border-slate-100 bg-slate-50/70 hover:bg-emerald-50/50 hover:border-emerald-200 cursor-pointer transition-all">
                <span class="text-[11px] font-semibold uppercase text-amber-600">${this.escapeHTML(evt.category)}</span>
                <h4 class="font-semibold text-sm text-slate-800 mt-0.5">${this.escapeHTML(evt.title)}</h4>
                <p class="text-xs text-slate-500 mt-1"><i class="fa-regular fa-calendar mr-1"></i>${this.escapeHTML(evt.displayDate)} • ${(evt.attendees || []).length} registered</p>
            </div>
        `
            )
            .join("");
    },

    renderDirectory(alumniList, currentUserId) {
        const grid = document.getElementById("directory-grid");
        if (alumniList.length === 0) {
            grid.innerHTML = `<div class="col-span-full text-center py-12 text-slate-500 text-sm">No alumni match your search filters.</div>`;
            return;
        }

        grid.innerHTML = alumniList
            .map(alum => {
                const isMe = alum.id === currentUserId;
                return `
                <div data-alumni-id="${this.escapeHTML(alum.id)}" data-alumni-email="${this.escapeHTML((alum.email || "").toLowerCase())}" class="alumni-directory-card bg-white rounded-xl border ${isMe ? "border-emerald-300 ring-1 ring-emerald-100" : "border-slate-200"} p-5 shadow-sm flex flex-col justify-between">
                    <div>
                        <div class="flex items-start justify-between gap-3">
                            <div class="flex items-center gap-3">
                                <div class="w-11 h-11 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-sm shrink-0">
                                    ${this.getInitials(alum.name)}
                                </div>
                                <div>
                                    <h3 class="font-bold text-slate-800 text-sm flex items-center gap-2">
                                        ${this.escapeHTML(alum.name)}
                                        ${isMe ? '<span class="text-[10px] bg-emerald-600 text-white px-2 py-0.5 rounded-full">You</span>' : ""}
                                        ${alum.isAdmin ? '<span class="text-[10px] bg-amber-500 text-white px-2 py-0.5 rounded-full">Admin</span>' : ""}
                                    </h3>
                                    <p class="text-xs text-slate-500">Class of ${this.escapeHTML(alum.gradYear)} • ${this.escapeHTML(alum.department)}</p>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4 space-y-1.5 text-xs text-slate-600">
                            <p><i class="fa-solid fa-briefcase w-4 text-slate-400"></i> <strong>${this.escapeHTML(alum.role)}</strong> at ${this.escapeHTML(alum.company)}</p>
                            <p><i class="fa-solid fa-location-dot w-4 text-slate-400"></i> ${this.escapeHTML(alum.location)}</p>
                            <p><i class="fa-solid fa-envelope w-4 text-slate-400"></i> <a href="mailto:${this.escapeHTML(alum.email)}" class="text-emerald-600 hover:underline">${this.escapeHTML(alum.email)}</a></p>
                        </div>

                        <p class="mt-3 text-xs text-slate-500 line-clamp-2">${this.escapeHTML(alum.bio)}</p>
                    </div>

                    <div class="mt-4 pt-3 border-t border-slate-100 flex justify-between items-center">
                        <a href="mailto:${this.escapeHTML(alum.email)}" class="text-xs font-medium text-emerald-600 hover:text-emerald-800 inline-flex items-center gap-1.5">
                            <i class="fa-regular fa-paper-plane"></i> Connect via Email
                        </a>
                    </div>
                </div>
            `;
            })
            .join("");
    },

    renderJobs(jobsList, applications, currentUser) {
        const container = document.getElementById("jobs-list");
        const jobsWithApplicants = new Set(
            window.store.getState().jobs
                .filter(job => job.postedById === currentUser.id)
                .filter(job => applications.some(application => application.jobId === job.id))
                .map(job => job.id)
        );
        const jobsBadge = document.getElementById("sidebar-jobs-applications-badge");
        if (jobsBadge) {
            if (jobsWithApplicants.size > 0) {
                jobsBadge.textContent = jobsWithApplicants.size;
                jobsBadge.classList.remove("hidden");
            } else {
                jobsBadge.classList.add("hidden");
            }
        }
        if (jobsList.length === 0) {
            container.innerHTML = `<div class="col-span-full text-center py-12 text-slate-500 text-sm">No job opportunities found.</div>`;
            return;
        }

        container.innerHTML = jobsList
            .map(job => {
                const jobApplicants = applications.filter(a => a.jobId === job.id);
                const isMyJob = job.postedById === currentUser.id || currentUser.isAdmin;
                const existingApp = applications.find(a => a.jobId === job.id && (
                    a.userId === currentUser.id ||
                    (!a.userId && (a.applicantEmail || "").toLowerCase() === currentUser.email.toLowerCase())
                ));
                const poster = window.store.getState().alumni.find(alum => alum.id === job.postedById);
                const posterLink = poster
                    ? `<button type="button" class="directory-user-link text-emerald-700 hover:text-emerald-900 hover:underline font-semibold" data-directory-user-id="${this.escapeHTML(poster.id)}" data-directory-user-email="${this.escapeHTML(poster.email)}" data-directory-user-name="${this.escapeHTML(poster.name)}">${this.escapeHTML(poster.name || job.postedBy)}</button>`
                    : `<span class="font-semibold">${this.escapeHTML(job.postedBy || "Alumni Member")}</span>`;

                return `
                <div class="bg-white rounded-xl border border-slate-200 p-5 shadow-sm flex flex-col justify-between">
                    <div>
                        <div class="flex justify-between items-start gap-2">
                            <div>
                                <h3 class="font-bold text-slate-800 text-base">${this.escapeHTML(job.title)}</h3>
                                <p class="text-xs font-medium text-emerald-600">${this.escapeHTML(job.company)} • ${this.escapeHTML(job.location)}</p>
                            </div>
                            <span class="px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-700">${this.escapeHTML(job.type)}</span>
                        </div>
                        <p class="text-xs text-slate-600 mt-3 leading-relaxed">${this.escapeHTML(job.description)}</p>
                    </div>

                    <div class="mt-5 pt-3 border-t border-slate-100 space-y-3">
                        <div class="flex items-center justify-between flex-wrap gap-2">
                            <span class="text-[11px] text-slate-400">Posted by ${posterLink}</span>
                            ${
                                isMyJob
                                    ? `<div class="flex items-center gap-1.5">
                                         <button data-job-id="${job.id}" data-job-title="${this.escapeHTML(job.title)}" class="view-applicants-btn px-2.5 py-1 bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200 text-xs font-semibold rounded-lg">
                                           <i class="fa-solid fa-users-viewfinder mr-1"></i> Applicants (${jobApplicants.length})
                                         </button>
                                         <button data-job-id="${job.id}" class="edit-job-btn px-2.5 py-1 bg-slate-100 text-slate-700 hover:bg-slate-200 text-xs font-semibold rounded-lg" title="Edit Job">
                                           <i class="fa-solid fa-pen"></i>
                                         </button>
                                         <button data-job-id="${job.id}" class="delete-job-btn px-2.5 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 text-xs font-semibold rounded-lg" title="Delete Job">
                                           <i class="fa-solid fa-trash"></i>
                                         </button>
                                       </div>`
                                    : ""
                            }
                        </div>
                        <div class="flex justify-end">
                            ${
                                existingApp
                                    ? `<div class="flex items-center gap-2 flex-wrap">
                                         <span class="text-xs font-semibold text-emerald-600 flex items-center gap-1">
                                           <i class="fa-solid fa-circle-check"></i> Application Submitted
                                         </span>
                                         <button type="button" data-application-id="${this.escapeHTML(existingApp.id)}" class="remove-application-btn text-xs font-semibold text-rose-600 hover:text-rose-800 hover:underline">Withdraw</button>
                                       </div>`
                                    : `<button data-job-id="${job.id}" data-job-title="${this.escapeHTML(job.title)} at ${this.escapeHTML(job.company)}" class="open-apply-btn px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium rounded-lg transition-colors">
                                         Quick Apply
                                       </button>`
                            }
                        </div>
                    </div>
                </div>
            `;
            })
            .join("");
    },

    renderEvents(eventsList, currentUser) {
        const grid = document.getElementById("events-grid");

        grid.innerHTML = eventsList
            .map(evt => {
                const isPast = this.isEventConcluded(evt);
                const attendees = evt.attendees || [];
                const currentUserEmail = (currentUser.email || "").toLowerCase();
                const userRsvped = attendees.some(attendee =>
                    attendee.userId === currentUser.id ||
                    (!attendee.userId && (attendee.email || "").toLowerCase() === currentUserEmail)
                );
                const isMyEvent = evt.createdById === currentUser.id || currentUser.isAdmin;

                return `
                <div class="bg-white rounded-xl border ${isPast ? "border-slate-200 bg-slate-50/50 opacity-80" : "border-slate-200"} p-5 shadow-sm flex flex-col justify-between">
                    <div>
                        <div class="flex justify-between items-start">
                            <span class="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                                ${this.escapeHTML(evt.category)}
                            </span>
                            <div class="flex items-center gap-1.5">
                                ${
                                    isMyEvent
                                        ? `<button data-event-id="${evt.id}" class="edit-event-btn px-2 py-1 bg-slate-100 text-slate-700 hover:bg-slate-200 text-xs font-semibold rounded" title="Edit Event">
                                             <i class="fa-solid fa-pen"></i>
                                           </button>
                                           <button data-event-id="${evt.id}" class="delete-event-btn px-2 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 text-xs font-semibold rounded" title="Delete Event">
                                             <i class="fa-solid fa-trash"></i>
                                           </button>`
                                        : ""
                                }
                                ${
                                    isPast
                                        ? '<span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 text-slate-600"><i class="fa-solid fa-flag-checkered mr-1"></i> Concluded</span>'
                                        : '<span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700">Upcoming</span>'
                                }
                            </div>
                        </div>
                        <h3 class="font-bold text-slate-800 text-base mt-2">${this.escapeHTML(evt.title)}</h3>
                        <div class="mt-3 space-y-1.5 text-xs text-slate-600">
                            <p><i class="fa-regular fa-calendar w-4 text-slate-400"></i> ${this.escapeHTML(evt.displayDate)}</p>
                            <p><i class="fa-solid fa-location-dot w-4 text-slate-400"></i> ${this.escapeHTML(evt.location)}</p>
                        </div>
                    </div>

                    <div class="mt-5 pt-3 border-t border-slate-100 space-y-2">
                        <div class="flex items-center justify-between text-xs">
                            <button data-event-id="${evt.id}" data-event-title="${this.escapeHTML(evt.title)}" class="view-attendees-btn text-emerald-600 hover:underline font-semibold flex items-center gap-1">
                                <i class="fa-solid fa-users"></i> Registered Attendees (${attendees.length})
                            </button>
                        </div>
                        ${
                            isPast
                                ? '<div class="text-center text-xs text-slate-400 font-medium py-1">Event has concluded</div>'
                                : `<button data-event-id="${evt.id}" class="toggle-rsvp-btn w-full py-2 rounded-lg text-xs font-semibold transition-colors ${
                                    userRsvped
                                        ? "bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100"
                                        : "bg-emerald-600 text-white hover:bg-emerald-700"
                                }">
                                    ${userRsvped ? '<i class="fa-solid fa-check mr-1"></i> Registered (Click to Cancel)' : "Register / RSVP to Attend"}
                                  </button>`
                        }
                    </div>
                </div>
            `;
            })
            .join("");
    },

    renderAdminPendingTable(pendingList) {
        const tbody = document.getElementById("admin-pending-table-body");
        const badge = document.getElementById("pending-count-badge");
        const sidebarBadge = document.getElementById("sidebar-pending-badge");

        const count = pendingList ? pendingList.length : 0;
        if (badge) badge.textContent = `${count} Pending`;

        if (sidebarBadge) {
            if (count > 0) {
                sidebarBadge.textContent = count;
                sidebarBadge.classList.remove("hidden");
            } else {
                sidebarBadge.classList.add("hidden");
            }
        }

        if (count === 0) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-center py-6 text-slate-400 text-xs">No pending registration requests.</td></tr>`;
            return;
        }

        tbody.innerHTML = pendingList
            .map(
                p => `
            <tr class="hover:bg-amber-50/40 transition-colors">
                <td class="p-3">
                    <div class="font-semibold text-slate-900">${this.escapeHTML(p.name)}</div>
                    <div class="text-slate-400"><a href="mailto:${this.escapeHTML(p.email)}" class="text-emerald-600 hover:underline">${this.escapeHTML(p.email)}</a></div>
                </td>
                <td class="p-3 font-mono font-semibold text-slate-700">${this.escapeHTML(p.matricNumber || "N/A")}</td>
                <td class="p-3">${this.escapeHTML(p.department)}</td>
                <td class="p-3">Class of ${this.escapeHTML(p.gradYear)}</td>
                <td class="p-3 text-right space-x-1">
                    <button data-pending-id="${p.id}" class="view-pending-btn px-2.5 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 font-semibold rounded text-[11px]">
                        <i class="fa-solid fa-eye mr-1"></i> Details
                    </button>
                    <button data-pending-id="${p.id}" class="approve-user-btn px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded text-[11px]">
                        <i class="fa-solid fa-check mr-1"></i> Approve
                    </button>
                    <button data-pending-id="${p.id}" class="reject-user-btn px-2.5 py-1 bg-rose-100 text-rose-700 hover:bg-rose-200 font-semibold rounded text-[11px]">
                        <i class="fa-solid fa-xmark mr-1"></i> Reject
                    </button>
                </td>
            </tr>
        `
            )
            .join("");
    },

    openPendingDetailsModal(pendingUser) {
        const body = document.getElementById("pending-details-body");
        const actions = document.getElementById("pending-details-actions");

        body.innerHTML = `
            <div class="flex justify-between py-1 border-b border-slate-200">
                <span class="text-slate-500">Full Name:</span>
                <span class="font-semibold text-slate-900">${this.escapeHTML(pendingUser.firstName || "")} ${this.escapeHTML(pendingUser.lastName || pendingUser.name)}</span>
            </div>
            <div class="flex justify-between py-1 border-b border-slate-200">
                <span class="text-slate-500">Email Address:</span>
                <span class="font-semibold text-emerald-600">${this.escapeHTML(pendingUser.email)}</span>
            </div>
            <div class="flex justify-between py-1 border-b border-slate-200">
                <span class="text-slate-500">Matriculation No.:</span>
                <span class="font-mono font-bold text-slate-900">${this.escapeHTML(pendingUser.matricNumber || "N/A")}</span>
            </div>
            <div class="flex justify-between py-1 border-b border-slate-200">
                <span class="text-slate-500">Department:</span>
                <span class="font-semibold text-slate-900">${this.escapeHTML(pendingUser.department)}</span>
            </div>
            <div class="flex justify-between py-1 border-b border-slate-200">
                <span class="text-slate-500">Graduation Year:</span>
                <span class="font-semibold text-slate-900">Class of ${this.escapeHTML(pendingUser.gradYear)}</span>
            </div>
            <div class="flex justify-between py-1">
                <span class="text-slate-500">Account Status:</span>
                <span class="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-semibold text-[11px]">Pending Verification</span>
            </div>
        `;

        actions.innerHTML = `
            <button type="button" class="close-modal px-3.5 py-2 text-xs text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button>
            <button type="button" data-pending-id="${pendingUser.id}" class="reject-user-btn px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-lg">Decline</button>
            <button type="button" data-pending-id="${pendingUser.id}" class="approve-user-btn px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg">Approve & Grant Access</button>
        `;

        document.getElementById("view-pending-details-modal").classList.remove("hidden");
    },

    renderAdminTable(alumniList, currentUser, searchTerm = "") {
        const tbody = document.getElementById("admin-users-table-body");
        const countLabel = document.getElementById("admin-users-count");
        if (!tbody) return;
        const query = String(searchTerm || "").trim().toLowerCase();
        const filtered = (alumniList || []).filter(alum => {
            const searchable = [alum.name, alum.email, alum.matricNumber, alum.department, alum.gradYear,
                alum.role, alum.company, alum.location, alum.bio].join(" ").toLowerCase();
            return !query || searchable.includes(query);
        });
        if (countLabel) countLabel.textContent = `${filtered.length} of ${(alumniList || []).length} members`;

        if (filtered.length === 0) {
            tbody.innerHTML = `<tr><td colspan="8" class="text-center py-6 text-slate-400 text-xs">No alumni accounts match your search.</td></tr>`;
            return;
        }

        tbody.innerHTML = filtered.map(alum => `
            <tr class="hover:bg-slate-50 transition-colors">
                <td class="p-3">
                    <div class="font-semibold text-slate-900">${this.escapeHTML(alum.name)} ${alum.isAdmin ? '<span class="text-[10px] bg-amber-500 text-white px-2 py-0.5 rounded-full ml-1">Admin</span>' : ""}</div>
                    <div class="text-slate-400"><a href="mailto:${this.escapeHTML(alum.email)}" class="text-slate-500 hover:underline">${this.escapeHTML(alum.email)}</a></div>
                </td>
                <td class="p-3 font-mono text-slate-700">${this.escapeHTML(alum.matricNumber || "N/A")}</td>
                <td class="p-3">${this.escapeHTML(alum.department)}</td>
                <td class="p-3">Class of ${this.escapeHTML(alum.gradYear)}</td>
                <td class="p-3">${this.escapeHTML(alum.role)} at ${this.escapeHTML(alum.company)}</td>
                <td class="p-3">${this.escapeHTML(alum.location)}</td>
                <td class="p-3 max-w-[260px]" title="${this.escapeHTML(alum.bio || "")}"><span class="block max-w-[240px] truncate">${this.escapeHTML(alum.bio || "—")}</span></td>
                <td class="p-3 text-right">
                    <div class="inline-flex items-center gap-1">
                        <button type="button" data-user-id="${this.escapeHTML(alum.id)}" class="edit-alumni-btn p-2 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100" title="Edit member" aria-label="Edit ${this.escapeHTML(alum.name)}">
                            <i class="fa-solid fa-pen"></i>
                        </button>
                        <button type="button" data-user-id="${this.escapeHTML(alum.id)}" class="delete-alumni-btn p-2 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100" title="Delete member" aria-label="Delete ${this.escapeHTML(alum.name)}">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join("");
    },

    openEditAlumniModal(alum) {
        document.getElementById("edit-alumni-id").value = alum.id;
        document.getElementById("edit-alumni-name").value = alum.name || "";
        document.getElementById("edit-alumni-email").value = alum.email || "";
        document.getElementById("edit-alumni-matric").value = alum.matricNumber || "";
        document.getElementById("edit-alumni-year").value = String(alum.gradYear || "2026");
        document.getElementById("edit-alumni-dept").value = alum.department || "Computer Science";
        document.getElementById("edit-alumni-location").value = alum.location || "";
        document.getElementById("edit-alumni-role").value = alum.role || "";
        document.getElementById("edit-alumni-company").value = alum.company || "";
        document.getElementById("edit-alumni-bio").value = alum.bio || "";
        document.getElementById("edit-alumni-modal").classList.remove("hidden");
    },

    renderAttendeesModal(eventTitle, attendeesList) {
        document.getElementById("attendees-modal-event-title").textContent = eventTitle;
        const container = document.getElementById("attendees-list-container");

        if (!attendeesList || attendeesList.length === 0) {
            container.innerHTML = `<p class="text-center py-8 text-slate-400 text-xs">No alumni have registered for this event yet.</p>`;
        } else {
            container.innerHTML = attendeesList
                .map(att => {
                    const liveMember = this.findLiveAlumniMember(att.userId, att.email);
                    const attendeeId = liveMember?.id || att.userId || "";
                    const attendeeName = liveMember?.name || att.name || "Alumnus";
                    const attendeeEmail = liveMember?.email || att.email || "";
                    const attendeeGradYear = liveMember?.gradYear || att.gradYear || "N/A";
                    const normalizedEmail = attendeeEmail.toLowerCase();
                    return `
                <div class="p-3 rounded-lg border border-slate-200 bg-slate-50 flex items-center justify-between gap-2">
                    <div class="min-w-0">
                        <button type="button"
                            data-directory-user-id="${this.escapeHTML(attendeeId)}"
                            data-directory-user-email="${this.escapeHTML(normalizedEmail)}"
                            data-directory-user-name="${this.escapeHTML(attendeeName)}"
                            class="directory-user-link attendee-directory-link text-left font-semibold text-emerald-700 hover:text-emerald-900 hover:underline text-xs inline-flex items-center gap-1.5">
                            <span>${this.escapeHTML(attendeeName)}</span>
                            <i class="fa-solid fa-arrow-up-right-from-square text-[10px]"></i>
                        </button>
                        <span class="text-slate-400 font-normal text-xs"> (Class of ${this.escapeHTML(attendeeGradYear)})</span>
                        <div class="text-[11px] text-slate-500 mt-0.5"><a href="mailto:${this.escapeHTML(attendeeEmail)}" class="text-emerald-600 hover:underline">${this.escapeHTML(attendeeEmail)}</a></div>
                    </div>
                    <a href="mailto:${this.escapeHTML(attendeeEmail)}" class="text-xs text-emerald-600 hover:underline font-medium shrink-0">
                        <i class="fa-solid fa-envelope mr-1"></i> Contact
                    </a>
                </div>
            `;
                })
                .join("");
        }

        document.getElementById("view-attendees-modal").classList.remove("hidden");
    },

    renderMyApplicationsModal(applications, jobs) {
        const container = document.getElementById("my-applications-list-container");
        const currentUser = window.store.getState().currentUser;
        const currentUserEmail = currentUser.email.toLowerCase();
        const myApps = applications.filter(a => a.userId === currentUser.id ||
            (!a.userId && (a.applicantEmail || "").toLowerCase() === currentUserEmail));

        if (myApps.length === 0) {
            container.innerHTML = `<p class="text-center py-8 text-slate-400 text-xs">You have not submitted any job applications yet.</p>`;
        } else {
            container.innerHTML = myApps
                .map(app => {
                    const job = jobs.find(j => j.id === app.jobId) || { title: "Position", company: "Company", location: "Remote" };
                    return `
                    <div class="p-4 rounded-lg border border-slate-200 bg-slate-50 space-y-1.5">
                        <div class="flex justify-between items-start">
                            <div>
                                <h4 class="font-bold text-slate-900 text-sm">${this.escapeHTML(job.title)}</h4>
                                <p class="text-xs text-emerald-600 font-medium">${this.escapeHTML(job.company)} • ${this.escapeHTML(job.location)}</p>
                            </div>
                            <button type="button" data-application-id="${this.escapeHTML(app.id)}" class="remove-application-btn text-[10px] font-semibold px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100">Withdraw</button>
                        </div>
                        <p class="text-xs text-slate-600 bg-white p-2.5 rounded border border-slate-100"><strong>Your Note:</strong> "${this.escapeHTML(app.note)}"</p>
                        <p class="text-[10px] text-slate-400">Applied on: ${new Date(app.submittedAt).toLocaleDateString()}</p>
                    </div>
                `;
                })
                .join("");
        }

        document.getElementById("my-applications-modal").classList.remove("hidden");
    },

    renderApplicantsModal(jobTitle, applicantsList) {
        document.getElementById("applicants-modal-job-title").textContent = jobTitle;
        const container = document.getElementById("applicants-list-container");
        const alumni = window.store.getState().alumni || [];

        if (applicantsList.length === 0) {
            container.innerHTML = `<p class="text-center py-8 text-slate-400 text-xs">No applications submitted for this role yet.</p>`;
        } else {
            container.innerHTML = applicantsList.map(app => {
                const applicant = alumni.find(alum => alum.id === app.userId) ||
                    (!app.userId ? alumni.find(alum => alum.email.toLowerCase() === (app.applicantEmail || "").toLowerCase()) : null);
                const applicantName = this.escapeHTML(applicant?.name || app.applicantName || "Alumni Member");
                const nameMarkup = applicant
                    ? `<button type="button" class="directory-user-link font-semibold text-emerald-700 hover:text-emerald-900 hover:underline text-sm" data-directory-user-id="${this.escapeHTML(applicant.id)}" data-directory-user-email="${this.escapeHTML(applicant.email)}" data-directory-user-name="${applicantName}">${applicantName} <i class="fa-solid fa-arrow-up-right-from-square text-[10px] ml-1"></i></button>`
                    : `<span class="font-semibold text-slate-900 text-sm">${applicantName}</span>`;
                return `
                    <div class="p-3.5 rounded-lg border border-slate-200 bg-slate-50 space-y-1">
                        <div class="flex justify-between items-center gap-3 flex-wrap">
                            ${nameMarkup}
                            <a href="mailto:${this.escapeHTML(app.applicantEmail)}" class="text-xs text-emerald-600 hover:underline font-medium">
                                <i class="fa-solid fa-envelope mr-1"></i>${this.escapeHTML(app.applicantEmail)}
                            </a>
                        </div>
                        <p class="text-xs text-slate-600 bg-white p-2.5 rounded border border-slate-100">"${this.escapeHTML(app.note)}"</p>
                        <p class="text-[10px] text-slate-400">Submitted: ${new Date(app.submittedAt).toLocaleString()}</p>
                    </div>
                `;
            }).join("");
        }

        document.getElementById("view-applicants-modal").classList.remove("hidden");
    },

    openApplyModal(jobId, jobTitle) {
        const freshUser = window.store.getState().currentUser;
        document.getElementById("apply-job-id").value = jobId;
        document.getElementById("apply-job-title-display").textContent = jobTitle;
        document.getElementById("apply-applicant-name").value = freshUser.name;
        document.getElementById("apply-applicant-email").value = freshUser.email;
        document.getElementById("apply-applicant-note").value = "";
        document.getElementById("apply-job-modal").classList.remove("hidden");
    },

    openEditJobModal(job) {
        document.getElementById("edit-job-id").value = job.id;
        document.getElementById("edit-job-title").value = job.title;
        document.getElementById("edit-job-company").value = job.company;
        document.getElementById("edit-job-type").value = job.type;
        document.getElementById("edit-job-location").value = job.location;
        document.getElementById("edit-job-desc").value = job.description;
        document.getElementById("edit-job-modal").classList.remove("hidden");
    },

    openEditEventModal(event) {
        document.getElementById("edit-evt-id").value = event.id;
        document.getElementById("edit-evt-title").value = event.title;
        document.getElementById("edit-evt-date").value = event.date || "";
        document.getElementById("edit-evt-time").value = event.time || "10:00";
        document.getElementById("edit-evt-category").value = event.category || "Reunion";
        document.getElementById("edit-evt-location").value = event.location;
        document.getElementById("edit-event-modal").classList.remove("hidden");
    },

    openEditInfoModal(ann) {
        document.getElementById("edit-info-id").value = ann.id;
        document.getElementById("edit-info-title").value = ann.title;
        document.getElementById("edit-info-category").value = ann.category || "General Notice";
        document.getElementById("edit-info-content").value = ann.content;
        document.getElementById("edit-info-modal").classList.remove("hidden");
    },

    closeAllModals() {
        document.querySelectorAll(".modal-backdrop").forEach(m => m.classList.add("hidden"));
    }
};

window.UI = UI;
