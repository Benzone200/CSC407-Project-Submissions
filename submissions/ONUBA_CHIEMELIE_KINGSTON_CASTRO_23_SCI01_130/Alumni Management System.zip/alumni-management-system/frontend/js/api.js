

const AlumniAPI = {
    async getAlumniDirectory(filters = {}) {
        const state = window.store.getState();
        let list = [...state.alumni];

        if (filters.query && filters.query.trim() !== "") {
            const q = filters.query.toLowerCase();
            list = list.filter(a => 
                a.name.toLowerCase().includes(q) ||
                (a.company && a.company.toLowerCase().includes(q)) ||
                (a.role && a.role.toLowerCase().includes(q)) ||
                (a.location && a.location.toLowerCase().includes(q))
            );
        }

        if (filters.year && filters.year !== "all") {
            list = list.filter(a => String(a.gradYear) === String(filters.year));
        }

        if (filters.department && filters.department !== "all") {
            list = list.filter(a => a.department === filters.department);
        }

        return list;
    },

    async getJobs(query = "") {
        const state = window.store.getState();
        let jobs = state.jobs;
        if (query && query.trim() !== "") {
            const q = query.toLowerCase();
            jobs = jobs.filter(j => 
                j.title.toLowerCase().includes(q) ||
                j.company.toLowerCase().includes(q) ||
                j.type.toLowerCase().includes(q)
            );
        }
        return jobs;
    },

    async getAnnouncements() {
        return window.store.getState().announcements || [];
    },

    async updateUserProfile(updatedFields) {
        window.store.updateCurrentUser(updatedFields);
        return window.store.getState().currentUser;
    },

    async applyForJob(jobId, applicantEmail, note) {
        return window.store.submitApplication(jobId, null, applicantEmail, note);
    },

    async removeApplication(applicationId) {
        return window.store.removeApplication(applicationId);
    },

    async toggleRsvp(eventId) {
        window.store.toggleEventRsvp(eventId);
        return window.store.getState().events;
    }
};

window.AlumniAPI = AlumniAPI;
