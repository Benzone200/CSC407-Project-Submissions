

const DEFAULT_DATA = {
    currentUser: null,
    alumni: [],
    pendingAlumni: [],
    jobs: [],
    events: [],
    applications: [],
    announcements: []
};

class AppStore {
    constructor() {
        this.STORAGE_KEY = "alma_connect_state_v8";
        this.listeners = [];
        this.state = this.loadState();
    }

    loadState() {
        const saved = localStorage.getItem(this.STORAGE_KEY);
        if (saved) {
            try {
                const parsed = JSON.parse(saved);
                if (!parsed.pendingAlumni) parsed.pendingAlumni = [];
                if (!parsed.announcements) parsed.announcements = [];
                return parsed;
            } catch (e) {
                console.error("Failed to parse saved state", e);
            }
        }
        return JSON.parse(JSON.stringify(DEFAULT_DATA));
    }

    saveState() {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.state));
        this.notify();
    }

    subscribe(listenerFn) {
        this.listeners.push(listenerFn);
    }

    notify() {
        this.listeners.forEach(fn => fn(this.state));
    }

    getState() {
        return this.state;
    }

    sanitizeLength(value, maxLen, fieldLabel) {
        if (typeof value !== "string") return value;
        const trimmed = value.trim();
        if (trimmed.length > maxLen) {
            throw new Error(`${fieldLabel} cannot exceed ${maxLen} characters (currently ${trimmed.length}).`);
        }
        return trimmed;
    }

    syncUserReferences(user, previousUser = {}) {
        const userId = user.id;
        const previousEmail = (previousUser.email || "").trim().toLowerCase();

        this.state.jobs.forEach(job => {
            if (job.postedById === userId) job.postedBy = user.name;
        });

        this.state.announcements.forEach(announcement => {
            if (announcement.postedById === userId) announcement.postedBy = user.name;
        });

        // Applications use a stable userId. Backfill older records by their former
        // profile email, while preserving a separately supplied contact email.
        this.state.applications.forEach(application => {
            const applicationEmail = (application.applicantEmail || "").trim().toLowerCase();
            const belongsToUser = application.userId === userId ||
                (!application.userId && previousEmail && applicationEmail === previousEmail);

            if (belongsToUser) {
                application.userId = userId;
                application.applicantName = user.name;
                if (applicationEmail === previousEmail) application.applicantEmail = user.email;
            }
        });

        // Event attendee records historically stored a snapshot of a member's
        // name, email and graduation year. Keep that snapshot synchronized too.
        this.state.events.forEach(event => {
            (event.attendees || []).forEach(attendee => {
                const attendeeEmail = (attendee.email || "").trim().toLowerCase();
                const linkedById = attendee.userId === userId;
                const linkedByLegacyEmail = !attendee.userId && previousEmail && attendeeEmail === previousEmail;

                if (linkedById || linkedByLegacyEmail) {
                    attendee.userId = userId;
                    attendee.name = user.name;
                    attendee.gradYear = user.gradYear;
                    if (linkedById || attendeeEmail === previousEmail || !attendee.email) {
                        attendee.email = user.email;
                    }
                }
            });
        });
    }

    updateCurrentUser(updatedFields) {
        if (!this.state.currentUser) return;
        const previousUser = { ...this.state.currentUser };
        const validated = { ...updatedFields };

        if (validated.name !== undefined) validated.name = this.sanitizeLength(validated.name, 80, "Full Name");
        if (validated.email !== undefined) {
            validated.email = this.sanitizeLength(validated.email, 100, "Email");
            if (!validated.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(validated.email)) {
                throw new Error("Please enter a valid email address.");
            }
            const duplicateEmail = this.state.alumni.some(a => a.id !== previousUser.id && (a.email || "").toLowerCase() === validated.email.toLowerCase()) ||
                this.state.pendingAlumni.some(a => (a.email || "").toLowerCase() === validated.email.toLowerCase());
            if (duplicateEmail) throw new Error("That email address is already being used by another account.");
        }
        if (validated.location !== undefined) validated.location = this.sanitizeLength(validated.location, 80, "Location");
        if (validated.role !== undefined) validated.role = this.sanitizeLength(validated.role, 80, "Job Title");
        if (validated.company !== undefined) validated.company = this.sanitizeLength(validated.company, 80, "Company");
        if (validated.bio !== undefined) validated.bio = this.sanitizeLength(validated.bio, 400, "Bio / Mentorship Interests");

        // Keep one canonical in-memory member object shared by the signed-in
        // session and the directory/admin data source.
        const memberIndex = this.state.alumni.findIndex(alum => alum.id === previousUser.id);
        let updatedUser;
        if (memberIndex !== -1) {
            updatedUser = this.state.alumni[memberIndex];
            Object.assign(updatedUser, validated);
        } else {
            updatedUser = { ...previousUser, ...validated };
        }

        this.state.currentUser = updatedUser;
        this.syncUserReferences(updatedUser, previousUser);
        this.saveState();
        return updatedUser;
    }

    updateAlumniUser(userId, updatedFields) {
        if (!this.state.currentUser || !this.state.currentUser.isAdmin) {
            throw new Error("Only administrators can edit alumni accounts.");
        }

        const user = this.state.alumni.find(alum => alum.id === userId);
        if (!user) throw new Error("Alumni account not found.");

        const previousUser = { ...user };
        const fields = { ...updatedFields };
        const allowed = ["name", "email", "matricNumber", "gradYear", "department", "location", "role", "company", "bio"];
        Object.keys(fields).forEach(key => {
            if (!allowed.includes(key)) delete fields[key];
        });

        if (fields.name !== undefined) fields.name = this.sanitizeLength(fields.name, 80, "Full Name");
        if (fields.email !== undefined) {
            fields.email = this.sanitizeLength(fields.email, 100, "Email");
            if (!fields.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email)) {
                throw new Error("Please enter a valid email address.");
            }
            const duplicateEmail = this.state.alumni.some(a => a.id !== userId && (a.email || "").toLowerCase() === fields.email.toLowerCase()) ||
                this.state.pendingAlumni.some(a => (a.email || "").toLowerCase() === fields.email.toLowerCase());
            if (duplicateEmail) throw new Error("That email address is already being used by another account.");
        }
        if (fields.matricNumber !== undefined) fields.matricNumber = this.sanitizeLength(fields.matricNumber, 25, "Matriculation Number");
        if (fields.location !== undefined) fields.location = this.sanitizeLength(fields.location, 80, "Location");
        if (fields.role !== undefined) fields.role = this.sanitizeLength(fields.role, 80, "Job Title");
        if (fields.company !== undefined) fields.company = this.sanitizeLength(fields.company, 80, "Company");
        if (fields.bio !== undefined) fields.bio = this.sanitizeLength(fields.bio, 400, "Bio / Mentorship Interests");

        Object.assign(user, fields);
        if (this.state.currentUser.id === userId) this.state.currentUser = user;
        this.syncUserReferences(user, previousUser);
        this.saveState();
        return user;
    }

    deleteAccount(userId) {
        const requester = this.state.currentUser;
        if (!requester) throw new Error("You must be signed in to delete an account.");
        if (!requester.isAdmin && requester.id !== userId) {
            throw new Error("You do not have permission to delete this account.");
        }

        const user = this.state.alumni.find(alum => alum.id === userId) ||
            this.state.pendingAlumni.find(alum => alum.id === userId);
        if (!user) throw new Error("Account not found.");
        const userEmail = (user.email || "").toLowerCase();

        // First remove jobs and events authored by this member.
        const deletedJobIds = new Set(this.state.jobs.filter(job => job.postedById === userId).map(job => job.id));
        this.state.jobs = this.state.jobs.filter(job => job.postedById !== userId);
        this.state.events = this.state.events
            .filter(event => event.createdById !== userId)
            .map(event => ({
                ...event,
                attendees: (event.attendees || []).filter(attendee =>
                    attendee.userId !== userId &&
                    (attendee.userId || (attendee.email || "").toLowerCase() !== userEmail)
                )
            }));

        // Remove applications submitted by the member and every application on their jobs.
        this.state.applications = this.state.applications.filter(application => {
            const belongsToUser = application.userId === userId ||
                (!application.userId && (application.applicantEmail || "").toLowerCase() === userEmail);
            return !belongsToUser && !deletedJobIds.has(application.jobId);
        });

        this.state.announcements = this.state.announcements.filter(announcement => announcement.postedById !== userId);
        this.state.alumni = this.state.alumni.filter(alum => alum.id !== userId);
        this.state.pendingAlumni = this.state.pendingAlumni.filter(alum => alum.id !== userId);

        const deletedCurrentUser = requester.id === userId;
        if (deletedCurrentUser) this.state.currentUser = null;
        this.saveState();
        return { deletedCurrentUser, deletedUserName: user.name };
    }

    registerUser(userData) {
        const firstName = this.sanitizeLength(userData.firstName, 40, "First Name");
        const lastName = this.sanitizeLength(userData.lastName, 40, "Last Name");
        const cleanEmail = this.sanitizeLength(userData.email, 100, "Email");
        const matricNumber = this.sanitizeLength(userData.matricNumber || "N/A", 25, "Matriculation Number");
        this.sanitizeLength(userData.password, 64, "Password");
        const email = cleanEmail.toLowerCase();
        
        // Check if already active
        const emailInAlumni = this.state.alumni.some(a => a.email.toLowerCase() === email);
        if (emailInAlumni) {
            throw new Error(`An active account with email "${userData.email}" already exists. Please sign in instead.`);
        }

        // Check if already pending
        const emailInPending = this.state.pendingAlumni.some(p => p.email.toLowerCase() === email);
        if (emailInPending) {
            throw new Error(`An account registration for "${userData.email}" is already pending admin approval.`);
        }

        const isFirstUser = this.state.alumni.length === 0;

        const newUser = {
            id: "user-" + Date.now(),
            firstName,
            lastName,
            name: `${firstName} ${lastName}`,
            email: cleanEmail,
            password: userData.password,
            matricNumber,
            gradYear: userData.gradYear,
            department: userData.department,
            role: isFirstUser ? "Platform Administrator" : "Alumnus / Member",
            company: isFirstUser ? "University Alumni Office" : "Independent / Other",
            location: "Lagos, Nigeria",
            bio: isFirstUser ? "System administrator account." : "Registered alumni member.",
            isAdmin: isFirstUser,
            status: isFirstUser ? "approved" : "pending"
        };

        if (isFirstUser) {
            this.state.alumni.push(newUser);
            this.state.currentUser = newUser;
        } else {
            this.state.pendingAlumni.push(newUser);
        }

        this.saveState();
        return newUser;
    }

    approveUserRequest(userId) {
        const idx = this.state.pendingAlumni.findIndex(p => p.id === userId);
        if (idx === -1) return;
        const user = this.state.pendingAlumni.splice(idx, 1)[0];
        user.status = "approved";
        this.state.alumni.push(user);
        this.saveState();
    }

    rejectUserRequest(userId) {
        const idx = this.state.pendingAlumni.findIndex(p => p.id === userId);
        if (idx === -1) return;
        this.state.pendingAlumni.splice(idx, 1);
        this.saveState();
    }

    loginUser(email, password) {
        const emailLower = email.toLowerCase();
        
        // Check active alumni
        const user = this.state.alumni.find(a => a.email.toLowerCase() === emailLower);
        if (user) {
            if (user.password && user.password !== password) {
                throw new Error("Incorrect password. Please try again.");
            }
            this.state.currentUser = user;
            this.saveState();
            return user;
        }

        // Check pending queue
        const pendingUser = this.state.pendingAlumni.find(p => p.email.toLowerCase() === emailLower);
        if (pendingUser) {
            if (pendingUser.password && pendingUser.password !== password) {
                throw new Error("Incorrect password. Please try again.");
            }
            throw new Error("Your account registration is still pending admin approval. Please check back later.");
        }

        throw new Error("No account found with this email. Please register first.");
    }

    logoutUser() {
        this.state.currentUser = null;
        this.saveState();
    }

    // --- ADMIN ANNOUNCEMENTS / INFORMATION BOARD ---
    addAnnouncement(payload) {
        if (!this.state.currentUser || !this.state.currentUser.isAdmin) {
            throw new Error("Only administrators can post information announcements.");
        }
        const title = this.sanitizeLength(payload.title, 100, "Announcement Title");
        const content = this.sanitizeLength(payload.content, 1200, "Announcement Content");
        const category = this.sanitizeLength(payload.category || "General", 40, "Category");

        if (!title || !content) {
            throw new Error("Both title and message content are required.");
        }

        const announcement = {
            id: "ann-" + Date.now(),
            title,
            category,
            content,
            postedBy: this.state.currentUser.name,
            postedById: this.state.currentUser.id,
            createdAt: new Date().toISOString(),
            updatedAt: null
        };
        this.state.announcements.unshift(announcement);
        this.saveState();
        return announcement;
    }

    updateAnnouncement(annId, payload) {
        if (!this.state.currentUser || !this.state.currentUser.isAdmin) {
            throw new Error("Only administrators can edit information announcements.");
        }
        const ann = this.state.announcements.find(a => a.id === annId);
        if (!ann) throw new Error("Announcement not found.");

        const title = this.sanitizeLength(payload.title, 100, "Announcement Title");
        const content = this.sanitizeLength(payload.content, 1200, "Announcement Content");
        const category = this.sanitizeLength(payload.category || "General", 40, "Category");

        if (!title || !content) {
            throw new Error("Both title and message content are required.");
        }

        ann.title = title;
        ann.category = category;
        ann.content = content;
        ann.updatedAt = new Date().toISOString();
        this.saveState();
        return ann;
    }

    deleteAnnouncement(annId) {
        if (!this.state.currentUser || !this.state.currentUser.isAdmin) {
            throw new Error("Only administrators can delete information announcements.");
        }
        this.state.announcements = this.state.announcements.filter(a => a.id !== annId);
        this.saveState();
    }

    addJob(newJob) {
        if (!this.state.currentUser) return;
        const validatedJob = {
            ...newJob,
            title: this.sanitizeLength(newJob.title, 80, "Job Title"),
            company: this.sanitizeLength(newJob.company, 70, "Company"),
            location: this.sanitizeLength(newJob.location, 70, "Location"),
            description: this.sanitizeLength(newJob.description, 600, "Job Description")
        };
        const jobRecord = {
            id: "job-" + Date.now(),
            postedBy: this.state.currentUser.name,
            postedById: this.state.currentUser.id,
            ...validatedJob
        };
        this.state.jobs.unshift(jobRecord);
        this.saveState();
        return jobRecord;
    }

    updateJob(jobId, updatedFields) {
        const job = this.state.jobs.find(j => j.id === jobId);
        if (!job) return;
        if (!this.state.currentUser.isAdmin && job.postedById !== this.state.currentUser.id) {
            throw new Error("You do not have permission to edit this job posting.");
        }
        const validatedJob = {
            ...updatedFields,
            title: this.sanitizeLength(updatedFields.title, 80, "Job Title"),
            company: this.sanitizeLength(updatedFields.company, 70, "Company"),
            location: this.sanitizeLength(updatedFields.location, 70, "Location"),
            description: this.sanitizeLength(updatedFields.description, 600, "Job Description")
        };
        Object.assign(job, validatedJob);
        this.saveState();
    }

    deleteJob(jobId) {
        const job = this.state.jobs.find(j => j.id === jobId);
        if (!job) return;
        if (!this.state.currentUser.isAdmin && job.postedById !== this.state.currentUser.id) {
            throw new Error("You do not have permission to delete this job posting.");
        }
        this.state.jobs = this.state.jobs.filter(j => j.id !== jobId);
        this.state.applications = this.state.applications.filter(a => a.jobId !== jobId);
        this.saveState();
    }

    formatEventDate(dateValue) {
        const dateText = String(dateValue || "");
        const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateText);
        const dateObj = match
            ? new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]))
            : new Date(dateText);

        if (Number.isNaN(dateObj.getTime())) return dateText;
        return dateObj.toLocaleDateString("en-US", {
            year: "numeric",
            month: "long",
            day: "numeric"
        });
    }

    addEvent(eventPayload) {
        const formattedDate = this.formatEventDate(eventPayload.date);

        const cleanTitle = this.sanitizeLength(eventPayload.title, 80, "Event Title");
        const cleanLocation = this.sanitizeLength(eventPayload.location, 90, "Event Location");
        const timeStr = eventPayload.time ? ` • ${eventPayload.time}` : '';
        const eventRecord = {
            id: "evt-" + Date.now(),
            title: cleanTitle,
            date: eventPayload.date,
            time: eventPayload.time,
            displayDate: `${formattedDate}${timeStr}`,
            location: cleanLocation,
            category: eventPayload.category,
            createdById: this.state.currentUser ? this.state.currentUser.id : null,
            attendees: []
        };
        this.state.events.unshift(eventRecord);
        this.saveState();
        return eventRecord;
    }

    updateEvent(eventId, eventPayload) {
        const event = this.state.events.find(e => e.id === eventId);
        if (!event) return;
        if (!this.state.currentUser.isAdmin && event.createdById !== this.state.currentUser.id) {
            throw new Error("You do not have permission to edit this event.");
        }

        const formattedDate = this.formatEventDate(eventPayload.date);
        const timeStr = eventPayload.time ? ` • ${eventPayload.time}` : '';

        event.title = this.sanitizeLength(eventPayload.title, 80, "Event Title");
        event.date = eventPayload.date;
        event.time = eventPayload.time;
        event.displayDate = `${formattedDate}${timeStr}`;
        event.location = this.sanitizeLength(eventPayload.location, 90, "Event Location");
        event.category = eventPayload.category;

        this.saveState();
    }

    deleteEvent(eventId) {
        const event = this.state.events.find(e => e.id === eventId);
        if (!event) return;
        if (!this.state.currentUser.isAdmin && event.createdById !== this.state.currentUser.id) {
            throw new Error("You do not have permission to delete this event.");
        }
        this.state.events = this.state.events.filter(e => e.id !== eventId);
        this.saveState();
    }

    submitApplication(jobId, applicantName, applicantEmail, note) {
        const currentUser = this.state.currentUser;
        if (!currentUser) throw new Error("Please sign in before applying for a job.");
        const job = this.state.jobs.find(item => item.id === jobId);
        if (!job) throw new Error("This job posting could not be found.");

        // The applicant name is always taken from the signed-in profile. Any name
        // submitted by the browser is deliberately ignored.
        const cleanEmail = this.sanitizeLength(applicantEmail, 100, "Applicant Email");
        if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
            throw new Error("Please enter a valid contact email address.");
        }
        const alreadyApplied = this.state.applications.some(app => app.jobId === jobId && (
            app.userId === currentUser.id ||
            (!app.userId && (app.applicantEmail || "").toLowerCase() === currentUser.email.toLowerCase())
        ));
        if (alreadyApplied) {
            throw new Error("You have already applied for this position.");
        }

        const application = {
            id: "app-" + Date.now(),
            jobId,
            userId: currentUser.id,
            applicantName: currentUser.name,
            applicantEmail: cleanEmail,
            note: this.sanitizeLength(note, 500, "Cover Note"),
            submittedAt: new Date().toISOString()
        };
        this.state.applications.push(application);
        this.saveState();
        return application;
    }

    removeApplication(applicationId) {
        const currentUser = this.state.currentUser;
        if (!currentUser) throw new Error("Please sign in to manage your applications.");
        const application = this.state.applications.find(app => app.id === applicationId);
        if (!application) throw new Error("Application not found. It may have already been removed.");
        const belongsToUser = application.userId === currentUser.id ||
            (!application.userId && (application.applicantEmail || "").toLowerCase() === currentUser.email.toLowerCase());
        if (!belongsToUser) throw new Error("You can only withdraw your own applications.");
        this.state.applications = this.state.applications.filter(app => app.id !== applicationId);
        this.saveState();
        return application;
    }

    toggleEventRsvp(eventId) {
        if (!this.state.currentUser) return;
        const event = this.state.events.find(e => e.id === eventId);
        if (!event) return;

        if (!event.attendees) event.attendees = [];

        const userEmail = (this.state.currentUser.email || "").toLowerCase();
        const existingIdx = event.attendees.findIndex(attendee =>
            attendee.userId === this.state.currentUser.id ||
            (!attendee.userId && (attendee.email || "").toLowerCase() === userEmail)
        );

        if (existingIdx !== -1) {
            event.attendees.splice(existingIdx, 1);
        } else {
            event.attendees.push({
                userId: this.state.currentUser.id,
                name: this.state.currentUser.name,
                email: this.state.currentUser.email,
                gradYear: this.state.currentUser.gradYear
            });
        }
        this.saveState();
    }

    resetAll() {
        localStorage.removeItem(this.STORAGE_KEY);
        this.state = JSON.parse(JSON.stringify(DEFAULT_DATA));
        this.state.currentUser = null;
        this.saveState();
    }
}

window.store = new AppStore();
