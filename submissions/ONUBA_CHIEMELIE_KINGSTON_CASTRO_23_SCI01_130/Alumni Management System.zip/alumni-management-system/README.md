# AlmaConnect | University Alumni Management System

## 1. Project Description

AlmaConnect is a University Alumni Management System designed to provide a platform where university graduates can connect, interact, access career opportunities, participate in events, and stay informed about alumni activities.

The system provides alumni profile management, a searchable alumni directory, a career and job board, event management, and administrative features for managing alumni accounts.

## 2. Features

### User and Account Management
- **First-User Admin System:** The first user to register becomes the Site Administrator.
- **Account Management:** Members can delete their own accounts, while administrators can search, edit, and delete approved alumni accounts.
- **Account Deletion:** Deleting an account also removes the member's associated jobs, applications, events, event registrations, and announcements.

### Alumni Directory
- **Alumni Directory:** Search and filter graduates by name, company, graduation year, and department.
- **Sequential Graduation Years:** Graduation years are structured from 2019 to 2026.

### Career and Job Board
- **Job Opportunities:** Members can post job opportunities, submit applications, and view applicants.
- **Job Applicant Profiles:** Job posters and applicants can be selected to open their corresponding alumni profiles in the directory.
- **Application Withdrawal:** Members can withdraw their own applications from the Job Board or My Applications list.
- **Verified Applicant Names:** Applicant names are read-only during application and are obtained from the signed-in alumni profile. Applicants can provide a separate contact email.
- **Job Activity Badge:** The Career & Job Board navigation badge counts a member's posted jobs that have received at least one application, rather than the total number of applications.

### Events and Reunions
- **Event Management:** Create events with specific dates and times.
- **Event Registration:** Alumni can RSVP to events and view registered attendees.
- **Time-Aware Event Status:** Event statuses update automatically based on their scheduled dates and times while the portal is open.
- **Attendee Directory Shortcuts:** Selecting a registered attendee opens and highlights their profile in the alumni directory.

### Interface and Navigation
- **Emerald Green Theme:** A green colour palette is applied throughout the existing interface.
- **SPA History Routing:** Supports browser back and forward navigation between application views.
- **Responsive Admin Tables:** Pending and approved member tables maintain their column widths and support horizontal scrolling on smaller screens.
- **Fixed Desktop Sidebar:** The desktop sidebar remains within the viewport height while the main page content scrolls.

## 3. Technologies Used

- **HTML5:** Provides the structure of the application.
- **CSS3:** Handles the styling, layout, and responsive interface.
- **JavaScript:** Implements application logic, user interactions, navigation, and data management.
- **Node.js:** Provides the JavaScript runtime for the local server.
- **Express.js:** Handles server setup, serves frontend files, and provides API endpoints.
- **Browser localStorage:** Stores application data locally in the user's browser.

## 4. Project Structure

```text
alumni-management-system/
│
├── backend/
│   └── server.js
│
├── frontend/
│   ├── index.html
│   ├── css/
│   │   └── styles.css
│   └── js/
│       ├── state.js
│       ├── ui.js
│       ├── api.js
│       └── app.js
│
├── database/
│   └── schema.sql
│
├── package.json
└── README.md
```

## 5. Requirements

To run the application using the local server, you need:

- Node.js installed on your computer.
- A modern web browser.
- An internet connection for external styling and icon resources.

## 6. Installation and Setup

### Option 1: Open Directly in a Browser

1. Extract the project ZIP file.
2. Open the `alumni-management-system` folder.
3. Navigate to the `frontend` folder.
4. Double-click `index.html` to open the application in your browser.

No Node.js installation or additional package installation is required for this method.

### Option 2: Run Using Node.js

1. Install Node.js if it is not already installed.
2. Extract the project ZIP file.
3. Open the `alumni-management-system` folder in Visual Studio Code.
4. Open the integrated terminal.
5. Install the project dependencies:

   ```bash
   npm install
   ```

6. Start the application:

   ```bash
   npm start
   ```

7. Open your browser and visit:

   ```text
   http://localhost:3000
   ```

8. Register the first account to obtain Site Administrator access.


## 7. Data Storage and Limitations

AlmaConnect is currently a class-project prototype that primarily uses the browser's `localStorage` for application data storage.

- User accounts, profiles, jobs, applications, events, and other application data are stored locally in the browser.
- Data is specific to the browser and origin in which the application is accessed.
- Data is not automatically shared between different users, browsers, or computers.
- The application does not currently use a connected central database for its main application data.
- The `database/schema.sql` file provides a database schema but is not currently integrated into the application's data storage system.

For a production deployment, further development would be required to integrate a centralized database, backend data persistence, and appropriate authentication and security mechanisms.

## 8. Project Status

AlmaConnect was developed as an academic project to demonstrate the application of web development technologies in building a University Alumni Management System. It provides the core interface and functionality for alumni interaction, career opportunities, event participation, and administrative management.