const express = require('express');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));


let announcementsStore = [];

app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'AlmaConnect server is running' });
});

app.get('/api/announcements', (req, res) => {
    res.json(announcementsStore);
});

app.post('/api/announcements', (req, res) => {
    const { title, category, content, postedBy, postedById, isAdmin } = req.body;
    if (!isAdmin) {
        return res.status(403).json({ error: 'Only administrators can post announcements.' });
    }
    const newPost = {
        id: 'ann-' + Date.now(),
        title,
        category: category || 'General',
        content,
        postedBy,
        postedById,
        createdAt: new Date().toISOString(),
        updatedAt: null
    };
    announcementsStore.unshift(newPost);
    res.status(201).json(newPost);
});

app.put('/api/announcements/:id', (req, res) => {
    const { title, category, content, isAdmin } = req.body;
    if (!isAdmin) {
        return res.status(403).json({ error: 'Only administrators can edit announcements.' });
    }
    const idx = announcementsStore.findIndex(a => a.id === req.params.id);
    if (idx === -1) {
        return res.status(404).json({ error: 'Announcement not found.' });
    }
    announcementsStore[idx] = {
        ...announcementsStore[idx],
        title: title ?? announcementsStore[idx].title,
        category: category ?? announcementsStore[idx].category,
        content: content ?? announcementsStore[idx].content,
        updatedAt: new Date().toISOString()
    };
    res.json(announcementsStore[idx]);
});

app.delete('/api/announcements/:id', (req, res) => {
    const { isAdmin } = req.body || {};
    if (!isAdmin) {
        return res.status(403).json({ error: 'Only administrators can delete announcements.' });
    }
    announcementsStore = announcementsStore.filter(a => a.id !== req.params.id);
    res.json({ message: 'Announcement deleted successfully.' });
});

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.listen(PORT, () => {
    console.log(`AlmaConnect Portal running at http://localhost:${PORT}`);
});
