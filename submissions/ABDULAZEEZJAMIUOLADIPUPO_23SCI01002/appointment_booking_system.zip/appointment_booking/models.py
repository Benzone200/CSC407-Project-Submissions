"""Database models: users and appointments."""
from datetime import datetime, timezone

from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

db = SQLAlchemy()

ROLE_USER = "user"
ROLE_ADMIN = "admin"

SCHEDULED = "scheduled"
COMPLETED = "completed"
CANCELLED = "cancelled"
STATUSES = (SCHEDULED, COMPLETED, CANCELLED)
STATUS_LABELS = {SCHEDULED: "Upcoming", COMPLETED: "Completed", CANCELLED: "Cancelled"}


def utcnow():
    return datetime.now(timezone.utc)


class User(UserMixin, db.Model):
    __tablename__ = "users"
    __table_args__ = (
        db.CheckConstraint("role IN ('user', 'admin')", name="ck_users_role"),
    )

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), nullable=False, unique=True, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(10), nullable=False, default=ROLE_USER)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)

    appointments = db.relationship(
        "Appointment",
        back_populates="user",
        cascade="all, delete-orphan",
        order_by="Appointment.appointment_date, Appointment.appointment_time",
    )

    def set_password(self, password):
        # Werkzeug generates a salted hash (scrypt by default in Werkzeug 3).
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def is_admin(self):
        return self.role == ROLE_ADMIN


class Appointment(db.Model):
    __tablename__ = "appointments"
    __table_args__ = (
        db.CheckConstraint(
            "status IN ('scheduled', 'completed', 'cancelled')", name="ck_appointments_status"
        ),
        db.Index("ix_appointments_user_date", "user_id", "appointment_date"),
        # Booking rule: a date + time slot can hold only ONE non-cancelled appointment.
        # Cancelling an appointment frees its slot for someone else.
        db.Index(
            "uq_appointments_active_slot",
            "appointment_date",
            "appointment_time",
            unique=True,
            sqlite_where=db.text("status != 'cancelled'"),
        ),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    title = db.Column(db.String(100), nullable=False)
    appointment_date = db.Column(db.Date, nullable=False)
    appointment_time = db.Column(db.Time, nullable=False)
    notes = db.Column(db.String(500))
    status = db.Column(db.String(10), nullable=False, default=SCHEDULED, index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=utcnow)

    user = db.relationship("User", back_populates="appointments")

    @property
    def status_label(self):
        return STATUS_LABELS.get(self.status, self.status)
