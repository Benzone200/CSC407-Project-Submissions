"""Application configuration. Values come from environment variables (.env)."""
import os
from datetime import timedelta

from dotenv import load_dotenv

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))


def _env_bool(name, default=False):
    return os.environ.get(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


# Bookable times: every 30 minutes from 09:00 to 16:30.
SLOT_TIMES = [f"{h:02d}:{m:02d}" for h in range(9, 17) for m in (0, 30)]
MAX_DAYS_AHEAD = 90


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "")

    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL") or (
        "sqlite:///" + os.path.join(BASE_DIR, "booking.db")
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Session / cookie hardening
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _env_bool("SESSION_COOKIE_SECURE", False)  # True behind HTTPS
    SESSION_COOKIE_NAME = "slotline_session"
    PERMANENT_SESSION_LIFETIME = timedelta(hours=2)
    REMEMBER_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SAMESITE = "Lax"
    REMEMBER_COOKIE_SECURE = SESSION_COOKIE_SECURE

    # CSRF tokens live as long as the session
    WTF_CSRF_TIME_LIMIT = 7200

    # Reject oversized request bodies
    MAX_CONTENT_LENGTH = 64 * 1024
