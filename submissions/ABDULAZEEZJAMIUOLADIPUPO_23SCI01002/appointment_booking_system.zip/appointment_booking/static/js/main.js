/* Slotline front-end behaviour. Plain JavaScript; untrusted text is only ever written with textContent. */
(function () {
  'use strict';

  // Mobile navigation toggle
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('site-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  // Confirmation before destructive actions (forms with data-confirm)
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!window.confirm(form.getAttribute('data-confirm'))) {
        event.preventDefault();
      }
    });
  });

  function showErrors(form, messages) {
    var box = form.querySelector('.form-errors');
    if (!box) { return; }
    box.textContent = '';
    if (!messages.length) { box.hidden = true; return; }
    var list = document.createElement('ul');
    list.className = 'plain';
    messages.forEach(function (message) {
      var item = document.createElement('li');
      item.textContent = message;
      list.appendChild(item);
    });
    box.appendChild(list);
    box.hidden = false;
    box.scrollIntoView({ block: 'nearest' });
  }

  // Password rules (mirrors the server; the server is the real check)
  document.querySelectorAll('form[data-validate-password]').forEach(function (form) {
    form.addEventListener('submit', function (event) {
      var pw = form.querySelector('[data-new-password]');
      var confirm = form.querySelector('[data-confirm-password]');
      var errors = [];
      if (pw.value.length < 10) { errors.push('Password must be at least 10 characters.'); }
      if (!/[A-Za-z]/.test(pw.value) || !/\d/.test(pw.value)) {
        errors.push('Password must contain at least one letter and one number.');
      }
      if (pw.value !== confirm.value) { errors.push('Passwords do not match.'); }
      showErrors(form, errors);
      if (errors.length) { event.preventDefault(); }
    });
  });

  // Booking form: show taken/past times and validate before submitting
  var booking = document.querySelector('form[data-availability-url]');
  if (booking) {
    var dateInput = booking.querySelector('#date');
    var timeSelect = booking.querySelector('#time');
    var titleInput = booking.querySelector('#title');
    var taken = [];

    function startOf(dateValue, timeValue) {
      return new Date(dateValue + 'T' + timeValue + ':00'); // local time
    }

    function refreshTimes() {
      Array.prototype.forEach.call(timeSelect.options, function (option) {
        if (!option.value) { return; }
        var note = '';
        if (dateInput.value) {
          if (taken.indexOf(option.value) !== -1) { note = ' (booked)'; }
          else if (startOf(dateInput.value, option.value) <= new Date()) { note = ' (passed)'; }
        }
        option.disabled = note !== '';
        option.textContent = option.value + note;
      });
      if (timeSelect.selectedOptions.length && timeSelect.selectedOptions[0].disabled) {
        timeSelect.value = '';
      }
    }

    function loadAvailability() {
      if (!dateInput.value) { taken = []; refreshTimes(); return; }
      var url = booking.getAttribute('data-availability-url') + '?date=' + encodeURIComponent(dateInput.value);
      fetch(url, { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
        .then(function (response) { return response.ok ? response.json() : { taken: [] }; })
        .then(function (data) { taken = Array.isArray(data.taken) ? data.taken : []; refreshTimes(); })
        .catch(function () { taken = []; refreshTimes(); });
    }

    dateInput.addEventListener('change', loadAvailability);
    loadAvailability();

    booking.addEventListener('submit', function (event) {
      var errors = [];
      var title = titleInput.value.trim();
      if (title.length < 3 || title.length > 100) { errors.push('Purpose must be between 3 and 100 characters.'); }
      if (!dateInput.value) { errors.push('Choose a date.'); }
      if (!timeSelect.value) { errors.push('Choose a time.'); }
      if (dateInput.value && timeSelect.value && startOf(dateInput.value, timeSelect.value) <= new Date()) {
        errors.push("Appointments can't be booked in the past.");
      }
      showErrors(booking, errors);
      if (errors.length) { event.preventDefault(); }
    });
  }
})();
