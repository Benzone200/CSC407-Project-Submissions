"""Slotline - a small appointment booking application (Flask)."""
import re
import threading
import time
from datetime import date, datetime, timedelta
from functools import wraps
from urllib.parse import urljoin, urlparse

import click
from flask import (Flask, abort, flash, jsonify, redirect, render_template,
                   request, session, url_for)
from flask_login import (LoginManager, current_user, login_required,
                         login_user, logout_user)
from flask_wtf.csrf import CSRFError, CSRFProtect, generate_csrf
from markupsafe import Markup
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import joinedload
from werkzeug.security import check_password_hash, generate_password_hash

from config import MAX_DAYS_AHEAD, SLOT_TIMES, Config
from models import (CANCELLED, COMPLETED, ROLE_ADMIN, ROLE_USER, SCHEDULED,
                    STATUS_LABELS, STATUSES, Appointment, User, db)

app = Flask(__name__)
app.config.from_object(Config)

_key = app.config.get("SECRET_KEY") or ""
if len(_key) < 32 or _key.startswith("replace-this"):
    raise RuntimeError(
        "SECRET_KEY is missing or too weak. Copy .env to .env and set SECRET_KEY to the "
        "output of: python -c \"import secrets; print(secrets.token_hex(32))\""
    )

db.init_app(app)
csrf = CSRFProtect(app)

login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message = "Please log in to continue."
login_manager.login_message_category = "error"
login_manager.session_protection = "strong"

with app.app_context():
    db.create_all()


@login_manager.user_loader
def load_user(user_id):
    try:
        return db.session.get(User, int(user_id))
    except (TypeError, ValueError):
        return None


# --------------------------------------------------------------------------- helpers
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
DUMMY_HASH = generate_password_hash("not-a-real-password")  # equalises timing for unknown emails


def clean(value, multiline=False):
    """Trim text, drop control characters, and (for single-line fields) collapse whitespace."""
    value = CONTROL_RE.sub("", (value or "").replace("\r\n", "\n")).strip()
    if not multiline:
        value = re.sub(r"\s+", " ", value)
    return value


def validate_name(name):
    if not 2 <= len(name) <= 80:
        return ["Full name must be between 2 and 80 characters."]
    return []


def validate_email(email):
    if len(email) > 120 or not EMAIL_RE.match(email):
        return ["Enter a valid email address (up to 120 characters)."]
    return []


def validate_password(password):
    errors = []
    if len(password) < 10:
        errors.append("Password must be at least 10 characters.")
    if len(password) > 128:
        errors.append("Password must be 128 characters or fewer.")
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        errors.append("Password must contain at least one letter and one number.")
    return errors


def is_safe_next(target):
    if not target or not target.startswith("/") or target.startswith("//") or "\\" in target:
        return False
    ref, test = urlparse(request.host_url), urlparse(urljoin(request.host_url, target))
    return test.scheme in ("http", "https") and ref.netloc == test.netloc


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user.is_authenticated:
            return login_manager.unauthorized()
        if not current_user.is_admin:  # enforced on the server, not just hidden in the UI
            abort(403)
        return view(*args, **kwargs)
    return wrapped


# Login rate limiting (in memory, per process): 5 failures / 15 min per email, 20 per IP.
_attempts, _lock = {}, threading.Lock()
WINDOW, EMAIL_LIMIT, IP_LIMIT = 900, 5, 20


def _rate_keys(email):
    return [(f"ip:{request.remote_addr}", IP_LIMIT), (f"email:{email}", EMAIL_LIMIT)]


def login_limited(email):
    now = time.time()
    with _lock:
        for key, limit in _rate_keys(email):
            hits = [t for t in _attempts.get(key, []) if now - t < WINDOW]
            if hits:
                _attempts[key] = hits
            else:
                _attempts.pop(key, None)
            if len(hits) >= limit:
                return True
    return False


def record_failure(email):
    with _lock:
        for key, _ in _rate_keys(email):
            _attempts.setdefault(key, []).append(time.time())


def clear_failures(email):
    with _lock:
        _attempts.pop(f"email:{email}", None)


# --------------------------------------------------------------------------- hooks
@app.context_processor
def inject_globals():
    return {
        "csrf_field": Markup(
            f'<input type="hidden" name="csrf_token" value="{generate_csrf()}">'
        ),
        "status_labels": STATUS_LABELS,
    }


@app.before_request
def complete_past_appointments():
    """Scheduled appointments whose time has passed become 'completed'."""
    if request.endpoint in (None, "static") or not current_user.is_authenticated:
        return
    now = datetime.now()
    changed = Appointment.query.filter(
        Appointment.status == SCHEDULED,
        db.or_(
            Appointment.appointment_date < now.date(),
            db.and_(Appointment.appointment_date == now.date(),
                    Appointment.appointment_time <= now.time()),
        ),
    ).update({"status": COMPLETED}, synchronize_session=False)
    if changed:
        db.session.commit()


@app.after_request
def security_headers(response):
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
        "form-action 'self'; frame-ancestors 'none'; base-uri 'self'"
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "same-origin"
    if app.config["SESSION_COOKIE_SECURE"]:
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    if current_user.is_authenticated:
        response.headers["Cache-Control"] = "no-store"
    return response


def render_error(code, title, message):
    return render_template("error.html", code=code, title=title, message=message), code


@app.errorhandler(400)
def bad_request(_):
    return render_error(400, "Bad request", "The request could not be understood.")


@app.errorhandler(CSRFError)
def csrf_failed(_):
    return render_error(400, "Session expired",
                        "Your form expired or could not be verified. Go back, refresh the page and try again.")


@app.errorhandler(403)
def forbidden(_):
    return render_error(403, "Access denied", "You don't have permission to view this page.")


@app.errorhandler(404)
def not_found(_):
    return render_error(404, "Page not found", "That page doesn't exist or isn't available to you.")


@app.errorhandler(413)
def too_large(_):
    return render_error(413, "Request too large", "The data you sent was too large.")


@app.errorhandler(500)
def server_error(_):
    db.session.rollback()
    return render_error(500, "Something went wrong", "An unexpected error occurred. Please try again.")


# --------------------------------------------------------------------------- public pages
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/security")
def security():
    return render_template("security.html", slot_count=len(SLOT_TIMES))


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    form, errors = {}, []
    if request.method == "POST":
        form["full_name"] = clean(request.form.get("full_name"))
        form["email"] = (request.form.get("email") or "").strip().lower()
        password = request.form.get("password") or ""
        confirm = request.form.get("confirm_password") or ""
        errors += validate_name(form["full_name"]) + validate_email(form["email"])
        errors += validate_password(password)
        if password != confirm:
            errors.append("Passwords do not match.")
        if not errors and User.query.filter_by(email=form["email"]).first():
            errors.append("An account with this email already exists. Try logging in instead.")
        if not errors:
            user = User(full_name=form["full_name"], email=form["email"], role=ROLE_USER)
            user.set_password(password)
            db.session.add(user)
            try:
                db.session.commit()
            except IntegrityError:
                db.session.rollback()
                errors.append("An account with this email already exists. Try logging in instead.")
            else:
                flash("Account created. Log in to book your first appointment.", "success")
                return redirect(url_for("login"))
    return render_template("register.html", form=form, errors=errors), (400 if errors else 200)


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    next_url = request.values.get("next", "")
    email = ""
    if request.method == "POST":
        email = (request.form.get("email") or "").strip().lower()[:120]
        password = request.form.get("password") or ""
        if login_limited(email):
            flash("Too many failed attempts. Please wait 15 minutes and try again.", "error")
            return render_template("login.html", email=email, next_url=next_url), 429
        user = User.query.filter_by(email=email).first()
        # Always run one hash check so response time doesn't reveal whether the email exists.
        valid = check_password_hash(user.password_hash if user else DUMMY_HASH, password[:128])
        if user and valid:
            clear_failures(email)
            session.clear()
            login_user(user)
            session.permanent = True
            return redirect(next_url if is_safe_next(next_url) else url_for("dashboard"))
        record_failure(email)
        flash("Incorrect email or password.", "error")
        return render_template("login.html", email=email, next_url=next_url), 401
    return render_template("login.html", email=email, next_url=next_url)


@app.post("/logout")
@login_required
def logout():
    logout_user()
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("index"))


# --------------------------------------------------------------------------- user pages
@app.route("/dashboard")
@login_required
def dashboard():
    rows = (db.session.query(Appointment.status, db.func.count(Appointment.id))
            .filter(Appointment.user_id == current_user.id)
            .group_by(Appointment.status).all())
    counts = dict(rows)
    stats = {
        "total": sum(counts.values()),
        "upcoming": counts.get(SCHEDULED, 0),
        "completed": counts.get(COMPLETED, 0),
        "cancelled": counts.get(CANCELLED, 0),
    }
    recent = (Appointment.query.filter(Appointment.user_id == current_user.id)
              .order_by(Appointment.created_at.desc()).limit(5).all())
    return render_template("dashboard.html", stats=stats, recent=recent)


@app.route("/appointments")
@login_required
def appointments():
    base = Appointment.query.filter(Appointment.user_id == current_user.id)
    order_asc = (Appointment.appointment_date.asc(), Appointment.appointment_time.asc())
    order_desc = (Appointment.appointment_date.desc(), Appointment.appointment_time.desc())
    return render_template(
        "appointments.html",
        upcoming=base.filter(Appointment.status == SCHEDULED).order_by(*order_asc).all(),
        completed=base.filter(Appointment.status == COMPLETED).order_by(*order_desc).all(),
        cancelled=base.filter(Appointment.status == CANCELLED).order_by(*order_desc).all(),
    )


@app.get("/appointments/availability")
@login_required
def availability():
    """Returns only the booked times for a date (no names or other details)."""
    try:
        day = date.fromisoformat(request.args.get("date", ""))
    except ValueError:
        return jsonify(error="Invalid date"), 400
    booked = Appointment.query.filter(Appointment.appointment_date == day,
                                      Appointment.status != CANCELLED).all()
    return jsonify(taken=[a.appointment_time.strftime("%H:%M") for a in booked])


@app.route("/appointments/new", methods=["GET", "POST"])
@login_required
def book_appointment():
    form, errors = {}, []
    if request.method == "POST":
        form = {
            "title": clean(request.form.get("title")),
            "date": (request.form.get("date") or "").strip(),
            "time": (request.form.get("time") or "").strip(),
            "notes": clean(request.form.get("notes"), multiline=True),
        }
        if not 3 <= len(form["title"]) <= 100:
            errors.append("Purpose must be between 3 and 100 characters.")
        try:
            day = date.fromisoformat(form["date"])
        except ValueError:
            day = None
            errors.append("Choose a valid date.")
        if form["time"] not in SLOT_TIMES:
            errors.append("Choose one of the available times.")
        if len(form["notes"]) > 500:
            errors.append("Notes must be 500 characters or fewer.")

        if not errors:
            start = datetime.combine(day, datetime.strptime(form["time"], "%H:%M").time())
            now = datetime.now()
            if start <= now:
                errors.append("Appointments can't be booked in the past.")
            elif start > now + timedelta(days=MAX_DAYS_AHEAD):
                errors.append(f"Appointments can be booked up to {MAX_DAYS_AHEAD} days ahead.")
            elif Appointment.query.filter(Appointment.appointment_date == start.date(),
                                          Appointment.appointment_time == start.time(),
                                          Appointment.status != CANCELLED).first():
                errors.append("That time is already booked. Choose another slot.")

        if not errors:
            db.session.add(Appointment(
                user_id=current_user.id, title=form["title"], appointment_date=start.date(),
                appointment_time=start.time(), notes=form["notes"] or None, status=SCHEDULED))
            try:
                db.session.commit()
            except IntegrityError:  # someone else took the slot between check and insert
                db.session.rollback()
                errors.append("That time was just booked by someone else. Choose another slot.")
            else:
                flash(f"Booked: {form['title']} on {start:%A %d %B %Y} at {start:%H:%M}.", "success")
                return redirect(url_for("appointments"))

    today = date.today()
    return render_template(
        "book_appointment.html", form=form, errors=errors, slots=SLOT_TIMES,
        min_date=today.isoformat(), max_date=(today + timedelta(days=MAX_DAYS_AHEAD)).isoformat(),
        max_days=MAX_DAYS_AHEAD), (400 if errors else 200)


@app.post("/appointments/<int:appointment_id>/cancel")
@login_required
def cancel_appointment(appointment_id):
    appt = db.session.get(Appointment, appointment_id)
    if appt is None or appt.user_id != current_user.id:
        abort(404)  # same response whether it doesn't exist or belongs to someone else
    if appt.status != SCHEDULED:
        flash("Only upcoming appointments can be cancelled.", "error")
    else:
        appt.status = CANCELLED
        db.session.commit()
        flash("Appointment cancelled.", "success")
    return redirect(url_for("appointments"))


def render_profile(name_errors=None, pw_errors=None, name_value=None, status=200):
    return render_template("profile.html", name_errors=name_errors or [], pw_errors=pw_errors or [],
                           name_value=name_value if name_value is not None else current_user.full_name), status


@app.get("/profile")
@login_required
def profile():
    return render_profile()


@app.post("/profile/name")
@login_required
def update_name():
    name = clean(request.form.get("full_name"))
    errors = validate_name(name)
    if errors:
        return render_profile(name_errors=errors, name_value=name, status=400)
    current_user.full_name = name  # role and email are never read from this form
    db.session.commit()
    flash("Name updated.", "success")
    return redirect(url_for("profile"))


@app.post("/profile/password")
@login_required
def update_password():
    current = request.form.get("current_password") or ""
    new = request.form.get("new_password") or ""
    confirm = request.form.get("confirm_password") or ""
    errors = []
    if not current_user.check_password(current[:128]):
        errors.append("Current password is incorrect.")
    errors += validate_password(new)
    if new != confirm:
        errors.append("New passwords do not match.")
    if not errors and new == current:
        errors.append("Choose a password different from your current one.")
    if errors:
        return render_profile(pw_errors=errors, status=400)
    current_user.set_password(new)
    db.session.commit()
    flash("Password changed.", "success")
    return redirect(url_for("profile"))


# --------------------------------------------------------------------------- admin
@app.route("/admin")
@admin_required
def admin_dashboard():
    rows = (db.session.query(Appointment.status, db.func.count(Appointment.id))
            .group_by(Appointment.status).all())
    counts = dict(rows)
    stats = {
        "users": User.query.count(),
        "appointments": sum(counts.values()),
        "upcoming": counts.get(SCHEDULED, 0),
        "completed": counts.get(COMPLETED, 0),
        "cancelled": counts.get(CANCELLED, 0),
    }
    users = (db.session.query(User, db.func.count(Appointment.id))
             .outerjoin(Appointment, Appointment.user_id == User.id)
             .group_by(User.id).order_by(User.created_at.desc()).all())
    appts = (Appointment.query.options(joinedload(Appointment.user))
             .order_by(Appointment.appointment_date.desc(), Appointment.appointment_time.desc()).all())
    return render_template("admin_dashboard.html", stats=stats, users=users, appts=appts,
                           statuses=STATUSES)


@app.post("/admin/appointments/<int:appointment_id>/status")
@admin_required
def admin_set_status(appointment_id):
    appt = db.get_or_404(Appointment, appointment_id)
    status = request.form.get("status")
    if status not in STATUSES:
        flash("Invalid status.", "error")
    else:
        appt.status = status
        try:
            db.session.commit()
            flash("Status updated.", "success")
        except IntegrityError:
            db.session.rollback()
            flash("Can't reopen this appointment: its slot has been booked by someone else.", "error")
    return redirect(url_for("admin_dashboard"))


@app.post("/admin/appointments/<int:appointment_id>/delete")
@admin_required
def admin_delete_appointment(appointment_id):
    appt = db.get_or_404(Appointment, appointment_id)
    db.session.delete(appt)
    db.session.commit()
    flash("Appointment deleted.", "success")
    return redirect(url_for("admin_dashboard"))


# --------------------------------------------------------------------------- CLI
@app.cli.command("init-db")
def init_db_command():
    """Create database tables (also done automatically on startup)."""
    db.create_all()
    click.echo("Database ready.")


@app.cli.command("create-admin")
@click.option("--name", prompt="Full name")
@click.option("--email", prompt="Email")
@click.password_option()
def create_admin_command(name, email, password):
    """Create the first administrator, or promote an existing user by email."""
    name, email = clean(name), email.strip().lower()
    problems = validate_name(name) + validate_email(email) + validate_password(password)
    if problems:
        raise click.ClickException(" ".join(problems))
    user = User.query.filter_by(email=email).first()
    if user:
        user.role = ROLE_ADMIN
        click.echo(f"{email} already existed and is now an administrator.")
    else:
        user = User(full_name=name, email=email, role=ROLE_ADMIN)
        user.set_password(password)
        db.session.add(user)
        click.echo(f"Administrator {email} created.")
    db.session.commit()


if __name__ == "__main__":
    import os
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1")
