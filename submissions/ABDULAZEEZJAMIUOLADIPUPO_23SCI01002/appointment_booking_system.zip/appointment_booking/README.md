# Slotline: Appointment Booking

A small, secure appointment booking web app. Users register, log in, book time slots, view their
appointments and cancel upcoming ones. Administrators can manage all users and appointments.

## Technology

- **Backend:** Python, Flask, Flask-SQLAlchemy, Flask-Login, Flask-WTF (CSRF), Werkzeug password hashing
- **Database:** SQLite
- **Frontend:** HTML5, CSS3, vanilla JavaScript, Jinja2 templates

## Project structure

```
appointment_booking/
├── app.py              routes, security helpers, admin and CLI commands
├── models.py           User and Appointment models
├── config.py           settings read from environment variables
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/          base, _macros, index, login, register, dashboard,
│                       book_appointment, appointments, profile,
│                       admin_dashboard, security, error
└── static/
    ├── css/style.css
    └── js/main.js
```

## Setup

You need Python 3.9 or newer. Run these commands inside the `appointment_booking` folder.

1. **Create and activate a virtual environment**

   macOS / Linux:
   ```
   python3 -m venv venv
   source venv/bin/activate
   ```
   Windows (PowerShell):
   ```
   python -m venv venv
   venv\Scripts\Activate.ps1
   ```

2. **Install dependencies**
   ```
   pip install -r requirements.txt
   ```

3. **Configure environment variables**

   Copy `.env.example` to `.env` (`cp .env.example .env` on macOS/Linux, `copy .env.example .env` on Windows),
   then generate a secret key and paste it as the value of `SECRET_KEY`:
   ```
   python -c "import secrets; print(secrets.token_hex(32))"
   ```
   The app will not start without a strong `SECRET_KEY`.

4. **Initialize the database**
   ```
   flask --app app init-db
   ```
   This creates `booking.db`. (The tables are also created automatically when the app starts.)

5. **Create the first administrator**
   ```
   flask --app app create-admin
   ```
   You will be asked for a name, email and password. Running it with the email of an existing user
   promotes that user to administrator. Registering through the website always creates a regular user.

6. **Start the app**
   ```
   flask --app app run
   ```
   Open **http://127.0.0.1:5000** in your browser. Add `--debug` for auto-reload during development.

## Using the app

- **Register** an account, then **log in**.
- **Book Appointment:** enter a purpose, pick a date and a free time (09:00 to 16:30, every 30 minutes,
  up to 90 days ahead), add optional notes, and confirm.
- **My Appointments:** see upcoming, completed and cancelled appointments. Cancel an upcoming one with the Cancel button.
  Appointments whose time has passed are marked completed automatically.
- **Profile:** change your name or password (your current password is required).
- **Security:** a description of the protections implemented in this app.
- **Admin Dashboard** (admins only): statistics, all users, all appointments with details, status changes and deletion.

**Booking rule:** each date and time slot can hold one non-cancelled appointment, enforced by a unique
database index as well as an application check. Cancelling frees the slot.

## Production notes

- Serve over HTTPS and set `SESSION_COOKIE_SECURE=true`.
- Run with a production server such as gunicorn instead of the Flask development server.
- The login rate limiter is in memory (per process), so it resets on restart.
- Back up `booking.db` and never commit `.env`.
