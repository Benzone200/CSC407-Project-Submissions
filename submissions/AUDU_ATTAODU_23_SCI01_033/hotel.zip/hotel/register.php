<?php require 'config.php';
$err = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $name = trim($_POST['name'] ?? ''); $email = trim($_POST['email'] ?? ''); $pw = $_POST['password'] ?? '';
    // Input validation (server side)
    if ($name === '' || strlen($name) > 100) $err[] = 'Enter your name (max 100 characters).';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $err[] = 'Enter a valid email address.';
    if (strlen($pw) < 8 || !preg_match('/[A-Za-z]/', $pw) || !preg_match('/\d/', $pw)) $err[] = 'Password must be at least 8 characters with letters and numbers.';
    if (!$err) {
        $s = $pdo->prepare('SELECT id FROM users WHERE email=?'); $s->execute([$email]);
        if ($s->fetch()) $err[] = 'That email is already registered.';
        else {
            // Password hashing: the real password is never stored
            $pdo->prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)')
                ->execute([$name, $email, password_hash($pw, PASSWORD_DEFAULT)]);
            $_SESSION['flash'] = 'Registration successful. Please log in.';
            header('Location: login.php'); exit;
        }
    }
}
include 'header.php'; ?>
<h1>Register</h1>
<?php foreach ($err as $m) echo '<p class="error">' . e($m) . '</p>'; ?>
<form class="box" method="post">
  <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
  <label>Full name</label><input name="name" required maxlength="100" value="<?= e($_POST['name'] ?? '') ?>">
  <label>Email</label><input type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>">
  <label>Password (8+ chars, letters and numbers)</label><input type="password" name="password" required>
  <button>Create account</button>
</form>
<?php include 'footer.php';
