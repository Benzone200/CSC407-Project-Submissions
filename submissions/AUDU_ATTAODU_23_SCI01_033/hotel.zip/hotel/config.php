<?php
// Settings come from environment variables when deployed; defaults work for XAMPP.
$DB_HOST = getenv('DB_HOST') ?: 'localhost';
$DB_NAME = getenv('DB_NAME') ?: 'hotel_db';
$DB_USER = getenv('DB_USER') ?: 'root';
$DB_PASS = getenv('DB_PASS') ?: '';

// Secure session cookie: not readable by JavaScript, not sent from other sites
session_set_cookie_params(['httponly' => true, 'samesite' => 'Strict']);
session_start();

// Session timeout: log out after 15 minutes of inactivity
if (isset($_SESSION['last']) && time() - $_SESSION['last'] > 900) {
    session_unset(); session_destroy(); session_start();
    $_SESSION['flash'] = 'Session expired. Please log in again.';
}
$_SESSION['last'] = time();

try {
    // Prepared statements are used everywhere = protection against SQL injection
    $pdo = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $ex) {
    error_log($ex->getMessage());           // details go to the log, not the screen
    die('Database connection error.');
}

// Escape output = protection against XSS
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// CSRF token: stops other websites from submitting forms on the user's behalf
function csrf() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function check_csrf() {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(400); die('Invalid request.'); }
}

// Access control
function require_login() {
    if (empty($_SESSION['uid'])) { header('Location: login.php'); exit; }
}
function require_admin() {
    require_login();
    if ($_SESSION['role'] !== 'admin') { http_response_code(403); die('Access denied.'); }
}
