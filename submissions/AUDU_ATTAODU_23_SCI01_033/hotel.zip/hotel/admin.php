<?php require 'config.php'; require_admin();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $status = $_POST['status'] ?? '';
    if (in_array($status, ['confirmed', 'cancelled'], true))
        $pdo->prepare('UPDATE reservations SET status=? WHERE id=?')->execute([$status, (int)($_POST['id'] ?? 0)]);
    header('Location: admin.php'); exit;
}
$total = $pdo->query("SELECT COUNT(*) FROM reservations")->fetchColumn();
$pending = $pdo->query("SELECT COUNT(*) FROM reservations WHERE status='pending'")->fetchColumn();
$revenue = $pdo->query("SELECT COALESCE(SUM(total),0) FROM reservations WHERE status='confirmed'")->fetchColumn();
$users = $pdo->query("SELECT COUNT(*) FROM users WHERE role='guest'")->fetchColumn();
$list = $pdo->query('SELECT r.*, u.name, rm.room_number FROM reservations r JOIN users u ON u.id=r.user_id JOIN rooms rm ON rm.id=r.room_id ORDER BY r.created_at DESC')->fetchAll();
include 'header.php'; ?>
<h1>Admin Dashboard</h1>
<div class="stats">
<div class="card"><h2><?= (int)$total ?></h2>Reservations</div><div class="card"><h2><?= (int)$pending ?></h2>Pending</div>
<div class="card"><h2><?= (int)$users ?></h2>Guests</div><div class="card"><h2>NGN <?= number_format($revenue) ?></h2>Confirmed revenue</div></div>
<h2>All Reservations</h2>
<div class="wrap"><table><tr><th>Guest</th><th>Room</th><th>In</th><th>Out</th><th>Total</th><th>Status</th><th>Action</th></tr>
<?php foreach ($list as $b): ?>
<tr><td><?= e($b['name']) ?></td><td><?= e($b['room_number']) ?></td><td><?= e($b['check_in']) ?></td><td><?= e($b['check_out']) ?></td>
<td><?= number_format($b['total'], 2) ?></td><td><?= e($b['status']) ?></td>
<td><form method="post"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>">
<button class="ok" name="status" value="confirmed">Confirm</button> <button class="danger" name="status" value="cancelled">Cancel</button></form></td></tr>
<?php endforeach; ?></table></div>
<?php include 'footer.php';
