<?php require 'config.php'; require_login();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    // user_id check = a guest can only cancel their OWN bookings
    $pdo->prepare("UPDATE reservations SET status='cancelled' WHERE id=? AND user_id=? AND status<>'cancelled'")
        ->execute([(int)($_POST['id'] ?? 0), $_SESSION['uid']]);
    $_SESSION['flash'] = 'Booking cancelled.'; header('Location: my_bookings.php'); exit;
}
$s = $pdo->prepare('SELECT r.*, rm.room_number, rm.type FROM reservations r JOIN rooms rm ON rm.id=r.room_id WHERE r.user_id=? ORDER BY r.check_in DESC');
$s->execute([$_SESSION['uid']]); $list = $s->fetchAll();
include 'header.php'; ?>
<h1>My Bookings</h1>
<div class="wrap"><table><tr><th>Room</th><th>Check-in</th><th>Check-out</th><th>Total (NGN)</th><th>Status</th><th></th></tr>
<?php foreach ($list as $b): ?>
<tr><td><?= e($b['room_number']) ?> (<?= e($b['type']) ?>)</td><td><?= e($b['check_in']) ?></td><td><?= e($b['check_out']) ?></td>
<td><?= number_format($b['total'], 2) ?></td><td><?= e($b['status']) ?></td>
<td><?php if ($b['status'] !== 'cancelled'): ?><form method="post"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
<input type="hidden" name="id" value="<?= (int)$b['id'] ?>"><button class="danger">Cancel</button></form><?php endif; ?></td></tr>
<?php endforeach; ?></table></div>
<?php if (!$list) echo '<p>No bookings yet.</p>';
include 'footer.php';
