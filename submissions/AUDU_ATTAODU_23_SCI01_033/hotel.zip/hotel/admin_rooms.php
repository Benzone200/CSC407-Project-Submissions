<?php require 'config.php'; require_admin();
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $num = trim($_POST['room_number'] ?? ''); $type = $_POST['type'] ?? ''; $price = $_POST['price'] ?? ''; $desc = trim($_POST['description'] ?? '');
    if ($num === '' || strlen($num) > 10 || !in_array($type, ['Single', 'Double', 'Suite'], true) || !is_numeric($price) || $price <= 0 || strlen($desc) > 255) {
        $err = 'Please fill in all fields correctly.';
    } else {
        try {
            $pdo->prepare('INSERT INTO rooms(room_number,type,price,description) VALUES(?,?,?,?)')->execute([$num, $type, $price, $desc]);
            $_SESSION['flash'] = 'Room added.'; header('Location: admin_rooms.php'); exit;
        } catch (PDOException $ex) { $err = 'That room number already exists.'; }
    }
}
$rooms = $pdo->query('SELECT * FROM rooms ORDER BY room_number')->fetchAll();
include 'header.php'; ?>
<h1>Manage Rooms</h1>
<?php if ($err) echo '<p class="error">' . e($err) . '</p>'; ?>
<form class="box" method="post"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
<label>Room number</label><input name="room_number" required maxlength="10">
<label>Type</label><select name="type"><option>Single</option><option>Double</option><option>Suite</option></select>
<label>Price per night (NGN)</label><input type="number" name="price" min="1" step="0.01" required>
<label>Description</label><input name="description" maxlength="255"><button>Add room</button></form>
<div class="wrap"><table><tr><th>No.</th><th>Type</th><th>Price</th><th>Description</th></tr>
<?php foreach ($rooms as $r) echo '<tr><td>' . e($r['room_number']) . '</td><td>' . e($r['type']) . '</td><td>' . number_format($r['price'], 2) . '</td><td>' . e($r['description']) . '</td></tr>'; ?>
</table></div>
<?php include 'footer.php';
