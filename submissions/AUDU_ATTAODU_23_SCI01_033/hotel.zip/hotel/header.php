<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Grand Hotel Reservations</title><link rel="stylesheet" href="style.css"></head><body>
<nav>
  <a href="index.php" class="brand">Grand Hotel</a>
  <a href="rooms.php">Rooms</a>
  <?php if (!empty($_SESSION['uid'])): ?>
    <a href="my_bookings.php">My Bookings</a>
    <?php if ($_SESSION['role'] === 'admin'): ?>
      <a href="admin.php">Admin</a><a href="admin_rooms.php">Manage Rooms</a>
    <?php endif; ?>
    <a href="security.php">Security</a>
    <a href="logout.php">Logout (<?= e($_SESSION['name']) ?>)</a>
  <?php else: ?>
    <a href="security.php">Security</a><a href="login.php">Login</a><a href="register.php">Register</a>
  <?php endif; ?>
</nav>
<main>
<?php if (!empty($_SESSION['flash'])) { echo '<p class="flash">' . e($_SESSION['flash']) . '</p>'; unset($_SESSION['flash']); } ?>
