<?php require 'config.php';
$in = $_GET['check_in'] ?? ''; $out = $_GET['check_out'] ?? '';
$type = $_GET['type'] ?? ''; $max = $_GET['max_price'] ?? '';
$valid = false;
$d1 = DateTime::createFromFormat('Y-m-d', $in); $d2 = DateTime::createFromFormat('Y-m-d', $out);
if ($d1 && $d2 && $d1->format('Y-m-d') === $in && $d2->format('Y-m-d') === $out && $d2 > $d1) $valid = true;

$sql = 'SELECT * FROM rooms WHERE 1=1'; $p = [];
if (in_array($type, ['Single', 'Double', 'Suite'], true)) { $sql .= ' AND type=?'; $p[] = $type; }
if (is_numeric($max) && $max > 0) { $sql .= ' AND price<=?'; $p[] = $max; }
if ($valid) {   // only show rooms with no overlapping booking
    $sql .= " AND NOT EXISTS (SELECT 1 FROM reservations r WHERE r.room_id=rooms.id AND r.status<>'cancelled' AND r.check_in<? AND r.check_out>?)";
    $p[] = $out; $p[] = $in;
}
$s = $pdo->prepare($sql . ' ORDER BY price'); $s->execute($p); $rooms = $s->fetchAll();
include 'header.php'; ?>
<h1>Find a Room</h1>
<form class="box" method="get">
  <label>Check-in</label><input type="date" name="check_in" value="<?= e($in) ?>">
  <label>Check-out</label><input type="date" name="check_out" value="<?= e($out) ?>">
  <label>Room type</label><select name="type"><option value="">Any</option>
    <?php foreach (['Single', 'Double', 'Suite'] as $t) echo '<option' . ($type === $t ? ' selected' : '') . '>' . $t . '</option>'; ?></select>
  <label>Max price per night (NGN)</label><input type="number" name="max_price" min="0" value="<?= e($max) ?>">
  <button>Search</button>
</form>
<?php if (!$valid && ($in || $out)) echo '<p class="error">Enter valid dates (check-out must be after check-in).</p>'; ?>
<?php foreach ($rooms as $r): ?>
  <div class="card room"><div class="pic pic-<?= e($r['type']) ?>"></div><div class="info"><h2>Room <?= e($r['room_number']) ?> - <?= e($r['type']) ?></h2>
  <p><?= e($r['description']) ?></p><p><b>NGN <?= number_format($r['price'], 2) ?></b> per night</p>
  <?php if ($valid && !empty($_SESSION['uid'])): ?>
    <form method="post" action="book.php">
      <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
      <input type="hidden" name="room_id" value="<?= (int)$r['id'] ?>">
      <input type="hidden" name="check_in" value="<?= e($in) ?>"><input type="hidden" name="check_out" value="<?= e($out) ?>">
      <button>Book this room</button></form>
  <?php elseif (!$valid): ?><small>Choose dates to book.</small>
  <?php else: ?><a href="login.php">Log in to book</a><?php endif; ?></div></div>
<?php endforeach; if (!$rooms) echo '<p>No rooms found.</p>';
include 'footer.php';
