<?php require 'config.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    // Simple brute-force protection: 5 failed attempts = 5 minute lock
    if (($_SESSION['fails'] ?? 0) >= 5 && time() - ($_SESSION['fail_time'] ?? 0) < 300) {
        $err = 'Too many failed attempts. Try again in 5 minutes.';
    } else {
        $s = $pdo->prepare('SELECT * FROM users WHERE email=?'); $s->execute([trim($_POST['email'] ?? '')]);
        $u = $s->fetch();
        if ($u && password_verify($_POST['password'] ?? '', $u['password_hash'])) {
            session_regenerate_id(true);   // prevents session fixation
            $_SESSION['uid'] = $u['id']; $_SESSION['name'] = $u['name']; $_SESSION['role'] = $u['role'];
            $_SESSION['fails'] = 0;
            header('Location: index.php'); exit;
        }
        $_SESSION['fails'] = ($_SESSION['fails'] ?? 0) + 1; $_SESSION['fail_time'] = time();
        $err = 'Invalid email or password.';   // same message either way
    }
}
include 'header.php'; ?>
<h1>Login</h1>
<?php if ($err) echo '<p class="error">' . e($err) . '</p>'; ?>
<form class="box" method="post">
  <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
  <label>Email</label><input type="email" name="email" required>
  <label>Password</label><input type="password" name="password" required>
  <button>Login</button>
</form>
<?php include 'footer.php';
