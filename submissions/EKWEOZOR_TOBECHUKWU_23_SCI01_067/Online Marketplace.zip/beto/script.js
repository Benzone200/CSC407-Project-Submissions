// =============================================
// beto marketplace - main script
// Data is saved in the browser using localStorage
// =============================================


// ---------- 1. Starting products ----------
const defaultProducts = [
  {
    id: 1,
    name: "Red Rising Series (6 Books)",
    price: 45000,
    category: "Books",
    condition: "Like new",
    seller: "Tolu's Bookshelf",
    image: "images/red-rising-series.jpg",
    description: "Pierce Brown's full Red Rising saga in paperback. Red Rising, Golden Son, Morning Star, Iron Gold, Dark Age and Light Bringer."
  },
  {
    id: 2,
    name: "The Poppy War Trilogy",
    price: 28000,
    category: "Books",
    condition: "Like new",
    seller: "Tolu's Bookshelf",
    image: "images/poppy-war-trilogy.jpg",
    description: "R.F. Kuang's trilogy in paperback. The Poppy War, The Dragon Republic and The Burning God."
  },
  {
    id: 3,
    name: "Dior Black Lace Mary Jane Pumps",
    price: 480000,
    category: "Shoes",
    condition: "Gently used",
    seller: "Closet by Zara O.",
    image: "images/dior-lace-mary-janes.jpg",
    description: "Christian Dior black embroidered lace Mary Janes with crossover buckle straps. Worn twice."
  },
  {
    id: 4,
    name: "Chanel Tweed Slingback Flats",
    price: 950000,
    category: "Shoes",
    condition: "New",
    seller: "Closet by Zara O.",
    image: "images/chanel-tweed-slingbacks.jpg",
    description: "Cream tweed slingbacks with a black cap toe and CC button details. Comes with the box."
  },
  {
    id: 5,
    name: "Adidas Samba OG (Pink and Maroon)",
    price: 85000,
    category: "Shoes",
    condition: "New",
    seller: "Kicks by Dami",
    image: "images/adidas-samba-pink.jpg",
    description: "Pink suede Sambas with maroon stripes and a gum sole. Brand new."
  },
  {
    id: 6,
    name: "Talbots Brown Patent Ballet Flats",
    price: 35000,
    category: "Shoes",
    condition: "Like new",
    seller: "Ada's Finds",
    image: "images/talbots-ballet-flats.jpg",
    description: "Chocolate brown patent leather ballet flats with a small bow at the toe."
  },
  {
    id: 7,
    name: "Mango Brown Patent Slingback Heels",
    price: 48000,
    category: "Shoes",
    condition: "Like new",
    seller: "Ada's Finds",
    image: "images/mango-slingback-heels.jpg",
    description: "MNG pointed toe slingback heels in brown patent leather. Mid height stiletto."
  },
  {
    id: 8,
    name: "Plum Sequin Butterfly Halter Top",
    price: 30000,
    category: "Clothing",
    condition: "Gently used",
    seller: "Y2K Vault",
    image: "images/butterfly-halter-top.jpg",
    description: "Sheer plum mesh halter top with sequin butterfly and flower details and beaded lines."
  },
  {
    id: 9,
    name: "Coach Signature Tote in Burgundy (2000s)",
    price: 120000,
    category: "Bags",
    condition: "Gently used",
    seller: "Y2K Vault",
    image: "images/coach-burgundy-tote.jpg",
    description: "Vintage Coach signature jacquard tote with patent leather trim. Flower and cherry charms included."
  },
  {
    id: 10,
    name: "Burgundy Patent Shoulder Bag",
    price: 22000,
    category: "Bags",
    condition: "New",
    seller: "Kemi Accessories",
    image: "images/burgundy-shoulder-bag.jpg",
    description: "Glossy burgundy shoulder bag with a zip top and a silver bow and cherry charm."
  },
  {
    id: 11,
    name: "Wine Glitter Maxi Dress",
    price: 55000,
    category: "Clothing",
    condition: "New",
    seller: "Kemi Accessories",
    image: "images/wine-glitter-dress.jpg",
    description: "Shimmery wine maxi dress with a square neckline, ruched waist and flowing cape sleeves."
  },
  {
    id: 12,
    name: "Zimmermann Ivory Draped Top",
    price: 280000,
    category: "Clothing",
    condition: "Like new",
    seller: "Closet by Zara O.",
    image: "images/zimmermann-ivory-top.jpg",
    description: "Ivory silk draped off shoulder top with leaf appliqué and a gathered waist."
  }
];


// ---------- 2. Load saved data ----------
// Items that users post through the Sell page are saved separately
let userProducts = JSON.parse(localStorage.getItem("betoUserProducts")) || [];
let cart = JSON.parse(localStorage.getItem("betoCart")) || [];
let users = JSON.parse(localStorage.getItem("betoUsers")) || [];
let currentUser = JSON.parse(localStorage.getItem("betoCurrentUser")) || null;

function getAllProducts() {
  return userProducts.concat(defaultProducts);
}

function saveData() {
  localStorage.setItem("betoUserProducts", JSON.stringify(userProducts));
  localStorage.setItem("betoCart", JSON.stringify(cart));
  localStorage.setItem("betoUsers", JSON.stringify(users));
  localStorage.setItem("betoCurrentUser", JSON.stringify(currentUser));
}


// ---------- 3. Helper functions ----------

// Formats a number as Naira, e.g. 45000 becomes ₦45,000
function formatPrice(amount) {
  return "₦" + amount.toLocaleString();
}

// Stops users from typing HTML or scripts into the forms (XSS protection)
function cleanText(text) {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// Shows a small message at the bottom of the screen
function showMessage(text) {
  const box = document.getElementById("message");
  box.textContent = text;
  box.style.display = "block";
  setTimeout(function () {
    box.style.display = "none";
  }, 2500);
}

// Hides all pages and shows only the one we want
function showPage(pageName) {
  const pages = document.querySelectorAll(".page");
  pages.forEach(function (page) {
    page.classList.add("hidden");
  });
  document.getElementById(pageName + "-page").classList.remove("hidden");

  if (pageName === "cart") {
    displayCart();
  }
  window.scrollTo(0, 0);
}


// ---------- 4. Showing products ----------
function displayProducts() {
  const searchText = document.getElementById("search").value.toLowerCase();
  const category = document.getElementById("category").value;
  const productList = document.getElementById("product-list");

  // Keep only the products that match the search and category
  const results = getAllProducts().filter(function (product) {
    const matchesSearch = product.name.toLowerCase().includes(searchText);
    const matchesCategory = category === "All" || product.category === category;
    return matchesSearch && matchesCategory;
  });

  if (results.length === 0) {
    productList.innerHTML = '<p class="no-results">No items found. Try another search.</p>';
    return;
  }

  let html = "";
  results.forEach(function (product) {
    html += `
      <div class="product-card" onclick="openProduct(${product.id})">
        <img src="${product.image}" alt="${product.name}">
        <div class="product-info">
          <h3>${product.name}</h3>
          <p class="seller">${product.seller}</p>
          <span class="price">${formatPrice(product.price)}</span>
        </div>
      </div>
    `;
  });
  productList.innerHTML = html;
}


// ---------- 5. Product popup ----------
function openProduct(id) {
  const product = getAllProducts().find(function (p) {
    return p.id === id;
  });

  document.getElementById("modal-content").innerHTML = `
    <button class="close-btn" onclick="hideModal()">&times;</button>
    <img src="${product.image}" alt="${product.name}">
    <div>
      <h2>${product.name}</h2>
      <p class="price">${formatPrice(product.price)}</p>
      <p>${product.description}</p>
      <p><strong>Condition</strong> ${product.condition}</p>
      <p><strong>Seller</strong> ${product.seller}</p>
      <button class="btn" onclick="addToCart(${product.id})">Add to cart</button>
    </div>
  `;
  document.getElementById("modal").classList.remove("hidden");
}

function hideModal() {
  document.getElementById("modal").classList.add("hidden");
}

// Closes the popup when you click the dark area around it
function closeModal(event) {
  if (event.target.id === "modal") {
    hideModal();
  }
}


// ---------- 6. Cart ----------
function addToCart(id) {
  const item = cart.find(function (c) {
    return c.id === id;
  });

  if (item) {
    item.quantity += 1;
  } else {
    cart.push({ id: id, quantity: 1 });
  }

  saveData();
  updateCartCount();
  hideModal();
  showMessage("Added to cart");
}

function changeQuantity(id, amount) {
  const item = cart.find(function (c) {
    return c.id === id;
  });
  item.quantity += amount;

  // Remove the item if quantity goes to zero
  if (item.quantity <= 0) {
    removeFromCart(id);
    return;
  }
  saveData();
  displayCart();
}

function removeFromCart(id) {
  cart = cart.filter(function (c) {
    return c.id !== id;
  });
  saveData();
  displayCart();
}

function updateCartCount() {
  let count = 0;
  cart.forEach(function (item) {
    count += item.quantity;
  });
  document.getElementById("cart-count").textContent = count;
}

function displayCart() {
  const cartBox = document.getElementById("cart-items");
  const checkoutForm = document.getElementById("checkout-form");
  let total = 0;
  let html = "";

  cart.forEach(function (item) {
    const product = getAllProducts().find(function (p) {
      return p.id === item.id;
    });
    if (!product) return;

    total += product.price * item.quantity;
    html += `
      <div class="cart-item">
        <img src="${product.image}" alt="${product.name}">
        <div class="details">
          <p><strong>${product.name}</strong></p>
          <p class="price">${formatPrice(product.price)}</p>
        </div>
        <button class="qty-btn" onclick="changeQuantity(${product.id}, -1)">-</button>
        <span>${item.quantity}</span>
        <button class="qty-btn" onclick="changeQuantity(${product.id}, 1)">+</button>
        <button class="remove-btn" onclick="removeFromCart(${product.id})">Remove</button>
      </div>
    `;
  });

  if (cart.length === 0) {
    html = '<p class="note">Your cart is empty. Go to the Shop page to find something you love.</p>';
    checkoutForm.classList.add("hidden");
  } else {
    checkoutForm.classList.remove("hidden");
  }

  cartBox.innerHTML = html;
  document.getElementById("cart-total").textContent = formatPrice(total);
  updateCartCount();
}

function checkout(event) {
  event.preventDefault();

  if (currentUser === null) {
    showMessage("Please login before you checkout");
    showPage("login");
    return;
  }

  const name = document.getElementById("buyer-name").value;
  cart = [];
  saveData();
  updateCartCount();
  document.getElementById("checkout-form").reset();
  displayCart();
  showMessage("Thank you " + name + ". Your order has been placed");
}


// ---------- 7. Login and sign up ----------
// Note: this is only a demo. A real site would check passwords on a server
// and store them hashed, never in the browser like this.
function register(event) {
  event.preventDefault();
  const name = document.getElementById("reg-name").value.trim();
  const email = document.getElementById("reg-email").value.trim().toLowerCase();
  const password = document.getElementById("reg-password").value;

  const exists = users.find(function (u) {
    return u.email === email;
  });
  if (exists) {
    showMessage("An account with this email already exists");
    return;
  }

  users.push({ name: name, email: email, password: password });
  currentUser = { name: name, email: email };
  saveData();
  updateLoginButton();
  event.target.reset();
  showMessage("Welcome to beto, " + name);
  showPage("shop");
}

function login(event) {
  event.preventDefault();
  const email = document.getElementById("login-email").value.trim().toLowerCase();
  const password = document.getElementById("login-password").value;

  const user = users.find(function (u) {
    return u.email === email && u.password === password;
  });

  if (!user) {
    showMessage("Wrong email or password");
    return;
  }

  currentUser = { name: user.name, email: user.email };
  saveData();
  updateLoginButton();
  event.target.reset();
  showMessage("Welcome back, " + user.name);
  showPage("shop");
}

function logout() {
  currentUser = null;
  saveData();
  updateLoginButton();
  showMessage("You have logged out");
  showPage("shop");
}

// Changes the Login button to Logout when someone is logged in
function updateLoginButton() {
  const button = document.getElementById("login-btn");
  if (currentUser) {
    button.textContent = "Logout (" + currentUser.name + ")";
    button.onclick = logout;
  } else {
    button.textContent = "Login";
    button.onclick = function () {
      showPage("login");
    };
  }
}


// ---------- 8. Selling an item ----------
function sellItem(event) {
  event.preventDefault();

  if (currentUser === null) {
    showMessage("Please login to sell an item");
    showPage("login");
    return;
  }

  const photo = document.getElementById("sell-photo").files[0];
  const reader = new FileReader();

  // This runs once the photo has been read
  reader.onload = function () {
    const newProduct = {
      id: Date.now(),
      name: cleanText(document.getElementById("sell-name").value.trim()),
      price: Number(document.getElementById("sell-price").value),
      category: document.getElementById("sell-category").value,
      condition: document.getElementById("sell-condition").value,
      seller: cleanText(currentUser.name),
      image: reader.result,
      description: cleanText(document.getElementById("sell-description").value.trim())
    };

    userProducts.unshift(newProduct);

    try {
      saveData();
    } catch (error) {
      // localStorage only holds about 5MB, so very large photos can fail
      userProducts.shift();
      showMessage("That photo is too large. Please use a smaller one.");
      return;
    }

    document.getElementById("sell-form").reset();
    showMessage("Your item has been posted");
    showPage("shop");
    displayProducts();
  };

  reader.readAsDataURL(photo);
}


// ---------- 9. Contact form ----------
// For the demo the message is not really sent anywhere
function sendMessage(event) {
  event.preventDefault();
  const name = document.getElementById("contact-name").value;
  document.getElementById("contact-form").reset();
  showMessage("Thanks " + name + ", we will get back to you soon");
}


// ---------- 10. Start the site ----------
displayProducts();
updateCartCount();
updateLoginButton();
