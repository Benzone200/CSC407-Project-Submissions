"""
security.py - ALL security controls for the Customer Feedback System live here,
so they are easy to point out to the lecturer.

Controls implemented:
  1. Password hashing (salted, via werkzeug)      -> hash_password / check_password
  2. Password + email validation                  -> validate_password / validate_email
  3. CSRF protection (token per session)          -> csrf_token / verify_csrf
  4. Brute-force protection (account lockout)     -> MAX_FAILED / LOCK_MINUTES (used in app.py)
  5. Access control (login + admin only routes)   -> login_required / admin_required
  6. Secure HTTP headers (CSP, nosniff, etc.)     -> add_security_headers
  7. Input sanitising / length limits             -> clean_text
(SQL injection is prevented in app.py by using parameterised queries only,
 and XSS by Jinja2 auto-escaping + the CSP header.)
"""
import re
import secrets
from functools import wraps

from flask import abort, flash, redirect, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

MAX_FAILED = 5        # failed logins before lockout
LOCK_MINUTES = 10     # lockout duration

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# 1. Password hashing -------------------------------------------------------
def hash_password(password: str) -> str:
    # pbkdf2/scrypt with a random salt; the plain password is never stored
    return generate_password_hash(password)


def check_password(stored_hash: str, password: str) -> bool:
    return check_password_hash(stored_hash, password)


# 2. Validation -------------------------------------------------------------
def validate_password(pw: str):
    """Return an error message, or None if the password is acceptable."""
    if len(pw) < 8:
        return "Password must be at least 8 characters."
    if not re.search(r"[A-Za-z]", pw) or not re.search(r"\d", pw):
        return "Password must contain letters and numbers."
    return None


def validate_email(email: str) -> bool:
    return bool(EMAIL_RE.match(email)) and len(email) <= 120


# 3. CSRF -------------------------------------------------------------------
def csrf_token() -> str:
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return session["_csrf"]


def verify_csrf():
    sent = request.form.get("_csrf", "")
    expected = session.get("_csrf", "")
    # constant-time comparison avoids timing attacks
    if not expected or not secrets.compare_digest(sent, expected):
        abort(400, "Invalid or missing CSRF token.")


# 5. Access control ---------------------------------------------------------
def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in first.", "error")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapper


def admin_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        if session.get("role") != "admin":
            abort(403)
        return view(*args, **kwargs)
    return wrapper


# 6. Security headers -------------------------------------------------------
def add_security_headers(resp):
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self'; script-src 'none'; "
        "frame-ancestors 'none'; form-action 'self'"
    )
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "same-origin"
    resp.headers["Cache-Control"] = "no-store"
    return resp


# 7. Input cleaning ---------------------------------------------------------
def clean_text(value: str, max_len: int) -> str:
    value = (value or "").strip()
    value = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", value)  # control chars
    return value[:max_len]
