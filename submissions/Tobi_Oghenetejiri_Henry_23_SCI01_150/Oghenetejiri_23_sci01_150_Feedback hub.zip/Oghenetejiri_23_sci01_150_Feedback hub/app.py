"""Customer Feedback System - Flask app (routes + database)."""
import os
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone

from flask import Flask, flash, g, redirect, render_template, request, session, url_for

import security as sec

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join(BASE_DIR, "feedback.db"))
CATEGORIES = ["Product", "Service", "Delivery", "Pricing", "Website", "Other"]

app = Flask(__name__)


def _load_secret_key():
    # SECURITY: secret key from environment, else generated once and kept in a file
    key = os.environ.get("SECRET_KEY")
    if key:
        return key
    path = os.path.join(BASE_DIR, ".secret_key")
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write(secrets.token_hex(32))
    with open(path) as f:
        return f.read().strip()


app.config.update(
    SECRET_KEY=_load_secret_key(),
    # SECURITY: cookie hardening
    SESSION_COOKIE_HTTPONLY=True,      # JS cannot read the cookie
    SESSION_COOKIE_SAMESITE="Lax",     # blocks most cross-site requests
    SESSION_COOKIE_SECURE=os.environ.get("PRODUCTION") == "1",  # HTTPS only in production
    PERMANENT_SESSION_LIFETIME=timedelta(minutes=30),
    MAX_CONTENT_LENGTH=16 * 1024,      # reject huge request bodies
)
app.jinja_env.globals["csrf_token"] = sec.csrf_token
app.after_request(sec.add_security_headers)


# ---------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            failed_attempts INTEGER NOT NULL DEFAULT 0,
            locked_until TEXT
        );
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id),
            category TEXT NOT NULL,
            rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
            message TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """
    )
    # Repair an old/damaged users table: add any column the code needs but the file lacks
    have = {row[1] for row in db.execute("PRAGMA table_info(users)")}
    for col, ddl in (("failed_attempts", "INTEGER NOT NULL DEFAULT 0"), ("locked_until", "TEXT")):
        if col not in have:
            db.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")  # constants only, no user input
    db.commit()
    # Seed an admin account once, with a random password printed to the console
    if not db.execute("SELECT 1 FROM users WHERE role='admin'").fetchone():
        pw = os.environ.get("ADMIN_PASSWORD") or secrets.token_urlsafe(9)
        db.execute(
            "INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,'admin')",
            ("Admin", "admin@example.com", sec.hash_password(pw)),
        )
        db.commit()
        print(f"\n[setup] Admin created -> admin@example.com / {pw}\n")
    db.close()


def now():
    return datetime.now(timezone.utc)


# ------------------------------------------------------------------ routes
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        sec.verify_csrf()
        name = sec.clean_text(request.form.get("name"), 60)
        email = sec.clean_text(request.form.get("email"), 120).lower()
        pw = request.form.get("password", "")
        error = None
        if not name:
            error = "Name is required."
        elif not sec.validate_email(email):
            error = "Enter a valid email address."
        else:
            error = sec.validate_password(pw)
        if error:
            flash(error, "error")
            return render_template("register.html"), 400
        try:
            # SECURITY: parameterised query (?) -> prevents SQL injection
            get_db().execute(
                "INSERT INTO users (name, email, password_hash) VALUES (?,?,?)",
                (name, email, sec.hash_password(pw)),
            )
            get_db().commit()
        except sqlite3.IntegrityError:
            flash("That email is already registered.", "error")
            return render_template("register.html"), 400
        flash("Account created. Please log in.", "ok")
        return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        sec.verify_csrf()
        email = sec.clean_text(request.form.get("email"), 120).lower()
        pw = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()

        # SECURITY: account lockout after repeated failures (brute-force defence)
        if user and user["locked_until"] and datetime.fromisoformat(user["locked_until"]) > now():
            flash(f"Account locked. Try again in {sec.LOCK_MINUTES} minutes.", "error")
            return render_template("login.html"), 429

        if user and sec.check_password(user["password_hash"], pw):
            db.execute("UPDATE users SET failed_attempts=0, locked_until=NULL WHERE id=?", (user["id"],))
            db.commit()
            session.clear()  # SECURITY: new session on login prevents session fixation
            session.permanent = True
            session.update(user_id=user["id"], name=user["name"], role=user["role"])
            return redirect(url_for("dashboard"))

        if user:
            fails = user["failed_attempts"] + 1
            locked = None
            if fails >= sec.MAX_FAILED:
                locked = (now() + timedelta(minutes=sec.LOCK_MINUTES)).isoformat()
                fails = 0
            db.execute("UPDATE users SET failed_attempts=?, locked_until=? WHERE id=?",
                       (fails, locked, user["id"]))
            db.commit()
        # SECURITY: same message whether the email or password was wrong (no user enumeration)
        flash("Invalid email or password.", "error")
        return render_template("login.html"), 401
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    sec.verify_csrf()
    session.clear()
    flash("Logged out.", "ok")
    return redirect(url_for("index"))


@app.route("/dashboard", methods=["GET", "POST"])
@sec.login_required
def dashboard():
    db = get_db()
    if request.method == "POST":
        sec.verify_csrf()
        category = request.form.get("category", "")
        message = sec.clean_text(request.form.get("message"), 1000)
        try:
            rating = int(request.form.get("rating", ""))
        except ValueError:
            rating = 0
        # SECURITY: whitelist validation of every field
        if category not in CATEGORIES or not 1 <= rating <= 5 or len(message) < 5:
            flash("Please choose a category, a 1-5 rating and write at least 5 characters.", "error")
        else:
            db.execute(
                "INSERT INTO feedback (user_id, category, rating, message, created_at) VALUES (?,?,?,?,?)",
                (session["user_id"], category, rating, message, now().strftime("%Y-%m-%d %H:%M")),
            )
            db.commit()
            flash("Thank you! Your feedback was submitted.", "ok")
            return redirect(url_for("dashboard"))
    # users only ever see their own feedback (WHERE user_id = ?)
    mine = db.execute(
        "SELECT * FROM feedback WHERE user_id = ? ORDER BY id DESC", (session["user_id"],)
    ).fetchall()
    return render_template("dashboard.html", categories=CATEGORIES, mine=mine)


@app.route("/admin")
@sec.admin_required
def admin():
    db = get_db()
    rows = db.execute(
        "SELECT f.*, u.name, u.email FROM feedback f JOIN users u ON u.id = f.user_id ORDER BY f.id DESC"
    ).fetchall()
    stats = db.execute("SELECT COUNT(*) AS n, ROUND(AVG(rating),2) AS avg FROM feedback").fetchone()
    by_cat = db.execute(
        "SELECT category, COUNT(*) AS n, ROUND(AVG(rating),2) AS avg FROM feedback GROUP BY category"
    ).fetchall()
    return render_template("admin.html", rows=rows, stats=stats, by_cat=by_cat)


@app.errorhandler(400)
@app.errorhandler(403)
@app.errorhandler(404)
def error(e):
    return render_template("error.html", e=e), e.code


init_db()

if __name__ == "__main__":
    app.run(debug=False)
