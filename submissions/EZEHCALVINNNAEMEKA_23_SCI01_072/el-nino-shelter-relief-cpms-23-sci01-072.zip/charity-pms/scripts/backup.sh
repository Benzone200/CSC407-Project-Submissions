#!/usr/bin/env bash
# Makes a compressed backup of the PostgreSQL database.
# Usage: DATABASE_URL=postgres://... ./scripts/backup.sh
# Keeps the newest 14 backups in ./backups
set -euo pipefail
: "${DATABASE_URL:?Set DATABASE_URL first}"
mkdir -p backups
FILE="backups/cpms-$(date +%Y-%m-%d_%H%M).sql.gz"
pg_dump --no-owner --no-privileges "$DATABASE_URL" | gzip > "$FILE"
echo "Backup saved: $FILE"
ls -1t backups/cpms-*.sql.gz | tail -n +15 | xargs -r rm --
