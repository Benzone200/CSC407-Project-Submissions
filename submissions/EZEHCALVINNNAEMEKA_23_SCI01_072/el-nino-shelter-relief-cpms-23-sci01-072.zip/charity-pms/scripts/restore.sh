#!/usr/bin/env bash
# Restores a backup made by backup.sh.
# Usage: DATABASE_URL=postgres://... ./scripts/restore.sh backups/cpms-2026-11-16_0200.sql.gz
set -euo pipefail
: "${DATABASE_URL:?Set DATABASE_URL first}"
FILE="${1:?Give the backup file to restore}"
gunzip -c "$FILE" | psql "$DATABASE_URL"
echo "Restored from $FILE"
