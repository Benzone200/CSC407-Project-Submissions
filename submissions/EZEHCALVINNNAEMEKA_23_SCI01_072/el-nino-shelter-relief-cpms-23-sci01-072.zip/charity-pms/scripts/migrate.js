// Run with: npm run migrate
const db = require('../src/db');
const { migrate } = require('../src/setup');

(async () => {
  await db.init();
  await migrate();
  console.log(`Tables are ready (${db.kind()}).`);
  await db.close();
})().catch((err) => {
  console.error('Migration failed:', err.message);
  process.exit(1);
});
