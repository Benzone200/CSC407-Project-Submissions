// Run with: npm run seed  (only adds data when the users table is empty)
const db = require('../src/db');
const { migrate, seed } = require('../src/setup');

(async () => {
  await db.init();
  await migrate();
  const r = await seed();
  console.log(r.created ? 'Starting data added.' : 'Data already exists. Nothing was added.');
  await db.close();
})().catch((err) => {
  console.error('Seeding failed:', err.message);
  process.exit(1);
});
