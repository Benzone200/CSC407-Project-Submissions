# Testing

The system was tested in two ways:

1. **Automated tests:** 156 tests written with **Jest** and **Supertest**. They act like a browser: they log in, fill in forms, click buttons, and check the results and the database.
2. **Manual tests:** usability and responsive (phone/computer) checks done by a person, using the tables at the end of this document.

## How to run the automated tests

```
npm install
npm test
```

Each test file starts with a **fresh, empty database**, so the tests never change your real data. By default the tests use the built-in PostgreSQL (PGlite) in memory. To run them against a real PostgreSQL server:

```
TEST_DATABASE_URL=postgres://user:password@localhost:5432/cpms_test npm test
```

### Result

```
Test Suites: 6 passed, 6 total
Tests:       156 passed, 156 total
```

The suite passed on both the built-in database and **PostgreSQL 16**.

### Are the tests really checking something?

To prove the tests can catch real bugs, two protections were switched off on purpose and the tests were run again:

| Protection switched off | Result |
|---|---|
| CSRF token check | CSRF tests failed (forms from other sites were accepted) |
| "Owner only" check on donation receipts | "cannot open another user's receipt" failed |

**4 tests failed**, as expected. After the code was put back, all 156 passed again.

---

## What is covered

| File | Tests | Area |
|---|---:|---|
| `auth.test.js` | 27 | Registration, login, lockout, sessions, logout |
| `access.test.js` | 40 | Role-based access and access-control checks |
| `security.test.js` | 22 | CSRF, SQL injection, XSS, headers, cookies, sensitive data, rate limit |
| `functional.test.js` | 33 | Donations, volunteering, projects, tasks, expenses, search, profile |
| `database.test.js` | 19 | Tables, database rules, relationships, transactions, totals |
| `errors-and-validation.test.js` | 15 | Error pages, server errors, validation rules |
| **Total** | **156** | |

### 1. Functional testing (`functional.test.js`)

| # | Test | Expected result |
|---|---|---|
| F1 | User records a donation | Redirect to receipt with a `DON-XXXXXXXX` reference, status Pending |
| F2 | Pending donation is not counted | Project "raised" total does not change |
| F3 | Admin confirms donation | Project "raised" goes up by the amount |
| F4 | Admin tries to review the same donation again | Status stays the same (can only be reviewed once) |
| F5 | Admin rejects a donation | Status Rejected, reviewer saved |
| F6 | Donate to a completed project | Refused, nothing saved |
| F7 | User signs up to volunteer twice | Only one sign-up is saved |
| F8 | User withdraws a pending sign-up | Sign-up deleted |
| F9 | Admin approves a volunteer | Status Approved |
| F10 | Admin creates and edits a project | Saved, and shown in public search |
| F11 | Add, update and delete a task | Each change saved |
| F12 | Record two expenses | Project "spent" = the sum |
| F13 | Delete a project without donations | Project, tasks and expenses removed |
| F14 | Delete a project with donations | Refused, project kept |
| F15 | Search and filter projects, donations, users and the activity log | Only matching rows shown |
| F16 | Update profile, change password | Saved, other devices logged out |

### 2. Login and registration testing (`auth.test.js`)

| # | Test | Expected result |
|---|---|---|
| A1 | Register with valid details | Account created, logged in, sent to dashboard |
| A2 | Email saved in lower case, phone without spaces | `ngozi.eze@example.com`, `08031112222` |
| A3 | Password stored as bcrypt hash | Starts with `$2b$`, plain password not stored |
| A4 | Same email again (different case) | 422 "already exists" |
| A5 | Add `role=admin` to the sign-up form | Account is still `user` |
| A6 | 7 bad inputs (empty name, symbols, bad email, bad phone, short password, no number, mismatch) | 422 with the right message each time |
| A7 | Admin login / user login | Sent to `/admin` / `/dashboard` |
| A8 | Wrong password vs unknown email | Same message, status 401 |
| A9 | 5 wrong passwords | Account locked for 15 minutes (423) |
| A10 | Correct password while locked | Still refused |
| A11 | After the lock time | Login works |
| A12 | Session ID at login | A new session is created (no fixation) |
| A13 | Logout | Session deleted, dashboard redirects to login |
| A14 | Session older than the timeout | Logged out |
| A15 | Return to the page you wanted after login | Redirect to that page |

### 3. Form validation testing

Covered in `auth.test.js`, `functional.test.js` and `errors-and-validation.test.js`.

| Form | Invalid input tested | Message shown |
|---|---|---|
| Register | empty name, `Bad<Name>`, `not-an-email`, `abc123` phone, `Ab1`, `onlyletters`, mismatch | Clear message under each field |
| Donate | `50`, `ten`, `-500`, `100.5`, method `bitcoin` | "Amount must be a whole number between ₦100 and ₦100,000,000." / "Choose how you will pay." |
| Volunteer | empty skills, availability `never` | "Tell us how you can help…" / "Choose when you are available." |
| Project | title `abc`, category `space`, target `5`, date `2026-02-30`, status `done` | Five messages at once |
| Project | end date before start date | "End date cannot be before the start date." |
| Expense | date in the future | "Date cannot be in the future." |
| Task status | `finished` | 400 Bad request |
| Password change | wrong current password | "Your current password is wrong." |
| Any form | arrays instead of text, extra spaces | Treated as empty / trimmed |

### 4. Security testing (`security.test.js`, `access.test.js`)

| # | Attack or check | Expected result |
|---|---|---|
| S1 | POST without CSRF token | 403 |
| S2 | POST with a fake token, or another user's token | 403, nothing saved |
| S3 | `' OR 1=1 --`, `'; DROP TABLE users; --`, UNION attack in search | Treated as text, 0 results, tables still there |
| S4 | SQL in the login form | 401, no login |
| S5 | SQL in the sort option | Ignored, fixed sort used |
| S6 | `<script>` in a donation message | Shown as `&lt;script&gt;` on the admin page |
| S7 | `<img onerror>` in a project title | Escaped on the public page |
| S8 | Security headers | CSP, nosniff, X-Frame-Options, Referrer-Policy present; X-Powered-By removed |
| S9 | Session cookie | HttpOnly and SameSite=Lax (plus Secure in production) |
| S10 | 30 KB form body | 413 |
| S11 | Public page shows donors | Only "First L.", no emails or phones |
| S12 | User opens 9 admin pages | 403 for each |
| S13 | User sends 6 admin POST actions | 403, nothing changed |
| S14 | User opens another user's receipt | 404 |
| S15 | Admin removes own admin role | Refused |
| S16 | Disabled user | Logged out at once and cannot log in |
| S17 | 6 POSTs from one IP with a limit of 3 | Last 2 get 429 |

### 5. Error handling testing (`errors-and-validation.test.js`)

| # | Test | Expected result |
|---|---|---|
| E1 | Unknown page, `/projects/0`, `/projects/-1`, `/projects/1abc`, huge number | Friendly 404 page |
| E2 | Bad IDs on admin pages and actions | 404 |
| E3 | Database error during a page | 500 "Something went wrong on our side", **no technical details shown** |
| E4 | Database down | `/health` returns 503 |

### 6. Database testing (`database.test.js`)

| # | Test | Expected result |
|---|---|---|
| D1 | All 8 tables exist | ✓ |
| D2 | Run migration again / seed again | No error, no duplicates |
| D3 | Duplicate email, upper-case email, role `superuser` | Refused by the database |
| D4 | Target 0, end before start | Refused |
| D5 | Donation of ₦50 or ₦200,000,000, status `paid`, duplicate reference, unknown project | Refused |
| D6 | Delete a project that has donations | Refused (RESTRICT) |
| D7 | Delete a project with tasks and expenses | Tasks and expenses removed too (CASCADE) |
| D8 | Volunteer twice on one project | Refused (UNIQUE) |
| D9 | Transaction where step 2 fails | Step 1 is undone too |
| D10 | "Raised" total | Equals the sum of confirmed donations only |

---

## 7. Responsive / mobile testing (manual)

Checked with Chrome DevTools device mode and real screenshots (see `docs/screenshots/`, named `phone-…` and `desk-…`).

| Screen size | Width | What was checked | Result |
|---|---|---|---|
| Phone (iPhone 12/13/14) | 390 px | Menu collapses to "☰ Menu"; cards in one column; tables turn into cards; buttons at least 44 px tall; no sideways scrolling | Pass |
| Tablet | 768 px | Two-column card grid; filter bar in one row | Pass |
| Laptop | 1366 px | Three-column grid; project page with sticky funding panel on the right | Pass |

Steps to repeat: open the site in Chrome → press `F12` → click the phone icon (Toggle device toolbar) → choose "iPhone 12 Pro", then "iPad", then "Responsive" at 1366 px → visit every page in the table below.

## 8. Usability testing (manual)

Ask 3 to 5 people (for example classmates) to do these tasks **without help**. Write down the time, whether they finished, and what confused them.

| # | Task for the tester | Success when… | Tester 1 | Tester 2 | Tester 3 |
|---|---|---|---|---|---|
| U1 | Create an account | Sees "Welcome, [name]!" | | | |
| U2 | Find an active **shelter** project in **Kano** | Opens "Heat-Safe Roofs for Vulnerable Homes" | | | |
| U3 | Donate ₦10,000 by bank transfer | Sees the receipt with a reference | | | |
| U4 | Sign up to volunteer on any project | Sees "Thank you for offering to help!" | | | |
| U5 | Find your donation and print the receipt | Print window opens | | | |
| U6 | Change your phone number | Sees "Your profile was updated." | | | |
| U7 | (Admin) Confirm a pending donation | Status changes to Confirmed | | | |
| U8 | (Admin) Add a task to a project and mark it Done | Task shows a tick | | | |
| U9 | (Admin) Record a ₦50,000 expense | "Spent" goes up | | | |
| U10 | (Admin) Find all failed logins in the activity log | Filters by "Logins and sign-ups" | | | |

After the tasks, ask each tester to rate 1 (very hard) to 5 (very easy):

| Question | T1 | T2 | T3 |
|---|---|---|---|
| The pages were easy to understand | | | |
| I always knew where I was (menu, page titles) | | | |
| Error messages told me how to fix the problem | | | |
| The site worked well on my phone | | | |

### Usability features already built in
- Plain, short wording on every page and every error message.
- Errors appear next to the field, and the other answers are kept.
- Quick amount buttons (₦5,000, ₦10,000 …) on the donate form.
- Confirmation box before deleting or rejecting anything.
- Status colours are the same everywhere (green = done/confirmed, amber = pending, red = rejected).
- Keyboard and screen-reader support: "Skip to content" link, labels on every field, visible focus outline, `aria-current` on the active menu item, `role="alert"` on error messages.
