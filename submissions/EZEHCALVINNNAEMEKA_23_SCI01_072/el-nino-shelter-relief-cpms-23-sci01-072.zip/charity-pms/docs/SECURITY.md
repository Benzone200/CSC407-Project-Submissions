# Web Application Security

This document explains how the Charity Project Management System protects its users and data. Each section says **what the risk is**, **what we did**, **where it is in the code**, and **how it was tested**. The same measures are explained for users on the `/security` page inside the app.

---

## 1. User authentication (login and logout)

**Risk:** someone uses the system as another person.

**What we did**
- Users log in with email and password. Email is not case sensitive (`User@Mail.com` = `user@mail.com`).
- A wrong email and a wrong password get the **same message** ("Email or password is wrong."), so attackers cannot find out which emails are registered.
- When the email does not exist, the server still runs a bcrypt check on a dummy hash. Both cases take the same time, so the response time does not give the answer away either.
- Logout is a **POST** form with a CSRF token. It deletes the session from the database and clears the cookie.

**Code:** `src/routes/auth.js`
**Tests:** `tests/auth.test.js` → "Login", "Sessions and logout"

## 2. Password hashing

**Risk:** if the database is stolen, the passwords are exposed.

**What we did**
- Passwords are hashed with **bcrypt** (cost 12). bcrypt adds a random **salt** to every password, so two users with the same password get different hashes.
- The plain password is never stored, logged or shown anywhere.
- Password rules: 8 to 72 characters with at least one letter and one number. (72 is bcrypt's limit.)
- To change a password, the user must type the current one. After a change, **all other sessions of that user are logged out**.

**Code:** `src/routes/auth.js`, `src/routes/user.js` (`/profile/password`), `src/validate.js`
**Tests:** "the password is stored as a bcrypt hash", "changing the password logs out other devices"

A stored hash looks like this (example only):
```
$2b$12$Gm1H0y9cQm2W8nQ3r2uY0eJx3p7bq8bJ7l1yQ4tq3P0n2Ww9pYzKa
```

## 3. Role-based access (Admin and User)

| Feature | Visitor | User | Admin |
|---|:---:|:---:|:---:|
| Browse projects, security page | ✓ | ✓ | ✓ |
| Donate, volunteer, see own donations | | ✓ | |
| Edit own profile, change password | | ✓ | ✓ |
| Create / edit / delete projects, tasks, expenses | | | ✓ |
| Confirm or reject donations, approve volunteers | | | ✓ |
| Change roles, disable / unlock users, read activity log | | | ✓ |

**What we did**
- The role is stored in the database (`users.role`), and the database only allows `admin` or `user`.
- New accounts are **always** `user`. The role is never read from the form, so adding `role=admin` to the sign-up form does nothing (no "mass assignment").
- The whole `/admin` area is protected in one place: `router.use(requireRole('admin'))`.
- The logged-in user is **loaded from the database on every request**, so a role change or a disabled account takes effect immediately.

**Code:** `src/middleware/security.js` (`requireLogin`, `requireRole`), `src/routes/admin.js`
**Tests:** `tests/access.test.js` (40 tests)

## 4. Access-control checks (your own data only)

**Risk:** a user changes a number in the address bar (for example `/donations/5` to `/donations/6`) to see someone else's data. This is called IDOR (Insecure Direct Object Reference).

**What we did**
- Every query for personal data includes the owner:
  ```sql
  SELECT ... FROM donations d ... WHERE d.id = $1 AND d.user_id = $2
  ```
  If the donation belongs to someone else, the result is empty and the user sees **404 Not Found**. This does not even confirm that the record exists.
- The same check is used when withdrawing a volunteer sign-up.
- An admin cannot change their own role or disable their own account, so the system cannot be left without an admin by mistake.
- Every refused attempt (403) is written to the activity log as `security.access_denied`.

**Tests:** "a user cannot open another user's donation receipt", "cannot withdraw another user's volunteer sign-up", "an admin cannot remove their own admin role"

## 5. Input validation

**Risk:** bad or harmful data gets into the system.

**What we did**
- **Every form is checked on the server** (`src/validate.js`), even though the browser also has `required` and `maxlength`, because browser checks can be skipped.
- Rules include: name letters only (2 to 80), valid email, phone digits (7 to 15), amounts as whole naira within limits (₦100 to ₦100,000,000 for donations), real calendar dates (`2026-02-30` is refused), end date not before start date, expenses not dated in the future, and choices (category, status, method) only from fixed lists.
- Values that arrive as arrays instead of text (parameter tampering) are treated as empty.
- Route IDs must be positive whole numbers. Anything else gives 404.
- Form bodies are limited to **20 KB**. Larger requests get **413**.
- The **database also enforces rules** (CHECK, UNIQUE, FOREIGN KEY), so bad data is refused even if a bug got past the app.
- Errors are shown next to each field in simple words, and the user's other answers are kept.

**Tests:** registration cases, "bad project data is refused", donation amount cases, "Validation rules (unit)", `tests/database.test.js`

## 6. Protection against SQL injection

**Risk:** an attacker types SQL code into a form to read or delete data, for example `' OR 1=1 --`.

**What we did**
- **Every query uses parameters** (`$1`, `$2` …). User input is sent separately from the SQL text, so the database always treats it as data:
  ```js
  db.query('SELECT id, password_hash FROM users WHERE email = $1', [email]);
  ```
- There is **no string joining** of user input into SQL anywhere in the project.
- Sorting cannot take user input directly. The user picks a key such as `newest`, and the SQL comes from a fixed list (`SORTS` in `src/models.js`).
- In searches, `%` and `_` are escaped so they are not wildcards.

**Tests:** "SQL injection protection" (7 tests), including `'; DROP TABLE users; --` and a UNION attack

## 7. Protection against Cross-Site Scripting (XSS)

**Risk:** an attacker saves `<script>` code (for example in a donation message), and it runs in another user's browser.

**What we did**
- All output uses EJS `<%= %>`, which **escapes HTML**. `<script>` is shown as the text `&lt;script&gt;`.
- A strict **Content Security Policy** (Helmet) tells the browser to run scripts only from this site (`script-src 'self'`). Inline scripts and inline styles are blocked. That is why all JavaScript is in `public/js/app.js` and there are no `onclick=` attributes.
- `object-src 'none'` and `base-uri 'self'` close other common attack routes.

**Tests:** "text typed by a user is shown as text", "project fields are escaped", "a Content Security Policy blocks inline and outside scripts"

## 8. Protection against CSRF (Cross-Site Request Forgery)

**Risk:** a bad website secretly submits a form to our site using the visitor's logged-in session (for example "confirm donation").

**What we did**
- Each session gets a random 32-byte **CSRF token**. Every form includes it in a hidden `_csrf` field.
- Every POST is checked. A missing or wrong token gets **403**. Tokens are compared with `crypto.timingSafeEqual`.
- The session cookie is also `SameSite=Lax`, so browsers do not send it with forms posted from other sites.

**Code:** `src/middleware/security.js` (`csrfProtection`)
**Tests:** "CSRF protection" (3 tests)

## 9. Session management

**What we did**
- Sessions are stored **on the server** in the `sessions` table. The browser only holds a random ID.
- Cookie settings: `HttpOnly` (JavaScript cannot read it), `SameSite=Lax`, and `Secure` on the live site (sent only over HTTPS).
- **New session ID on login** (`req.session.regenerate`), which stops session fixation.
- **Idle timeout:** 30 minutes (`SESSION_MINUTES`). The timer restarts on each request (rolling session).
- Expired sessions are deleted from the database automatically.
- Disabling a user or changing a password deletes that user's sessions.
- After login, the user is only sent back to a page **on this site**, which blocks open redirects such as `//evil.com`.

**Tests:** "Sessions and logout" (5 tests), "disabling an account logs that person out at once"

## 10. Brute-force protection

- **Account lockout:** 5 wrong passwords lock the account for 15 minutes. Even the correct password is refused while it is locked. Admins can unlock it on the Users page.
- **Rate limit per IP address:** 30 login attempts per 15 minutes, and 10 sign-ups per hour. Going over the limit gives **429 Too Many Requests**.
- Lockouts and failed logins are recorded in the activity log.

**Tests:** "Account lockout" (3 tests), "Rate limiting"

## 11. Secure handling of sensitive information

- Secrets (database password, session secret, admin password) are kept in **environment variables**, not in the code. `.env` is in `.gitignore`. See `.env.example`.
- In production, the app **refuses to start** without `SESSION_SECRET`, and it will not create the first admin without `ADMIN_EMAIL` and `ADMIN_PASSWORD`.
- Public pages show donors as **first name + initial** (for example "Tunde B."), never their email or phone. Only admins see volunteer contact details, because they need them to arrange the work.
- Users see friendly error pages. **Stack traces and database errors only go to the server log.**
- Pages are sent with `Cache-Control: no-store`, so after logout the browser's Back button does not show private pages.
- The `X-Powered-By` header is removed, so the server software is not advertised.
- Money records are protected: a donation can only be reviewed once (`WHERE status = 'pending'`), and a project with donations cannot be deleted (`ON DELETE RESTRICT`).

## 12. HTTPS and security headers

On the live site (`NODE_ENV=production`):
- Every `http://` request is redirected to `https://` (301).
- **HSTS** (`Strict-Transport-Security: max-age=31536000; includeSubDomains`) tells browsers to always use HTTPS.
- `upgrade-insecure-requests` is added to the CSP.
- The session cookie gets the `Secure` flag.

On every page, Helmet also sets `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `frame-ancestors 'none'` (blocks clickjacking) and `Referrer-Policy: same-origin`.

Production check (run on this project):
```
http request  -> 301 https://cpms.example.org/login
https request -> Strict-Transport-Security: max-age=31536000; includeSubDomains
login         -> Set-Cookie: cpms.sid=...; HttpOnly; Secure; SameSite=Lax
```

## 13. Logging and monitoring

- The `activity_log` table records logins, failed logins, lockouts, refused access, and every admin change, with the time and IP address. Admins can search and filter it at **Admin → Activity log**.
- The server writes one JSON line per request and per error. Passwords and tokens are never logged.

## Summary

| Requirement | Done | Where |
|---|:---:|---|
| User authentication (login/logout) | ✓ | `routes/auth.js` |
| Password hashing | ✓ | bcrypt, cost 12 |
| Role-based access (Admin/User) | ✓ | `requireRole`, `/admin` router |
| Input validation | ✓ | `validate.js` + database rules |
| SQL injection protection | ✓ | parameterised queries only |
| XSS protection | ✓ | EJS escaping + CSP |
| Session management | ✓ | database sessions, regenerate, timeout, secure cookies |
| Access-control checks | ✓ | owner in every query, 404 for others |
| Secure handling of sensitive information | ✓ | env vars, masked names, no stack traces |
| HTTPS / security configuration | ✓ | redirect, HSTS, Helmet headers |
| Extra: CSRF, lockout, rate limit, activity log | ✓ | `middleware/security.js`, `activity.js` |
