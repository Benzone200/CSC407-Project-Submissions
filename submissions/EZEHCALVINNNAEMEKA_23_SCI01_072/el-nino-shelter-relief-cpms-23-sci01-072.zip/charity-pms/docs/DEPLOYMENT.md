# Deployment

This document explains how the application moves from **development** (your own computer) to a **live environment** on the internet.

```
 Your computer                GitHub                    Render (live)
 ─────────────                ──────                    ─────────────
 write code                   stores the code           builds the app
 npm test   ──git push──▶     main branch    ──auto──▶  runs migrations
 npm start                                              starts server (HTTPS)
 built-in DB (PGlite)                                   PostgreSQL database
```

## 1. Environments

| | Development | Production (live) |
|---|---|---|
| `NODE_ENV` | `development` | `production` |
| Database | Built-in PGlite in `./data/local-db` (or local PostgreSQL) | Render PostgreSQL |
| Sample data | Yes (El Niño projects + test accounts) | No, only the admin from `ADMIN_EMAIL` (unless `DEMO_DATA=true`) |
| HTTPS | Not needed (localhost) | Forced: HTTP → HTTPS redirect + HSTS |
| Cookie `Secure` flag | Off | On |
| Session secret | Fixed development value | **Required**, random |
| Error details | Server log only | Server log only |

## 2. Database configuration

- All tables, rules and indexes are in **`src/schema.sql`**.
- `npm run migrate` creates the tables. It is safe to run many times, because it uses `CREATE TABLE IF NOT EXISTS`.
- `npm run seed` adds the first admin (and the sample data in development) **only when the users table is empty**.
- `npm start` runs both automatically before the server starts.
- The app connects with a **pool** of up to 10 connections (`src/db.js`).
- Every query uses parameters (see SECURITY.md).

**Using a local PostgreSQL instead of the built-in database:**
```
createdb cpms
# in .env
DATABASE_URL=postgres://postgres:yourpassword@localhost:5432/cpms
npm start
```

## 3. Environment variables

Settings and secrets are **never written in the code**. They come from environment variables. On your computer, copy `.env.example` to `.env`. On Render, they are set in the dashboard.

| Variable | Needed in production | Example / note |
|---|:---:|---|
| `NODE_ENV` | ✓ | `production` |
| `DATABASE_URL` | ✓ | Set automatically by `render.yaml` |
| `DATABASE_SSL` | | `true` if the database host needs SSL |
| `SESSION_SECRET` | ✓ | Generated automatically by Render. The app will not start without it. |
| `SESSION_MINUTES` | | `30` |
| `BCRYPT_ROUNDS` | | `12` |
| `ADMIN_EMAIL` | ✓ (first start) | the first admin's email |
| `ADMIN_PASSWORD` | ✓ (first start) | a strong password (change it after the first login) |
| `DEMO_DATA` | | `true` only for a class demo |
| `LOG_FILE` | | `logs/app.log` to also write logs to a file |
| `PORT` | | Set by Render automatically |

`.env` is listed in `.gitignore`, so it is never uploaded to GitHub.

## 4. Server configuration

- **Runtime:** Node.js 22, Express 5.
- **Start command:** `npm run migrate && npm start`.
- **Health check:** `GET /health` returns `{"status":"ok","database":"ok"}`, or `503` if the database is down. Render uses it to decide whether a new version is healthy.
- **Proxy:** Render handles HTTPS in front of the app. `trust proxy` is turned on in production, so the app knows the real protocol and visitor IP.
- **Graceful shutdown:** on `SIGTERM` the server stops taking new requests, finishes the current ones, and closes the database connections.
- **Request limits:** 20 KB form size, login and sign-up rate limits.
- **Static files** (`/public`) are cached by browsers for 7 days in production.

## 5. Deployment process (Render)

### First time

1. **Put the code on GitHub**
   ```
   git init
   git add .
   git commit -m "Charity Project Management System"
   git branch -M main
   git remote add origin https://github.com/<your-username>/el-nino-shelter-relief.git
   git push -u origin main
   ```
2. Create a free account at **render.com** and connect your GitHub.
3. Click **New → Blueprint** and choose the repository. Render reads `render.yaml` and plans:
   - a PostgreSQL database `cpms-db`
   - a web service `el-nino-shelter-relief`
4. Render asks for the values marked `sync: false`. Type your **ADMIN_EMAIL** and a strong **ADMIN_PASSWORD**. `SESSION_SECRET` is generated for you.
   *For the class presentation*, you can set `DEMO_DATA` to `true` in the Environment tab so the sample El Niño projects appear.
5. Click **Apply**. Render will:
   1. run `npm ci --omit=dev` (install the exact package versions, without test tools)
   2. run `npm run migrate && npm start`
   3. check `/health`, then put the app live at `https://el-nino-shelter-relief.onrender.com` (the name may differ)
6. Open the link, log in as the admin, and check for the padlock in the address bar.

### Every update after that

```
edit code → npm test → git commit → git push → Render builds and deploys automatically
```

If the tests fail, do not push. If a deploy fails its health check, Render keeps the old version running. You can also roll back to any earlier deploy in the Render dashboard (**Events → Rollback**).

## 6. Domain and hosting

- Render gives a free address: `https://<service-name>.onrender.com`.
- **Your own domain** (for example `relief.yourcharity.org`): in Render → **Settings → Custom Domains**, add the domain, then add the `CNAME` record Render shows you at your domain seller. Render then issues the certificate automatically.
- **Free plan notes:** the web service sleeps after 15 minutes without visitors (the first visit after that takes about a minute), and the free database expires after 30 days. For real use, choose a paid plan for both.

## 7. HTTPS / SSL

- Render provides a free **Let's Encrypt** SSL certificate and renews it automatically.
- The app adds three more protections in production:
  1. **Redirect:** any `http://` request gets a 301 to `https://`.
  2. **HSTS:** browsers remember to use HTTPS for one year.
  3. **Secure cookies:** the session cookie is never sent over plain HTTP.

Checked by running the app with `NODE_ENV=production` on PostgreSQL 16:
```
http request  -> 301 https://cpms.example.org/login
https request -> Strict-Transport-Security: max-age=31536000; includeSubDomains
login         -> Set-Cookie: cpms.sid=...; HttpOnly; Secure; SameSite=Lax
```

You can test the live site's HTTPS for free at **ssllabs.com/ssltest** and its headers at **securityheaders.com**. Add both results to your report.

## 8. Backup considerations

| What | How | How often |
|---|---|---|
| Database | Render paid plans make daily backups automatically, with point-in-time recovery | Daily |
| Database (manual / free plan) | `scripts/backup.sh` (uses `pg_dump`, keeps the newest 14 files) | Daily, plus before every big change |
| Code | GitHub keeps every version | Every push |
| Secrets | Keep a copy of the environment variables in a password manager | When changed |

**Make a backup:**
```
DATABASE_URL="<External Database URL from Render>" ./scripts/backup.sh
# → backups/cpms-2026-11-16_0200.sql.gz
```

**Restore a backup:**
```
DATABASE_URL="<database url>" ./scripts/restore.sh backups/cpms-2026-11-16_0200.sql.gz
```

Good habits:
- Store backups somewhere other than the server (for example Google Drive or an S3 bucket).
- **Test a restore** into a spare database once a month. A backup you have never restored is not proven.
- The most important data is in `users`, `donations` and `expenses`. Donations can never be deleted by the app, so their history is always there.

## 9. Error and log monitoring

| What | Where |
|---|---|
| Every request (method, page, status, time taken, user ID) | Render → **Logs** (one JSON line per request) |
| Server errors with full details (stack trace) | Render → Logs, `"level":"error"`. The user only sees a friendly message. |
| Refused requests (403, 429, CSRF) | Render → Logs, `"level":"warn"` |
| Security and admin events (logins, failed logins, lockouts, access denied, every change) | In the app: **Admin → Activity log** (search and filter) |
| Is the site up? | `/health`, checked by Render. Add a free uptime monitor (for example UptimeRobot) on `https://<your-site>/health` to get an email if it goes down. |

Example log lines:
```json
{"time":"2026-11-16T15:19:45.492Z","level":"info","message":"server started","port":10000,"env":"production","database":"postgres"}
{"time":"2026-11-16T15:19:50.064Z","level":"info","message":"request","method":"GET","path":"/login","status":200,"ms":15,"user":null}
```

What to watch for:
- Many `auth.login_failed` or `auth.account_locked` entries from one IP address may mean someone is guessing passwords.
- `security.access_denied` entries mean a user tried to open a page they are not allowed to see.
- Any `"level":"error"` line should be investigated.

## 10. Go-live checklist

- [ ] `npm test` passes (156 tests)
- [ ] `NODE_ENV=production`
- [ ] `SESSION_SECRET` is long and random
- [ ] Strong `ADMIN_PASSWORD`, changed after the first login
- [ ] `DEMO_DATA=false` for real use
- [ ] Site opens on `https://` with a padlock, and `http://` redirects
- [ ] `/health` returns `ok`
- [ ] Backup made and test restore done
- [ ] Uptime monitor set up on `/health`
