// Writes a line to the activity log table (who did what, when, from which IP).
const db = require('./db');

async function log(req, action, details = null, userId) {
  const uid = userId !== undefined ? userId : req.user ? req.user.id : null;
  await db.query('INSERT INTO activity_log (user_id, action, details, ip_address) VALUES ($1, $2, $3, $4)', [
    uid,
    action,
    details ? String(details).slice(0, 300) : null,
    (req.ip || '').slice(0, 64),
  ]);
}

module.exports = { log };
