// Security middleware: CSRF tokens, login checks, roles and simple rate limiting.
const crypto = require('crypto');

// ---------- CSRF (Cross-Site Request Forgery) protection ----------
// Each session gets a secret random token. Every form sends it back in a hidden
// "_csrf" field. A form posted from another website cannot know the token, so it is refused.
function csrfToken(req) {
  if (!req.session.csrfToken) {
    req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  }
  return req.session.csrfToken;
}

function sameToken(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
}

function csrfProtection(req, res, next) {
  res.locals.csrfToken = csrfToken(req);
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const sent = (req.body && req.body._csrf) || req.get('x-csrf-token');
  if (!sameToken(sent, req.session.csrfToken)) {
    const err = new Error('Invalid or missing CSRF token');
    err.status = 403;
    err.publicMessage = 'Your form has expired or was not sent from this site. Please go back, refresh the page and try again.';
    return next(err);
  }
  next();
}

// ---------- Login and role checks ----------
function requireLogin(req, res, next) {
  if (!req.user) {
    req.session.returnTo = req.method === 'GET' ? req.originalUrl : undefined;
    req.session.flash = { type: 'info', message: 'Please log in to continue.' };
    return res.redirect('/login');
  }
  next();
}

function requireRole(role) {
  return (req, res, next) => {
    if (!req.user) return requireLogin(req, res, next);
    if (req.user.role !== role) {
      const err = new Error(`Role "${req.user.role}" tried to open ${req.originalUrl}`);
      err.status = 403;
      err.publicMessage = 'You do not have permission to open this page.';
      return next(err);
    }
    next();
  };
}

function guestOnly(req, res, next) {
  if (req.user) return res.redirect(req.user.role === 'admin' ? '/admin' : '/dashboard');
  next();
}

// ---------- Rate limiting (per IP address) ----------
// Stops one computer from sending too many login or sign-up attempts.
function rateLimit({ windowMs, max, name }) {
  const hits = new Map();
  return (req, res, next) => {
    if (req.method !== 'POST') return next();
    const key = req.ip;
    const now = Date.now();
    const entry = hits.get(key);
    if (!entry || now > entry.reset) {
      hits.set(key, { count: 1, reset: now + windowMs });
    } else {
      entry.count += 1;
      if (entry.count > max) {
        res.set('Retry-After', String(Math.ceil((entry.reset - now) / 1000)));
        const err = new Error(`Rate limit hit on ${name} from ${key}`);
        err.status = 429;
        err.publicMessage = 'Too many attempts from your network. Please wait a few minutes and try again.';
        return next(err);
      }
    }
    if (hits.size > 5000) {
      for (const [k, v] of hits) if (now > v.reset) hits.delete(k);
    }
    next();
  };
}

module.exports = { csrfProtection, requireLogin, requireRole, guestOnly, rateLimit };
