const path = require('path');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');

const config = require('./config');
const db = require('./db');
const logger = require('./logger');
const h = require('./helpers');
const DbSessionStore = require('./session-store');
const { csrfProtection } = require('./middleware/security');

function createApp() {
  const app = express();

  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, '..', 'views'));
  app.disable('x-powered-by'); // do not tell attackers which server we use
  if (config.trustProxy) app.set('trust proxy', 1);

  // ---------- HTTPS in production ----------
  if (config.forceHttps) {
    app.use((req, res, next) => {
      if (req.secure || req.path === '/health') return next();
      return res.redirect(301, `https://${req.get('host')}${req.originalUrl}`);
    });
  }

  // ---------- Security headers (Helmet) ----------
  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: false,
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          styleSrc: ["'self'"],
          imgSrc: ["'self'", 'data:'],
          fontSrc: ["'self'"],
          connectSrc: ["'self'"],
          formAction: ["'self'"],
          frameAncestors: ["'none'"],
          objectSrc: ["'none'"],
          baseUri: ["'self'"],
          ...(config.isProduction ? { upgradeInsecureRequests: [] } : {}),
        },
      },
      strictTransportSecurity: config.isProduction ? { maxAge: 31536000, includeSubDomains: true } : false,
      referrerPolicy: { policy: 'same-origin' },
    })
  );

  // ---------- Request logging ----------
  app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
      if (req.path.startsWith('/public') || req.path === '/health') return;
      logger.info('request', {
        method: req.method,
        path: req.path,
        status: res.statusCode,
        ms: Date.now() - start,
        user: req.user ? req.user.id : null,
      });
    });
    next();
  });

  app.use('/public', express.static(path.join(__dirname, '..', 'public'), { maxAge: config.isProduction ? '7d' : 0 }));

  // Health check for the hosting platform
  app.get('/health', async (req, res) => {
    try {
      await db.query('SELECT 1');
      res.json({ status: 'ok', database: 'ok' });
    } catch (err) {
      logger.error('health check failed', { error: err.message });
      res.status(503).json({ status: 'error', database: 'down' });
    }
  });

  // Small body size limit: blocks very large requests
  app.use(express.urlencoded({ extended: false, limit: '20kb' }));

  // ---------- Sessions ----------
  app.use(
    session({
      name: 'cpms.sid',
      store: new DbSessionStore(),
      secret: config.sessionSecret,
      resave: false,
      saveUninitialized: false,
      rolling: true, // the timer restarts on every request; the session ends after inactivity
      cookie: {
        httpOnly: true, // JavaScript in the page cannot read the cookie
        sameSite: 'lax', // the cookie is not sent with forms posted from other sites
        secure: config.isProduction, // only sent over HTTPS on the live site
        maxAge: config.sessionMinutes * 60 * 1000,
      },
    })
  );

  // Load the logged-in user from the database on every request, so role
  // changes and disabled accounts take effect straight away.
  app.use(async (req, res, next) => {
    req.user = null;
    if (req.session.userId) {
      const { rows } = await db.query(
        'SELECT id, full_name, email, phone, role, is_active, created_at FROM users WHERE id = $1',
        [req.session.userId]
      );
      if (rows[0] && rows[0].is_active) {
        req.user = rows[0];
      } else {
        delete req.session.userId;
      }
    }
    next();
  });

  // Values every page can use
  app.use((req, res, next) => {
    res.locals.h = h;
    res.locals.showDemo = config.demoData;
    res.locals.currentUser = req.user;
    res.locals.currentPath = req.path;
    res.locals.flash = req.session.flash || null;
    res.locals.errors = {};
    res.locals.values = {};
    delete req.session.flash;
    // Pages with personal data should not be kept in the browser cache
    res.set('Cache-Control', 'no-store');
    next();
  });

  app.use(csrfProtection);

  // ---------- Routes ----------
  app.use(require('./routes/public'));
  app.use(require('./routes/auth'));
  app.use(require('./routes/user'));
  app.use('/admin', require('./routes/admin'));

  // ---------- 404 ----------
  app.use((req, res) => {
    res.status(404).render('error', {
      title: 'Page not found',
      status: 404,
      message: 'We could not find that page. It may have been moved or deleted.',
    });
  });

  // ---------- Error handler ----------
  // Users see a friendly message. Technical details only go to the server log.
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    const status = err.status || err.statusCode || 500;
    if (status >= 500) {
      logger.error('server error', { path: req.path, error: err.message, stack: err.stack });
    } else {
      logger.warn('request refused', { path: req.path, status, reason: err.message });
    }
    if (status === 403 && req.user) {
      require('./activity')
        .log(req, 'security.access_denied', `${req.method} ${req.originalUrl}`.slice(0, 300))
        .catch(() => {});
    }
    const messages = {
      400: 'The request was not valid.',
      403: 'You do not have permission to do that.',
      413: 'What you sent is too large.',
      429: 'Too many attempts. Please wait and try again.',
      500: 'Something went wrong on our side. Please try again later.',
    };
    const message = err.publicMessage || (status >= 500 ? messages[500] : messages[status] || messages[400]);
    if (res.headersSent) return next(err);
    res.status(status).render('error', {
      title: status === 403 ? 'Access denied' : status >= 500 ? 'Server error' : 'Request problem',
      status,
      message,
    });
  });

  return app;
}

module.exports = { createApp };
