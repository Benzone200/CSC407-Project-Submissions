// Input validation. Every form is checked on the server, even if the browser also checks it,
// because a user can skip browser checks.
const { CATEGORIES, PROJECT_STATUS, TASK_STATUS, METHODS, AVAILABILITY } = require('./helpers');

const EMAIL_RE = /^[^\s@<>()[\]\\,;:"]+@[^\s@<>()[\]\\,;:"]+\.[a-z]{2,}$/i;
const PHONE_RE = /^\+?[0-9]{7,15}$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function text(v) {
  return typeof v === 'string' ? v.trim() : '';
}

function isRealDate(v) {
  if (!DATE_RE.test(v)) return false;
  const d = new Date(v + 'T00:00:00Z');
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === v;
}

// Whole naira amounts. Accepts "25,000" or "25000".
function wholeNumber(v) {
  const s = text(v).replace(/,/g, '');
  if (!/^\d{1,10}$/.test(s)) return NaN;
  return Number(s);
}

function strongPassword(pw) {
  return typeof pw === 'string' && pw.length >= 8 && pw.length <= 72 && /[A-Za-z]/.test(pw) && /\d/.test(pw);
}

const PASSWORD_RULE = 'Password must be 8 to 72 characters and include at least one letter and one number.';

function registration(body) {
  const data = {
    full_name: text(body.full_name),
    email: text(body.email).toLowerCase(),
    phone: text(body.phone).replace(/[\s-]/g, ''),
  };
  const errors = {};
  if (data.full_name.length < 2 || data.full_name.length > 80) errors.full_name = 'Enter your full name (2 to 80 characters).';
  else if (!/^[\p{L} .'-]+$/u.test(data.full_name)) errors.full_name = 'Name can only contain letters, spaces, dots, hyphens and apostrophes.';
  if (!EMAIL_RE.test(data.email) || data.email.length > 120) errors.email = 'Enter a valid email address.';
  if (data.phone && !PHONE_RE.test(data.phone)) errors.phone = 'Enter a valid phone number (digits only, 7 to 15).';
  if (!strongPassword(body.password)) errors.password = PASSWORD_RULE;
  else if (body.password !== body.confirm_password) errors.confirm_password = 'The two passwords do not match.';
  return { data, errors };
}

function profile(body) {
  const { data, errors } = registration({ ...body, email: 'x@x.co', password: 'abcdefg1', confirm_password: 'abcdefg1' });
  delete data.email;
  return { data, errors };
}

function passwordChange(body) {
  const errors = {};
  if (!body.current_password) errors.current_password = 'Enter your current password.';
  if (!strongPassword(body.new_password)) errors.new_password = PASSWORD_RULE;
  else if (body.new_password !== body.confirm_password) errors.confirm_password = 'The two passwords do not match.';
  else if (body.new_password === body.current_password) errors.new_password = 'Choose a password different from your current one.';
  return { errors };
}

function project(body) {
  const data = {
    title: text(body.title),
    category: text(body.category),
    summary: text(body.summary),
    description: text(body.description),
    location: text(body.location),
    target_amount: wholeNumber(body.target_amount),
    start_date: text(body.start_date),
    end_date: text(body.end_date) || null,
    status: text(body.status) || 'planned',
  };
  const errors = {};
  if (data.title.length < 5 || data.title.length > 120) errors.title = 'Title must be 5 to 120 characters.';
  if (!CATEGORIES[data.category]) errors.category = 'Choose a category from the list.';
  if (data.summary.length < 10 || data.summary.length > 200) errors.summary = 'Summary must be 10 to 200 characters.';
  if (data.description.length < 20 || data.description.length > 5000) errors.description = 'Description must be 20 to 5,000 characters.';
  if (data.location.length < 2 || data.location.length > 120) errors.location = 'Enter the location (2 to 120 characters).';
  if (!Number.isInteger(data.target_amount) || data.target_amount < 1000 || data.target_amount > 1000000000)
    errors.target_amount = 'Target must be a whole number between ₦1,000 and ₦1,000,000,000.';
  if (!isRealDate(data.start_date)) errors.start_date = 'Enter a valid start date.';
  if (data.end_date && !isRealDate(data.end_date)) errors.end_date = 'Enter a valid end date.';
  else if (data.end_date && !errors.start_date && data.end_date < data.start_date) errors.end_date = 'End date cannot be before the start date.';
  if (!PROJECT_STATUS[data.status]) errors.status = 'Choose a valid status.';
  return { data, errors };
}

function task(body) {
  const data = { title: text(body.title), due_date: text(body.due_date) || null, status: text(body.status) || 'todo' };
  const errors = {};
  if (data.title.length < 3 || data.title.length > 120) errors.title = 'Task must be 3 to 120 characters.';
  if (data.due_date && !isRealDate(data.due_date)) errors.due_date = 'Enter a valid due date.';
  if (!TASK_STATUS[data.status]) errors.status = 'Choose a valid status.';
  return { data, errors };
}

function expense(body) {
  const data = { description: text(body.description), amount: wholeNumber(body.amount), spent_on: text(body.spent_on) };
  const errors = {};
  if (data.description.length < 3 || data.description.length > 150) errors.description = 'Description must be 3 to 150 characters.';
  if (!Number.isInteger(data.amount) || data.amount < 1 || data.amount > 1000000000) errors.amount = 'Enter a whole amount in naira.';
  if (!isRealDate(data.spent_on)) errors.spent_on = 'Enter a valid date.';
  else if (data.spent_on > new Date().toISOString().slice(0, 10)) errors.spent_on = 'Date cannot be in the future.';
  return { data, errors };
}

function donation(body) {
  const data = { amount: wholeNumber(body.amount), method: text(body.method), message: text(body.message) || null };
  const errors = {};
  if (!Number.isInteger(data.amount) || data.amount < 100 || data.amount > 100000000)
    errors.amount = 'Amount must be a whole number between ₦100 and ₦100,000,000.';
  if (!METHODS[data.method]) errors.method = 'Choose how you will pay.';
  if (data.message && data.message.length > 300) errors.message = 'Message must be 300 characters or less.';
  return { data, errors };
}

function volunteer(body) {
  const data = { skills: text(body.skills), availability: text(body.availability) };
  const errors = {};
  if (data.skills.length < 3 || data.skills.length > 200) errors.skills = 'Tell us how you can help (3 to 200 characters).';
  if (!AVAILABILITY[data.availability]) errors.availability = 'Choose when you are available.';
  return { data, errors };
}

// Route IDs must be positive whole numbers. Anything else is treated as "not found".
function id(v) {
  return /^[1-9]\d{0,8}$/.test(String(v)) ? Number(v) : null;
}

module.exports = {
  text, registration, profile, passwordChange, project, task, expense, donation, volunteer, id,
  isRealDate, strongPassword, PASSWORD_RULE,
};
