// Saves login sessions in the "sessions" table.
// The browser only holds a random session ID in a cookie; the real data stays on the server.
const session = require('express-session');
const db = require('./db');

class DbSessionStore extends session.Store {
  constructor() {
    super();
    this.lastCleanup = 0;
  }

  expiry(sess) {
    const ms = sess && sess.cookie && sess.cookie.expires ? new Date(sess.cookie.expires).getTime() : Date.now() + 86400000;
    return new Date(ms);
  }

  async cleanup() {
    // Delete old sessions at most once every 10 minutes
    if (Date.now() - this.lastCleanup < 600000) return;
    this.lastCleanup = Date.now();
    await db.query('DELETE FROM sessions WHERE expire < NOW()');
  }

  get(sid, cb) {
    db.query('SELECT sess FROM sessions WHERE sid = $1 AND expire > NOW()', [sid])
      .then((r) => cb(null, r.rows[0] ? r.rows[0].sess : null))
      .catch(cb);
  }

  set(sid, sess, cb) {
    db.query(
      `INSERT INTO sessions (sid, sess, expire) VALUES ($1, $2, $3)
       ON CONFLICT (sid) DO UPDATE SET sess = EXCLUDED.sess, expire = EXCLUDED.expire`,
      [sid, JSON.stringify(sess), this.expiry(sess)]
    )
      .then(() => this.cleanup())
      .then(() => cb && cb(null))
      .catch((err) => cb && cb(err));
  }

  destroy(sid, cb) {
    db.query('DELETE FROM sessions WHERE sid = $1', [sid])
      .then(() => cb && cb(null))
      .catch((err) => cb && cb(err));
  }

  touch(sid, sess, cb) {
    db.query('UPDATE sessions SET expire = $2 WHERE sid = $1', [sid, this.expiry(sess)])
      .then(() => cb && cb(null))
      .catch((err) => cb && cb(err));
  }
}

module.exports = DbSessionStore;
