// All settings come from environment variables (see .env.example).
// Nothing secret is written in the code.
require('dotenv').config({ quiet: true });

const env = process.env.NODE_ENV || 'development';
const isProduction = env === 'production';

function required(name) {
  const value = process.env[name];
  if (!value) {
    throw new Error(`Missing environment variable: ${name}`);
  }
  return value;
}

const config = {
  env,
  isProduction,
  isTest: env === 'test',
  port: Number(process.env.PORT) || 3000,

  // PostgreSQL connection. If DATABASE_URL is empty, the app uses a small
  // built-in PostgreSQL (PGlite) stored in ./data so it runs without setup.
  databaseUrl: process.env.DATABASE_URL || '',
  databaseSsl: process.env.DATABASE_SSL === 'true',
  localDataDir: process.env.LOCAL_DB_DIR || './data/local-db',

  // In production the session secret must be set. In development a fixed
  // value is fine because the data is only on your own computer.
  sessionSecret: isProduction
    ? required('SESSION_SECRET')
    : process.env.SESSION_SECRET || 'dev-only-secret-change-me',
  sessionMinutes: Number(process.env.SESSION_MINUTES) || 30,

  bcryptRounds: Number(process.env.BCRYPT_ROUNDS) || 12,

  // Login protection
  maxFailedLogins: 5,
  lockMinutes: 15,

  // Behind a host like Render the app sits behind a proxy that handles HTTPS.
  trustProxy: process.env.TRUST_PROXY === 'true' || isProduction,
  forceHttps: process.env.FORCE_HTTPS === 'true' || isProduction,

  logFile: process.env.LOG_FILE || '',

  // Sample projects and test accounts. Always on in development; on the live site
  // only when DEMO_DATA=true (useful for a class demo, never for real use).
  demoData: !isProduction || process.env.DEMO_DATA === 'true',
};

module.exports = config;
