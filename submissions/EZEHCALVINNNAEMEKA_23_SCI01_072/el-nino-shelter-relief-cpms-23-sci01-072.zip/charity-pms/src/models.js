// Shared database queries
const db = require('./db');
const { CATEGORIES, PROJECT_STATUS } = require('./helpers');

// Escape % and _ so a search for "50%" looks for the text "50%" and is not a wildcard.
function likePattern(s) {
  return '%' + String(s).replace(/[\\%_]/g, (c) => '\\' + c) + '%';
}

const PROJECT_SELECT = `
  SELECT p.*,
         COALESCE(d.raised, 0)  AS raised,
         COALESCE(d.donors, 0)  AS donors,
         COALESCE(e.spent, 0)   AS spent
  FROM projects p
  LEFT JOIN (SELECT project_id, SUM(amount) AS raised, COUNT(DISTINCT user_id) AS donors
             FROM donations WHERE status = 'confirmed' GROUP BY project_id) d ON d.project_id = p.id
  LEFT JOIN (SELECT project_id, SUM(amount) AS spent FROM expenses GROUP BY project_id) e ON e.project_id = p.id`;

// Sorting options are fixed here. The user only picks a key, never writes SQL.
const SORTS = {
  newest: { label: 'Newest first', sql: 'p.created_at DESC, p.id DESC' },
  ending: { label: 'Ending soon', sql: 'p.end_date ASC NULLS LAST, p.id' },
  most_funded: { label: 'Most funded (%)', sql: '(COALESCE(d.raised,0)::float / p.target_amount) DESC, p.id' },
  target: { label: 'Biggest target', sql: 'p.target_amount DESC, p.id' },
};

function cleanFilters(query, { allowedStatuses } = {}) {
  const pick = (v) => (typeof v === 'string' ? v.trim() : '');
  const f = {
    q: pick(query.q).slice(0, 80),
    category: pick(query.category),
    status: pick(query.status),
    sort: pick(query.sort),
    page: Math.max(1, Math.min(1000, parseInt(query.page, 10) || 1)),
  };
  if (!CATEGORIES[f.category]) f.category = '';
  if (!PROJECT_STATUS[f.status] || (allowedStatuses && !allowedStatuses.includes(f.status))) f.status = '';
  if (!SORTS[f.sort]) f.sort = 'newest';
  return f;
}

async function listProjects(f, { perPage = 9, statuses } = {}) {
  const where = [];
  const params = [];
  if (f.q) {
    params.push(likePattern(f.q));
    where.push(`(p.title ILIKE $${params.length} OR p.summary ILIKE $${params.length} OR p.location ILIKE $${params.length})`);
  }
  if (f.category) {
    params.push(f.category);
    where.push(`p.category = $${params.length}`);
  }
  if (f.status) {
    params.push(f.status);
    where.push(`p.status = $${params.length}`);
  } else if (statuses) {
    params.push(statuses);
    where.push(`p.status = ANY($${params.length})`);
  }
  const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const count = await db.query(`SELECT COUNT(*) AS n FROM projects p ${whereSql}`, params);
  const total = count.rows[0].n;
  const pages = Math.max(1, Math.ceil(total / perPage));
  const page = Math.min(f.page, pages);
  const rows = await db.query(
    `${PROJECT_SELECT} ${whereSql} ORDER BY ${SORTS[f.sort].sql} LIMIT ${perPage} OFFSET ${(page - 1) * perPage}`,
    params
  );
  return { projects: rows.rows, total, page, pages };
}

async function getProject(id) {
  const { rows } = await db.query(`${PROJECT_SELECT} WHERE p.id = $1`, [id]);
  return rows[0] || null;
}

async function projectTasks(id) {
  const { rows } = await db.query(
    `SELECT * FROM tasks WHERE project_id = $1
     ORDER BY CASE status WHEN 'in_progress' THEN 0 WHEN 'todo' THEN 1 ELSE 2 END, due_date NULLS LAST, id`,
    [id]
  );
  return rows;
}

async function projectExpenses(id) {
  const { rows } = await db.query('SELECT * FROM expenses WHERE project_id = $1 ORDER BY spent_on DESC, id DESC', [id]);
  return rows;
}

// Total figures for the home page and admin dashboard
async function siteTotals() {
  const { rows } = await db.query(`
    SELECT
      (SELECT COALESCE(SUM(amount), 0) FROM donations WHERE status = 'confirmed') AS raised,
      (SELECT COALESCE(SUM(amount), 0) FROM expenses)                           AS spent,
      (SELECT COUNT(*) FROM projects WHERE status = 'active')                   AS active_projects,
      (SELECT COUNT(*) FROM projects WHERE status = 'completed')                AS completed_projects,
      (SELECT COUNT(*) FROM projects)                                           AS projects,
      (SELECT COUNT(DISTINCT user_id) FROM donations WHERE status = 'confirmed') AS donors,
      (SELECT COUNT(*) FROM volunteers WHERE status = 'approved')               AS volunteers,
      (SELECT COUNT(*) FROM donations WHERE status = 'pending')                 AS pending_donations,
      (SELECT COALESCE(SUM(amount), 0) FROM donations WHERE status = 'pending') AS pending_amount,
      (SELECT COUNT(*) FROM volunteers WHERE status = 'pending')                AS pending_volunteers,
      (SELECT COUNT(*) FROM users)                                              AS users`);
  return rows[0];
}

module.exports = { likePattern, SORTS, cleanFilters, listProjects, getProject, projectTasks, projectExpenses, siteTotals };
