// Creates the tables and fills in starting data.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const bcrypt = require('bcrypt');
const db = require('./db');
const config = require('./config');

async function migrate() {
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  await db.exec(sql);
}

function newReference() {
  return 'DON-' + crypto.randomBytes(4).toString('hex').toUpperCase();
}

function daysFromToday(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

// Adds the admin account and sample data, but only if the database is empty.
async function seed({ demo = true } = {}) {
  const { rows } = await db.query('SELECT COUNT(*) AS n FROM users');
  if (rows[0].n > 0) return { created: false };

  let adminEmail = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  let adminPassword = process.env.ADMIN_PASSWORD || '';
  if (config.isProduction && (!adminEmail || !adminPassword)) {
    throw new Error('Set ADMIN_EMAIL and ADMIN_PASSWORD before the first start in production.');
  }
  if (!adminEmail) adminEmail = 'admin@charity.test';
  if (!adminPassword) adminPassword = 'Admin@12345';

  const hash = (pw) => bcrypt.hash(pw, config.bcryptRounds);
  const admin = await db.query(
    `INSERT INTO users (full_name, email, phone, password_hash, role)
     VALUES ($1, $2, $3, $4, 'admin') RETURNING id`,
    ['Programme Admin', adminEmail, '08030000000', await hash(adminPassword)]
  );
  const adminId = admin.rows[0].id;

  if (!demo || !config.demoData) return { created: true };

  // Sample donors / volunteers
  const userHash = await hash('User@12345');
  const people = [
    ['Chiamaka Okafor', 'user@charity.test', '08031234567'],
    ['Tunde Bakare', 'tunde@charity.test', '08051112222'],
    ['Halima Musa', 'halima@charity.test', '08093334444'],
  ];
  const userIds = [];
  for (const [name, email, phone] of people) {
    const r = await db.query(
      `INSERT INTO users (full_name, email, phone, password_hash) VALUES ($1, $2, $3, $4) RETURNING id`,
      [name, email, phone, userHash]
    );
    userIds.push(r.rows[0].id);
  }

  // Sample projects: shelter and relief for families hit by the El Niño heatwave
  const projects = [
    {
      title: 'Cooling Shelters for the El Niño Heatwave',
      category: 'shelter',
      summary: 'Three shaded, well-ventilated cooling shelters where 1,500 people can rest safely during the hottest hours.',
      description:
        'The El Niño heatwave has pushed afternoon temperatures above 44°C. Older people, babies and people living in hot zinc-roofed rooms are at high risk of heatstroke. This project turns three community halls into cooling shelters with fans, solar power, shade nets, drinking water and resting mats. The shelters open from 11 am to 5 pm every day during the heatwave, and volunteers keep a daily register of visitors.',
      location: 'Maiduguri, Borno State',
      target: 9000000,
      start: -30,
      end: 45,
      status: 'active',
      tasks: [
        ['Agree use of 3 community halls with ward leaders', -25, 'done'],
        ['Buy fans, solar panels and batteries', -8, 'done'],
        ['Fit shade nets and set up the shelters', 10, 'in_progress'],
        ['Train volunteers to spot heatstroke', 25, 'todo'],
      ],
      expenses: [
        ['Solar panels, batteries and inverters', 2100000, -9],
        ['Standing fans (60 pieces) and resting mats', 950000, -7],
        ['Transport of equipment to the halls', 180000, -4],
      ],
    },
    {
      title: 'Heat-Safe Roofs for Vulnerable Homes',
      category: 'shelter',
      summary: 'Insulated ceilings, reflective roof paint and vents for 60 homes that get dangerously hot.',
      description:
        'Many families live under bare zinc roofs that trap heat, so their rooms stay hot even at night. This project fits ceiling insulation, paints roofs with heat-reflective paint and adds air vents to 60 homes chosen by a community committee. Widows, older people and families with small children are helped first.',
      location: 'Kano, Kano State',
      target: 7500000,
      start: -15,
      end: 75,
      status: 'active',
      tasks: [
        ['Community committee picks 60 homes', -10, 'done'],
        ['Buy insulation boards and reflective paint', 5, 'in_progress'],
        ['Fit the first 30 homes', 40, 'todo'],
        ['Fit the remaining 30 homes', 70, 'todo'],
      ],
      expenses: [['Home heat survey and measurements', 250000, -6]],
    },
    {
      title: 'Drinking Water Points for Heat-Hit Communities',
      category: 'water',
      summary: 'Solar borehole and shaded water points so families can stay hydrated during the drought.',
      description:
        'El Niño has brought very little rain, and many wells have dried up. This project drills a solar-powered borehole and builds four shaded water points near the cooling shelters, so people can get safe drinking water without walking long distances in the heat.',
      location: 'Maiduguri, Borno State',
      target: 4000000,
      start: 5,
      end: 60,
      status: 'planned',
      tasks: [
        ['Water test and site survey', 5, 'in_progress'],
        ['Drill borehole and build water points', 30, 'todo'],
      ],
      expenses: [],
    },
    {
      title: 'Heatstroke Checks and First Aid',
      category: 'health',
      summary: 'Free checks for heat exhaustion, dehydration and high blood pressure in the cooling shelters.',
      description:
        'Volunteer doctors and nurses will visit the cooling shelters every week for two months. They will check people for heat exhaustion and dehydration, give oral rehydration salts, and refer serious cases to the general hospital.',
      location: 'Sokoto, Sokoto State',
      target: 2500000,
      start: 10,
      end: 70,
      status: 'planned',
      tasks: [
        ['Recruit 10 medical volunteers', 5, 'in_progress'],
        ['Buy rehydration salts and first-aid kits', 15, 'todo'],
      ],
      expenses: [],
    },
    {
      title: 'Food Packs for Drought-Hit Farming Families',
      category: 'food',
      summary: 'Rice, beans, garri and oil for 300 farming families whose crops failed in the heat.',
      description:
        'The heat and lack of rain destroyed many farms this season. Each pack holds rice, beans, garri, vegetable oil and salt, enough for one family for two weeks. Packs were given out at community centres using a registered list.',
      location: 'Yola, Adamawa State',
      target: 3000000,
      start: -120,
      end: -60,
      status: 'completed',
      tasks: [
        ['Register farming families with community leaders', -110, 'done'],
        ['Buy and pack food items', -75, 'done'],
        ['Distribute food packs', -62, 'done'],
      ],
      expenses: [
        ['Rice, beans, garri and oil (300 packs)', 2650000, -76],
        ['Packing bags and labour', 120000, -70],
        ['Transport and loading', 95000, -63],
      ],
    },
    {
      title: 'Tree Shade Belts Around Shelters',
      category: 'environment',
      summary: 'Plant 1,000 neem and shade trees around shelters and schools to cool them in future heatwaves.',
      description:
        'Trees lower the temperature around buildings. Youth groups will plant and water neem and other shade trees around the cooling shelters and nearby schools, and care for them for one year.',
      location: 'Kano, Kano State',
      target: 1200000,
      start: 30,
      end: 180,
      status: 'on_hold',
      tasks: [['Get land approval from the local government', 20, 'in_progress']],
      expenses: [],
    },
  ];

  const projectIds = [];
  for (const p of projects) {
    const r = await db.query(
      `INSERT INTO projects (title, category, summary, description, location, target_amount, start_date, end_date, status, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING id`,
      [p.title, p.category, p.summary, p.description, p.location, p.target, daysFromToday(p.start), daysFromToday(p.end), p.status, adminId]
    );
    const id = r.rows[0].id;
    projectIds.push(id);
    for (const [title, due, status] of p.tasks) {
      await db.query('INSERT INTO tasks (project_id, title, due_date, status) VALUES ($1, $2, $3, $4)', [id, title, daysFromToday(due), status]);
    }
    for (const [desc, amount, day] of p.expenses) {
      await db.query(
        'INSERT INTO expenses (project_id, description, amount, spent_on, recorded_by) VALUES ($1, $2, $3, $4, $5)',
        [id, desc, amount, daysFromToday(day), adminId]
      );
    }
  }

  // [projectIndex, userIndex, amount, method, status, message]
  const donations = [
    [0, 0, 250000, 'bank_transfer', 'confirmed', 'Stay cool and safe.'],
    [0, 1, 4000000, 'bank_transfer', 'confirmed', null],
    [0, 2, 500000, 'card', 'confirmed', 'From my family'],
    [0, 0, 50000, 'cash', 'pending', null],
    [1, 1, 2000000, 'bank_transfer', 'confirmed', 'For the families who need it most.'],
    [1, 2, 300000, 'card', 'pending', null],
    [1, 0, 20000, 'card', 'rejected', null],
    [4, 0, 1800000, 'bank_transfer', 'confirmed', null],
    [4, 1, 1200000, 'bank_transfer', 'confirmed', 'God bless this work'],
    [2, 2, 100000, 'card', 'pending', 'Happy to support'],
  ];
  let daysAgo = donations.length * 3;
  for (const [pi, ui, amount, method, status, message] of donations) {
    const made = new Date(Date.now() - daysAgo * 86400000);
    const reviewed = new Date(made.getTime() + 86400000);
    daysAgo -= 3;
    await db.query(
      `INSERT INTO donations (reference, project_id, user_id, amount, method, message, status, reviewed_by, reviewed_at, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [newReference(), projectIds[pi], userIds[ui], amount, method, message, status,
        status === 'pending' ? null : adminId, status === 'pending' ? null : reviewed, made]
    );
  }

  const volunteers = [
    [0, 0, 'Teaching and record keeping', 'weekends', 'approved'],
    [1, 1, 'Roofing and painting', 'weekdays', 'pending'],
    [3, 2, 'Registered nurse', 'anytime', 'approved'],
    [0, 1, 'Driving and delivering water', 'anytime', 'pending'],
  ];
  for (const [pi, ui, skills, availability, status] of volunteers) {
    await db.query(
      'INSERT INTO volunteers (project_id, user_id, skills, availability, status) VALUES ($1, $2, $3, $4, $5)',
      [projectIds[pi], userIds[ui], skills, availability, status]
    );
  }

  await db.query("INSERT INTO activity_log (user_id, action, details) VALUES ($1, 'system.seed', 'Sample data added')", [adminId]);
  return { created: true };
}

module.exports = { migrate, seed, newReference };
