// Labels and small helpers shared by routes and pages.

const CATEGORIES = {
  education: { label: 'Education', icon: '📚' },
  health: { label: 'Health', icon: '🩺' },
  food: { label: 'Food Support', icon: '🍲' },
  water: { label: 'Clean Water', icon: '💧' },
  shelter: { label: 'Shelter', icon: '🏠' },
  environment: { label: 'Environment', icon: '🌳' },
};

const PROJECT_STATUS = {
  planned: { label: 'Planned' },
  active: { label: 'Active' },
  on_hold: { label: 'On hold' },
  completed: { label: 'Completed' },
};

const TASK_STATUS = {
  todo: { label: 'To do' },
  in_progress: { label: 'In progress' },
  done: { label: 'Done' },
};

const DONATION_STATUS = {
  pending: { label: 'Pending' },
  confirmed: { label: 'Confirmed' },
  rejected: { label: 'Rejected' },
};

const VOLUNTEER_STATUS = {
  pending: { label: 'Pending' },
  approved: { label: 'Approved' },
  declined: { label: 'Declined' },
};

const METHODS = {
  bank_transfer: { label: 'Bank transfer' },
  card: { label: 'Card (POS)' },
  cash: { label: 'Cash at office' },
};

const AVAILABILITY = {
  weekdays: { label: 'Weekdays' },
  weekends: { label: 'Weekends' },
  anytime: { label: 'Any time' },
};

function naira(n) {
  return '₦' + Number(n || 0).toLocaleString('en-NG', { maximumFractionDigits: 0 });
}

function percent(part, whole) {
  if (!whole) return 0;
  return Math.min(100, Math.round((Number(part) / Number(whole)) * 100));
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function formatDate(v) {
  if (!v) return '—';
  const s = typeof v === 'string' ? v.slice(0, 10) : new Date(v).toISOString().slice(0, 10);
  const [y, m, d] = s.split('-');
  return `${Number(d)} ${MONTHS[Number(m) - 1]} ${y}`;
}

function formatDateTime(v) {
  if (!v) return '—';
  const d = new Date(v);
  const time = d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', timeZone: 'Africa/Lagos' });
  const day = d.toLocaleDateString('en-CA', { timeZone: 'Africa/Lagos' });
  return `${formatDate(day)}, ${time}`;
}

function firstName(name) {
  return String(name || '').split(' ')[0];
}

function initials(name) {
  return String(name || '?')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0].toUpperCase())
    .join('');
}

// Builds a link that keeps the current filters but changes one value (used by pagination).
function withQuery(base, query, changes) {
  const params = new URLSearchParams();
  for (const [k, v] of Object.entries({ ...query, ...changes })) {
    if (v !== undefined && v !== null && v !== '') params.set(k, v);
  }
  const s = params.toString();
  return s ? `${base}?${s}` : base;
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

module.exports = {
  CATEGORIES, PROJECT_STATUS, TASK_STATUS, DONATION_STATUS, VOLUNTEER_STATUS, METHODS, AVAILABILITY,
  naira, percent, formatDate, formatDateTime, firstName, initials, withQuery, today,
};
