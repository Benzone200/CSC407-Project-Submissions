// Pages anyone can see: home, project list, project details, security page
const express = require('express');
const db = require('../db');
const models = require('../models');
const validate = require('../validate');

const router = express.Router();

router.get('/', async (req, res) => {
  const totals = await models.siteTotals();
  const { projects } = await models.listProjects(models.cleanFilters({ sort: 'most_funded' }), {
    perPage: 3,
    statuses: ['active'],
  });
  res.render('home', { title: 'Home', totals, projects });
});

router.get('/projects', async (req, res) => {
  const filters = models.cleanFilters(req.query);
  const result = await models.listProjects(filters);
  res.render('projects', { title: 'Projects', filters, ...result, sorts: models.SORTS });
});

router.get('/projects/:id', async (req, res, next) => {
  const id = validate.id(req.params.id);
  const project = id && (await models.getProject(id));
  if (!project) return next(); // 404

  const [tasks, expenses, recentDonors] = await Promise.all([
    models.projectTasks(id),
    models.projectExpenses(id),
    // Only first name and first letter of surname are shown in public, never email or phone
    db.query(
      `SELECT u.full_name, d.amount, d.message, d.created_at
       FROM donations d JOIN users u ON u.id = d.user_id
       WHERE d.project_id = $1 AND d.status = 'confirmed'
       ORDER BY d.created_at DESC LIMIT 5`,
      [id]
    ),
  ]);

  let myVolunteer = null;
  let myDonations = [];
  if (req.user && req.user.role === 'user') {
    const v = await db.query('SELECT * FROM volunteers WHERE project_id = $1 AND user_id = $2', [id, req.user.id]);
    myVolunteer = v.rows[0] || null;
    const d = await db.query(
      'SELECT * FROM donations WHERE project_id = $1 AND user_id = $2 ORDER BY created_at DESC',
      [id, req.user.id]
    );
    myDonations = d.rows;
  }

  // If a donate/volunteer form had mistakes, show them again (saved by the form handler)
  const formState = req.session.formState && req.session.formState.projectId === id ? req.session.formState : null;
  delete req.session.formState;

  res.render('project', {
    title: project.title,
    formState,
    project,
    tasks,
    expenses,
    recentDonors: recentDonors.rows,
    myVolunteer,
    myDonations,
  });
});

router.get('/security', (req, res) => {
  res.render('security', { title: 'How we keep your data safe' });
});

module.exports = router;
