// Admin area. Every route here needs the "admin" role (checked once below for the whole router).
const express = require('express');
const db = require('../db');
const activity = require('../activity');
const validate = require('../validate');
const models = require('../models');
const h = require('../helpers');
const { requireRole } = require('../middleware/security');

const router = express.Router();
router.use(requireRole('admin'));

const PER_PAGE = 15;

function pageOf(query) {
  return Math.max(1, Math.min(1000, parseInt(query.page, 10) || 1));
}

// ---------- Dashboard ----------
router.get('/', async (req, res) => {
  const [totals, pending, projects, recent] = await Promise.all([
    models.siteTotals(),
    db.query(
      `SELECT d.*, u.full_name, p.title FROM donations d
       JOIN users u ON u.id = d.user_id JOIN projects p ON p.id = d.project_id
       WHERE d.status = 'pending' ORDER BY d.created_at ASC LIMIT 6`
    ),
    models.listProjects(models.cleanFilters({ sort: 'ending' }), { perPage: 6, statuses: ['active', 'planned', 'on_hold'] }),
    db.query(
      `SELECT a.*, u.full_name FROM activity_log a LEFT JOIN users u ON u.id = a.user_id
       ORDER BY a.created_at DESC, a.id DESC LIMIT 8`
    ),
  ]);
  const byCategory = await db.query(
    `SELECT p.category, COALESCE(SUM(d.amount), 0) AS raised
     FROM projects p LEFT JOIN donations d ON d.project_id = p.id AND d.status = 'confirmed'
     GROUP BY p.category ORDER BY raised DESC`
  );
  res.render('admin/dashboard', {
    title: 'Admin dashboard',
    totals,
    pending: pending.rows,
    projects: projects.projects,
    recent: recent.rows,
    byCategory: byCategory.rows,
  });
});

// ---------- Projects ----------
router.get('/projects', async (req, res) => {
  const filters = models.cleanFilters(req.query);
  const result = await models.listProjects(filters, { perPage: PER_PAGE });
  res.render('admin/projects', { title: 'Manage projects', filters, ...result, sorts: models.SORTS });
});

router.get('/projects/new', (req, res) => {
  res.render('admin/project-form', {
    title: 'New project',
    project: null,
    values: { status: 'planned', start_date: h.today() },
  });
});

router.post('/projects', async (req, res) => {
  const { data, errors } = validate.project(req.body);
  if (Object.keys(errors).length) {
    return res.status(422).render('admin/project-form', { title: 'New project', project: null, values: req.body, errors });
  }
  const { rows } = await db.query(
    `INSERT INTO projects (title, category, summary, description, location, target_amount, start_date, end_date, status, created_by)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING id`,
    [data.title, data.category, data.summary, data.description, data.location, data.target_amount, data.start_date, data.end_date, data.status, req.user.id]
  );
  await activity.log(req, 'project.create', `#${rows[0].id} ${data.title}`);
  req.session.flash = { type: 'success', message: 'Project created. You can now add tasks and expenses.' };
  res.redirect(`/admin/projects/${rows[0].id}`);
});

async function loadProject(req, res, next) {
  const id = validate.id(req.params.id);
  const project = id && (await models.getProject(id));
  if (!project) return next('route');
  req.project = project;
  next();
}

router.get('/projects/:id', loadProject, async (req, res) => {
  const id = req.project.id;
  const [tasks, expenses, donations, volunteers] = await Promise.all([
    models.projectTasks(id),
    models.projectExpenses(id),
    db.query(
      `SELECT d.*, u.full_name FROM donations d JOIN users u ON u.id = d.user_id
       WHERE d.project_id = $1 ORDER BY d.created_at DESC LIMIT 20`,
      [id]
    ),
    db.query(
      `SELECT v.*, u.full_name, u.email, u.phone FROM volunteers v JOIN users u ON u.id = v.user_id
       WHERE v.project_id = $1 ORDER BY v.created_at DESC`,
      [id]
    ),
  ]);
  const formState = req.session.formState && req.session.formState.projectId === id ? req.session.formState : null;
  delete req.session.formState;
  res.render('admin/project', {
    title: req.project.title,
    project: req.project,
    tasks,
    expenses,
    donations: donations.rows,
    volunteers: volunteers.rows,
    formState,
  });
});

router.get('/projects/:id/edit', loadProject, (req, res) => {
  res.render('admin/project-form', { title: 'Edit project', project: req.project, values: req.project });
});

router.post('/projects/:id', loadProject, async (req, res) => {
  const { data, errors } = validate.project(req.body);
  if (Object.keys(errors).length) {
    return res.status(422).render('admin/project-form', { title: 'Edit project', project: req.project, values: req.body, errors });
  }
  await db.query(
    `UPDATE projects SET title = $2, category = $3, summary = $4, description = $5, location = $6,
       target_amount = $7, start_date = $8, end_date = $9, status = $10, updated_at = NOW()
     WHERE id = $1`,
    [req.project.id, data.title, data.category, data.summary, data.description, data.location, data.target_amount, data.start_date, data.end_date, data.status]
  );
  const statusNote = data.status !== req.project.status ? ` (status ${req.project.status} → ${data.status})` : '';
  await activity.log(req, 'project.update', `#${req.project.id} ${data.title}${statusNote}`);
  req.session.flash = { type: 'success', message: 'Project saved.' };
  res.redirect(`/admin/projects/${req.project.id}`);
});

router.post('/projects/:id/delete', loadProject, async (req, res) => {
  const { rows } = await db.query('SELECT COUNT(*) AS n FROM donations WHERE project_id = $1', [req.project.id]);
  if (rows[0].n > 0) {
    req.session.flash = {
      type: 'error',
      message: 'This project has donations, so it cannot be deleted (money records must be kept). Mark it as "Completed" or "On hold" instead.',
    };
    return res.redirect(`/admin/projects/${req.project.id}`);
  }
  await db.query('DELETE FROM projects WHERE id = $1', [req.project.id]);
  await activity.log(req, 'project.delete', `#${req.project.id} ${req.project.title}`);
  req.session.flash = { type: 'success', message: 'Project deleted.' };
  res.redirect('/admin/projects');
});

// ---------- Tasks ----------
router.post('/projects/:id/tasks', loadProject, async (req, res) => {
  const { data, errors } = validate.task(req.body);
  if (Object.keys(errors).length) {
    req.session.formState = { projectId: req.project.id, form: 'task', values: data, errors };
    return res.redirect(`/admin/projects/${req.project.id}#tasks`);
  }
  await db.query('INSERT INTO tasks (project_id, title, due_date, status) VALUES ($1, $2, $3, $4)', [
    req.project.id, data.title, data.due_date, data.status,
  ]);
  await activity.log(req, 'task.create', `Project #${req.project.id}: ${data.title}`);
  res.redirect(`/admin/projects/${req.project.id}#tasks`);
});

router.post('/tasks/:id/status', async (req, res, next) => {
  const id = validate.id(req.params.id);
  const status = validate.text(req.body.status);
  if (!id) return next();
  if (!h.TASK_STATUS[status]) {
    const err = new Error('Bad task status');
    err.status = 400;
    return next(err);
  }
  const r = await db.query('UPDATE tasks SET status = $2 WHERE id = $1 RETURNING project_id, title', [id, status]);
  if (!r.rows.length) return next();
  await activity.log(req, 'task.status', `${r.rows[0].title} → ${status}`);
  res.redirect(`/admin/projects/${r.rows[0].project_id}#tasks`);
});

router.post('/tasks/:id/delete', async (req, res, next) => {
  const id = validate.id(req.params.id);
  if (!id) return next();
  const r = await db.query('DELETE FROM tasks WHERE id = $1 RETURNING project_id, title', [id]);
  if (!r.rows.length) return next();
  await activity.log(req, 'task.delete', r.rows[0].title);
  res.redirect(`/admin/projects/${r.rows[0].project_id}#tasks`);
});

// ---------- Expenses ----------
router.post('/projects/:id/expenses', loadProject, async (req, res) => {
  const { data, errors } = validate.expense(req.body);
  if (Object.keys(errors).length) {
    req.session.formState = {
      projectId: req.project.id,
      form: 'expense',
      values: { description: data.description, amount: validate.text(req.body.amount).slice(0, 20), spent_on: data.spent_on },
      errors,
    };
    return res.redirect(`/admin/projects/${req.project.id}#expenses`);
  }
  await db.query(
    'INSERT INTO expenses (project_id, description, amount, spent_on, recorded_by) VALUES ($1, $2, $3, $4, $5)',
    [req.project.id, data.description, data.amount, data.spent_on, req.user.id]
  );
  await activity.log(req, 'expense.create', `Project #${req.project.id}: ${h.naira(data.amount)} ${data.description}`);
  req.session.flash = { type: 'success', message: 'Expense recorded.' };
  res.redirect(`/admin/projects/${req.project.id}#expenses`);
});

router.post('/expenses/:id/delete', async (req, res, next) => {
  const id = validate.id(req.params.id);
  if (!id) return next();
  const r = await db.query('DELETE FROM expenses WHERE id = $1 RETURNING project_id, amount, description', [id]);
  if (!r.rows.length) return next();
  await activity.log(req, 'expense.delete', `${h.naira(r.rows[0].amount)} ${r.rows[0].description}`);
  req.session.flash = { type: 'success', message: 'Expense removed.' };
  res.redirect(`/admin/projects/${r.rows[0].project_id}#expenses`);
});

// ---------- Donations ----------
router.get('/donations', async (req, res) => {
  const q = validate.text(req.query.q).slice(0, 80);
  const status = h.DONATION_STATUS[req.query.status] ? req.query.status : '';
  const projectId = validate.id(req.query.project) || '';
  const where = [];
  const params = [];
  if (q) {
    params.push(models.likePattern(q));
    where.push(`(d.reference ILIKE $${params.length} OR u.full_name ILIKE $${params.length} OR u.email ILIKE $${params.length})`);
  }
  if (status) {
    params.push(status);
    where.push(`d.status = $${params.length}`);
  }
  if (projectId) {
    params.push(projectId);
    where.push(`d.project_id = $${params.length}`);
  }
  const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const from = 'FROM donations d JOIN users u ON u.id = d.user_id JOIN projects p ON p.id = d.project_id';
  const count = await db.query(`SELECT COUNT(*) AS n, COALESCE(SUM(d.amount), 0) AS sum ${from} ${whereSql}`, params);
  const pages = Math.max(1, Math.ceil(count.rows[0].n / PER_PAGE));
  const page = Math.min(pageOf(req.query), pages);
  const { rows } = await db.query(
    `SELECT d.*, u.full_name, u.email, p.title ${from} ${whereSql}
     ORDER BY CASE d.status WHEN 'pending' THEN 0 ELSE 1 END, d.created_at DESC
     LIMIT ${PER_PAGE} OFFSET ${(page - 1) * PER_PAGE}`,
    params
  );
  const projects = await db.query('SELECT id, title FROM projects ORDER BY title');
  res.render('admin/donations', {
    title: 'Donations',
    donations: rows,
    total: count.rows[0].n,
    sum: count.rows[0].sum,
    page,
    pages,
    filters: { q, status, project: projectId },
    projects: projects.rows,
  });
});

router.post('/donations/:id/review', async (req, res, next) => {
  const id = validate.id(req.params.id);
  const decision = validate.text(req.body.decision);
  if (!id) return next();
  if (!['confirmed', 'rejected'].includes(decision)) {
    const err = new Error('Bad donation decision');
    err.status = 400;
    return next(err);
  }
  // Only a pending donation can be reviewed, and only once.
  const r = await db.query(
    `UPDATE donations SET status = $2, reviewed_by = $3, reviewed_at = NOW()
     WHERE id = $1 AND status = 'pending' RETURNING reference, amount`,
    [id, decision, req.user.id]
  );
  if (!r.rows.length) {
    req.session.flash = { type: 'error', message: 'That donation was already reviewed or does not exist.' };
  } else {
    await activity.log(req, `donation.${decision}`, `${r.rows[0].reference} ${h.naira(r.rows[0].amount)}`);
    req.session.flash = { type: 'success', message: `Donation ${r.rows[0].reference} marked as ${decision}.` };
  }
  res.redirect(safeBack(req, '/admin/donations'));
});

// ---------- Volunteers ----------
router.get('/volunteers', async (req, res) => {
  const status = h.VOLUNTEER_STATUS[req.query.status] ? req.query.status : '';
  const params = [];
  let whereSql = '';
  if (status) {
    params.push(status);
    whereSql = 'WHERE v.status = $1';
  }
  const { rows } = await db.query(
    `SELECT v.*, u.full_name, u.email, u.phone, p.title FROM volunteers v
     JOIN users u ON u.id = v.user_id JOIN projects p ON p.id = v.project_id ${whereSql}
     ORDER BY CASE v.status WHEN 'pending' THEN 0 ELSE 1 END, v.created_at DESC LIMIT 200`,
    params
  );
  res.render('admin/volunteers', { title: 'Volunteers', volunteers: rows, status });
});

router.post('/volunteers/:id/review', async (req, res, next) => {
  const id = validate.id(req.params.id);
  const decision = validate.text(req.body.decision);
  if (!id) return next();
  if (!['approved', 'declined'].includes(decision)) {
    const err = new Error('Bad volunteer decision');
    err.status = 400;
    return next(err);
  }
  const r = await db.query('UPDATE volunteers SET status = $2 WHERE id = $1 RETURNING project_id', [id, decision]);
  if (!r.rows.length) return next();
  await activity.log(req, `volunteer.${decision}`, `Sign-up #${id}, project #${r.rows[0].project_id}`);
  req.session.flash = { type: 'success', message: `Volunteer ${decision}.` };
  res.redirect(safeBack(req, '/admin/volunteers'));
});

// ---------- Users ----------
router.get('/users', async (req, res) => {
  const q = validate.text(req.query.q).slice(0, 80);
  const role = ['admin', 'user'].includes(req.query.role) ? req.query.role : '';
  const where = [];
  const params = [];
  if (q) {
    params.push(models.likePattern(q));
    where.push(`(u.full_name ILIKE $${params.length} OR u.email ILIKE $${params.length})`);
  }
  if (role) {
    params.push(role);
    where.push(`u.role = $${params.length}`);
  }
  const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const { rows } = await db.query(
    `SELECT u.id, u.full_name, u.email, u.phone, u.role, u.is_active, u.locked_until, u.last_login_at, u.created_at,
            COALESCE(SUM(d.amount) FILTER (WHERE d.status = 'confirmed'), 0) AS given
     FROM users u LEFT JOIN donations d ON d.user_id = u.id ${whereSql}
     GROUP BY u.id ORDER BY u.created_at DESC LIMIT 200`,
    params
  );
  res.render('admin/users', { title: 'Users', users: rows, filters: { q, role } });
});

async function loadOtherUser(req, res, next) {
  const id = validate.id(req.params.id);
  if (!id) return next('route');
  if (id === req.user.id) {
    req.session.flash = { type: 'error', message: 'You cannot change your own role or status. Ask another admin.' };
    return res.redirect('/admin/users');
  }
  const { rows } = await db.query('SELECT id, full_name, role, is_active FROM users WHERE id = $1', [id]);
  if (!rows[0]) return next('route');
  req.target = rows[0];
  next();
}

router.post('/users/:id/role', loadOtherUser, async (req, res, next) => {
  const role = validate.text(req.body.role);
  if (!['admin', 'user'].includes(role)) {
    const err = new Error('Bad role');
    err.status = 400;
    return next(err);
  }
  await db.query('UPDATE users SET role = $2 WHERE id = $1', [req.target.id, role]);
  await activity.log(req, 'user.role', `${req.target.full_name} (#${req.target.id}): ${req.target.role} → ${role}`);
  req.session.flash = { type: 'success', message: `${req.target.full_name} is now ${role === 'admin' ? 'an Admin' : 'a User'}.` };
  res.redirect('/admin/users');
});

router.post('/users/:id/status', loadOtherUser, async (req, res, next) => {
  const action = validate.text(req.body.action);
  if (action === 'disable') {
    await db.query('UPDATE users SET is_active = FALSE WHERE id = $1', [req.target.id]);
    // End all their sessions straight away
    await db.query("DELETE FROM sessions WHERE sess->>'userId' = $1", [String(req.target.id)]);
  } else if (action === 'enable') {
    await db.query('UPDATE users SET is_active = TRUE WHERE id = $1', [req.target.id]);
  } else if (action === 'unlock') {
    await db.query('UPDATE users SET locked_until = NULL, failed_logins = 0 WHERE id = $1', [req.target.id]);
  } else {
    const err = new Error('Bad user action');
    err.status = 400;
    return next(err);
  }
  await activity.log(req, `user.${action}`, `${req.target.full_name} (#${req.target.id})`);
  req.session.flash = { type: 'success', message: `Done: ${action} ${req.target.full_name}.` };
  res.redirect('/admin/users');
});

// ---------- Activity log ----------
const ACTION_GROUPS = {
  auth: 'Logins and sign-ups',
  security: 'Security warnings',
  donation: 'Donations',
  volunteer: 'Volunteers',
  project: 'Projects',
  task: 'Tasks',
  expense: 'Expenses',
  user: 'User management',
  profile: 'Profile changes',
};

router.get('/activity', async (req, res) => {
  const group = ACTION_GROUPS[req.query.group] ? req.query.group : '';
  const q = validate.text(req.query.q).slice(0, 80);
  const where = [];
  const params = [];
  if (group) {
    params.push(group + '.%');
    where.push(`a.action LIKE $${params.length}`);
  }
  if (q) {
    params.push(models.likePattern(q));
    where.push(`(a.details ILIKE $${params.length} OR u.full_name ILIKE $${params.length} OR a.ip_address ILIKE $${params.length})`);
  }
  const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const from = 'FROM activity_log a LEFT JOIN users u ON u.id = a.user_id';
  const count = await db.query(`SELECT COUNT(*) AS n ${from} ${whereSql}`, params);
  const perPage = 25;
  const pages = Math.max(1, Math.ceil(count.rows[0].n / perPage));
  const page = Math.min(pageOf(req.query), pages);
  const { rows } = await db.query(
    `SELECT a.*, u.full_name ${from} ${whereSql} ORDER BY a.created_at DESC, a.id DESC LIMIT ${perPage} OFFSET ${(page - 1) * perPage}`,
    params
  );
  res.render('admin/activity', {
    title: 'Activity log',
    entries: rows,
    groups: ACTION_GROUPS,
    filters: { group, q },
    page,
    pages,
    total: count.rows[0].n,
  });
});

// Go back to the page the admin came from, but only if it is inside /admin.
function safeBack(req, fallback) {
  const back = validate.text(req.body.back);
  return back.startsWith('/admin') && !back.includes('//') ? back : fallback;
}

module.exports = router;
