// Pages for logged-in donors / volunteers, plus the profile page for everyone
const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../db');
const config = require('../config');
const activity = require('../activity');
const validate = require('../validate');
const models = require('../models');
const { newReference } = require('../setup');
const { requireLogin, requireRole } = require('../middleware/security');
const h = require('../helpers');

const router = express.Router();
const userOnly = requireRole('user');

const OPEN_FOR_DONATIONS = ['planned', 'active'];

// Admins have their own dashboard
router.get('/dashboard', (req, res, next) => (req.user && req.user.role === 'admin' ? res.redirect('/admin') : next()));

router.get('/dashboard', userOnly, async (req, res) => {
  const uid = req.user.id;
  const [stats, donations, volunteering, suggested] = await Promise.all([
    db.query(
      `SELECT
         COALESCE(SUM(amount) FILTER (WHERE status = 'confirmed'), 0) AS given,
         COUNT(*) FILTER (WHERE status = 'pending')                   AS pending,
         COUNT(DISTINCT project_id) FILTER (WHERE status = 'confirmed') AS projects_helped
       FROM donations WHERE user_id = $1`,
      [uid]
    ),
    db.query(
      `SELECT d.*, p.title FROM donations d JOIN projects p ON p.id = d.project_id
       WHERE d.user_id = $1 ORDER BY d.created_at DESC LIMIT 5`,
      [uid]
    ),
    db.query(
      `SELECT v.*, p.title, p.status AS project_status, p.start_date, p.location
       FROM volunteers v JOIN projects p ON p.id = v.project_id
       WHERE v.user_id = $1 ORDER BY v.created_at DESC`,
      [uid]
    ),
    models.listProjects(models.cleanFilters({ sort: 'ending' }), { perPage: 3, statuses: ['active'] }),
  ]);
  res.render('user/dashboard', {
    title: 'My dashboard',
    stats: stats.rows[0],
    donations: donations.rows,
    volunteering: volunteering.rows,
    suggested: suggested.projects,
  });
});

router.get('/donations', userOnly, async (req, res) => {
  const status = h.DONATION_STATUS[req.query.status] ? req.query.status : '';
  const params = [req.user.id];
  let extra = '';
  if (status) {
    params.push(status);
    extra = ' AND d.status = $2';
  }
  const { rows } = await db.query(
    `SELECT d.*, p.title FROM donations d JOIN projects p ON p.id = d.project_id
     WHERE d.user_id = $1${extra} ORDER BY d.created_at DESC`,
    params
  );
  res.render('user/donations', { title: 'My donations', donations: rows, status });
});

// Receipt. The "AND user_id = $2" part means you can only open your OWN donation,
// even if you change the number in the address bar.
router.get('/donations/:id', userOnly, async (req, res, next) => {
  const id = validate.id(req.params.id);
  if (!id) return next();
  const { rows } = await db.query(
    `SELECT d.*, p.title, p.location FROM donations d JOIN projects p ON p.id = d.project_id
     WHERE d.id = $1 AND d.user_id = $2`,
    [id, req.user.id]
  );
  if (!rows[0]) return next();
  res.render('user/receipt', { title: `Donation ${rows[0].reference}`, d: rows[0] });
});

async function openProject(id) {
  if (!id) return null;
  const { rows } = await db.query('SELECT id, title, status FROM projects WHERE id = $1', [id]);
  return rows[0] || null;
}

router.post('/projects/:id/donate', userOnly, async (req, res, next) => {
  const id = validate.id(req.params.id);
  const project = await openProject(id);
  if (!project) return next();
  if (!OPEN_FOR_DONATIONS.includes(project.status)) {
    req.session.flash = { type: 'error', message: 'This project is not taking donations right now.' };
    return res.redirect(`/projects/${id}`);
  }
  const { data, errors } = validate.donation(req.body);
  if (Object.keys(errors).length) {
    const values = {
      amount: validate.text(req.body.amount).slice(0, 20),
      method: data.method,
      message: (data.message || '').slice(0, 300),
    };
    req.session.formState = { projectId: id, form: 'donate', values, errors };
    return res.redirect(`/projects/${id}#donate`);
  }
  const ref = newReference();
  const { rows } = await db.query(
    `INSERT INTO donations (reference, project_id, user_id, amount, method, message)
     VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
    [ref, id, req.user.id, data.amount, data.method, data.message]
  );
  await activity.log(req, 'donation.created', `${ref} ${h.naira(data.amount)} to project #${id}`);
  req.session.flash = {
    type: 'success',
    message: `Thank you! Your pledge of ${h.naira(data.amount)} is recorded as ${ref}. It will show as confirmed once our team checks the payment.`,
  };
  res.redirect(`/donations/${rows[0].id}`);
});

router.post('/projects/:id/volunteer', userOnly, async (req, res, next) => {
  const id = validate.id(req.params.id);
  const project = await openProject(id);
  if (!project) return next();
  if (!OPEN_FOR_DONATIONS.includes(project.status)) {
    req.session.flash = { type: 'error', message: 'This project is not taking volunteers right now.' };
    return res.redirect(`/projects/${id}`);
  }
  const { data, errors } = validate.volunteer(req.body);
  if (Object.keys(errors).length) {
    req.session.formState = { projectId: id, form: 'volunteer', values: { skills: data.skills, availability: data.availability }, errors };
    return res.redirect(`/projects/${id}#volunteer`);
  }
  // The UNIQUE rule in the database stops double sign-ups, even if two requests arrive at once.
  const r = await db.query(
    `INSERT INTO volunteers (project_id, user_id, skills, availability) VALUES ($1, $2, $3, $4)
     ON CONFLICT (project_id, user_id) DO NOTHING RETURNING id`,
    [id, req.user.id, data.skills, data.availability]
  );
  if (!r.rows.length) {
    req.session.flash = { type: 'info', message: 'You have already signed up to volunteer on this project.' };
  } else {
    await activity.log(req, 'volunteer.signup', `Project #${id}`);
    req.session.flash = { type: 'success', message: 'Thank you for offering to help! The project team will review your sign-up.' };
  }
  res.redirect(`/projects/${id}#volunteer`);
});

router.post('/volunteering/:id/withdraw', userOnly, async (req, res, next) => {
  const id = validate.id(req.params.id);
  if (!id) return next();
  const r = await db.query(
    "DELETE FROM volunteers WHERE id = $1 AND user_id = $2 AND status = 'pending' RETURNING project_id",
    [id, req.user.id]
  );
  if (!r.rows.length) return next();
  await activity.log(req, 'volunteer.withdraw', `Project #${r.rows[0].project_id}`);
  req.session.flash = { type: 'success', message: 'Your volunteer sign-up was withdrawn.' };
  res.redirect('/dashboard');
});

// ---------- Profile (all logged-in users) ----------
router.get('/profile', requireLogin, async (req, res) => {
  const { rows } = await db.query('SELECT last_login_at FROM users WHERE id = $1', [req.user.id]);
  res.render('profile', { title: 'My profile', values: req.user, lastLogin: rows[0].last_login_at, pwErrors: {} });
});

router.post('/profile', requireLogin, async (req, res) => {
  const { data, errors } = validate.profile(req.body);
  if (Object.keys(errors).length) {
    return res.status(422).render('profile', { title: 'My profile', values: { ...req.user, ...data }, errors, pwErrors: {} });
  }
  await db.query('UPDATE users SET full_name = $2, phone = $3 WHERE id = $1', [req.user.id, data.full_name, data.phone || null]);
  await activity.log(req, 'profile.update');
  req.session.flash = { type: 'success', message: 'Your profile was updated.' };
  res.redirect('/profile');
});

router.post('/profile/password', requireLogin, async (req, res) => {
  const { errors } = validate.passwordChange(req.body);
  if (!errors.current_password) {
    const { rows } = await db.query('SELECT password_hash FROM users WHERE id = $1', [req.user.id]);
    if (!(await bcrypt.compare(String(req.body.current_password), rows[0].password_hash))) {
      errors.current_password = 'Your current password is wrong.';
    }
  }
  if (Object.keys(errors).length) {
    if (errors.current_password) await activity.log(req, 'profile.password_failed');
    return res.status(422).render('profile', { title: 'My profile', values: req.user, errors: {}, pwErrors: errors });
  }
  const hash = await bcrypt.hash(req.body.new_password, config.bcryptRounds);
  await db.query('UPDATE users SET password_hash = $2 WHERE id = $1', [req.user.id, hash]);
  // Log out every OTHER device that was logged in with the old password
  await db.query("DELETE FROM sessions WHERE sess->>'userId' = $1 AND sid <> $2", [String(req.user.id), req.sessionID]);
  await activity.log(req, 'profile.password_changed');
  req.session.flash = { type: 'success', message: 'Your password was changed. Other devices have been logged out.' };
  res.redirect('/profile');
});

module.exports = router;
