// Registration, login and logout
const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../db');
const config = require('../config');
const activity = require('../activity');
const validate = require('../validate');
const { guestOnly, rateLimit } = require('../middleware/security');

const router = express.Router();

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: config.isTest ? 1000 : 30, name: 'login' });
const registerLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: config.isTest ? 1000 : 10, name: 'register' });

// Used when the email does not exist, so a wrong email takes as long as a wrong password.
// This stops attackers from finding real emails by timing the response.
let dummyHash = null;
async function getDummyHash() {
  if (!dummyHash) dummyHash = await bcrypt.hash('not-a-real-password-1', config.bcryptRounds);
  return dummyHash;
}

// Only allow redirects to pages on this site (stops "open redirect" attacks)
function safeReturnTo(url) {
  return typeof url === 'string' && url.startsWith('/') && !url.startsWith('//') && !url.startsWith('/\\') ? url : null;
}

// Log the user in: a NEW session ID is created so an old (possibly stolen) ID is useless.
function startSession(req, user) {
  const returnTo = safeReturnTo(req.session.returnTo);
  return new Promise((resolve, reject) => {
    req.session.regenerate((err) => {
      if (err) return reject(err);
      req.session.userId = user.id;
      req.session.save((err2) => (err2 ? reject(err2) : resolve(returnTo)));
    });
  });
}

function home(user) {
  return user.role === 'admin' ? '/admin' : '/dashboard';
}

router.get('/login', guestOnly, (req, res) => {
  res.render('login', { title: 'Log in', loggedOut: req.query.out === '1' });
});

router.post('/login', loginLimiter, guestOnly, async (req, res) => {
  const email = validate.text(req.body.email).toLowerCase();
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  const fail = (message, status = 401) =>
    res.status(status).render('login', { title: 'Log in', values: { email }, formError: message });

  if (!email || !password) return fail('Enter your email and password.', 422);

  const { rows } = await db.query(
    'SELECT id, password_hash, role, is_active, failed_logins, locked_until FROM users WHERE email = $1',
    [email]
  );
  const user = rows[0];

  if (!user) {
    await bcrypt.compare(password, await getDummyHash());
    await activity.log(req, 'auth.login_failed', `Unknown email: ${email.slice(0, 80)}`, null);
    return fail('Email or password is wrong.');
  }

  if (user.locked_until && new Date(user.locked_until) > new Date()) {
    const mins = Math.ceil((new Date(user.locked_until) - new Date()) / 60000);
    await activity.log(req, 'auth.login_blocked', 'Attempt while account locked', user.id);
    return fail(`Too many failed attempts. This account is locked for ${mins} more minute${mins === 1 ? '' : 's'}.`, 423);
  }

  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) {
    const failed = user.failed_logins + 1;
    if (failed >= config.maxFailedLogins) {
      await db.query(
        `UPDATE users SET failed_logins = 0, locked_until = NOW() + ($2 || ' minutes')::interval WHERE id = $1`,
        [user.id, String(config.lockMinutes)]
      );
      await activity.log(req, 'auth.account_locked', `Locked after ${failed} failed attempts`, user.id);
      return fail(`Too many failed attempts. This account is locked for ${config.lockMinutes} minutes.`, 423);
    }
    await db.query('UPDATE users SET failed_logins = $2 WHERE id = $1', [user.id, failed]);
    await activity.log(req, 'auth.login_failed', `Wrong password (${failed} of ${config.maxFailedLogins})`, user.id);
    return fail('Email or password is wrong.');
  }

  if (!user.is_active) {
    await activity.log(req, 'auth.login_blocked', 'Disabled account', user.id);
    return fail('This account has been disabled. Please contact the admin.', 403);
  }

  await db.query('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = NOW() WHERE id = $1', [user.id]);
  const returnTo = await startSession(req, user);
  await activity.log(req, 'auth.login', null, user.id);
  res.redirect(returnTo || home(user));
});

router.get('/register', guestOnly, (req, res) => {
  res.render('register', { title: 'Create account' });
});

router.post('/register', registerLimiter, guestOnly, async (req, res) => {
  const { data, errors } = validate.registration(req.body);
  if (!errors.email) {
    const exists = await db.query('SELECT 1 FROM users WHERE email = $1', [data.email]);
    if (exists.rows.length) errors.email = 'An account with this email already exists. Try logging in.';
  }
  if (Object.keys(errors).length) {
    return res.status(422).render('register', { title: 'Create account', values: data, errors });
  }

  const hash = await bcrypt.hash(req.body.password, config.bcryptRounds);
  // The role is always "user". It is never taken from the form, so nobody can sign up as admin.
  const { rows } = await db.query(
    `INSERT INTO users (full_name, email, phone, password_hash, role) VALUES ($1, $2, $3, $4, 'user')
     RETURNING id, role`,
    [data.full_name, data.email, data.phone || null, hash]
  );
  await startSession(req, rows[0]);
  await activity.log(req, 'auth.register', null, rows[0].id);
  req.session.flash = { type: 'success', message: `Welcome, ${data.full_name.split(' ')[0]}! Your account is ready.` };
  res.redirect('/dashboard');
});

router.post('/logout', (req, res, next) => {
  const userId = req.user ? req.user.id : null;
  req.session.destroy(async (err) => {
    if (err) return next(err);
    res.clearCookie('cpms.sid');
    if (userId) await activity.log(req, 'auth.logout', null, userId).catch(() => {});
    res.redirect('/login?out=1');
  });
});

module.exports = router;
