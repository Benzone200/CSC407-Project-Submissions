// Simple logger. Each line is JSON so hosting dashboards can search it.
// Passwords and tokens are never passed to the logger.
const fs = require('fs');
const path = require('path');
const config = require('./config');

let stream = null;
if (config.logFile) {
  fs.mkdirSync(path.dirname(config.logFile), { recursive: true });
  stream = fs.createWriteStream(config.logFile, { flags: 'a' });
}

function write(level, message, extra = {}) {
  if (config.isTest && level !== 'error') return;
  if (config.isTest && process.env.SHOW_TEST_ERRORS !== 'true') return;
  const line = JSON.stringify({ time: new Date().toISOString(), level, message, ...extra });
  if (level === 'error') console.error(line);
  else console.log(line);
  if (stream) stream.write(line + '\n');
}

module.exports = {
  info: (msg, extra) => write('info', msg, extra),
  warn: (msg, extra) => write('warn', msg, extra),
  error: (msg, extra) => write('error', msg, extra),
};
