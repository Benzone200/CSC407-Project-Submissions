// Database layer.
// - With DATABASE_URL set, it connects to a normal PostgreSQL server (used on the live site).
// - Without it, it uses PGlite: real PostgreSQL that runs inside Node and saves to a folder.
//   This lets anyone run the project with "npm install" and "npm start" only.
// Every query in the app goes through query(text, params). Values are always passed
// as parameters ($1, $2 ...), never joined into the SQL text. This blocks SQL injection.
const config = require('./config');

let backend = null; // { query, exec, transaction, close, kind }

// Return numbers as JS numbers and dates as 'YYYY-MM-DD' strings.
const INT8 = 20;
const NUMERIC = 1700;
const DATE = 1082;
const parsers = {
  [INT8]: (v) => (v === null ? null : parseInt(v, 10)),
  [NUMERIC]: (v) => (v === null ? null : parseFloat(v)),
  [DATE]: (v) => v,
};

async function connectPostgres(url) {
  const { Pool, types } = require('pg');
  types.setTypeParser(INT8, parsers[INT8]);
  types.setTypeParser(NUMERIC, parsers[NUMERIC]);
  types.setTypeParser(DATE, parsers[DATE]);
  const pool = new Pool({
    connectionString: url,
    ssl: config.databaseSsl ? { rejectUnauthorized: false } : undefined,
    max: 10,
    idleTimeoutMillis: 30000,
  });
  await pool.query('SELECT 1');
  return {
    kind: 'postgres',
    async query(text, params = []) {
      const r = await pool.query(text, params);
      return { rows: r.rows, rowCount: r.rowCount };
    },
    async exec(sql) {
      await pool.query(sql);
    },
    async transaction(fn) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const q = async (text, params = []) => {
          const r = await client.query(text, params);
          return { rows: r.rows, rowCount: r.rowCount };
        };
        const result = await fn(q);
        await client.query('COMMIT');
        return result;
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      } finally {
        client.release();
      }
    },
    async close() {
      await pool.end();
    },
  };
}

async function connectPglite(dataDir) {
  const { PGlite } = require('@electric-sql/pglite');
  if (dataDir) {
    require('fs').mkdirSync(dataDir, { recursive: true });
  }
  const db = dataDir ? new PGlite(dataDir, { parsers }) : new PGlite({ parsers });
  await db.waitReady;
  const wrap = (r) => ({ rows: r.rows, rowCount: r.affectedRows ?? r.rows.length });
  return {
    kind: dataDir ? 'pglite' : 'pglite-memory',
    async query(text, params = []) {
      return wrap(await db.query(text, params));
    },
    async exec(sql) {
      await db.exec(sql);
    },
    async transaction(fn) {
      return db.transaction(async (tx) => fn(async (text, params = []) => wrap(await tx.query(text, params))));
    },
    async close() {
      await db.close();
    },
  };
}

// options.url: PostgreSQL URL. options.memory: true for a throw-away database (tests).
async function init(options = {}) {
  if (backend) return backend;
  const url = options.url !== undefined ? options.url : config.databaseUrl;
  if (url) {
    backend = await connectPostgres(url);
  } else if (options.memory) {
    backend = await connectPglite(null);
  } else {
    backend = await connectPglite(config.localDataDir);
  }
  return backend;
}

function get() {
  if (!backend) throw new Error('Database not started. Call db.init() first.');
  return backend;
}

module.exports = {
  init,
  query: (text, params) => get().query(text, params),
  exec: (sql) => get().exec(sql),
  transaction: (fn) => get().transaction(fn),
  kind: () => (backend ? backend.kind : 'none'),
  async close() {
    if (backend) {
      await backend.close();
      backend = null;
    }
  },
};
