-- Charity Project Management System - database tables
-- Safe to run many times (IF NOT EXISTS).

CREATE TABLE IF NOT EXISTS users (
  id             SERIAL PRIMARY KEY,
  full_name      VARCHAR(80)  NOT NULL,
  email          VARCHAR(120) NOT NULL UNIQUE,
  phone          VARCHAR(20),
  password_hash  VARCHAR(100) NOT NULL,
  role           VARCHAR(10)  NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'user')),
  is_active      BOOLEAN      NOT NULL DEFAULT TRUE,
  failed_logins  INTEGER      NOT NULL DEFAULT 0,
  locked_until   TIMESTAMPTZ,
  last_login_at  TIMESTAMPTZ,
  created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  CONSTRAINT email_lowercase CHECK (email = LOWER(email))
);

CREATE TABLE IF NOT EXISTS projects (
  id             SERIAL PRIMARY KEY,
  title          VARCHAR(120) NOT NULL,
  category       VARCHAR(20)  NOT NULL CHECK (category IN ('education', 'health', 'food', 'water', 'shelter', 'environment')),
  summary        VARCHAR(200) NOT NULL,
  description    TEXT         NOT NULL,
  location       VARCHAR(120) NOT NULL,
  target_amount  INTEGER      NOT NULL CHECK (target_amount > 0),
  start_date     DATE         NOT NULL,
  end_date       DATE,
  status         VARCHAR(12)  NOT NULL DEFAULT 'planned' CHECK (status IN ('planned', 'active', 'on_hold', 'completed')),
  created_by     INTEGER      REFERENCES users(id) ON DELETE SET NULL,
  created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  CONSTRAINT end_after_start CHECK (end_date IS NULL OR end_date >= start_date)
);

-- Tasks (milestones) inside a project
CREATE TABLE IF NOT EXISTS tasks (
  id          SERIAL PRIMARY KEY,
  project_id  INTEGER      NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  title       VARCHAR(120) NOT NULL,
  due_date    DATE,
  status      VARCHAR(12)  NOT NULL DEFAULT 'todo' CHECK (status IN ('todo', 'in_progress', 'done')),
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Money spent on a project
CREATE TABLE IF NOT EXISTS expenses (
  id           SERIAL PRIMARY KEY,
  project_id   INTEGER      NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  description  VARCHAR(150) NOT NULL,
  amount       INTEGER      NOT NULL CHECK (amount > 0),
  spent_on     DATE         NOT NULL,
  recorded_by  INTEGER      REFERENCES users(id) ON DELETE SET NULL,
  created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Donations. A donation starts as "pending" until an admin confirms the payment.
-- RESTRICT: a project that has donations cannot be deleted, so money records are never lost.
CREATE TABLE IF NOT EXISTS donations (
  id           SERIAL PRIMARY KEY,
  reference    VARCHAR(20)  NOT NULL UNIQUE,
  project_id   INTEGER      NOT NULL REFERENCES projects(id) ON DELETE RESTRICT,
  user_id      INTEGER      NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  amount       INTEGER      NOT NULL CHECK (amount >= 100 AND amount <= 100000000),
  method       VARCHAR(15)  NOT NULL CHECK (method IN ('bank_transfer', 'card', 'cash')),
  message      VARCHAR(300),
  status       VARCHAR(10)  NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'rejected')),
  reviewed_by  INTEGER      REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at  TIMESTAMPTZ,
  created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Volunteer sign-ups. One sign-up per person per project.
CREATE TABLE IF NOT EXISTS volunteers (
  id            SERIAL PRIMARY KEY,
  project_id    INTEGER      NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id       INTEGER      NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  skills        VARCHAR(200) NOT NULL,
  availability  VARCHAR(20)  NOT NULL CHECK (availability IN ('weekdays', 'weekends', 'anytime')),
  status        VARCHAR(10)  NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'declined')),
  created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  CONSTRAINT one_signup_per_project UNIQUE (project_id, user_id)
);

-- Record of important actions (logins, changes) for monitoring and audits
CREATE TABLE IF NOT EXISTS activity_log (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER     REFERENCES users(id) ON DELETE SET NULL,
  action      VARCHAR(40) NOT NULL,
  details     VARCHAR(300),
  ip_address  VARCHAR(64),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Login sessions are stored in the database, not in the browser
CREATE TABLE IF NOT EXISTS sessions (
  sid     VARCHAR(128) PRIMARY KEY,
  sess    JSONB        NOT NULL,
  expire  TIMESTAMPTZ  NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_projects_status    ON projects(status);
CREATE INDEX IF NOT EXISTS idx_projects_category  ON projects(category);
CREATE INDEX IF NOT EXISTS idx_tasks_project      ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_expenses_project   ON expenses(project_id);
CREATE INDEX IF NOT EXISTS idx_donations_project  ON donations(project_id);
CREATE INDEX IF NOT EXISTS idx_donations_user     ON donations(user_id);
CREATE INDEX IF NOT EXISTS idx_donations_status   ON donations(status);
CREATE INDEX IF NOT EXISTS idx_volunteers_user    ON volunteers(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_created   ON activity_log(created_at);
CREATE INDEX IF NOT EXISTS idx_sessions_expire    ON sessions(expire);
