# El Niño Shelter Relief: Charity Project Management System

**CSC 407 project by Ezeh Calvin Nnaemeka**

A responsive web application for planning, funding and tracking charity projects. The sample data focuses on **shelter and relief for families hit by the El Niño heatwave and drought**: cooling shelters, heat-safe roofs, drinking water, heatstroke checks and food packs.

- **Donors and volunteers (Users)** browse projects, record donations, sign up to volunteer, and follow progress.
- **Admins** create projects, add tasks and expenses, confirm donations, approve volunteers, manage users and read the activity log.

---

## 1. How to run it on your computer

You only need **Node.js version 20 or newer** ([nodejs.org](https://nodejs.org)). You do **not** need to install PostgreSQL. When no database address is set, the app uses a built-in PostgreSQL database (PGlite) that is saved in the `data/` folder.

1. Unzip the project and open a terminal **inside the project folder** (the folder that has `package.json`).
   In VS Code: *Terminal → New Terminal*.
2. Install the packages (first time only):
   ```
   npm install
   ```
3. Start the app:
   ```
   npm start
   ```
4. Wait until you see **"Open http://localhost:3000 in your browser"** (the first start takes a few seconds). Then open **http://localhost:3000**.

> **Note:** this is a server app, so VS Code's "Go Live" button and double-clicking an HTML file will **not** work. The pages are made by the Node server, so always use `npm start`.

To stop the app, press `Ctrl + C` in the terminal.

### Sample accounts

| Role  | Email                | Password      |
|-------|----------------------|---------------|
| Admin | admin@charity.test   | Admin@12345   |
| User  | user@charity.test    | User@12345    |
| User  | tunde@charity.test   | User@12345    |
| User  | halima@charity.test  | User@12345    |

To start again with fresh sample data, stop the app, delete the `data` folder, and run `npm start` again.

### Run the automated tests

```
npm test
```
This runs 156 tests on a fresh in-memory database. It does not touch your `data` folder. See [docs/TESTING.md](docs/TESTING.md).

---

## 2. Features

| Area | What it does |
|------|--------------|
| Home / Dashboard | Totals raised and spent, active projects, a dashboard for each role |
| Registration and Login | Sign up, log in, log out, account lockout after 5 wrong passwords |
| User profile | Edit name and phone, change password (logs out other devices) |
| Navigation menu | Different menu for visitors, users and admins; collapses on phones |
| Forms | Register, donate, volunteer, create or edit a project, add a task, record an expense |
| Search and filter | Projects (keyword, category, status, sort), donations, users, activity log |
| Responsive design | Works on phones and computers; tables turn into cards on small screens |
| Security page | `/security` explains every security measure in plain words |

## 3. Technology

| Part | Tool |
|------|------|
| Server | Node.js + Express 5 |
| Pages | EJS templates, plain HTML and CSS, a small JavaScript file |
| Database | PostgreSQL (PGlite built in for local use) |
| Passwords | bcrypt |
| Security headers | Helmet |
| Tests | Jest + Supertest |
| Hosting | Render (see `render.yaml`) |

## 4. Folder structure

```
server.js              starts the app
src/
  app.js               Express setup: security headers, sessions, CSRF, routes, error pages
  config.js            reads settings from environment variables
  db.js                database connection (PostgreSQL or built-in PGlite)
  schema.sql           all tables and database rules
  setup.js             creates tables and sample data
  session-store.js     saves login sessions in the database
  validate.js          checks every form on the server
  models.js            shared database queries
  activity.js          writes to the activity log
  logger.js            server logs
  middleware/security.js  CSRF, login check, role check, rate limit
  routes/              public.js, auth.js, user.js, admin.js
views/                 EJS pages (admin/ and user/ folders)
public/                CSS, JavaScript, icon
tests/                 automated tests
scripts/               migrate, seed, backup and restore
docs/                  SECURITY.md, TESTING.md, DEPLOYMENT.md, screenshots/
```

## 5. Documentation

- [docs/SECURITY.md](docs/SECURITY.md): web application security
- [docs/TESTING.md](docs/TESTING.md): testing
- [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md): deployment
- [docs/screenshots](docs/screenshots): screenshots on phone and computer

## 6. Note on payments

No real payment is taken. A donation is recorded with a reference number (for example `DON-3F9A21C7`). The donor pays by bank transfer, card or cash using that reference, and an admin confirms the donation after checking the payment. Only confirmed donations count towards a project's "raised" total.
