// Security tests: CSRF, SQL injection, XSS, headers, cookies, sensitive data
const { setup, teardown, client, loginAs, ADMIN, USER, db, request } = require('./helpers');

let app;
beforeAll(async () => {
  app = await setup();
});
afterAll(teardown);

describe('CSRF protection', () => {
  test('a form without the CSRF token is refused', async () => {
    const c = await client(app);
    const res = await c.post('/login').type('form').send({ email: USER[0], password: USER[1] });
    expect(res.status).toBe(403);
    expect(res.text).toContain('Your form has expired');
  });

  test('a form with a wrong CSRF token is refused', async () => {
    const c = await loginAs(app, ...USER);
    const res = await c.post('/projects/1/donate').type('form').send({ _csrf: 'a'.repeat(64), amount: '5000', method: 'card' });
    expect(res.status).toBe(403);
    const { rows } = await db.query("SELECT COUNT(*) AS n FROM donations WHERE amount = 5000 AND method = 'card'");
    expect(rows[0].n).toBe(0);
  });

  test("another user's token does not work in my session", async () => {
    const a = await loginAs(app, ...USER);
    const b = await loginAs(app, ...ADMIN);
    const res = await a.post('/profile').type('form').send({ _csrf: b.csrf, full_name: 'Hacked Name' });
    expect(res.status).toBe(403);
  });
});

describe('SQL injection protection', () => {
  test.each([
    "' OR 1=1 --",
    "'; DROP TABLE users; --",
    "%' UNION SELECT email, password_hash FROM users --",
  ])('search box treats %s as plain text', async (attack) => {
    const res = await request(app).get('/projects').query({ q: attack });
    expect(res.status).toBe(200);
    expect(res.text).toContain('0 projects found');
    const { rows } = await db.query('SELECT COUNT(*) AS n FROM users');
    expect(rows[0].n).toBeGreaterThan(0); // table still there
  });

  test('login form cannot be bypassed with SQL', async () => {
    const c = await client(app);
    const res = await c.send('/login', { email: "admin@charity.test' --", password: "' OR '1'='1" });
    expect(res.status).toBe(401);
  });

  test('an unknown sort option cannot inject SQL into ORDER BY', async () => {
    const res = await request(app).get('/projects').query({ sort: 'title; DROP TABLE projects' });
    expect(res.status).toBe(200);
    const { rows } = await db.query('SELECT COUNT(*) AS n FROM projects');
    expect(rows[0].n).toBeGreaterThan(0);
  });

  test('% and _ in a search are not wildcards', async () => {
    const res = await request(app).get('/projects').query({ q: '%' });
    expect(res.text).toContain('0 projects found');
  });

  test('admin search with an attack string is safe', async () => {
    const a = await loginAs(app, ...ADMIN);
    for (const url of ['/admin/donations', '/admin/users', '/admin/activity', '/admin/projects']) {
      const res = await a.get(url).query({ q: "' OR 1=1 --" });
      expect(res.status).toBe(200);
    }
  });
});

describe('XSS protection', () => {
  const script = '<script>alert("xss")</script>';

  test('text typed by a user is shown as text, not run as code', async () => {
    const c = await loginAs(app, ...USER);
    await c.send('/projects/1/donate', { amount: '1000', method: 'card', message: script });
    const admin = await loginAs(app, ...ADMIN);
    const res = await admin.get('/admin/donations');
    expect(res.text).not.toContain(script);
    expect(res.text).toContain('&lt;script&gt;alert(&#34;xss&#34;)&lt;/script&gt;');
  });

  test('project fields are escaped on the public page', async () => {
    const a = await loginAs(app, ...ADMIN);
    const res = await a.send('/admin/projects', {
      title: 'Test <img src=x onerror=alert(1)>',
      category: 'health',
      summary: 'Summary with <b>bold</b> tags inside',
      description: 'A long enough description <script>bad()</script>',
      location: 'Enugu',
      target_amount: '50000',
      start_date: '2026-12-01',
      status: 'active',
    });
    expect(res.status).toBe(302);
    const page = await request(app).get(res.headers.location.replace('/admin', ''));
    expect(page.text).not.toContain('<img src=x');
    expect(page.text).not.toContain('<script>bad()');
    expect(page.text).toContain('&lt;img src=x onerror=alert(1)&gt;');
  });

  test('a Content Security Policy blocks inline and outside scripts', async () => {
    const res = await request(app).get('/');
    const csp = res.headers['content-security-policy'];
    expect(csp).toContain("script-src 'self'");
    expect(csp).toContain("object-src 'none'");
    expect(csp).toContain("frame-ancestors 'none'");
    expect(res.text).not.toMatch(/<script>(?!\s*<\/script>)/); // no inline scripts in our pages
  });
});

describe('Security headers and cookies', () => {
  test('important security headers are set', async () => {
    const res = await request(app).get('/');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-frame-options']).toBe('SAMEORIGIN');
    expect(res.headers['referrer-policy']).toBe('same-origin');
    expect(res.headers['x-powered-by']).toBeUndefined();
  });

  test('the session cookie is HttpOnly and SameSite', async () => {
    const c = await client(app);
    const res = await c.send('/login', { email: USER[0], password: USER[1] });
    const cookie = res.headers['set-cookie'].find((x) => x.startsWith('cpms.sid='));
    expect(cookie).toMatch(/HttpOnly/i);
    expect(cookie).toMatch(/SameSite=Lax/i);
  });

  test('pages are not stored in the browser cache', async () => {
    const c = await loginAs(app, ...USER);
    const res = await c.get('/dashboard');
    expect(res.headers['cache-control']).toBe('no-store');
  });

  test('very large form submissions are refused', async () => {
    const c = await client(app);
    const res = await c.send('/login', { email: 'a@b.co', password: 'x'.repeat(30000) });
    expect(res.status).toBe(413);
  });
});

describe('Sensitive information', () => {
  test('public project page does not show donor emails or phone numbers', async () => {
    const res = await request(app).get('/projects/1');
    expect(res.text).not.toContain('@charity.test');
    expect(res.text).not.toContain('0803');
    expect(res.text).toMatch(/Tunde B\.|Chiamaka O\.|Halima M\./);
  });

  test('error pages do not show technical details', async () => {
    const res = await request(app).get('/projects/99999');
    expect(res.status).toBe(404);
    expect(res.text).not.toMatch(/at .*\.js:\d+/);
  });

  test('password hashes never appear on admin pages', async () => {
    const a = await loginAs(app, ...ADMIN);
    const res = await a.get('/admin/users');
    expect(res.text).not.toMatch(/\$2[aby]\$/);
  });

  test('the security page explains the measures', async () => {
    const res = await request(app).get('/security');
    expect(res.status).toBe(200);
    for (const word of ['hashed', 'SQL injection', 'Cross-Site Scripting', 'CSRF', 'HTTPS', 'Account lockout']) {
      expect(res.text).toContain(word);
    }
  });
});

describe('Rate limiting (unit)', () => {
  test('too many POSTs from one IP get a 429', () => {
    const { rateLimit } = require('../src/middleware/security');
    const limiter = rateLimit({ windowMs: 60000, max: 3, name: 'test' });
    const results = [];
    for (let i = 0; i < 5; i++) {
      const res = { set: jest.fn() };
      limiter({ method: 'POST', ip: '1.2.3.4' }, res, (err) => results.push(err ? err.status : 'ok'));
    }
    expect(results).toEqual(['ok', 'ok', 'ok', 429, 429]);
  });
});
