// Error handling and input validation unit tests
const { setup, teardown, loginAs, ADMIN, db, request } = require('./helpers');
const validate = require('../src/validate');

let app;
beforeAll(async () => {
  app = await setup();
});
afterAll(teardown);

describe('Error handling', () => {
  test.each(['/no-such-page', '/projects/0', '/projects/-1', '/projects/1abc', '/projects/99999999999', '/donations/abc'])(
    '%s shows a friendly page (404 or login), never a crash',
    async (url) => {
      const res = await request(app).get(url);
      expect([302, 404]).toContain(res.status);
      if (res.status === 404) expect(res.text).toContain('We could not find that page');
    }
  );

  test('admin pages with bad IDs return 404', async () => {
    const a = await loginAs(app, ...ADMIN);
    for (const url of ['/admin/projects/abc', '/admin/projects/99999', '/admin/projects/99999/edit']) {
      expect((await a.get(url)).status).toBe(404);
    }
    expect((await a.send('/admin/tasks/99999/delete')).status).toBe(404);
    expect((await a.send('/admin/expenses/abc/delete')).status).toBe(404);
  });

  test('a server error shows a friendly message and hides the details', async () => {
    const spy = jest.spyOn(db, 'query').mockRejectedValueOnce(new Error('secret database detail'));
    const res = await request(app).get('/projects');
    spy.mockRestore();
    expect(res.status).toBe(500);
    expect(res.text).toContain('Something went wrong on our side');
    expect(res.text).not.toContain('secret database detail');
  });

  test('the health check returns 503 when the database is down', async () => {
    const spy = jest.spyOn(db, 'query').mockRejectedValueOnce(new Error('down'));
    const res = await request(app).get('/health');
    spy.mockRestore();
    expect(res.status).toBe(503);
  });
});

describe('Validation rules (unit)', () => {
  test('strong password rule', () => {
    expect(validate.strongPassword('Abcdefg1')).toBe(true);
    expect(validate.strongPassword('short1')).toBe(false);
    expect(validate.strongPassword('nonumbers')).toBe(false);
    expect(validate.strongPassword('12345678')).toBe(false);
    expect(validate.strongPassword('a1' + 'x'.repeat(80))).toBe(false); // bcrypt limit
    expect(validate.strongPassword(['Abcdefg1'])).toBe(false); // arrays are not accepted
  });

  test('real dates only', () => {
    expect(validate.isRealDate('2026-02-28')).toBe(true);
    expect(validate.isRealDate('2026-02-30')).toBe(false);
    expect(validate.isRealDate('28/02/2026')).toBe(false);
    expect(validate.isRealDate('')).toBe(false);
  });

  test('IDs must be positive whole numbers', () => {
    expect(validate.id('12')).toBe(12);
    expect(validate.id('0')).toBeNull();
    expect(validate.id('-3')).toBeNull();
    expect(validate.id('1e3')).toBeNull();
    expect(validate.id('1; DROP TABLE')).toBeNull();
  });

  test('donation amount accepts commas but not decimals', () => {
    expect(validate.donation({ amount: '25,000', method: 'card' }).errors).toEqual({});
    expect(validate.donation({ amount: '25.50', method: 'card' }).errors.amount).toBeDefined();
  });

  test('fields sent as arrays (parameter tampering) are treated as empty', () => {
    const { errors } = validate.registration({ full_name: ['a', 'b'], email: ['x@y.com'], password: 'Abcdefg1', confirm_password: 'Abcdefg1' });
    expect(errors.full_name).toBeDefined();
    expect(errors.email).toBeDefined();
  });

  test('extra spaces are trimmed', () => {
    const { data } = validate.volunteer({ skills: '   Driving   ', availability: 'weekends' });
    expect(data.skills).toBe('Driving');
  });
});
