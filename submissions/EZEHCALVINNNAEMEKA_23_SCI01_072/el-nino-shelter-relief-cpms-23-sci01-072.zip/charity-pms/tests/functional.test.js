// Functional tests: the main things users and admins do
const { setup, teardown, loginAs, ADMIN, USER, USER2, db, request } = require('./helpers');
const { getProject } = require('../src/models');

let app;
beforeAll(async () => {
  app = await setup();
});
afterAll(teardown);

describe('Donations from start to finish', () => {
  let donationId;
  let raisedBefore;

  test('a user records a donation and gets a reference number', async () => {
    raisedBefore = (await getProject(1)).raised;
    const u = await loginAs(app, ...USER);
    const res = await u.send('/projects/1/donate', { amount: '15,000', method: 'bank_transfer', message: 'Stay safe' });
    expect(res.status).toBe(302);
    expect(res.headers.location).toMatch(/^\/donations\/\d+$/);
    donationId = Number(res.headers.location.split('/').pop());
    const receipt = await u.get(res.headers.location);
    expect(receipt.text).toMatch(/DON-[0-9A-F]{8}/);
    expect(receipt.text).toContain('₦15,000');
    expect(receipt.text).toContain('Pending');
  });

  test('a pending donation is not counted as raised yet', async () => {
    expect((await getProject(1)).raised).toBe(raisedBefore);
  });

  test('an admin confirms it, and the project total goes up', async () => {
    const a = await loginAs(app, ...ADMIN);
    const res = await a.send(`/admin/donations/${donationId}/review`, { decision: 'confirmed' });
    expect(res.status).toBe(302);
    expect((await getProject(1)).raised).toBe(raisedBefore + 15000);
  });

  test('a donation cannot be reviewed twice', async () => {
    const a = await loginAs(app, ...ADMIN);
    await a.send(`/admin/donations/${donationId}/review`, { decision: 'rejected' });
    const { rows } = await db.query('SELECT status FROM donations WHERE id = $1', [donationId]);
    expect(rows[0].status).toBe('confirmed');
  });

  test('an admin can reject a donation', async () => {
    const u = await loginAs(app, ...USER2);
    const r = await u.send('/projects/2/donate', { amount: '5000', method: 'cash' });
    const id = Number(r.headers.location.split('/').pop());
    const a = await loginAs(app, ...ADMIN);
    await a.send(`/admin/donations/${id}/review`, { decision: 'rejected' });
    const { rows } = await db.query('SELECT status, reviewed_by FROM donations WHERE id = $1', [id]);
    expect(rows[0].status).toBe('rejected');
    expect(rows[0].reviewed_by).not.toBeNull();
  });

  test('a bad decision value is refused', async () => {
    const a = await loginAs(app, ...ADMIN);
    const res = await a.send(`/admin/donations/1/review`, { decision: 'deleted' });
    expect(res.status).toBe(400);
  });

  test('a completed project does not accept donations', async () => {
    const { rows } = await db.query("SELECT id FROM projects WHERE status = 'completed' LIMIT 1");
    const u = await loginAs(app, ...USER);
    const res = await u.send(`/projects/${rows[0].id}/donate`, { amount: '5000', method: 'card' });
    expect(res.status).toBe(302);
    const { rows: d } = await db.query("SELECT COUNT(*) AS n FROM donations WHERE project_id = $1 AND status = 'pending'", [rows[0].id]);
    expect(d[0].n).toBe(0);
  });

  test.each([
    ['too small', { amount: '50', method: 'card' }, 'between ₦100'],
    ['not a number', { amount: 'ten', method: 'card' }, 'between ₦100'],
    ['negative', { amount: '-500', method: 'card' }, 'between ₦100'],
    ['decimal', { amount: '100.5', method: 'card' }, 'between ₦100'],
    ['bad method', { amount: '1000', method: 'bitcoin' }, 'Choose how you will pay'],
  ])('donation form shows an error when the amount is %s', async (_n, data, msg) => {
    const u = await loginAs(app, ...USER);
    const res = await u.send('/projects/1/donate', data);
    expect(res.headers.location).toBe('/projects/1#donate');
    const page = await u.get('/projects/1');
    expect(page.text).toContain(msg);
  });
});

describe('Volunteering', () => {
  test('a user signs up, cannot sign up twice, then withdraws', async () => {
    const u = await loginAs(app, ...USER2);
    const res = await u.send('/projects/3/volunteer', { skills: 'Plumbing', availability: 'weekends' });
    expect(res.status).toBe(302);
    await u.send('/projects/3/volunteer', { skills: 'Plumbing again', availability: 'anytime' });
    const { rows } = await db.query(
      "SELECT id, skills FROM volunteers WHERE project_id = 3 AND user_id = (SELECT id FROM users WHERE email = 'tunde@charity.test')"
    );
    expect(rows.length).toBe(1);
    expect(rows[0].skills).toBe('Plumbing');
    await u.send(`/volunteering/${rows[0].id}/withdraw`);
    expect((await db.query('SELECT COUNT(*) AS n FROM volunteers WHERE id = $1', [rows[0].id])).rows[0].n).toBe(0);
  });

  test('missing details are refused', async () => {
    const u = await loginAs(app, ...USER2);
    await u.send('/projects/3/volunteer', { skills: '', availability: 'never' });
    const page = await u.get('/projects/3');
    expect(page.text).toContain('Tell us how you can help');
    expect(page.text).toContain('Choose when you are available');
  });

  test('an admin approves a volunteer', async () => {
    const { rows } = await db.query("SELECT id FROM volunteers WHERE status = 'pending' LIMIT 1");
    const a = await loginAs(app, ...ADMIN);
    await a.send(`/admin/volunteers/${rows[0].id}/review`, { decision: 'approved' });
    const after = await db.query('SELECT status FROM volunteers WHERE id = $1', [rows[0].id]);
    expect(after.rows[0].status).toBe('approved');
  });
});

describe('Project management (admin)', () => {
  const project = {
    title: 'Shade Canopies for Market Traders',
    category: 'shelter',
    summary: 'Put up shade canopies over open market stalls where traders sit in the heat all day.',
    description: 'Traders and their children sit in direct sun for hours. Shade canopies will cover 50 stalls before the hottest months.',
    location: 'Kano, Kano State',
    target_amount: '1,500,000',
    start_date: '2026-12-01',
    end_date: '2027-02-28',
    status: 'planned',
  };
  let id;

  test('an admin creates a project', async () => {
    const a = await loginAs(app, ...ADMIN);
    const res = await a.send('/admin/projects', project);
    expect(res.status).toBe(302);
    id = Number(res.headers.location.split('/').pop());
    const p = await getProject(id);
    expect(p.title).toBe(project.title);
    expect(p.target_amount).toBe(1500000);
  });

  test('the new project shows in the public list and search', async () => {
    const res = await request(app).get('/projects').query({ q: 'canopies' });
    expect(res.text).toContain(project.title);
    expect(res.text).toContain('1 project found');
  });

  test('an admin edits the project', async () => {
    const a = await loginAs(app, ...ADMIN);
    await a.send(`/admin/projects/${id}`, { ...project, status: 'active', target_amount: '2000000' });
    const p = await getProject(id);
    expect(p.status).toBe('active');
    expect(p.target_amount).toBe(2000000);
  });

  test('bad project data is refused with clear messages', async () => {
    const a = await loginAs(app, ...ADMIN);
    const res = await a.send('/admin/projects', {
      ...project, title: 'abc', category: 'space', target_amount: '5', start_date: '2026-02-30', end_date: '2020-01-01', status: 'done',
    });
    expect(res.status).toBe(422);
    for (const msg of ['Title must be', 'Choose a category', 'Target must be', 'valid start date', 'Choose a valid status']) {
      expect(res.text).toContain(msg);
    }
  });

  test('end date cannot be before the start date', async () => {
    const a = await loginAs(app, ...ADMIN);
    const res = await a.send('/admin/projects', { ...project, start_date: '2026-12-10', end_date: '2026-12-01' });
    expect(res.text).toContain('End date cannot be before the start date');
  });

  test('tasks can be added, updated and deleted', async () => {
    const a = await loginAs(app, ...ADMIN);
    await a.send(`/admin/projects/${id}/tasks`, { title: 'Measure the market stalls', due_date: '2026-12-05', status: 'todo' });
    const { rows } = await db.query('SELECT id FROM tasks WHERE project_id = $1', [id]);
    expect(rows.length).toBe(1);
    await a.send(`/admin/tasks/${rows[0].id}/status`, { status: 'done' });
    expect((await db.query('SELECT status FROM tasks WHERE id = $1', [rows[0].id])).rows[0].status).toBe('done');
    const bad = await a.send(`/admin/tasks/${rows[0].id}/status`, { status: 'finished' });
    expect(bad.status).toBe(400);
    await a.send(`/admin/tasks/${rows[0].id}/delete`);
    expect((await db.query('SELECT COUNT(*) AS n FROM tasks WHERE project_id = $1', [id])).rows[0].n).toBe(0);
  });

  test('expenses are recorded and add up', async () => {
    const a = await loginAs(app, ...ADMIN);
    await a.send(`/admin/projects/${id}/expenses`, { description: 'Canopy frames (50)', amount: '250,000', spent_on: '2026-11-10' });
    await a.send(`/admin/projects/${id}/expenses`, { description: 'Shade cloth and ropes', amount: '80000', spent_on: '2026-11-11' });
    expect((await getProject(id)).spent).toBe(330000);
  });

  test('an expense dated in the future is refused', async () => {
    const a = await loginAs(app, ...ADMIN);
    await a.send(`/admin/projects/${id}/expenses`, { description: 'Future thing', amount: '1000', spent_on: '2099-01-01' });
    const page = await a.get(`/admin/projects/${id}`);
    expect(page.text).toContain('Date cannot be in the future');
    expect((await getProject(id)).spent).toBe(330000);
  });

  test('a project WITHOUT donations can be deleted', async () => {
    const a = await loginAs(app, ...ADMIN);
    await a.send(`/admin/projects/${id}/delete`);
    expect(await getProject(id)).toBeNull();
    const { rows } = await db.query('SELECT COUNT(*) AS n FROM expenses WHERE project_id = $1', [id]);
    expect(rows[0].n).toBe(0); // expenses removed with it
  });

  test('a project WITH donations cannot be deleted (money records are kept)', async () => {
    const a = await loginAs(app, ...ADMIN);
    await a.send('/admin/projects/1/delete');
    expect(await getProject(1)).not.toBeNull();
  });
});

describe('Search and filters', () => {
  test('projects can be filtered by category and status', async () => {
    const res = await request(app).get('/projects').query({ category: 'shelter', status: 'active' });
    expect(res.text).toContain('Cooling Shelters for the El Niño Heatwave');
    expect(res.text).not.toContain('Food Packs for Drought-Hit Farming Families');
  });

  test('search looks in title, summary and location', async () => {
    const res = await request(app).get('/projects').query({ q: 'sokoto' });
    expect(res.text).toContain('Heatstroke Checks and First Aid');
  });

  test('admin can filter donations by status and search by donor', async () => {
    const a = await loginAs(app, ...ADMIN);
    const res = await a.get('/admin/donations').query({ status: 'confirmed', q: 'tunde' });
    expect(res.text).toContain('Tunde Bakare');
    expect(res.text).not.toContain('Halima Musa');
  });

  test('admin can search users and filter the activity log', async () => {
    const a = await loginAs(app, ...ADMIN);
    const users = await a.get('/admin/users').query({ q: 'halima' });
    expect(users.text).toContain('halima@charity.test');
    expect(users.text).not.toContain('tunde@charity.test');
    const log = await a.get('/admin/activity').query({ group: 'auth' });
    expect(log.text).toContain('auth.login');
    expect(log.text).not.toContain('project.create');
  });
});

describe('Profile', () => {
  test('a user updates their name and phone', async () => {
    const u = await loginAs(app, ...USER);
    await u.send('/profile', { full_name: 'Chiamaka N. Okafor', phone: '08099998888' });
    const { rows } = await db.query("SELECT full_name, phone FROM users WHERE email = 'user@charity.test'");
    expect(rows[0]).toEqual({ full_name: 'Chiamaka N. Okafor', phone: '08099998888' });
  });

  test('the email cannot be changed through the profile form', async () => {
    const u = await loginAs(app, ...USER);
    await u.send('/profile', { full_name: 'Chiamaka Okafor', email: 'new@evil.com' });
    const { rows } = await db.query("SELECT COUNT(*) AS n FROM users WHERE email = 'new@evil.com'");
    expect(rows[0].n).toBe(0);
  });

  test('changing the password needs the current password', async () => {
    const u = await loginAs(app, ...USER);
    const res = await u.send('/profile/password', { current_password: 'Wrong1234', new_password: 'NewPass123', confirm_password: 'NewPass123' });
    expect(res.status).toBe(422);
    expect(res.text).toContain('Your current password is wrong');
  });

  test('changing the password logs out other devices', async () => {
    const phone = await loginAs(app, ...USER);
    const laptop = await loginAs(app, ...USER);
    const res = await laptop.send('/profile/password', { current_password: USER[1], new_password: 'NewPass123', confirm_password: 'NewPass123' });
    expect(res.status).toBe(302);
    expect((await laptop.get('/dashboard')).status).toBe(200);
    expect((await phone.get('/dashboard')).status).toBe(302);
    await loginAs(app, USER[0], 'NewPass123'); // new password works
  });
});
