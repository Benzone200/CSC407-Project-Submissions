// Registration, login, logout and session tests
const { setup, teardown, client, loginAs, ADMIN, USER, db } = require('./helpers');

let app;
beforeAll(async () => {
  app = await setup();
});
afterAll(teardown);

const good = {
  full_name: 'Ngozi Eze',
  email: 'Ngozi.Eze@Example.com',
  phone: '0803 111 2222',
  password: 'Strong123',
  confirm_password: 'Strong123',
};

describe('Registration', () => {
  test('a new user can register and is logged in', async () => {
    const c = await client(app);
    const res = await c.send('/register', good);
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/dashboard');
    const dash = await c.get('/dashboard');
    expect(dash.status).toBe(200);
    expect(dash.text).toContain('Welcome, Ngozi');
  });

  test('email is saved in lower case and phone without spaces', async () => {
    const { rows } = await db.query("SELECT email, phone, role FROM users WHERE email = 'ngozi.eze@example.com'");
    expect(rows[0]).toEqual({ email: 'ngozi.eze@example.com', phone: '08031112222', role: 'user' });
  });

  test('the password is stored as a bcrypt hash, never as plain text', async () => {
    const { rows } = await db.query("SELECT password_hash FROM users WHERE email = 'ngozi.eze@example.com'");
    expect(rows[0].password_hash).not.toContain('Strong123');
    expect(rows[0].password_hash).toMatch(/^\$2[aby]\$\d{2}\$.{53}$/);
  });

  test('the same email cannot register twice (any letter case)', async () => {
    const c = await client(app);
    const res = await c.send('/register', { ...good, email: 'NGOZI.EZE@example.com' });
    expect(res.status).toBe(422);
    expect(res.text).toContain('already exists');
  });

  test('a user cannot make themselves admin by adding role=admin to the form', async () => {
    const c = await client(app);
    await c.send('/register', { ...good, email: 'sneaky@example.com', role: 'admin' });
    const { rows } = await db.query("SELECT role FROM users WHERE email = 'sneaky@example.com'");
    expect(rows[0].role).toBe('user');
  });

  test.each([
    ['empty name', { full_name: '' }, 'Enter your full name'],
    ['name with symbols', { full_name: 'Bad<Name>' }, 'Name can only contain letters'],
    ['bad email', { email: 'not-an-email' }, 'Enter a valid email'],
    ['bad phone', { phone: 'abc123' }, 'Enter a valid phone'],
    ['short password', { password: 'Ab1', confirm_password: 'Ab1' }, 'Password must be 8 to 72'],
    ['password without a number', { password: 'onlyletters', confirm_password: 'onlyletters' }, 'Password must be 8 to 72'],
    ['passwords do not match', { confirm_password: 'Different123' }, 'do not match'],
  ])('registration is refused for %s', async (_name, change, message) => {
    const c = await client(app);
    const res = await c.send('/register', { ...good, email: `x${Date.now()}${Math.random()}@ex.com`, ...change });
    expect(res.status).toBe(422);
    expect(res.text).toContain(message);
  });
});

describe('Login', () => {
  test('admin is sent to the admin dashboard', async () => {
    const c = await client(app);
    const res = await c.send('/login', { email: ADMIN[0], password: ADMIN[1] });
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/admin');
  });

  test('user is sent to the user dashboard', async () => {
    const c = await client(app);
    const res = await c.send('/login', { email: USER[0], password: USER[1] });
    expect(res.headers.location).toBe('/dashboard');
  });

  test('email is not case sensitive at login', async () => {
    const c = await client(app);
    const res = await c.send('/login', { email: 'USER@Charity.Test', password: USER[1] });
    expect(res.status).toBe(302);
  });

  test('wrong password and unknown email give the same message', async () => {
    const c = await client(app);
    const a = await c.send('/login', { email: 'tunde@charity.test', password: 'Wrong1234' });
    const b = await c.send('/login', { email: 'nobody@charity.test', password: 'Wrong1234' });
    expect(a.status).toBe(401);
    expect(b.status).toBe(401);
    expect(a.text).toContain('Email or password is wrong.');
    expect(b.text).toContain('Email or password is wrong.');
    await db.query("UPDATE users SET failed_logins = 0 WHERE email = 'tunde@charity.test'");
  });

  test('empty fields are refused', async () => {
    const c = await client(app);
    const res = await c.send('/login', { email: '', password: '' });
    expect(res.status).toBe(422);
  });

  test('the failed login is recorded in the activity log', async () => {
    const { rows } = await db.query("SELECT COUNT(*) AS n FROM activity_log WHERE action = 'auth.login_failed'");
    expect(rows[0].n).toBeGreaterThan(0);
  });

  test('a logged-in user is sent away from the login page', async () => {
    const c = await loginAs(app, ...USER);
    const res = await c.get('/login');
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/dashboard');
  });
});

describe('Account lockout', () => {
  const email = 'halima@charity.test';

  test('5 wrong passwords lock the account', async () => {
    const c = await client(app);
    for (let i = 1; i <= 4; i++) {
      const r = await c.send('/login', { email, password: 'Wrong1234' });
      expect(r.status).toBe(401);
    }
    const fifth = await c.send('/login', { email, password: 'Wrong1234' });
    expect(fifth.status).toBe(423);
    expect(fifth.text).toContain('locked for 15 minutes');
  });

  test('even the correct password is refused while locked', async () => {
    const c = await client(app);
    const res = await c.send('/login', { email, password: 'User@12345' });
    expect(res.status).toBe(423);
  });

  test('login works again once the lock time has passed', async () => {
    await db.query("UPDATE users SET locked_until = NOW() - interval '1 minute' WHERE email = $1", [email]);
    const c = await client(app);
    const res = await c.send('/login', { email, password: 'User@12345' });
    expect(res.status).toBe(302);
  });
});

describe('Sessions and logout', () => {
  test('the session ID changes at login (stops session fixation)', async () => {
    const c = await client(app);
    const before = (await c.get('/login')).headers['set-cookie'];
    // anonymous visitors only get a cookie once the session has data
    const sid = () => db.query('SELECT sid FROM sessions');
    const sidsBefore = (await sid()).rows.map((r) => r.sid);
    await c.send('/login', { email: USER[0], password: USER[1] });
    const sidsAfter = (await sid()).rows.map((r) => r.sid);
    const newOnes = sidsAfter.filter((s) => !sidsBefore.includes(s));
    expect(newOnes.length).toBe(1);
    expect(before === undefined || Array.isArray(before)).toBe(true);
  });

  test('sessions are stored on the server in the database', async () => {
    const { rows } = await db.query("SELECT COUNT(*) AS n FROM sessions WHERE sess->>'userId' IS NOT NULL");
    expect(rows[0].n).toBeGreaterThan(0);
  });

  test('logout ends the session on the server', async () => {
    const c = await loginAs(app, ...USER);
    expect((await c.get('/dashboard')).status).toBe(200);
    const out = await c.send('/logout');
    expect(out.status).toBe(302);
    expect(out.headers.location).toBe('/login?out=1');
    const after = await c.get('/dashboard');
    expect(after.status).toBe(302);
    expect(after.headers.location).toBe('/login');
  });

  test('after logging in, the user goes back to the page they wanted', async () => {
    const c = await client(app);
    await c.get('/donations');
    await c.refreshCsrf('/login');
    const res = await c.send('/login', { email: USER[0], password: USER[1] });
    expect(res.headers.location).toBe('/donations');
  });

  test('a session expires after the set time of inactivity', async () => {
    const c = await loginAs(app, ...USER);
    await db.query("UPDATE sessions SET expire = NOW() - interval '1 second'");
    const res = await c.get('/dashboard');
    expect(res.status).toBe(302);
  });
});
