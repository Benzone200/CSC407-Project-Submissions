// Database tests: tables, rules (constraints), relationships and transactions
const { setup, teardown, db, request } = require('./helpers');
const { migrate, seed } = require('../src/setup');

let app;
beforeAll(async () => {
  app = await setup();
});
afterAll(teardown);

async function fails(sql, params) {
  await expect(db.query(sql, params)).rejects.toThrow();
}

describe('Setup', () => {
  test('all tables exist', async () => {
    const { rows } = await db.query(
      "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name"
    );
    expect(rows.map((r) => r.table_name)).toEqual(
      expect.arrayContaining(['activity_log', 'donations', 'expenses', 'projects', 'sessions', 'tasks', 'users', 'volunteers'])
    );
  });

  test('running the migration again is safe', async () => {
    await expect(migrate()).resolves.not.toThrow();
  });

  test('seeding again does not add duplicate data', async () => {
    const before = (await db.query('SELECT COUNT(*) AS n FROM users')).rows[0].n;
    const r = await seed();
    expect(r.created).toBe(false);
    expect((await db.query('SELECT COUNT(*) AS n FROM users')).rows[0].n).toBe(before);
  });

  test('the health check reports the database is working', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ status: 'ok', database: 'ok' });
  });
});

describe('Rules the database enforces', () => {
  test('emails must be unique', async () => {
    await fails("INSERT INTO users (full_name, email, password_hash) VALUES ('X', 'user@charity.test', 'h')");
  });

  test('emails must be stored in lower case', async () => {
    await fails("INSERT INTO users (full_name, email, password_hash) VALUES ('X', 'Upper@Case.com', 'h')");
  });

  test('role must be admin or user', async () => {
    await fails("INSERT INTO users (full_name, email, password_hash, role) VALUES ('X', 'x@y.com', 'h', 'superuser')");
  });

  test('project target must be more than zero', async () => {
    await fails(
      "INSERT INTO projects (title, category, summary, description, location, target_amount, start_date) VALUES ('T','shelter','S','D','L', 0, '2026-01-01')"
    );
  });

  test('project end date cannot be before start date', async () => {
    await fails(
      "INSERT INTO projects (title, category, summary, description, location, target_amount, start_date, end_date) VALUES ('T','shelter','S','D','L', 10, '2026-05-01', '2026-01-01')"
    );
  });

  test('donation amount must be between ₦100 and ₦100,000,000', async () => {
    await fails("INSERT INTO donations (reference, project_id, user_id, amount, method) VALUES ('DON-T1', 1, 2, 50, 'card')");
    await fails("INSERT INTO donations (reference, project_id, user_id, amount, method) VALUES ('DON-T2', 1, 2, 200000000, 'card')");
  });

  test('donation status must be pending, confirmed or rejected', async () => {
    await fails("INSERT INTO donations (reference, project_id, user_id, amount, method, status) VALUES ('DON-T3', 1, 2, 500, 'card', 'paid')");
  });

  test('donation references must be unique', async () => {
    const { rows } = await db.query('SELECT reference FROM donations LIMIT 1');
    await fails("INSERT INTO donations (reference, project_id, user_id, amount, method) VALUES ($1, 1, 2, 500, 'card')", [rows[0].reference]);
  });

  test('a donation must belong to a real project and user', async () => {
    await fails("INSERT INTO donations (reference, project_id, user_id, amount, method) VALUES ('DON-T4', 9999, 2, 500, 'card')");
  });

  test('a project with donations cannot be deleted (RESTRICT)', async () => {
    await fails('DELETE FROM projects WHERE id = 1');
  });

  test('one person can only sign up once per project', async () => {
    const { rows } = await db.query('SELECT project_id, user_id FROM volunteers LIMIT 1');
    await fails(
      "INSERT INTO volunteers (project_id, user_id, skills, availability) VALUES ($1, $2, 'x', 'weekends')",
      [rows[0].project_id, rows[0].user_id]
    );
  });

  test('deleting a project also deletes its tasks and expenses (CASCADE)', async () => {
    const p = await db.query(
      "INSERT INTO projects (title, category, summary, description, location, target_amount, start_date) VALUES ('Temp','shelter','S','D','L', 10, '2026-01-01') RETURNING id"
    );
    const id = p.rows[0].id;
    await db.query("INSERT INTO tasks (project_id, title) VALUES ($1, 'temp task')", [id]);
    await db.query("INSERT INTO expenses (project_id, description, amount, spent_on) VALUES ($1, 'temp', 5, '2026-01-01')", [id]);
    await db.query('DELETE FROM projects WHERE id = $1', [id]);
    expect((await db.query('SELECT COUNT(*) AS n FROM tasks WHERE project_id = $1', [id])).rows[0].n).toBe(0);
    expect((await db.query('SELECT COUNT(*) AS n FROM expenses WHERE project_id = $1', [id])).rows[0].n).toBe(0);
  });
});

describe('Transactions', () => {
  test('if one step fails, nothing in the transaction is saved', async () => {
    const before = (await db.query('SELECT COUNT(*) AS n FROM tasks')).rows[0].n;
    await expect(
      db.transaction(async (q) => {
        await q("INSERT INTO tasks (project_id, title) VALUES (1, 'step one')");
        await q("INSERT INTO tasks (project_id, title, status) VALUES (1, 'step two', 'not-a-status')");
      })
    ).rejects.toThrow();
    expect((await db.query('SELECT COUNT(*) AS n FROM tasks')).rows[0].n).toBe(before);
  });

  test('a successful transaction saves everything', async () => {
    const before = (await db.query('SELECT COUNT(*) AS n FROM tasks')).rows[0].n;
    await db.transaction(async (q) => {
      await q("INSERT INTO tasks (project_id, title) VALUES (1, 'a')");
      await q("INSERT INTO tasks (project_id, title) VALUES (1, 'b')");
    });
    expect((await db.query('SELECT COUNT(*) AS n FROM tasks')).rows[0].n).toBe(before + 2);
  });
});

describe('Totals are calculated correctly', () => {
  test('raised = sum of confirmed donations only', async () => {
    const { getProject } = require('../src/models');
    const p = await getProject(1);
    const { rows } = await db.query("SELECT COALESCE(SUM(amount),0) AS s FROM donations WHERE project_id = 1 AND status = 'confirmed'");
    expect(p.raised).toBe(rows[0].s);
    const all = await db.query('SELECT SUM(amount) AS s FROM donations WHERE project_id = 1');
    expect(p.raised).toBeLessThan(all.rows[0].s); // pending/rejected are not counted
  });
});
