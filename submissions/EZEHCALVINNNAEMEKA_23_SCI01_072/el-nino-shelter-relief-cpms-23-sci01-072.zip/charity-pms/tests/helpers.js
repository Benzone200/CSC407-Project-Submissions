// Shared test setup.
// By default tests use a fresh in-memory PostgreSQL (PGlite), so no setup is needed.
// To test against a real PostgreSQL server: TEST_DATABASE_URL=postgres://... npm test
process.env.NODE_ENV = 'test';
process.env.BCRYPT_ROUNDS = '4'; // fast hashing in tests only
process.env.DATABASE_URL = '';

const request = require('supertest');
const db = require('../src/db');
const { migrate, seed } = require('../src/setup');
const { createApp } = require('../src/app');

async function setup() {
  const url = process.env.TEST_DATABASE_URL || '';
  await db.init(url ? { url } : { memory: true });
  if (url) {
    // Start every test file from an empty database
    await db.exec('DROP SCHEMA public CASCADE; CREATE SCHEMA public;');
  }
  await migrate();
  await seed();
  return createApp();
}

async function teardown() {
  await db.close();
}

function csrfFrom(html) {
  const m = /name="_csrf" value="([^"]+)"/.exec(html);
  if (!m) throw new Error('No CSRF token on page');
  return m[1];
}

// A browser-like client that keeps cookies and knows the CSRF token
async function client(app) {
  const agent = request.agent(app);
  const page = await agent.get('/login');
  agent.csrf = csrfFrom(page.text);
  // post() adds the CSRF token automatically
  agent.send = (url, data = {}) => agent.post(url).type('form').send({ _csrf: agent.csrf, ...data });
  agent.refreshCsrf = async (url = '/projects') => {
    const r = await agent.get(url);
    agent.csrf = csrfFrom(r.text);
    return r;
  };
  return agent;
}

async function loginAs(app, email, password) {
  const agent = await client(app);
  const res = await agent.send('/login', { email, password });
  if (res.status !== 302) throw new Error(`Login failed for ${email}: ${res.status}`);
  await agent.refreshCsrf(); // session ID and token change after login
  return agent;
}

const ADMIN = ['admin@charity.test', 'Admin@12345'];
const USER = ['user@charity.test', 'User@12345'];
const USER2 = ['tunde@charity.test', 'User@12345'];

async function userId(email) {
  const { rows } = await db.query('SELECT id FROM users WHERE email = $1', [email]);
  return rows[0].id;
}

module.exports = { setup, teardown, client, loginAs, csrfFrom, ADMIN, USER, USER2, userId, db, request };
