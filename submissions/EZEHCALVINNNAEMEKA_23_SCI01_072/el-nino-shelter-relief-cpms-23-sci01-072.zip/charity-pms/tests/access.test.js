// Role-based access and access-control checks
const { setup, teardown, client, loginAs, ADMIN, USER, USER2, userId, db, request } = require('./helpers');

let app;
beforeAll(async () => {
  app = await setup();
});
afterAll(teardown);

const adminPages = ['/admin', '/admin/projects', '/admin/projects/new', '/admin/projects/1', '/admin/projects/1/edit',
  '/admin/donations', '/admin/volunteers', '/admin/users', '/admin/activity'];
const userPages = ['/dashboard', '/donations', '/profile'];

describe('Visitors who are not logged in', () => {
  test.each([...adminPages, ...userPages])('%s sends them to the login page', async (url) => {
    const res = await request(app).get(url);
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/login');
  });

  test('they can still browse public pages', async () => {
    for (const url of ['/', '/projects', '/projects/1', '/security']) {
      expect((await request(app).get(url)).status).toBe(200);
    }
  });
});

describe('Normal users cannot use admin features', () => {
  let u;
  beforeAll(async () => {
    u = await loginAs(app, ...USER);
  });

  test.each(adminPages)('GET %s returns 403', async (url) => {
    const res = await u.get(url);
    expect(res.status).toBe(403);
    expect(res.text).toContain('You do not have permission');
  });

  test.each([
    ['/admin/projects', { title: 'Hack' }],
    ['/admin/projects/1/delete', {}],
    ['/admin/donations/1/review', { decision: 'confirmed' }],
    ['/admin/volunteers/1/review', { decision: 'approved' }],
    ['/admin/users/2/role', { role: 'admin' }],
    ['/admin/projects/1/expenses', { description: 'x', amount: '1', spent_on: '2026-01-01' }],
  ])('POST %s returns 403 and changes nothing', async (url, data) => {
    const res = await u.send(url, data);
    expect(res.status).toBe(403);
  });

  test('no user was made admin and nothing was deleted', async () => {
    const { rows } = await db.query("SELECT role FROM users WHERE email = 'user@charity.test'");
    expect(rows[0].role).toBe('user');
    expect((await db.query('SELECT COUNT(*) AS n FROM projects WHERE id = 1')).rows[0].n).toBe(1);
  });

  test('blocked attempts are written to the activity log', async () => {
    const { rows } = await db.query("SELECT COUNT(*) AS n FROM activity_log WHERE action = 'security.access_denied'");
    expect(rows[0].n).toBeGreaterThan(0);
  });
});

describe('Users can only see and change their own records', () => {
  test("a user cannot open another user's donation receipt", async () => {
    const tunde = await userId(USER2[0]);
    const { rows } = await db.query('SELECT id FROM donations WHERE user_id = $1 LIMIT 1', [tunde]);
    const u = await loginAs(app, ...USER);
    const res = await u.get(`/donations/${rows[0].id}`);
    expect(res.status).toBe(404);
  });

  test('a user can open their own receipt', async () => {
    const me = await userId(USER[0]);
    const { rows } = await db.query('SELECT id, reference FROM donations WHERE user_id = $1 LIMIT 1', [me]);
    const u = await loginAs(app, ...USER);
    const res = await u.get(`/donations/${rows[0].id}`);
    expect(res.status).toBe(200);
    expect(res.text).toContain(rows[0].reference);
  });

  test("a user cannot withdraw another user's volunteer sign-up", async () => {
    const tunde = await userId(USER2[0]);
    const { rows } = await db.query("SELECT id FROM volunteers WHERE user_id = $1 AND status = 'pending' LIMIT 1", [tunde]);
    const u = await loginAs(app, ...USER);
    const res = await u.send(`/volunteering/${rows[0].id}/withdraw`);
    expect(res.status).toBe(404);
    expect((await db.query('SELECT COUNT(*) AS n FROM volunteers WHERE id = $1', [rows[0].id])).rows[0].n).toBe(1);
  });

  test('the "My donations" list only shows my donations', async () => {
    const u = await loginAs(app, ...USER);
    const res = await u.get('/donations');
    const tunde = await userId(USER2[0]);
    const { rows } = await db.query('SELECT reference FROM donations WHERE user_id = $1', [tunde]);
    for (const r of rows) expect(res.text).not.toContain(r.reference);
  });

  test('admins do not see the donate form (only users donate)', async () => {
    const a = await loginAs(app, ...ADMIN);
    const page = await a.get('/projects/1');
    expect(page.text).not.toContain('Record my donation');
    expect(page.text).toContain('Manage this project');
    const res = await a.send('/projects/1/donate', { amount: '1000', method: 'card' });
    expect(res.status).toBe(403);
  });
});

describe('Admin user management safety', () => {
  test('an admin cannot remove their own admin role', async () => {
    const a = await loginAs(app, ...ADMIN);
    const me = await userId(ADMIN[0]);
    const res = await a.send(`/admin/users/${me}/role`, { role: 'user' });
    expect(res.status).toBe(302);
    const { rows } = await db.query('SELECT role FROM users WHERE id = $1', [me]);
    expect(rows[0].role).toBe('admin');
  });

  test('a role change takes effect on the next page load', async () => {
    const u = await loginAs(app, ...USER2);
    expect((await u.get('/admin')).status).toBe(403);
    const a = await loginAs(app, ...ADMIN);
    await a.send(`/admin/users/${await userId(USER2[0])}/role`, { role: 'admin' });
    expect((await u.get('/admin')).status).toBe(200);
    await a.send(`/admin/users/${await userId(USER2[0])}/role`, { role: 'user' });
    expect((await u.get('/admin')).status).toBe(403);
  });

  test('disabling an account logs that person out at once and blocks login', async () => {
    const victim = await loginAs(app, 'halima@charity.test', 'User@12345');
    expect((await victim.get('/dashboard')).status).toBe(200);
    const a = await loginAs(app, ...ADMIN);
    await a.send(`/admin/users/${await userId('halima@charity.test')}/status`, { action: 'disable' });
    expect((await victim.get('/dashboard')).status).toBe(302);
    const c = await client(app);
    const res = await c.send('/login', { email: 'halima@charity.test', password: 'User@12345' });
    expect(res.status).toBe(403);
    expect(res.text).toContain('disabled');
    await a.send(`/admin/users/${await userId('halima@charity.test')}/status`, { action: 'enable' });
  });

  test('an admin can unlock a locked account', async () => {
    await db.query("UPDATE users SET locked_until = NOW() + interval '10 minutes' WHERE email = $1", [USER2[0]]);
    const a = await loginAs(app, ...ADMIN);
    await a.send(`/admin/users/${await userId(USER2[0])}/status`, { action: 'unlock' });
    const { rows } = await db.query('SELECT locked_until FROM users WHERE email = $1', [USER2[0]]);
    expect(rows[0].locked_until).toBeNull();
  });

  test('an unknown action is refused', async () => {
    const a = await loginAs(app, ...ADMIN);
    const res = await a.send(`/admin/users/${await userId(USER2[0])}/status`, { action: 'delete_everything' });
    expect(res.status).toBe(400);
  });
});
