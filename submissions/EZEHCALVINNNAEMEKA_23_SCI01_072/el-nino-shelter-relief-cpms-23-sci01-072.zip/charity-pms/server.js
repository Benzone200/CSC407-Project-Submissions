// Starts the web server.
const config = require('./src/config');
const db = require('./src/db');
const logger = require('./src/logger');
const { migrate, seed } = require('./src/setup');
const { createApp } = require('./src/app');

async function main() {
  await db.init();
  await migrate(); // creates tables if they are missing
  const seeded = await seed(); // adds the admin (and sample data in development) on first run only
  const app = createApp();
  const server = app.listen(config.port, () => {
    logger.info('server started', { port: config.port, env: config.env, database: db.kind() });
    if (!config.isProduction) {
      console.log(`\n  El Niño Shelter Relief - Charity Project Management System is running.`);
      console.log(`  Open http://localhost:${config.port} in your browser.\n`);
      if (seeded.created && config.demoData) {
        console.log('  Sample logins (development only):');
        console.log('    Admin: admin@charity.test / Admin@12345');
        console.log('    User:  user@charity.test  / User@12345\n');
      }
    }
  });

  // Close cleanly when the host stops the app
  const stop = (signal) => {
    logger.info('shutting down', { signal });
    server.close(async () => {
      await db.close();
      process.exit(0);
    });
    setTimeout(() => process.exit(1), 10000).unref();
  };
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
}

process.on('unhandledRejection', (err) => {
  logger.error('unhandled rejection', { error: err && err.message, stack: err && err.stack });
});

main().catch((err) => {
  logger.error('failed to start', { error: err.message, stack: err.stack });
  process.exit(1);
});
