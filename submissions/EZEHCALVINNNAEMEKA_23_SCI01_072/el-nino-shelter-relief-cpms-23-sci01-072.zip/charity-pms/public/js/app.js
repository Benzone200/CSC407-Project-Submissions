// Small page helpers. Kept in a separate file because our Content Security Policy
// blocks inline scripts (a protection against XSS).
document.documentElement.classList.remove('no-js');

// Mobile menu
const toggle = document.querySelector('.menu-toggle');
const nav = document.getElementById('main-nav');
if (toggle && nav) {
  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
  });
}

// Ask before dangerous actions, e.g. <form data-confirm="Delete this?">
document.querySelectorAll('form[data-confirm]').forEach((form) => {
  form.addEventListener('submit', (e) => {
    if (!window.confirm(form.dataset.confirm)) e.preventDefault();
  });
});

// Quick amount buttons on the donate form
document.querySelectorAll('[data-amount]').forEach((btn) => {
  btn.addEventListener('click', () => {
    const input = document.getElementById(btn.dataset.target || 'amount');
    if (input) {
      input.value = Number(btn.dataset.amount).toLocaleString('en-NG');
      input.focus();
    }
  });
});

// Auto-submit select filters that are marked with data-autosubmit
document.querySelectorAll('select[data-autosubmit]').forEach((sel) => {
  sel.addEventListener('change', () => sel.form && sel.form.submit());
});

// Print button on receipts
document.querySelectorAll('[data-print]').forEach((btn) => {
  btn.addEventListener('click', () => window.print());
});
