# Deployment Guide

## 1. Run locally

```bash
# Backend
cd server && npm install && cp .env.example .env && npm start     # http://localhost:5000

# Frontend (second terminal)
cd client && npm install && npm run dev                           # http://localhost:5173
```

## 2. Environment variables

**Backend (`server/.env`)** – copy from `server/.env.example`

| Variable | Purpose | Example |
|----------|---------|---------|
| `PORT` | Port the API listens on (hosts usually set this for you) | `5000` |
| `JWT_SECRET` | Secret used to sign tokens. Must be long and random | `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` |
| `JWT_EXPIRES_IN` | Token lifetime | `2h` |
| `CLIENT_URL` | Frontend origin allowed by CORS | `https://my-gym.vercel.app` |

**Frontend (`client/.env`)** – copy from `client/.env.example`

| Variable | Purpose | Example |
|----------|---------|---------|
| `VITE_API_URL` | Backend API base URL (include `/api`, no trailing slash) | `https://my-gym-api.onrender.com/api` |

`.env` files are git-ignored. Never commit real secrets.

## 3. Free hosting options

| Part | Options |
|------|---------|
| Frontend (static) | Vercel, Netlify |
| Backend (Node) | Render, Railway |

### Deploy the backend (Render example)
1. Push the project to GitHub.
2. Render → **New → Web Service** → pick the repo.
3. Root directory: `server`. Build command: `npm install`. Start command: `npm start`.
4. Add environment variables: `JWT_SECRET` (random), `CLIENT_URL` (your frontend URL – set it after step below, then redeploy).
5. Deploy and copy the URL, e.g. `https://my-gym-api.onrender.com`. Check `https://…/api/health` returns `{"status":"ok"}`.

(Railway is similar: New Project → Deploy from GitHub → set root to `server` and add the same variables.)

### Deploy the frontend (Vercel example)
1. Vercel → **Add New Project** → pick the repo.
2. Root directory: `client`. Framework preset: **Vite**. Build command: `npm run build`. Output: `dist`.
3. Add environment variable `VITE_API_URL=https://my-gym-api.onrender.com/api`.
4. Deploy. Copy the frontend URL and put it in the backend's `CLIENT_URL`, then redeploy the backend.

**Netlify:** same settings, plus a file `client/public/_redirects` containing `/*  /index.html  200` so React Router URLs work on refresh.
**Vercel:** add `client/vercel.json` with `{ "rewrites": [{ "source": "/(.*)", "destination": "/" }] }` for the same reason.

## 4. Connecting frontend to the deployed backend
The frontend reads `VITE_API_URL` at **build time** (`client/src/api/api.js`). If you change it, redeploy the frontend.
The backend only accepts requests from `CLIENT_URL` (CORS), so the two URLs must match each other.

## 5. HTTPS
HTTPS is provided automatically by the hosting platform (Vercel/Netlify/Render/Railway issue and renew TLS certificates). The application code does not need to configure SSL.

## 6. Free-tier notes
- Render's free web services sleep after inactivity, so the first request may take ~30-60 seconds.
- Because data is in memory, **all data resets** whenever the backend restarts or wakes up.
