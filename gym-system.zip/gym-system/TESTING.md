# Testing

Manual testing. Start both servers, then follow the **Steps** column and record what you see.

> **How to complete this table:** the *Expected Result* column is what the code is designed to do.
> Fill in **Actual Result** and **Status** (Pass/Fail) yourself as you run each test, ideally with a screenshot
> for your report. Do not mark Pass for a test you have not run.

Seed accounts: `admin@gym.com / Admin123!`, `chidi@example.com / Member123!` (active),
`tunde@example.com / Member123!` (expired). Yoga class starts full.

| # | Category | Test | Steps | Expected Result | Actual Result | Status |
|---|----------|------|-------|-----------------|---------------|--------|
| 1 | Login | Valid member login | Log in as Chidi | Redirect to member dashboard | | |
| 2 | Login | Valid admin login | Log in as admin | Redirect to admin dashboard | | |
| 3 | Login | Wrong password | Chidi + wrong password | "Invalid email or password" error | | |
| 4 | Registration | Empty registration field | Submit register form with empty name | Inline validation message under the field | | |
| 5 | Registration | Duplicate email | Register with `chidi@example.com` | "Email already exists" error | | |
| 6 | Validation | Weak password | Register with password `abc` | Password strength message | | |
| 7 | Validation | Passwords do not match | Different confirm password | "Passwords do not match" | | |
| 8 | Security | Member opens admin URL | Log in as Chidi, visit `/admin` | 403 "Access denied" screen | | |
| 9 | Security | Unauthenticated API call | Open `http://localhost:5000/api/members` in the browser (no token) | 401 JSON "Authentication required" | | |
| 10 | Security | Member calls admin API | Using Chidi's token (browser dev tools → Application → Local Storage → `token`), call `GET /api/members/stats` with Authorization header (e.g. Postman) | 403 returned | | |
| 11 | Security | XSS in profile name | As Chidi, set name to `<script>alert(1)</script>Chidi`, save | No alert; tags stripped/escaped, name shown as plain text | | |
| 12 | Security | Cancel another member's booking | Chidi's token → `DELETE /api/bookings/<Ngozi's booking id>` | 403 returned | | |
| 13 | Security | Logout clears token | Click Log out, check Local Storage; press Back to a dashboard URL | `token` removed; redirected to login | | |
| 14 | Functional | Expired membership status | Log in as Tunde | Dashboard shows "Expired" | | |
| 15 | Functional | Expired member cannot book | Tunde → Book a class → Cardio Blast | Error: membership not active | | |
| 16 | Functional | Book a class | Chidi → book "Weight Training Basics" | Booking confirmed; button changes to "Cancel booking" | | |
| 17 | Functional | Booking a full class | Chidi → "Morning Yoga Flow" | Shows "Class full"; cannot book | | |
| 18 | Functional | Cancel a booking | Chidi → cancel "Cardio Blast" | Booking removed; spots increase | | |
| 19 | Functional | Edit profile | Change phone number and save | Success message; new value shown | | |
| 20 | Functional | Change password | Change Chidi's password, log out, log in with new one | Login works with the new password | | |
| 21 | Functional | Admin search/filter | Admin → Members → search "tunde", filter "Expired" | Table shows only matching members | | |
| 22 | Functional | Admin deactivate member | Deactivate Ngozi | Status becomes "Inactive" | | |
| 23 | Functional | Admin creates class | Manage Classes → New class → valid data | Class appears in the table and member view | | |
| 24 | Validation | Invalid payment amount (admin) | Record payment with `-5` or `abc` | Validation error shown | | |
| 25 | Functional | Valid payment renews membership | Record ₦15,000 for Tunde | Success; Tunde's status becomes Active | | |
| 26 | Usability | Loading and error messages | Stop the backend, refresh a dashboard | Error message displayed, no blank/crashed screen | | |
| 27 | Responsive | Mobile layout | Browser dev tools → 375px width; open Home, Login, Member and Admin pages | Layout fits; menu collapses to ☰; tables scroll sideways | | |
| 28 | Error handling | Unknown route | Visit `/does-not-exist` | 404 page with link home | | |

## Test coverage
Functional (14–16, 18–23, 25) · Login/Registration (1–7) · Form validation (4, 6, 7, 24) · Security (8–13) ·
Usability (26) · Responsive (27) · Error handling (9, 26, 28).
