/**
 * In-memory data store (NO database).
 * Everything lives in plain JavaScript arrays and is re-created by seed()
 * every time the server starts, so data resets on restart.
 */
const bcrypt = require('bcryptjs');

const DAY = 24 * 60 * 60 * 1000;

const store = {
  users: [],
  plans: [],
  classes: [],
  bookings: [],
  payments: [],
};

// Simple auto-increment id shared by all collections
let idCounter = 0;
store.nextId = () => ++idCounter;

// Helpers for dates
const daysFromNow = (d) => new Date(Date.now() + d * DAY).toISOString();
const classTime = (daysAhead, hour) => {
  const d = new Date(Date.now() + daysAhead * DAY);
  d.setHours(hour, 0, 0, 0);
  return d.toISOString();
};

/**
 * Work out a member's membership status from the data:
 *  - "inactive": an admin deactivated the account
 *  - "expired":  the expiry date has passed
 *  - "active":   everything is fine
 */
store.membershipStatus = (user) => {
  if (user.role !== 'member') return null;
  if (!user.isActive) return 'inactive';
  if (!user.expiryDate || new Date(user.expiryDate) < new Date()) return 'expired';
  return 'active';
};

/** Remove the password hash before sending a user to the client. */
store.publicUser = (user) => {
  const plan = store.plans.find((p) => p.id === user.planId);
  const { passwordHash, ...safe } = user; // eslint-disable-line no-unused-vars
  return { ...safe, planName: plan ? plan.name : null, status: store.membershipStatus(user) };
};

store.seed = () => {
  // ---- Plans ----
  store.plans.push(
    { id: store.nextId(), name: 'Monthly', price: 15000, durationDays: 30, description: 'Full gym access for 30 days. Perfect for trying us out.' },
    { id: store.nextId(), name: 'Quarterly', price: 40000, durationDays: 90, description: 'Three months of access plus 2 free personal-training sessions.' },
    { id: store.nextId(), name: 'Annual', price: 140000, durationDays: 365, description: 'Best value: 12 months, free locker, and guest passes.' }
  );
  const [monthly, quarterly] = store.plans;

  // ---- Users (passwords are HASHED, never stored in plain text) ----
  const adminHash = bcrypt.hashSync('Admin123!', 10);
  const memberHash = bcrypt.hashSync('Member123!', 10);
  const now = new Date().toISOString();

  store.users.push(
    { id: store.nextId(), fullName: 'Gym Admin', email: 'admin@gym.com', phone: '08000000000', passwordHash: adminHash, role: 'admin', isActive: true, createdAt: now },
    { id: store.nextId(), fullName: 'Chidi Okafor', email: 'chidi@example.com', phone: '08011111111', passwordHash: memberHash, role: 'member', planId: monthly.id, startDate: daysFromNow(-10), expiryDate: daysFromNow(20), isActive: true, createdAt: now },
    { id: store.nextId(), fullName: 'Ngozi Eze', email: 'ngozi@example.com', phone: '08022222222', passwordHash: memberHash, role: 'member', planId: quarterly.id, startDate: daysFromNow(-30), expiryDate: daysFromNow(60), isActive: true, createdAt: now },
    { id: store.nextId(), fullName: 'Tunde Bakare', email: 'tunde@example.com', phone: '08033333333', passwordHash: memberHash, role: 'member', planId: monthly.id, startDate: daysFromNow(-40), expiryDate: daysFromNow(-10), isActive: true, createdAt: now } // EXPIRED
  );
  const [, chidi, ngozi, tunde] = store.users;

  // ---- Classes ----
  // Yoga has capacity 2 and is already fully booked, so you can demo "Class full".
  store.classes.push(
    { id: store.nextId(), name: 'Morning Yoga Flow', trainer: 'Amina Bello', schedule: classTime(1, 7), capacity: 2 },
    { id: store.nextId(), name: 'Cardio Blast', trainer: 'Emeka Obi', schedule: classTime(2, 18), capacity: 15 },
    { id: store.nextId(), name: 'Weight Training Basics', trainer: 'Sade Johnson', schedule: classTime(3, 17), capacity: 10 }
  );
  const [yoga, cardio] = store.classes;

  // ---- Bookings ----
  store.bookings.push(
    { id: store.nextId(), classId: yoga.id, userId: ngozi.id, createdAt: now },
    { id: store.nextId(), classId: yoga.id, userId: tunde.id, createdAt: now },
    { id: store.nextId(), classId: cardio.id, userId: chidi.id, createdAt: now }
  );

  // ---- Payments (seeded history) ----
  const pay = (user, plan, amount, daysAgo) =>
    store.payments.push({ id: store.nextId(), userId: user.id, amount, description: `${plan.name} plan`, method: 'Transfer', date: daysFromNow(-daysAgo) });
  pay(chidi, monthly, 15000, 40);
  pay(chidi, monthly, 15000, 10);
  pay(ngozi, quarterly, 40000, 30);
  pay(tunde, monthly, 15000, 70);
  pay(tunde, monthly, 15000, 40);
};

module.exports = store;
