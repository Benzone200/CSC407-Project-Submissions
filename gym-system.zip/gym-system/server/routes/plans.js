/**
 * Membership plan routes.
 */
const express = require('express');
const store = require('../data/store');
const { authenticate } = require('../middleware/auth');
const { requireRole } = require('../middleware/roleCheck');
const { validate, check, all } = require('../middleware/validate');

const router = express.Router();

// GET /api/plans  (public - shown on the landing and register pages)
router.get('/', (req, res) => res.json({ plans: store.plans }));

// PUT /api/plans/:id  (admin only)
router.put(
  '/:id',
  authenticate,
  requireRole('admin'),
  validate({
    name: all(check.required('Name'), check.length('Name', 2, 40)),
    price: all(check.required('Price'), check.positiveNumber('Price')),
    durationDays: all(check.required('Duration'), check.positiveInt('Duration (days)', 730)),
    description: check.length('Description', 0, 200),
  }),
  (req, res) => {
    const plan = store.plans.find((p) => p.id === Number(req.params.id));
    if (!plan) return res.status(404).json({ message: 'Plan not found' });
    plan.name = req.body.name;
    plan.price = Number(req.body.price);
    plan.durationDays = Number(req.body.durationDays);
    plan.description = req.body.description || '';
    res.json({ plan });
  }
);

module.exports = router;
