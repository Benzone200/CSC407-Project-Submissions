/**
 * Booking routes.
 *  Members: book a class, cancel their own booking.
 *  Admin:   view every booking.
 */
const express = require('express');
const store = require('../data/store');
const { authenticate } = require('../middleware/auth');
const { requireRole } = require('../middleware/roleCheck');
const { validate, check } = require('../middleware/validate');

const router = express.Router();
router.use(authenticate);

// Join booking with class + member names for display
function withNames(b) {
  const cls = store.classes.find((c) => c.id === b.classId);
  const user = store.users.find((u) => u.id === b.userId);
  return { ...b, className: cls ? cls.name : 'Deleted class', trainer: cls ? cls.trainer : '', schedule: cls ? cls.schedule : null, memberName: user ? user.fullName : 'Unknown', memberEmail: user ? user.email : '' };
}

// GET /api/bookings  (admin: all bookings)
router.get('/', requireRole('admin'), (req, res) => res.json({ bookings: store.bookings.map(withNames) }));

// GET /api/bookings/mine  (member: only their own)
router.get('/mine', requireRole('member'), (req, res) => {
  res.json({ bookings: store.bookings.filter((b) => b.userId === req.user.id).map(withNames) });
});

// POST /api/bookings  body: { classId }
router.post('/', requireRole('member'), validate({ classId: check.required('Class') }), (req, res) => {
  const cls = store.classes.find((c) => c.id === Number(req.body.classId));
  if (!cls) return res.status(404).json({ message: 'Class not found' });

  if (store.membershipStatus(req.user) !== 'active') {
    return res.status(403).json({ message: 'Your membership is not active. Renew it to book classes.' });
  }
  if (new Date(cls.schedule) < new Date()) return res.status(400).json({ message: 'This class has already started.' });
  if (store.bookings.some((b) => b.classId === cls.id && b.userId === req.user.id)) {
    return res.status(409).json({ message: 'You already booked this class.' });
  }
  if (store.bookings.filter((b) => b.classId === cls.id).length >= cls.capacity) {
    return res.status(409).json({ message: 'Class full' });
  }

  const booking = { id: store.nextId(), classId: cls.id, userId: req.user.id, createdAt: new Date().toISOString() };
  store.bookings.push(booking);
  res.status(201).json({ booking: withNames(booking) });
});

// DELETE /api/bookings/:id  (owner or admin)
router.delete('/:id', (req, res) => {
  const booking = store.bookings.find((b) => b.id === Number(req.params.id));
  if (!booking) return res.status(404).json({ message: 'Booking not found' });

  // Access control: members may only cancel THEIR OWN bookings
  if (req.user.role !== 'admin' && booking.userId !== req.user.id) {
    return res.status(403).json({ message: 'Access denied. You can only cancel your own bookings.' });
  }
  store.bookings.splice(store.bookings.indexOf(booking), 1);
  res.json({ message: 'Booking cancelled' });
});

module.exports = router;
