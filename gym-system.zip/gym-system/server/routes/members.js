/**
 * Member routes.
 *  /me...        -> a logged-in user working ONLY with their own data
 *  everything else -> admin only
 * NOTE: "/me" routes are declared before "/:id" routes so "me" isn't read as an id.
 */
const express = require('express');
const bcrypt = require('bcryptjs');
const store = require('../data/store');
const { authenticate } = require('../middleware/auth');
const { requireRole } = require('../middleware/roleCheck');
const { validate, check, all } = require('../middleware/validate');

const router = express.Router();
const DAY = 24 * 60 * 60 * 1000;

router.use(authenticate); // every route below needs a valid token

// ---------------- Member: own data ----------------

// GET /api/members/me
router.get('/me', (req, res) => res.json({ user: store.publicUser(req.user) }));

// PUT /api/members/me  (edit name / phone)
router.put(
  '/me',
  validate({
    fullName: all(check.required('Full name'), check.length('Full name', 2, 60)),
    phone: all(check.required('Phone'), check.phone()),
  }),
  (req, res) => {
    req.user.fullName = req.body.fullName; // already sanitised by sanitizeBody
    req.user.phone = req.body.phone;
    res.json({ user: store.publicUser(req.user), message: 'Profile updated' });
  }
);

// PUT /api/members/me/password
router.put(
  '/me/password',
  validate({
    currentPassword: check.required('Current password'),
    newPassword: all(check.required('New password'), check.password()),
    confirmPassword: check.matches('newPassword', 'Passwords do not match'),
  }),
  async (req, res) => {
    const ok = await bcrypt.compare(req.body.currentPassword, req.user.passwordHash);
    if (!ok) return res.status(400).json({ message: 'Please fix the highlighted fields', errors: { currentPassword: 'Current password is incorrect' } });
    req.user.passwordHash = await bcrypt.hash(req.body.newPassword, 10);
    res.json({ message: 'Password changed' });
  }
);

// GET /api/members/me/payments  (own payments only)
router.get('/me/payments', (req, res) => {
  const list = store.payments.filter((p) => p.userId === req.user.id).sort((a, b) => new Date(b.date) - new Date(a.date));
  res.json({ payments: list });
});

// ---------------- Admin only ----------------

// GET /api/members/stats  (dashboard numbers)
router.get('/stats', requireRole('admin'), (req, res) => {
  const members = store.users.filter((u) => u.role === 'member');
  const count = (s) => members.filter((m) => store.membershipStatus(m) === s).length;
  res.json({
    totalMembers: members.length,
    activeMemberships: count('active'),
    expiredMemberships: count('expired'),
    inactiveMembers: count('inactive'),
    totalRevenue: store.payments.reduce((sum, p) => sum + p.amount, 0),
    upcomingClasses: store.classes.filter((c) => new Date(c.schedule) >= new Date()).length,
  });
});

// GET /api/members?search=&status=
router.get('/', requireRole('admin'), (req, res) => {
  const search = String(req.query.search || '').toLowerCase();
  const status = String(req.query.status || '');
  let list = store.users.filter((u) => u.role === 'member').map(store.publicUser);
  if (search) list = list.filter((m) => m.fullName.toLowerCase().includes(search) || m.email.toLowerCase().includes(search));
  if (['active', 'expired', 'inactive'].includes(status)) list = list.filter((m) => m.status === status);
  res.json({ members: list });
});

// Helper: find a member by :id (admin accounts can't be touched here)
function findMember(req, res) {
  const member = store.users.find((u) => u.id === Number(req.params.id) && u.role === 'member');
  if (!member) res.status(404).json({ message: 'Member not found' });
  return member;
}

// PATCH /api/members/:id/status   body: { isActive: true|false }
router.patch('/:id/status', requireRole('admin'), (req, res) => {
  const member = findMember(req, res);
  if (!member) return;
  if (typeof req.body.isActive !== 'boolean') return res.status(400).json({ message: 'isActive must be true or false' });
  member.isActive = req.body.isActive;
  res.json({ member: store.publicUser(member) });
});

// DELETE /api/members/:id  (also removes their bookings and payments)
router.delete('/:id', requireRole('admin'), (req, res) => {
  const member = findMember(req, res);
  if (!member) return;
  store.users.splice(store.users.indexOf(member), 1);
  store.bookings = store.bookings.filter((b) => b.userId !== member.id);
  store.payments = store.payments.filter((p) => p.userId !== member.id);
  res.json({ message: 'Member deleted' });
});

// POST /api/members/:id/payments  body: { amount, method }
// Records a payment and renews the member's current plan.
router.post(
  '/:id/payments',
  requireRole('admin'),
  validate({
    amount: all(check.required('Amount'), check.positiveNumber('Amount')),
    method: check.oneOf('Method', ['Cash', 'Transfer', 'POS']),
  }),
  (req, res) => {
    const member = findMember(req, res);
    if (!member) return;
    const plan = store.plans.find((p) => p.id === member.planId);

    // Renew from today if already expired, otherwise extend the current expiry date
    const base = Math.max(Date.now(), new Date(member.expiryDate || 0).getTime());
    member.expiryDate = new Date(base + (plan ? plan.durationDays : 30) * DAY).toISOString();

    const payment = { id: store.nextId(), userId: member.id, amount: Number(req.body.amount), description: `${plan ? plan.name : 'Membership'} renewal`, method: req.body.method, date: new Date().toISOString() };
    store.payments.push(payment);
    res.status(201).json({ payment, member: store.publicUser(member) });
  }
);

module.exports = router;
