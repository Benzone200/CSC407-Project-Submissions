/**
 * Gym class routes. Logged-in users can view; only admins can change.
 */
const express = require('express');
const store = require('../data/store');
const { authenticate } = require('../middleware/auth');
const { requireRole } = require('../middleware/roleCheck');
const { validate, check, all } = require('../middleware/validate');

const router = express.Router();
router.use(authenticate);

// Add booking info to a class so the UI can show "Class full" etc.
function describe(cls, userId) {
  const bookings = store.bookings.filter((b) => b.classId === cls.id);
  const mine = bookings.find((b) => b.userId === userId);
  return { ...cls, bookedCount: bookings.length, isFull: bookings.length >= cls.capacity, myBookingId: mine ? mine.id : null };
}

const classRules = {
  name: all(check.required('Class name'), check.length('Class name', 2, 60)),
  trainer: all(check.required('Trainer'), check.length('Trainer', 2, 60)),
  schedule: all(check.required('Schedule'), check.validDate('Schedule')),
  capacity: all(check.required('Capacity'), check.positiveInt('Capacity', 200)),
};

// GET /api/classes
router.get('/', (req, res) => {
  const list = store.classes.slice().sort((a, b) => new Date(a.schedule) - new Date(b.schedule));
  res.json({ classes: list.map((c) => describe(c, req.user.id)) });
});

// POST /api/classes  (admin)
router.post('/', requireRole('admin'), validate(classRules), (req, res) => {
  const cls = { id: store.nextId(), name: req.body.name, trainer: req.body.trainer, schedule: new Date(req.body.schedule).toISOString(), capacity: Number(req.body.capacity) };
  store.classes.push(cls);
  res.status(201).json({ class: describe(cls, req.user.id) });
});

// PUT /api/classes/:id  (admin)
router.put('/:id', requireRole('admin'), validate(classRules), (req, res) => {
  const cls = store.classes.find((c) => c.id === Number(req.params.id));
  if (!cls) return res.status(404).json({ message: 'Class not found' });
  Object.assign(cls, { name: req.body.name, trainer: req.body.trainer, schedule: new Date(req.body.schedule).toISOString(), capacity: Number(req.body.capacity) });
  res.json({ class: describe(cls, req.user.id) });
});

// DELETE /api/classes/:id  (admin) - also removes its bookings
router.delete('/:id', requireRole('admin'), (req, res) => {
  const cls = store.classes.find((c) => c.id === Number(req.params.id));
  if (!cls) return res.status(404).json({ message: 'Class not found' });
  store.classes.splice(store.classes.indexOf(cls), 1);
  store.bookings = store.bookings.filter((b) => b.classId !== cls.id);
  res.json({ message: 'Class deleted' });
});

module.exports = router;
