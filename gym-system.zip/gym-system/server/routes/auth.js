/**
 * Auth routes: register, login, and "who am I".
 */
const express = require('express');
const bcrypt = require('bcryptjs');
const store = require('../data/store');
const { authenticate, signToken } = require('../middleware/auth');
const { validate, check, all } = require('../middleware/validate');

const router = express.Router();
const DAY = 24 * 60 * 60 * 1000;

// POST /api/auth/register  (public)
router.post(
  '/register',
  validate({
    fullName: all(check.required('Full name'), check.length('Full name', 2, 60)),
    email: all(check.required('Email'), check.email()),
    phone: all(check.required('Phone'), check.phone()),
    password: all(check.required('Password'), check.password()),
    confirmPassword: check.matches('password', 'Passwords do not match'),
    planId: check.required('Plan'),
  }),
  async (req, res) => {
    const { fullName, email, phone, password, planId } = req.body;

    const plan = store.plans.find((p) => p.id === Number(planId));
    if (!plan) return res.status(400).json({ message: 'Please fix the highlighted fields', errors: { planId: 'Choose a valid plan' } });

    // Duplicate email check (case-insensitive)
    if (store.users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
      return res.status(409).json({ message: 'Email already exists', errors: { email: 'Email already exists' } });
    }

    const passwordHash = await bcrypt.hash(password, 10); // hash, never store plain text
    const now = new Date();
    const user = {
      id: store.nextId(),
      fullName,
      email: email.toLowerCase(),
      phone,
      passwordHash,
      role: 'member', // public registration can ONLY create members
      planId: plan.id,
      startDate: now.toISOString(),
      expiryDate: new Date(now.getTime() + plan.durationDays * DAY).toISOString(),
      isActive: true,
      createdAt: now.toISOString(),
    };
    store.users.push(user);

    // Simulated payment record (no real payment gateway in this project)
    store.payments.push({ id: store.nextId(), userId: user.id, amount: plan.price, description: `${plan.name} plan (sign-up)`, method: 'Simulated', date: now.toISOString() });

    res.status(201).json({ token: signToken(user), user: store.publicUser(user) });
  }
);

// POST /api/auth/login  (public)
router.post(
  '/login',
  validate({ email: check.required('Email'), password: check.required('Password') }),
  async (req, res) => {
    const { email, password } = req.body;
    const user = store.users.find((u) => u.email.toLowerCase() === String(email).toLowerCase());

    // Same message for "no such user" and "wrong password" so attackers can't tell which emails exist
    const ok = user && (await bcrypt.compare(password, user.passwordHash));
    if (!ok) return res.status(401).json({ message: 'Invalid email or password' });

    res.json({ token: signToken(user), user: store.publicUser(user) });
  }
);

// GET /api/auth/me  (any logged-in user)
router.get('/me', authenticate, (req, res) => {
  res.json({ user: store.publicUser(req.user) });
});

module.exports = router;
