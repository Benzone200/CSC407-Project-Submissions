/**
 * Gym Membership Management System - API server
 * Run with:  npm start
 */
require('dotenv').config(); // loads values from .env into process.env

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const store = require('./data/store');
const { sanitizeBody } = require('./middleware/validate');
const rateLimit = require('./middleware/rateLimit');

store.seed(); // fill the in-memory arrays with sample data

const app = express();
const PORT = process.env.PORT || 5000;

if (!process.env.JWT_SECRET) {
  console.warn('WARNING: JWT_SECRET is not set. Using an insecure dev secret. Copy .env.example to .env!');
}

// ---- Security middleware ----
app.use(helmet()); // sets safe HTTP headers (X-Content-Type-Options, etc.)
app.use(
  cors({
    // Only the frontend origin(s) listed in CLIENT_URL may call this API
    origin: (process.env.CLIENT_URL || 'http://localhost:5173').split(',').map((s) => s.trim()),
  })
);
app.set('trust proxy', 1); // correct client IP behind Render/Railway proxies
app.use(express.json({ limit: '10kb' })); // reject huge request bodies
app.use(sanitizeBody); // strip HTML from every incoming string

// ---- Routes ----
app.get('/api/health', (req, res) => res.json({ status: 'ok' }));
app.use('/api/auth/login', rateLimit({ max: 30 }));
app.use('/api/auth/register', rateLimit({ max: 30 }));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/members', require('./routes/members'));
app.use('/api/plans', require('./routes/plans'));
app.use('/api/classes', require('./routes/classes'));
app.use('/api/bookings', require('./routes/bookings'));

// ---- 404 + error handling ----
app.use((req, res) => res.status(404).json({ message: 'Route not found' }));
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  if (err.type === 'entity.parse.failed') return res.status(400).json({ message: 'Invalid JSON body' });
  console.error(err);
  res.status(500).json({ message: 'Something went wrong on the server' }); // never leak stack traces
});

app.listen(PORT, () => console.log(`Gym API running on http://localhost:${PORT}`));
