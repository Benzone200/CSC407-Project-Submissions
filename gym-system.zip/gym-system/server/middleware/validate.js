/**
 * Input validation + sanitisation helpers.
 * Rule: never trust anything that comes from the client.
 */

// ---------- Sanitisation (XSS protection on the server) ----------
// Removes HTML tags and stray < > characters, then trims whitespace.
// "<script>alert(1)</script>Bob"  ->  "alert(1)Bob"  (no executable markup)
function sanitizeString(value) {
  return value.replace(/<[^>]*>/g, '').replace(/[<>]/g, '').trim();
}

// Passwords must be left untouched (we hash them, never display them).
const SKIP_FIELDS = ['password', 'confirmPassword', 'currentPassword', 'newPassword'];

function sanitizeBody(req, res, next) {
  if (req.body && typeof req.body === 'object') {
    for (const key of Object.keys(req.body)) {
      if (typeof req.body[key] === 'string' && !SKIP_FIELDS.includes(key)) {
        req.body[key] = sanitizeString(req.body[key]);
      }
    }
  }
  next();
}

// ---------- Individual checks: each returns an error message or null ----------
const check = {
  required: (label) => (v) => (v === undefined || v === null || String(v).trim() === '' ? `${label} is required` : null),

  length: (label, min, max) => (v) =>
    typeof v === 'string' && (v.trim().length < min || v.trim().length > max)
      ? `${label} must be ${min}-${max} characters`
      : null,

  email: () => (v) => (typeof v === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? null : 'Enter a valid email address'),

  phone: () => (v) => (typeof v === 'string' && /^\+?[0-9\s-]{7,15}$/.test(v) ? null : 'Enter a valid phone number (7-15 digits)'),

  // At least 8 chars, 1 uppercase, 1 lowercase, 1 number
  password: () => (v) => {
    if (typeof v !== 'string' || v.length < 8) return 'Password must be at least 8 characters';
    if (!/[A-Z]/.test(v)) return 'Password needs an uppercase letter';
    if (!/[a-z]/.test(v)) return 'Password needs a lowercase letter';
    if (!/[0-9]/.test(v)) return 'Password needs a number';
    return null;
  },

  matches: (otherField, message) => (v, body) => (v === body[otherField] ? null : message),

  positiveNumber: (label, max = 10000000) => (v) => {
    const n = Number(v);
    if (v === '' || v === null || v === undefined || Number.isNaN(n) || !Number.isFinite(n)) return `${label} must be a number`;
    if (n <= 0) return `${label} must be greater than 0`;
    if (n > max) return `${label} is too large`;
    return null;
  },

  positiveInt: (label, max = 1000) => (v) => {
    const n = Number(v);
    return Number.isInteger(n) && n >= 1 && n <= max ? null : `${label} must be a whole number between 1 and ${max}`;
  },

  validDate: (label) => (v) => (typeof v === 'string' && !Number.isNaN(Date.parse(v)) ? null : `${label} must be a valid date`),

  oneOf: (label, options) => (v) => (options.includes(v) ? null : `${label} must be one of: ${options.join(', ')}`),
};

// Run several checks on one field; stop at the first error.
const all = (...checks) => (v, body) => {
  for (const fn of checks) {
    const err = fn(v, body);
    if (err) return err;
  }
  return null;
};

/**
 * validate({ fieldName: checkFn, ... }) -> Express middleware.
 * Responds 400 with { message, errors: { field: "message" } } on failure.
 */
function validate(schema) {
  return (req, res, next) => {
    const errors = {};
    for (const [field, fn] of Object.entries(schema)) {
      const err = fn(req.body ? req.body[field] : undefined, req.body || {});
      if (err) errors[field] = err;
    }
    if (Object.keys(errors).length > 0) {
      return res.status(400).json({ message: 'Please fix the highlighted fields', errors });
    }
    next();
  };
}

module.exports = { validate, sanitizeBody, sanitizeString, check, all };
