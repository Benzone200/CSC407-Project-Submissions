/**
 * Role-based access control (RBAC).
 * Use AFTER authenticate:  router.get('/', authenticate, requireRole('admin'), handler)
 */
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Access denied. You do not have permission.' });
    }
    next();
  };
}

module.exports = { requireRole };
