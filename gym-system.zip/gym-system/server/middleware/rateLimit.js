/**
 * Tiny in-memory rate limiter (protects login/register from brute force).
 * Allows `max` requests per IP in each `windowMs` window.
 */
function rateLimit({ windowMs = 15 * 60 * 1000, max = 30 } = {}) {
  const hits = new Map(); // ip -> { count, resetAt }

  return (req, res, next) => {
    const now = Date.now();
    const entry = hits.get(req.ip);

    if (!entry || entry.resetAt < now) {
      hits.set(req.ip, { count: 1, resetAt: now + windowMs });
      return next();
    }
    entry.count += 1;
    if (entry.count > max) {
      return res.status(429).json({ message: 'Too many attempts. Please try again later.' });
    }
    next();
  };
}

module.exports = rateLimit;
