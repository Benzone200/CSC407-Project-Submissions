/**
 * Authentication middleware.
 * Reads "Authorization: Bearer <token>", verifies the JWT and attaches the
 * matching user to req.user. The user is looked up in the store on every
 * request, so a deleted account loses access immediately.
 */
const jwt = require('jsonwebtoken');
const store = require('../data/store');

function getSecret() {
  return process.env.JWT_SECRET || 'dev-only-secret-change-me';
}

function signToken(user) {
  return jwt.sign({ id: user.id, role: user.role }, getSecret(), {
    expiresIn: process.env.JWT_EXPIRES_IN || '2h', // token expiry
  });
}

function authenticate(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ message: 'Authentication required. Please log in.' });
  }

  try {
    const payload = jwt.verify(token, getSecret());
    const user = store.users.find((u) => u.id === payload.id);
    if (!user) return res.status(401).json({ message: 'Account no longer exists.' });
    req.user = user;
    next();
  } catch (err) {
    const message = err.name === 'TokenExpiredError' ? 'Session expired. Please log in again.' : 'Invalid token.';
    return res.status(401).json({ message });
  }
}

module.exports = { authenticate, signToken };
