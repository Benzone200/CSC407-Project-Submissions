# Review and Evaluation

## What the application does
IronPulse is a gym membership management web app. Visitors can view plans and register. **Members** log in to see their membership status, book and cancel classes, view payments and edit their profile. **Admins** manage members, plans, classes and bookings and see dashboard statistics.

## Features implemented
- Landing page with hero, services and live membership plans (Monthly, Quarterly, Annual)
- Registration with inline validation, and login with role-based redirect
- Security page explaining every protection in the app
- Member: dashboard (status, plan, expiry, payment summary), profile edit and password change, class booking with "Class full" handling, payment history
- Admin: dashboard stats, member table with search/filter, activate/deactivate/delete, record payment (renews membership), plan editing, class create/edit/delete, all-bookings view
- Reusable components (Button, Input, Card, Table, Modal, Alert), loading/error/success states
- Responsive layout (mobile menu, scrollable tables) with a dark gym theme

## Security measures
JWT authentication with 2-hour expiry · bcrypt password hashing · role-based access control middleware ·
members restricted to their own data · server-side validation (email, required fields, password strength, numbers, dates) ·
HTML-stripping sanitisation plus React's default escaping · token cleared on logout and on expiry ·
authentication check on every protected endpoint · secrets in `.env` (`.env.example` provided) ·
CORS limited to the frontend origin · Helmet headers · request size limit · login/register rate limiting ·
HTTPS provided by the hosting platform.

## Testing results
28 manual test cases are listed in `TESTING.md`, covering functional, login/registration, validation, security, usability, responsive and error-handling areas.
**Summary:** _X of 28 passed (fill in after running the tests)._ Note any failures and what you changed to fix them here.

## Limitations
- Data is in memory, so it resets every time the server restarts
- No real payments (payments are simulated or recorded manually by the admin)
- No email verification or password reset
- Tokens are stored in `localStorage` (simple, but more exposed to XSS than httpOnly cookies)
- Rate limiter and sessions are per server instance only
- Only manual testing; no automated test suite

## Future improvements
- Real database (e.g. PostgreSQL or MongoDB) with migrations
- Payment gateway integration (Paystack / Stripe)
- SMS or email reminders for expiring memberships and upcoming classes
- QR-code check-in at the gym door
- httpOnly cookie sessions with refresh tokens
- Automated tests (Jest / Supertest / Playwright) and CI
