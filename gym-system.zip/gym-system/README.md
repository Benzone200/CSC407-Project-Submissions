# IronPulse – Gym Membership Management System

Semi-project: **Building Web Applications: Web Application Security, Testing, Deployment and Review**

A full-stack gym app with two roles (Admin and Member).

- **Frontend:** React (Vite) + Tailwind CSS + React Router (`client/`)
- **Backend:** Node.js + Express (`server/`)
- **Data:** in-memory JavaScript arrays, seeded on every server start (no database)
- **Security:** JWT, bcrypt password hashing, role-based access control, server-side validation and sanitisation, CORS, Helmet, rate limiting

## Folder structure

```
gym-system/
├── README.md  TESTING.md  DEPLOYMENT.md  REVIEW.md
├── server/
│   ├── server.js              # app entry: middleware + routes
│   ├── .env.example
│   ├── data/store.js          # in-memory data + seed data
│   ├── middleware/            # auth.js, roleCheck.js, validate.js, rateLimit.js
│   └── routes/                # auth.js, members.js, plans.js, classes.js, bookings.js
└── client/
    ├── index.html  vite.config.js  tailwind.config.js
    ├── .env.example
    └── src/
        ├── main.jsx  App.jsx  index.css  utils.js
        ├── api/api.js         # fetch helper (adds JWT)
        ├── context/AuthContext.jsx
        ├── hooks/useFetch.js
        ├── components/        # Button, Input, Card, Table, Modal, Alert, Spinner,
        │                      # StatusBadge, Navbar, DashboardLayout, ProtectedRoute
        └── pages/
            ├── Home, Login, Register, Security
            ├── member/        # MemberDashboard, Profile, ClassBooking, PaymentHistory
            └── admin/         # AdminDashboard, ManageMembers, ManagePlans,
                               # ManageClasses, ManageBookings
```

## Run locally

You need **Node.js 18+**. Open two terminals.

**Terminal 1 – backend**
```bash
cd server
npm install
cp .env.example .env      # Windows: copy .env.example .env
npm start                 # API on http://localhost:5000
```

**Terminal 2 – frontend**
```bash
cd client
npm install
npm run dev               # App on http://localhost:5173
```

Open http://localhost:5173. The frontend talks to `http://localhost:5000/api` by default.
To change that, copy `client/.env.example` to `client/.env` and edit `VITE_API_URL`.

## Seed accounts (created on every server start)

| Role   | Email                | Password     | Notes                               |
|--------|----------------------|--------------|-------------------------------------|
| Admin  | admin@gym.com        | Admin123!    | Full admin access                   |
| Member | chidi@example.com    | Member123!   | Active, Monthly plan                |
| Member | ngozi@example.com    | Member123!   | Active, Quarterly plan              |
| Member | tunde@example.com    | Member123!   | **Expired** membership (for testing)|

Seeded extras: 3 plans (Monthly ₦15,000 / Quarterly ₦40,000 / Annual ₦140,000), 3 classes,
and payment history. "Morning Yoga Flow" starts **full** (capacity 2) so you can test "Class full"
by logging in as Chidi.

## API summary

| Method | Endpoint | Access |
|--------|----------|--------|
| POST | `/api/auth/register`, `/api/auth/login` | Public |
| GET | `/api/auth/me` | Logged in |
| GET | `/api/plans` | Public |
| PUT | `/api/plans/:id` | Admin |
| GET | `/api/classes` | Logged in |
| POST / PUT / DELETE | `/api/classes`, `/api/classes/:id` | Admin |
| GET / PUT | `/api/members/me`, PUT `/api/members/me/password`, GET `/api/members/me/payments` | Logged in (own data) |
| GET | `/api/members`, `/api/members/stats` | Admin |
| PATCH / DELETE | `/api/members/:id/status`, `/api/members/:id` | Admin |
| POST | `/api/members/:id/payments` | Admin |
| GET | `/api/bookings` | Admin |
| GET | `/api/bookings/mine`, POST `/api/bookings` | Member |
| DELETE | `/api/bookings/:id` | Owner or Admin |

## Notes

- Data resets whenever the server restarts (by design: no database).
- The project uses `bcryptjs` (pure JavaScript, same API as `bcrypt`) so installation never needs a C++ compiler.
