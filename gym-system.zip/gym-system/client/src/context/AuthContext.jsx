import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { api } from '../api/api.js';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // true while we check a saved token

  const logout = useCallback(() => {
    localStorage.removeItem('token'); // logout clears the token on the client
    setUser(null);
  }, []);

  // On page load: if a token is saved, ask the server who we are
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) { setLoading(false); return; }
    api('/auth/me')
      .then((d) => setUser(d.user))
      .catch(() => localStorage.removeItem('token'))
      .finally(() => setLoading(false));
  }, []);

  // api.js fires this event when the server says the token is expired
  useEffect(() => {
    window.addEventListener('auth:expired', logout);
    return () => window.removeEventListener('auth:expired', logout);
  }, [logout]);

  const saveSession = (data) => {
    localStorage.setItem('token', data.token);
    setUser(data.user);
    return data.user;
  };

  const login = async (email, password) => saveSession(await api('/auth/login', { method: 'POST', body: { email, password } }));
  const register = async (form) => saveSession(await api('/auth/register', { method: 'POST', body: form }));
  const refreshUser = async () => setUser((await api('/auth/me')).user);

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, refreshUser, setUser }}>
      {children}
    </AuthContext.Provider>
  );
}
