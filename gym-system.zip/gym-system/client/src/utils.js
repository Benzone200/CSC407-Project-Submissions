export const formatMoney = (n) => `₦${Number(n || 0).toLocaleString('en-NG')}`;
export const formatDate = (iso) => (iso ? new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—');
export const formatDateTime = (iso) => (iso ? new Date(iso).toLocaleString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—');
// ISO string -> value for <input type="datetime-local">
export const toLocalInput = (iso) => {
  if (!iso) return '';
  const d = new Date(iso);
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 16);
};
export const daysLeft = (iso) => Math.ceil((new Date(iso) - new Date()) / 86400000);
