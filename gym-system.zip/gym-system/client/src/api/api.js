// One place for all backend calls. Adds the JWT token automatically.
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export async function api(path, { method = 'GET', body } = {}) {
  const token = localStorage.getItem('token');
  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }

  if (!res.ok) {
    // Token expired / invalid -> tell AuthContext to log the user out
    if (res.status === 401 && token) window.dispatchEvent(new Event('auth:expired'));
    const err = new Error(data?.message || 'Request failed');
    err.status = res.status;
    err.fieldErrors = data?.errors || {};
    throw err;
  }
  return data;
}
