import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import useFetch from '../hooks/useFetch.js';
import Input, { Select } from '../components/Input.jsx';
import Button from '../components/Button.jsx';
import Alert from '../components/Alert.jsx';
import { formatMoney } from '../utils.js';

// Client-side checks give instant feedback. The server repeats them (never trust the client).
function validate(f) {
  const e = {};
  if (f.fullName.trim().length < 2) e.fullName = 'Enter your full name';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email)) e.email = 'Enter a valid email address';
  if (!/^\+?[0-9\s-]{7,15}$/.test(f.phone)) e.phone = 'Enter a valid phone number (7-15 digits)';
  if (f.password.length < 8) e.password = 'Password must be at least 8 characters';
  else if (!/[A-Z]/.test(f.password) || !/[a-z]/.test(f.password) || !/[0-9]/.test(f.password)) e.password = 'Use upper-case, lower-case and a number';
  if (f.confirmPassword !== f.password) e.confirmPassword = 'Passwords do not match';
  if (!f.planId) e.planId = 'Choose a plan';
  return e;
}

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const { data } = useFetch('/plans');
  const [form, setForm] = useState({ fullName: '', email: '', phone: '', password: '', confirmPassword: '', planId: params.get('plan') || '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  const onChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    if (errors[e.target.name]) setErrors({ ...errors, [e.target.name]: undefined }); // clear error while typing
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setServerError('');
    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length) return;

    setLoading(true);
    try {
      await register(form);
      navigate('/member', { replace: true });
    } catch (err) {
      setErrors(err.fieldErrors || {});
      setServerError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="mx-auto mt-10 max-w-lg px-4">
      <form onSubmit={onSubmit} noValidate className="rounded-lg border border-zinc-800 bg-zinc-900 p-6">
        <h1 className="mb-1 text-4xl font-bold">Join IronPulse</h1>
        <p className="mb-5 text-sm text-zinc-400">Create your account and pick a plan.</p>
        <Alert type="error">{serverError}</Alert>
        <div className="space-y-4">
          <Input label="Full name" name="fullName" value={form.fullName} onChange={onChange} error={errors.fullName} autoComplete="name" />
          <Input label="Email" name="email" type="email" value={form.email} onChange={onChange} error={errors.email} autoComplete="email" />
          <Input label="Phone" name="phone" type="tel" value={form.phone} onChange={onChange} error={errors.phone} autoComplete="tel" />
          <Select label="Membership plan" name="planId" value={form.planId} onChange={onChange} error={errors.planId}>
            <option value="">Choose a plan…</option>
            {data?.plans.map((p) => <option key={p.id} value={p.id}>{p.name} – {formatMoney(p.price)}</option>)}
          </Select>
          <Input label="Password" name="password" type="password" value={form.password} onChange={onChange} error={errors.password} autoComplete="new-password" />
          <Input label="Confirm password" name="confirmPassword" type="password" value={form.confirmPassword} onChange={onChange} error={errors.confirmPassword} autoComplete="new-password" />
        </div>
        <Button type="submit" loading={loading} className="mt-6 w-full">Create account</Button>
        <p className="mt-4 text-center text-sm text-zinc-400">Already a member? <Link to="/login" className="text-orange-400 underline">Log in</Link></p>
      </form>
    </main>
  );
}
