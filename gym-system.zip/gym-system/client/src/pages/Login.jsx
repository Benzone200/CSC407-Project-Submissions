import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Input from '../components/Input.jsx';
import Button from '../components/Button.jsx';
import Alert from '../components/Alert.jsx';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!form.email || !form.password) return setError('Enter your email and password.');
    setLoading(true);
    try {
      const user = await login(form.email, form.password);
      // Redirect by role (or back to the page they tried to open)
      const fallback = user.role === 'admin' ? '/admin' : '/member';
      navigate(location.state?.from?.pathname || fallback, { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="mx-auto mt-12 max-w-md px-4">
      <form onSubmit={onSubmit} className="rounded-lg border border-zinc-800 bg-zinc-900 p-6" noValidate>
        <h1 className="mb-1 text-4xl font-bold">Log in</h1>
        <p className="mb-5 text-sm text-zinc-400">Welcome back. Let's get to work.</p>
        <Alert type="error">{error}</Alert>
        <Input label="Email" name="email" type="email" autoComplete="email" value={form.email} onChange={onChange} className="mb-4" />
        <Input label="Password" name="password" type="password" autoComplete="current-password" value={form.password} onChange={onChange} className="mb-5" />
        <Button type="submit" loading={loading} className="w-full">Log in</Button>
        <p className="mt-4 text-center text-sm text-zinc-400">New here? <Link to="/register" className="text-orange-400 underline">Create an account</Link></p>
      </form>
    </main>
  );
}
