import { useState } from 'react';
import useFetch from '../../hooks/useFetch.js';
import { api } from '../../api/api.js';
import Card from '../../components/Card.jsx';
import Button from '../../components/Button.jsx';
import Alert from '../../components/Alert.jsx';
import Spinner from '../../components/Spinner.jsx';
import { formatDateTime } from '../../utils.js';

export default function ClassBooking() {
  const { data, loading, error, reload } = useFetch('/classes');
  const [msg, setMsg] = useState({ type: '', text: '' });
  const [busyId, setBusyId] = useState(null);

  const act = async (cls) => {
    setBusyId(cls.id); setMsg({ type: '', text: '' });
    try {
      if (cls.myBookingId) {
        await api(`/bookings/${cls.myBookingId}`, { method: 'DELETE' });
        setMsg({ type: 'success', text: `Booking for ${cls.name} cancelled.` });
      } else {
        await api('/bookings', { method: 'POST', body: { classId: cls.id } });
        setMsg({ type: 'success', text: `You're booked into ${cls.name}.` });
      }
    } catch (err) {
      setMsg({ type: 'error', text: err.message }); // e.g. "Class full"
    } finally {
      setBusyId(null);
      reload(); // refresh spots left
    }
  };

  if (loading && !data) return <Spinner />;
  return (
    <div>
      <h1 className="text-4xl font-bold">Book a class</h1>
      <p className="mb-6 text-zinc-400">Pick a session. You can cancel any time.</p>
      <Alert type="error">{error}</Alert>
      <Alert type={msg.type || 'info'} onClose={() => setMsg({ type: '', text: '' })}>{msg.text}</Alert>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {data?.classes.map((c) => {
          const full = c.isFull && !c.myBookingId;
          return (
            <Card key={c.id}>
              <h2 className="text-2xl font-bold">{c.name}</h2>
              <p className="text-sm text-zinc-400">with {c.trainer}</p>
              <p className="mt-3 text-sm">{formatDateTime(c.schedule)}</p>
              <p className="mt-1 text-sm text-zinc-400">{c.bookedCount}/{c.capacity} spots taken</p>
              <div className="mt-4">
                {full ? (
                  <span className="inline-block rounded-md bg-red-500/15 px-3 py-2 text-sm font-medium text-red-300">Class full</span>
                ) : (
                  <Button variant={c.myBookingId ? 'secondary' : 'primary'} loading={busyId === c.id} onClick={() => act(c)}>
                    {c.myBookingId ? 'Cancel booking' : 'Book class'}
                  </Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>
      {data?.classes.length === 0 && <p className="text-zinc-500">No classes scheduled yet.</p>}
    </div>
  );
}
