import useFetch from '../../hooks/useFetch.js';
import Card from '../../components/Card.jsx';
import Table from '../../components/Table.jsx';
import Alert from '../../components/Alert.jsx';
import Spinner from '../../components/Spinner.jsx';
import { formatDate, formatMoney } from '../../utils.js';

export default function PaymentHistory() {
  const { data, loading, error } = useFetch('/members/me/payments');
  const columns = [
    { header: 'Date', render: (p) => formatDate(p.date) },
    { header: 'Description', key: 'description' },
    { header: 'Method', key: 'method' },
    { header: 'Amount', render: (p) => formatMoney(p.amount) },
  ];
  return (
    <div>
      <h1 className="mb-6 text-4xl font-bold">Payment history</h1>
      <Alert type="error">{error}</Alert>
      <Card>{loading ? <Spinner /> : <Table columns={columns} rows={data?.payments} empty="No payments yet." />}</Card>
    </div>
  );
}
