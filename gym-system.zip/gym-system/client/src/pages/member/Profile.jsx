import { useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { api } from '../../api/api.js';
import Card from '../../components/Card.jsx';
import Input from '../../components/Input.jsx';
import Button from '../../components/Button.jsx';
import Alert from '../../components/Alert.jsx';

export default function Profile() {
  const { user, setUser } = useAuth();
  const [info, setInfo] = useState({ fullName: user.fullName, phone: user.phone });
  const [infoErrors, setInfoErrors] = useState({});
  const [infoMsg, setInfoMsg] = useState({ type: '', text: '' });
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [pwErrors, setPwErrors] = useState({});
  const [pwMsg, setPwMsg] = useState({ type: '', text: '' });
  const [busy, setBusy] = useState('');

  const saveInfo = async (e) => {
    e.preventDefault();
    setBusy('info'); setInfoErrors({}); setInfoMsg({ type: '', text: '' });
    try {
      const d = await api('/members/me', { method: 'PUT', body: info });
      setUser(d.user);
      setInfo({ fullName: d.user.fullName, phone: d.user.phone }); // show the sanitised value
      setInfoMsg({ type: 'success', text: 'Profile updated.' });
    } catch (err) {
      setInfoErrors(err.fieldErrors); setInfoMsg({ type: 'error', text: err.message });
    } finally { setBusy(''); }
  };

  const changePassword = async (e) => {
    e.preventDefault();
    setBusy('pw'); setPwErrors({}); setPwMsg({ type: '', text: '' });
    try {
      await api('/members/me/password', { method: 'PUT', body: pw });
      setPw({ currentPassword: '', newPassword: '', confirmPassword: '' });
      setPwMsg({ type: 'success', text: 'Password changed.' });
    } catch (err) {
      setPwErrors(err.fieldErrors); setPwMsg({ type: 'error', text: err.message });
    } finally { setBusy(''); }
  };

  return (
    <div className="max-w-xl space-y-6">
      <h1 className="text-4xl font-bold">My profile</h1>

      <Card title="Personal details">
        <form onSubmit={saveInfo} className="space-y-4" noValidate>
          <Alert type={infoMsg.type || 'info'}>{infoMsg.text}</Alert>
          <Input label="Full name" name="fullName" value={info.fullName} onChange={(e) => setInfo({ ...info, fullName: e.target.value })} error={infoErrors.fullName} />
          <Input label="Phone" name="phone" value={info.phone} onChange={(e) => setInfo({ ...info, phone: e.target.value })} error={infoErrors.phone} />
          <Input label="Email (cannot be changed)" value={user.email} disabled />
          <Button type="submit" loading={busy === 'info'}>Save changes</Button>
        </form>
      </Card>

      <Card title="Change password">
        <form onSubmit={changePassword} className="space-y-4" noValidate>
          <Alert type={pwMsg.type || 'info'}>{pwMsg.text}</Alert>
          <Input label="Current password" name="currentPassword" type="password" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} error={pwErrors.currentPassword} autoComplete="current-password" />
          <Input label="New password" name="newPassword" type="password" value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} error={pwErrors.newPassword} autoComplete="new-password" />
          <Input label="Confirm new password" name="confirmPassword" type="password" value={pw.confirmPassword} onChange={(e) => setPw({ ...pw, confirmPassword: e.target.value })} error={pwErrors.confirmPassword} autoComplete="new-password" />
          <Button type="submit" loading={busy === 'pw'}>Change password</Button>
        </form>
      </Card>
    </div>
  );
}
