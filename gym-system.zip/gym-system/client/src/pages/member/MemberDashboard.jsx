import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import useFetch from '../../hooks/useFetch.js';
import Card from '../../components/Card.jsx';
import Alert from '../../components/Alert.jsx';
import Spinner from '../../components/Spinner.jsx';
import StatusBadge from '../../components/StatusBadge.jsx';
import { formatDate, formatMoney, daysLeft } from '../../utils.js';

export default function MemberDashboard() {
  const { user } = useAuth();
  const { data, loading, error } = useFetch('/members/me/payments');

  if (loading) return <Spinner />;
  const payments = data?.payments || [];
  const total = payments.reduce((sum, p) => sum + p.amount, 0);
  const remaining = daysLeft(user.expiryDate);

  return (
    <div>
      <h1 className="text-4xl font-bold">Hi, {user.fullName}</h1>
      <p className="mb-6 text-zinc-400">Here's your membership at a glance.</p>
      <Alert type="error">{error}</Alert>
      {user.status === 'expired' && <Alert type="error">Your membership has expired. Visit the front desk to renew it.</Alert>}
      {user.status === 'inactive' && <Alert type="error">Your account is deactivated. Contact the gym admin.</Alert>}

      <div className="grid gap-4 md:grid-cols-3">
        <Card title="Status"><StatusBadge status={user.status} /></Card>
        <Card title="Plan"><p className="text-2xl font-bold">{user.planName || '—'}</p></Card>
        <Card title="Expires">
          <p className="text-2xl font-bold">{formatDate(user.expiryDate)}</p>
          <p className="text-sm text-zinc-400">{remaining > 0 ? `${remaining} days left` : 'Expired'}</p>
        </Card>
      </div>

      <Card title="Payment summary" className="mt-4" action={<Link to="/member/payments" className="text-sm text-orange-400 underline">View all</Link>}>
        <p className="text-zinc-300">Total paid: <strong>{formatMoney(total)}</strong> across {payments.length} payment(s).</p>
        {payments[0] && <p className="mt-1 text-sm text-zinc-400">Last payment: {formatMoney(payments[0].amount)} on {formatDate(payments[0].date)}</p>}
      </Card>
    </div>
  );
}
