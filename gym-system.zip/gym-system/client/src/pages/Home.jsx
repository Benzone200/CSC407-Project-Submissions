import { Link } from 'react-router-dom';
import useFetch from '../hooks/useFetch.js';
import Button from '../components/Button.jsx';
import Spinner from '../components/Spinner.jsx';
import Alert from '../components/Alert.jsx';
import { formatMoney } from '../utils.js';

const SERVICES = [
  { title: 'Strength floor', text: 'Free weights, racks and machines for every level, open 5am to 11pm.' },
  { title: 'Group classes', text: 'Yoga, cardio and weight training led by certified trainers.' },
  { title: 'Personal coaching', text: 'One-to-one programmes built around your goal and schedule.' },
  { title: 'Recovery zone', text: 'Stretch area, showers and lockers so you leave feeling fresh.' },
];

export default function Home() {
  const { data, loading, error } = useFetch('/plans');

  return (
    <main>
      {/* Hero */}
      <section className="mx-auto max-w-6xl px-4 pb-10 pt-16 md:pt-24">
        <h1 className="max-w-3xl text-6xl font-extrabold leading-[0.95] md:text-8xl">
          Train hard. <br />Get <span className="text-orange-500">stronger</span> every week.
        </h1>
        <p className="mt-6 max-w-xl text-lg text-zinc-400">Join IronPulse for full gym access, expert-led classes and a community that shows up. Pick a plan and start today.</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link to="/register"><Button className="px-6 py-3 text-base">Join now</Button></Link>
          <a href="#plans"><Button variant="secondary" className="px-6 py-3 text-base">See plans</Button></a>
        </div>
      </section>

      {/* Services */}
      <section className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="mb-6 text-4xl font-bold">What you get</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {SERVICES.map((s) => (
            <div key={s.title} className="rounded-lg border border-zinc-800 bg-zinc-900 p-5">
              <h3 className="text-xl font-bold text-orange-400">{s.title}</h3>
              <p className="mt-2 text-sm text-zinc-400">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Plans (loaded from the API) */}
      <section id="plans" className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="mb-6 text-4xl font-bold">Membership plans</h2>
        {loading && <Spinner />}
        <Alert type="error">{error}</Alert>
        <div className="grid gap-4 md:grid-cols-3">
          {data?.plans.map((p) => (
            <div key={p.id} className="flex flex-col rounded-lg border border-zinc-800 bg-zinc-900 p-6">
              <h3 className="text-2xl font-bold">{p.name}</h3>
              <p className="mt-3 font-display text-5xl font-extrabold text-orange-500">{formatMoney(p.price)}</p>
              <p className="text-sm text-zinc-500">for {p.durationDays} days</p>
              <p className="mt-4 flex-1 text-sm text-zinc-400">{p.description}</p>
              <Link to={`/register?plan=${p.id}`} className="mt-6"><Button className="w-full">Join now</Button></Link>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
