import { useState } from 'react';
import useFetch from '../../hooks/useFetch.js';
import { api } from '../../api/api.js';
import Card from '../../components/Card.jsx';
import Modal from '../../components/Modal.jsx';
import Input from '../../components/Input.jsx';
import Button from '../../components/Button.jsx';
import Alert from '../../components/Alert.jsx';
import Spinner from '../../components/Spinner.jsx';
import { formatMoney } from '../../utils.js';

export default function ManagePlans() {
  const { data, loading, error, reload } = useFetch('/plans');
  const [editing, setEditing] = useState(null); // the plan being edited (form values)
  const [errors, setErrors] = useState({});
  const [msg, setMsg] = useState({ type: '', text: '' });
  const [busy, setBusy] = useState(false);

  const save = async (e) => {
    e.preventDefault();
    setBusy(true); setErrors({});
    try {
      await api(`/plans/${editing.id}`, { method: 'PUT', body: editing });
      setMsg({ type: 'success', text: 'Plan updated.' });
      setEditing(null); reload();
    } catch (err) { setErrors(err.fieldErrors || {}); }
    finally { setBusy(false); }
  };
  const set = (k) => (e) => setEditing({ ...editing, [k]: e.target.value });

  if (loading && !data) return <Spinner />;
  return (
    <div>
      <h1 className="mb-6 text-4xl font-bold">Manage plans</h1>
      <Alert type="error">{error}</Alert>
      <Alert type={msg.type || 'info'} onClose={() => setMsg({ type: '', text: '' })}>{msg.text}</Alert>
      <div className="grid gap-4 md:grid-cols-3">
        {data?.plans.map((p) => (
          <Card key={p.id}>
            <h2 className="text-2xl font-bold">{p.name}</h2>
            <p className="mt-2 font-display text-4xl font-extrabold text-orange-500">{formatMoney(p.price)}</p>
            <p className="text-sm text-zinc-500">{p.durationDays} days</p>
            <p className="mt-3 text-sm text-zinc-400">{p.description}</p>
            <Button variant="secondary" className="mt-4" onClick={() => { setErrors({}); setEditing({ ...p }); }}>Edit plan</Button>
          </Card>
        ))}
      </div>

      <Modal open={!!editing} title="Edit plan" onClose={() => setEditing(null)}>
        {editing && (
          <form onSubmit={save} className="space-y-4" noValidate>
            <Input label="Name" value={editing.name} onChange={set('name')} error={errors.name} />
            <Input label="Price (₦)" value={editing.price} onChange={set('price')} error={errors.price} inputMode="decimal" />
            <Input label="Duration (days)" value={editing.durationDays} onChange={set('durationDays')} error={errors.durationDays} inputMode="numeric" />
            <Input label="Description" value={editing.description} onChange={set('description')} error={errors.description} />
            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={() => setEditing(null)}>Cancel</Button>
              <Button type="submit" loading={busy}>Save plan</Button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}
