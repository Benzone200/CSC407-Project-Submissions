import { useEffect, useState } from 'react';
import { api } from '../../api/api.js';
import Card from '../../components/Card.jsx';
import Table from '../../components/Table.jsx';
import Modal from '../../components/Modal.jsx';
import Input, { Select } from '../../components/Input.jsx';
import Button from '../../components/Button.jsx';
import Alert from '../../components/Alert.jsx';
import Spinner from '../../components/Spinner.jsx';
import StatusBadge from '../../components/StatusBadge.jsx';
import { formatDate } from '../../utils.js';

export default function ManageMembers() {
  const [members, setMembers] = useState([]);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState({ type: '', text: '' });
  const [toDelete, setToDelete] = useState(null);
  const [payFor, setPayFor] = useState(null);
  const [pay, setPay] = useState({ amount: '', method: 'Cash' });
  const [payErrors, setPayErrors] = useState({});
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      const q = new URLSearchParams({ search, status }).toString();
      setMembers((await api(`/members?${q}`)).members);
    } catch (err) {
      setMsg({ type: 'error', text: err.message });
    } finally { setLoading(false); }
  };

  // Re-load whenever the search/filter changes (small delay while typing)
  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
  }, [search, status]); // eslint-disable-line react-hooks/exhaustive-deps

  const toggle = async (m) => {
    try {
      await api(`/members/${m.id}/status`, { method: 'PATCH', body: { isActive: !m.isActive } });
      setMsg({ type: 'success', text: `${m.fullName} ${m.isActive ? 'deactivated' : 'activated'}.` });
      load();
    } catch (err) { setMsg({ type: 'error', text: err.message }); }
  };

  const confirmDelete = async () => {
    setBusy(true);
    try {
      await api(`/members/${toDelete.id}`, { method: 'DELETE' });
      setMsg({ type: 'success', text: `${toDelete.fullName} deleted.` });
      setToDelete(null); load();
    } catch (err) { setMsg({ type: 'error', text: err.message }); setToDelete(null); }
    finally { setBusy(false); }
  };

  const recordPayment = async (e) => {
    e.preventDefault();
    setBusy(true); setPayErrors({});
    try {
      await api(`/members/${payFor.id}/payments`, { method: 'POST', body: pay });
      setMsg({ type: 'success', text: `Payment recorded. ${payFor.fullName}'s membership was renewed.` });
      setPayFor(null); setPay({ amount: '', method: 'Cash' }); load();
    } catch (err) { setPayErrors(err.fieldErrors || {}); if (!err.fieldErrors?.amount) setMsg({ type: 'error', text: err.message }); }
    finally { setBusy(false); }
  };

  const columns = [
    { header: 'Name', render: (m) => <div><p className="font-medium">{m.fullName}</p><p className="text-xs text-zinc-500">{m.email}</p></div> },
    { header: 'Plan', render: (m) => m.planName || '—' },
    { header: 'Expires', render: (m) => formatDate(m.expiryDate) },
    { header: 'Status', render: (m) => <StatusBadge status={m.status} /> },
    { header: 'Actions', render: (m) => (
      <div className="flex flex-wrap gap-2">
        <Button variant="secondary" className="px-2 py-1" onClick={() => toggle(m)}>{m.isActive ? 'Deactivate' : 'Activate'}</Button>
        <Button variant="secondary" className="px-2 py-1" onClick={() => setPayFor(m)}>Record payment</Button>
        <Button variant="danger" className="px-2 py-1" onClick={() => setToDelete(m)}>Delete</Button>
      </div>
    ) },
  ];

  return (
    <div>
      <h1 className="mb-6 text-4xl font-bold">Manage members</h1>
      <Alert type={msg.type || 'info'} onClose={() => setMsg({ type: '', text: '' })}>{msg.text}</Alert>
      <Card>
        <div className="mb-4 grid gap-3 sm:grid-cols-2">
          <Input placeholder="Search by name or email…" aria-label="Search members" value={search} onChange={(e) => setSearch(e.target.value)} />
          <Select aria-label="Filter by status" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">All statuses</option>
            <option value="active">Active</option>
            <option value="expired">Expired</option>
            <option value="inactive">Inactive</option>
          </Select>
        </div>
        {loading ? <Spinner /> : <Table columns={columns} rows={members} empty="No members match your search." />}
      </Card>

      <Modal open={!!toDelete} title="Delete member?" onClose={() => setToDelete(null)}>
        <p className="text-sm text-zinc-300">This permanently removes <strong>{toDelete?.fullName}</strong>, their bookings and payments.</p>
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="ghost" onClick={() => setToDelete(null)}>Cancel</Button>
          <Button variant="danger" loading={busy} onClick={confirmDelete}>Delete member</Button>
        </div>
      </Modal>

      <Modal open={!!payFor} title={`Record payment${payFor ? ` – ${payFor.fullName}` : ''}`} onClose={() => setPayFor(null)}>
        <form onSubmit={recordPayment} className="space-y-4" noValidate>
          <Input label="Amount (₦)" name="amount" value={pay.amount} onChange={(e) => setPay({ ...pay, amount: e.target.value })} error={payErrors.amount} placeholder="15000" inputMode="decimal" />
          <Select label="Method" name="method" value={pay.method} onChange={(e) => setPay({ ...pay, method: e.target.value })} error={payErrors.method}>
            <option>Cash</option><option>Transfer</option><option>POS</option>
          </Select>
          <p className="text-xs text-zinc-500">Recording a payment renews the member's current plan.</p>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="ghost" onClick={() => setPayFor(null)}>Cancel</Button>
            <Button type="submit" loading={busy}>Save payment</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
