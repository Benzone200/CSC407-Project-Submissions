import useFetch from '../../hooks/useFetch.js';
import Card from '../../components/Card.jsx';
import Table from '../../components/Table.jsx';
import Alert from '../../components/Alert.jsx';
import Spinner from '../../components/Spinner.jsx';
import { formatDateTime, formatDate } from '../../utils.js';

export default function ManageBookings() {
  const { data, loading, error } = useFetch('/bookings');
  const columns = [
    { header: 'Member', render: (b) => <div><p className="font-medium">{b.memberName}</p><p className="text-xs text-zinc-500">{b.memberEmail}</p></div> },
    { header: 'Class', key: 'className' },
    { header: 'Trainer', key: 'trainer' },
    { header: 'Class time', render: (b) => formatDateTime(b.schedule) },
    { header: 'Booked on', render: (b) => formatDate(b.createdAt) },
  ];
  return (
    <div>
      <h1 className="mb-6 text-4xl font-bold">All bookings</h1>
      <Alert type="error">{error}</Alert>
      <Card>{loading ? <Spinner /> : <Table columns={columns} rows={data?.bookings} empty="No bookings yet." />}</Card>
    </div>
  );
}
