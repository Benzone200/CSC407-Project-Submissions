import useFetch from '../../hooks/useFetch.js';
import Card from '../../components/Card.jsx';
import Alert from '../../components/Alert.jsx';
import Spinner from '../../components/Spinner.jsx';
import { formatMoney } from '../../utils.js';

export default function AdminDashboard() {
  const { data, loading, error } = useFetch('/members/stats');
  if (loading) return <Spinner />;

  const cards = data && [
    ['Total members', data.totalMembers],
    ['Active memberships', data.activeMemberships],
    ['Expired memberships', data.expiredMemberships],
    ['Total revenue', formatMoney(data.totalRevenue)],
    ['Upcoming classes', data.upcomingClasses],
  ];

  return (
    <div>
      <h1 className="mb-6 text-4xl font-bold">Admin dashboard</h1>
      <Alert type="error">{error}</Alert>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {cards?.map(([label, value]) => (
          <Card key={label}>
            <p className="text-sm text-zinc-400">{label}</p>
            <p className="mt-1 font-display text-5xl font-extrabold text-orange-500">{value}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}
