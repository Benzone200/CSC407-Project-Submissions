import { useState } from 'react';
import useFetch from '../../hooks/useFetch.js';
import { api } from '../../api/api.js';
import Card from '../../components/Card.jsx';
import Table from '../../components/Table.jsx';
import Modal from '../../components/Modal.jsx';
import Input from '../../components/Input.jsx';
import Button from '../../components/Button.jsx';
import Alert from '../../components/Alert.jsx';
import Spinner from '../../components/Spinner.jsx';
import { formatDateTime, toLocalInput } from '../../utils.js';

const EMPTY = { name: '', trainer: '', schedule: '', capacity: '' };

export default function ManageClasses() {
  const { data, loading, error, reload } = useFetch('/classes');
  const [form, setForm] = useState(null); // null = modal closed
  const [errors, setErrors] = useState({});
  const [toDelete, setToDelete] = useState(null);
  const [msg, setMsg] = useState({ type: '', text: '' });
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const save = async (e) => {
    e.preventDefault();
    setBusy(true); setErrors({});
    // datetime-local gives "2026-11-10T07:00" (local time) -> convert to ISO for the API
    const body = { ...form, schedule: form.schedule ? new Date(form.schedule).toISOString() : '' };
    try {
      if (form.id) await api(`/classes/${form.id}`, { method: 'PUT', body });
      else await api('/classes', { method: 'POST', body });
      setMsg({ type: 'success', text: form.id ? 'Class updated.' : 'Class created.' });
      setForm(null); reload();
    } catch (err) { setErrors(err.fieldErrors || {}); if (!Object.keys(err.fieldErrors || {}).length) setMsg({ type: 'error', text: err.message }); }
    finally { setBusy(false); }
  };

  const remove = async () => {
    setBusy(true);
    try {
      await api(`/classes/${toDelete.id}`, { method: 'DELETE' });
      setMsg({ type: 'success', text: 'Class deleted.' });
      setToDelete(null); reload();
    } catch (err) { setMsg({ type: 'error', text: err.message }); setToDelete(null); }
    finally { setBusy(false); }
  };

  const columns = [
    { header: 'Class', key: 'name' },
    { header: 'Trainer', key: 'trainer' },
    { header: 'Schedule', render: (c) => formatDateTime(c.schedule) },
    { header: 'Booked', render: (c) => `${c.bookedCount}/${c.capacity}` },
    { header: 'Actions', render: (c) => (
      <div className="flex gap-2">
        <Button variant="secondary" className="px-2 py-1" onClick={() => { setErrors({}); setForm({ ...c, schedule: toLocalInput(c.schedule) }); }}>Edit</Button>
        <Button variant="danger" className="px-2 py-1" onClick={() => setToDelete(c)}>Delete</Button>
      </div>
    ) },
  ];

  return (
    <div>
      <div className="mb-6 flex items-center justify-between gap-3">
        <h1 className="text-4xl font-bold">Manage classes</h1>
        <Button onClick={() => { setErrors({}); setForm({ ...EMPTY }); }}>New class</Button>
      </div>
      <Alert type="error">{error}</Alert>
      <Alert type={msg.type || 'info'} onClose={() => setMsg({ type: '', text: '' })}>{msg.text}</Alert>
      <Card>{loading && !data ? <Spinner /> : <Table columns={columns} rows={data?.classes} empty="No classes yet. Create the first one." />}</Card>

      <Modal open={!!form} title={form?.id ? 'Edit class' : 'New class'} onClose={() => setForm(null)}>
        {form && (
          <form onSubmit={save} className="space-y-4" noValidate>
            <Input label="Class name" value={form.name} onChange={set('name')} error={errors.name} />
            <Input label="Trainer" value={form.trainer} onChange={set('trainer')} error={errors.trainer} />
            <Input label="Date and time" type="datetime-local" value={form.schedule} onChange={set('schedule')} error={errors.schedule} />
            <Input label="Capacity" value={form.capacity} onChange={set('capacity')} error={errors.capacity} inputMode="numeric" />
            <div className="flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={() => setForm(null)}>Cancel</Button>
              <Button type="submit" loading={busy}>Save class</Button>
            </div>
          </form>
        )}
      </Modal>

      <Modal open={!!toDelete} title="Delete class?" onClose={() => setToDelete(null)}>
        <p className="text-sm text-zinc-300">Delete <strong>{toDelete?.name}</strong> and cancel all its bookings?</p>
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="ghost" onClick={() => setToDelete(null)}>Cancel</Button>
          <Button variant="danger" loading={busy} onClick={remove}>Delete class</Button>
        </div>
      </Modal>
    </div>
  );
}
