import Card from '../components/Card.jsx';

// Each item explains one security measure and WHERE it is implemented.
const MEASURES = [
  ['JWT authentication', 'Logging in returns a signed JSON Web Token. The client sends it in the Authorization header and the authenticate middleware (server/middleware/auth.js) verifies it on every protected route.'],
  ['Password hashing (bcrypt)', 'Passwords are hashed with bcrypt (10 salt rounds) before storage and compared with bcrypt.compare at login. Plain-text passwords are never stored or returned. We use the bcryptjs package, which has the same API as bcrypt.'],
  ['Role-based access control', 'The requireRole("admin") middleware blocks members from admin routes with a 403. On the frontend, ProtectedRoute hides admin pages, but the server is the real gatekeeper.'],
  ['Members only see their own data', 'Member endpoints read the user id from the verified token, never from the request. Cancelling a booking checks the booking belongs to the caller.'],
  ['Server-side input validation', 'The validate middleware checks email format, required fields, password strength (8+ chars, upper, lower, number), phone format, and valid numbers and dates before any code runs.'],
  ['XSS protection', 'React escapes all rendered text by default. In addition, the sanitizeBody middleware strips HTML tags from every incoming string, so <script> input never gets stored. Helmet adds safe HTTP headers.'],
  ['No injection risk, but input is never trusted', 'There is no SQL database, so SQL injection does not apply. The server still validates types and ranges and uses strict id lookups. Request bodies are limited to 10 KB.'],
  ['Token expiry and logout', 'Tokens expire after 2 hours (JWT_EXPIRES_IN). When a token expires the API returns 401 and the app logs the user out. Logout deletes the token from the browser.'],
  ['Access checks on every endpoint', 'Every route except register, login, health and the public plans list requires authenticate. Admin routes also require requireRole("admin").'],
  ['Secrets in environment variables', 'JWT_SECRET, PORT and CLIENT_URL live in server/.env, which is git-ignored. Only .env.example is committed.'],
  ['CORS', 'The API only accepts browser requests from the origin(s) listed in CLIENT_URL.'],
  ['Brute-force protection', 'A small rate limiter on /login and /register returns 429 after too many attempts. Login errors never reveal whether an email exists.'],
  ['HTTPS', 'HTTPS is provided by the hosting platform (Vercel/Netlify/Render/Railway) once the app is deployed. See DEPLOYMENT.md.'],
];

export default function Security() {
  return (
    <main className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="text-5xl font-bold">Security measures</h1>
      <p className="mt-2 text-zinc-400">How this application protects its members and their data.</p>
      <div className="mt-8 grid gap-4">
        {MEASURES.map(([title, text]) => (
          <Card key={title} title={title}><p className="text-sm text-zinc-400">{text}</p></Card>
        ))}
      </div>
    </main>
  );
}
