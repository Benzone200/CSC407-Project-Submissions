import { Routes, Route, Outlet, Link } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import DashboardLayout from './components/DashboardLayout.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import Home from './pages/Home.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Security from './pages/Security.jsx';
import MemberDashboard from './pages/member/MemberDashboard.jsx';
import Profile from './pages/member/Profile.jsx';
import ClassBooking from './pages/member/ClassBooking.jsx';
import PaymentHistory from './pages/member/PaymentHistory.jsx';
import AdminDashboard from './pages/admin/AdminDashboard.jsx';
import ManageMembers from './pages/admin/ManageMembers.jsx';
import ManagePlans from './pages/admin/ManagePlans.jsx';
import ManageClasses from './pages/admin/ManageClasses.jsx';
import ManageBookings from './pages/admin/ManageBookings.jsx';

// Layout for public pages: navbar on top, footer at the bottom
function PublicLayout() {
  return (
    <>
      <Navbar />
      <Outlet />
      <footer className="mt-16 border-t border-zinc-800 py-6 text-center text-sm text-zinc-500">© {new Date().getFullYear()} IronPulse Gym. Student project.</footer>
    </>
  );
}

const NotFound = () => (
  <div className="py-24 text-center">
    <h1 className="text-5xl font-bold">404</h1>
    <p className="mt-2 text-zinc-400">That page doesn't exist.</p>
    <Link to="/" className="mt-4 inline-block text-orange-400 underline">Back home</Link>
  </div>
);

export default function App() {
  return (
    <Routes>
      {/* Public */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/security" element={<Security />} />
        <Route path="*" element={<NotFound />} />
      </Route>

      {/* Member only */}
      <Route path="/member" element={<ProtectedRoute role="member"><DashboardLayout /></ProtectedRoute>}>
        <Route index element={<MemberDashboard />} />
        <Route path="profile" element={<Profile />} />
        <Route path="classes" element={<ClassBooking />} />
        <Route path="payments" element={<PaymentHistory />} />
      </Route>

      {/* Admin only */}
      <Route path="/admin" element={<ProtectedRoute role="admin"><DashboardLayout /></ProtectedRoute>}>
        <Route index element={<AdminDashboard />} />
        <Route path="members" element={<ManageMembers />} />
        <Route path="plans" element={<ManagePlans />} />
        <Route path="classes" element={<ManageClasses />} />
        <Route path="bookings" element={<ManageBookings />} />
      </Route>
    </Routes>
  );
}
