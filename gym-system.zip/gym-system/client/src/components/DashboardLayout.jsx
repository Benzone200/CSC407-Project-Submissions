import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { Logo } from './Navbar.jsx';
import Button from './Button.jsx';

// Role-based sidebar links
const LINKS = {
  member: [
    { to: '/member', label: 'Dashboard', end: true },
    { to: '/member/classes', label: 'Book classes' },
    { to: '/member/payments', label: 'Payment history' },
    { to: '/member/profile', label: 'My profile' },
  ],
  admin: [
    { to: '/admin', label: 'Dashboard', end: true },
    { to: '/admin/members', label: 'Members' },
    { to: '/admin/plans', label: 'Plans' },
    { to: '/admin/classes', label: 'Classes' },
    { to: '/admin/bookings', label: 'Bookings' },
  ],
};

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const linkClass = ({ isActive }) => `block rounded-md px-3 py-2 text-sm ${isActive ? 'bg-orange-500 font-semibold text-zinc-950' : 'text-zinc-300 hover:bg-zinc-800'}`;

  return (
    <div className="min-h-screen md:flex">
      {/* Mobile top bar */}
      <div className="flex items-center justify-between border-b border-zinc-800 px-4 py-3 md:hidden">
        <Logo />
        <button onClick={() => setOpen(!open)} aria-label="Toggle menu" className="text-2xl">{open ? '✕' : '☰'}</button>
      </div>

      <aside className={`${open ? 'block' : 'hidden'} border-r border-zinc-800 bg-zinc-900 p-4 md:flex md:w-60 md:shrink-0 md:flex-col`}>
        <div className="mb-6 hidden md:block"><Logo /></div>
        <p className="mb-4 text-sm text-zinc-400">{user.fullName} <span className="text-zinc-600">({user.role})</span></p>
        <nav className="flex-1 space-y-1" onClick={() => setOpen(false)}>
          {LINKS[user.role].map((l) => <NavLink key={l.to} to={l.to} end={l.end} className={linkClass}>{l.label}</NavLink>)}
        </nav>
        <Button variant="secondary" className="mt-6 w-full" onClick={() => { logout(); navigate('/login'); }}>Log out</Button>
      </aside>

      <main className="flex-1 overflow-x-hidden p-4 md:p-8">
        <Outlet />
      </main>
    </div>
  );
}
