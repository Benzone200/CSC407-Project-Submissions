const styles = {
  error: 'border-red-500/40 bg-red-500/10 text-red-300',
  success: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300',
  info: 'border-sky-500/40 bg-sky-500/10 text-sky-300',
};

// Renders nothing when there is no message
export default function Alert({ type = 'info', children, onClose }) {
  if (!children) return null;
  return (
    <div role="alert" className={`mb-4 flex items-start justify-between gap-3 rounded-md border px-4 py-3 text-sm ${styles[type]}`}>
      <span>{children}</span>
      {onClose && <button onClick={onClose} aria-label="Dismiss" className="text-lg leading-none">×</button>}
    </div>
  );
}
