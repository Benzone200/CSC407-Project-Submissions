const styles = {
  active: 'bg-emerald-500/15 text-emerald-300',
  expired: 'bg-red-500/15 text-red-300',
  inactive: 'bg-zinc-700 text-zinc-300',
};
const labels = { active: 'Active', expired: 'Expired', inactive: 'Inactive' };

export default function StatusBadge({ status }) {
  return <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${styles[status] || styles.inactive}`}>{labels[status] || status}</span>;
}
