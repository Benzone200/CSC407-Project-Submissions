const base = 'w-full rounded-md border bg-zinc-900 px-3 py-2 text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-orange-500';

// Text input with label + inline error message
export default function Input({ label, error, id, className = '', ...props }) {
  const inputId = id || props.name;
  return (
    <div className={className}>
      {label && <label htmlFor={inputId} className="mb-1 block text-sm text-zinc-300">{label}</label>}
      <input id={inputId} className={`${base} ${error ? 'border-red-500' : 'border-zinc-700'}`} aria-invalid={!!error} {...props} />
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </div>
  );
}

// Dropdown with the same look
export function Select({ label, error, id, className = '', children, ...props }) {
  const inputId = id || props.name;
  return (
    <div className={className}>
      {label && <label htmlFor={inputId} className="mb-1 block text-sm text-zinc-300">{label}</label>}
      <select id={inputId} className={`${base} ${error ? 'border-red-500' : 'border-zinc-700'}`} {...props}>{children}</select>
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </div>
  );
}
