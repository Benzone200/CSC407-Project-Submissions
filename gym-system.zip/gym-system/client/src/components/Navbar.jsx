import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Button from './Button.jsx';

export const Logo = () => (
  <Link to="/" className="font-display text-2xl font-extrabold tracking-tight">
    IRON<span className="text-orange-500">PULSE</span>
  </Link>
);

// Top bar for public pages. Collapses into a menu on mobile.
export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const link = ({ isActive }) => `block py-2 text-sm md:py-0 ${isActive ? 'text-orange-400' : 'text-zinc-300 hover:text-white'}`;
  const home = user ? (user.role === 'admin' ? '/admin' : '/member') : null;

  return (
    <header className="sticky top-0 z-40 border-b border-zinc-800 bg-zinc-950/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Logo />
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu" aria-expanded={open}>
          <span className="text-2xl">{open ? '✕' : '☰'}</span>
        </button>
        <nav className={`${open ? 'block' : 'hidden'} absolute left-0 right-0 top-full border-b border-zinc-800 bg-zinc-950 px-4 pb-4 md:static md:flex md:items-center md:gap-6 md:border-0 md:bg-transparent md:p-0`} onClick={() => setOpen(false)}>
          <NavLink to="/" end className={link}>Home</NavLink>
          <NavLink to="/security" className={link}>Security</NavLink>
          {user ? (
            <>
              <NavLink to={home} className={link}>Dashboard</NavLink>
              <Button variant="secondary" onClick={() => { logout(); navigate('/'); }}>Log out</Button>
            </>
          ) : (
            <>
              <NavLink to="/login" className={link}>Log in</NavLink>
              <Button className="mt-2 w-full md:mt-0 md:w-auto" onClick={() => navigate('/register')}>Join now</Button>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
