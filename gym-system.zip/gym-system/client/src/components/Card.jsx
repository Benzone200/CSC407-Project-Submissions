export default function Card({ title, action, className = '', children }) {
  return (
    <section className={`rounded-lg border border-zinc-800 bg-zinc-900 p-5 ${className}`}>
      {(title || action) && (
        <div className="mb-4 flex items-center justify-between gap-3">
          {title && <h2 className="text-xl font-bold">{title}</h2>}
          {action}
        </div>
      )}
      {children}
    </section>
  );
}
