/**
 * columns: [{ header: 'Name', key: 'fullName', render?: (row) => JSX }]
 * Scrolls sideways on small screens so it never breaks the layout.
 */
export default function Table({ columns, rows, empty = 'Nothing to show yet.' }) {
  if (!rows || rows.length === 0) return <p className="py-8 text-center text-sm text-zinc-500">{empty}</p>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[600px] text-left text-sm">
        <thead className="border-b border-zinc-800 text-zinc-400">
          <tr>{columns.map((c) => <th key={c.header} className="px-3 py-2 font-medium">{c.header}</th>)}</tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.id} className="border-b border-zinc-800/60 last:border-0">
              {columns.map((c) => <td key={c.header} className="px-3 py-3 align-middle">{c.render ? c.render(row) : row[c.key]}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
