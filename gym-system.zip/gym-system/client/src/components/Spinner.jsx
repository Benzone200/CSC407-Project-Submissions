export default function Spinner({ label = 'Loading…' }) {
  return (
    <div className="flex items-center justify-center gap-3 py-12 text-zinc-400" role="status">
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-orange-500 border-t-transparent" />
      {label}
    </div>
  );
}
