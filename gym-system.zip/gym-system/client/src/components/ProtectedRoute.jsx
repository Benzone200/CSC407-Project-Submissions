import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Spinner from './Spinner.jsx';

/**
 * Wrap a route:  <ProtectedRoute role="admin"> ... </ProtectedRoute>
 *  - not logged in        -> redirect to /login
 *  - wrong role           -> "Access denied" screen
 * (The server ALSO checks every request - this is only for a nicer UI.)
 */
export default function ProtectedRoute({ role, children }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return <Spinner />;
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;

  if (role && user.role !== role) {
    return (
      <div className="mx-auto mt-24 max-w-md rounded-lg border border-red-500/40 bg-zinc-900 p-8 text-center">
        <h1 className="text-4xl font-bold text-red-400">403</h1>
        <p className="mt-2 text-zinc-300">Access denied. You don't have permission to view this page.</p>
        <a href={user.role === 'admin' ? '/admin' : '/member'} className="mt-5 inline-block text-orange-400 underline">Go to my dashboard</a>
      </div>
    );
  }
  return children;
}
